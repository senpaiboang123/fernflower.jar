/*   1:    */ package org.jetbrains.java.decompiler.struct;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.jar.Manifest;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeSourceMapper;
/*   9:    */ import org.jetbrains.java.decompiler.main.extern.IResultSaver;
/*  10:    */ import org.jetbrains.java.decompiler.struct.lazy.LazyLoader;
/*  11:    */ import org.jetbrains.java.decompiler.struct.lazy.LazyLoader.Link;
/*  12:    */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  13:    */ 
/*  14:    */ public class ContextUnit
/*  15:    */ {
/*  16:    */   public static final int TYPE_FOLDER = 0;
/*  17:    */   public static final int TYPE_JAR = 1;
/*  18:    */   public static final int TYPE_ZIP = 2;
/*  19:    */   private final int type;
/*  20:    */   private final boolean own;
/*  21:    */   private final String archivePath;
/*  22:    */   private final String filename;
/*  23:    */   private final IResultSaver resultSaver;
/*  24:    */   private final IDecompiledData decompiledData;
/*  25: 45 */   private final List<String> classEntries = new ArrayList();
/*  26: 46 */   private final List<String> dirEntries = new ArrayList();
/*  27: 47 */   private final List<String[]> otherEntries = new ArrayList();
/*  28: 49 */   private List<StructClass> classes = new ArrayList();
/*  29:    */   private Manifest manifest;
/*  30:    */   
/*  31:    */   public ContextUnit(int type, String archivePath, String filename, boolean own, IResultSaver resultSaver, IDecompiledData decompiledData)
/*  32:    */   {
/*  33: 53 */     this.type = type;
/*  34: 54 */     this.own = own;
/*  35: 55 */     this.archivePath = archivePath;
/*  36: 56 */     this.filename = filename;
/*  37: 57 */     this.resultSaver = resultSaver;
/*  38: 58 */     this.decompiledData = decompiledData;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void addClass(StructClass cl, String entryName)
/*  42:    */   {
/*  43: 62 */     this.classes.add(cl);
/*  44: 63 */     this.classEntries.add(entryName);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void addDirEntry(String entry)
/*  48:    */   {
/*  49: 67 */     this.dirEntries.add(entry);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void addOtherEntry(String fullPath, String entry)
/*  53:    */   {
/*  54: 71 */     this.otherEntries.add(new String[] { fullPath, entry });
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void reload(LazyLoader loader)
/*  58:    */     throws IOException
/*  59:    */   {
/*  60: 75 */     List<StructClass> lstClasses = new ArrayList();
/*  61: 77 */     for (StructClass cl : this.classes)
/*  62:    */     {
/*  63: 78 */       String oldName = cl.qualifiedName;
/*  64:    */       
/*  65:    */ 
/*  66: 81 */       DataInputFullStream in = loader.getClassStream(oldName);
/*  67:    */       StructClass newCl;
/*  68:    */       try
/*  69:    */       {
/*  70: 83 */         newCl = new StructClass(in, cl.isOwn(), loader);
/*  71:    */       }
/*  72:    */       finally
/*  73:    */       {
/*  74: 86 */         in.close();
/*  75:    */       }
/*  76: 89 */       lstClasses.add(newCl);
/*  77:    */       
/*  78: 91 */       LazyLoader.Link lnk = loader.getClassLink(oldName);
/*  79: 92 */       loader.removeClassLink(oldName);
/*  80: 93 */       loader.addClassLink(newCl.qualifiedName, lnk);
/*  81:    */     }
/*  82: 96 */     this.classes = lstClasses;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void save()
/*  86:    */   {
/*  87:100 */     switch (this.type)
/*  88:    */     {
/*  89:    */     case 0: 
/*  90:103 */       this.resultSaver.saveFolder(this.filename);
/*  91:106 */       for (String[] pair : this.otherEntries) {
/*  92:107 */         this.resultSaver.copyFile(pair[0], this.filename, pair[1]);
/*  93:    */       }
/*  94:111 */       for (int i = 0; i < this.classes.size(); i++)
/*  95:    */       {
/*  96:112 */         StructClass cl = (StructClass)this.classes.get(i);
/*  97:113 */         String entryName = this.decompiledData.getClassEntryName(cl, (String)this.classEntries.get(i));
/*  98:114 */         if (entryName != null)
/*  99:    */         {
/* 100:115 */           String content = this.decompiledData.getClassContent(cl);
/* 101:116 */           if (content != null)
/* 102:    */           {
/* 103:117 */             int[] mapping = null;
/* 104:118 */             if (DecompilerContext.getOption("bsm")) {
/* 105:119 */               mapping = DecompilerContext.getBytecodeSourceMapper().getOriginalLinesMapping();
/* 106:    */             }
/* 107:121 */             this.resultSaver.saveClassFile(this.filename, cl.qualifiedName, entryName, content, mapping);
/* 108:    */           }
/* 109:    */         }
/* 110:    */       }
/* 111:126 */       break;
/* 112:    */     case 1: 
/* 113:    */     case 2: 
/* 114:131 */       this.resultSaver.saveFolder(this.archivePath);
/* 115:132 */       this.resultSaver.createArchive(this.archivePath, this.filename, this.manifest);
/* 116:135 */       for (String dirEntry : this.dirEntries) {
/* 117:136 */         this.resultSaver.saveDirEntry(this.archivePath, this.filename, dirEntry);
/* 118:    */       }
/* 119:140 */       for (String[] pair : this.otherEntries) {
/* 120:141 */         if ((this.type != 1) || (!"META-INF/MANIFEST.MF".equalsIgnoreCase(pair[1]))) {
/* 121:142 */           this.resultSaver.copyEntry(pair[0], this.archivePath, this.filename, pair[1]);
/* 122:    */         }
/* 123:    */       }
/* 124:147 */       for (int i = 0; i < this.classes.size(); i++)
/* 125:    */       {
/* 126:148 */         StructClass cl = (StructClass)this.classes.get(i);
/* 127:149 */         String entryName = this.decompiledData.getClassEntryName(cl, (String)this.classEntries.get(i));
/* 128:150 */         if (entryName != null)
/* 129:    */         {
/* 130:151 */           String content = this.decompiledData.getClassContent(cl);
/* 131:152 */           this.resultSaver.saveClassEntry(this.archivePath, this.filename, cl.qualifiedName, entryName, content);
/* 132:    */         }
/* 133:    */       }
/* 134:156 */       this.resultSaver.closeArchive(this.archivePath, this.filename);
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void setManifest(Manifest manifest)
/* 139:    */   {
/* 140:161 */     this.manifest = manifest;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public boolean isOwn()
/* 144:    */   {
/* 145:165 */     return this.own;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public List<StructClass> getClasses()
/* 149:    */   {
/* 150:169 */     return this.classes;
/* 151:    */   }
/* 152:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.ContextUnit
 * JD-Core Version:    0.7.0.1
 */