/*  1:   */ package org.jetbrains.java.decompiler.struct;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import org.jetbrains.java.decompiler.struct.attr.StructGeneralAttribute;
/*  5:   */ import org.jetbrains.java.decompiler.struct.attr.StructLocalVariableTableAttribute;
/*  6:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  7:   */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  8:   */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  9:   */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/* 10:   */ 
/* 11:   */ public class StructMember
/* 12:   */ {
/* 13:   */   protected int accessFlags;
/* 14:   */   protected VBStyleCollection<StructGeneralAttribute, String> attributes;
/* 15:   */   
/* 16:   */   public int getAccessFlags()
/* 17:   */   {
/* 18:34 */     return this.accessFlags;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public VBStyleCollection<StructGeneralAttribute, String> getAttributes()
/* 22:   */   {
/* 23:38 */     return this.attributes;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public boolean hasModifier(int modifier)
/* 27:   */   {
/* 28:42 */     return (this.accessFlags & modifier) == modifier;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public boolean isSynthetic()
/* 32:   */   {
/* 33:46 */     return (hasModifier(4096)) || (this.attributes.containsKey("Synthetic"));
/* 34:   */   }
/* 35:   */   
/* 36:   */   protected VBStyleCollection<StructGeneralAttribute, String> readAttributes(DataInputFullStream in, ConstantPool pool)
/* 37:   */     throws IOException
/* 38:   */   {
/* 39:50 */     VBStyleCollection<StructGeneralAttribute, String> attributes = new VBStyleCollection();
/* 40:   */     
/* 41:52 */     int length = in.readUnsignedShort();
/* 42:53 */     for (int i = 0; i < length; i++)
/* 43:   */     {
/* 44:54 */       int nameIndex = in.readUnsignedShort();
/* 45:55 */       String name = pool.getPrimitiveConstant(nameIndex).getString();
/* 46:   */       
/* 47:57 */       StructGeneralAttribute attribute = readAttribute(in, pool, name);
/* 48:59 */       if (attribute != null) {
/* 49:60 */         if (("LocalVariableTable".equals(name)) && (attributes.containsKey(name)))
/* 50:   */         {
/* 51:62 */           StructLocalVariableTableAttribute table = (StructLocalVariableTableAttribute)attributes.getWithKey(name);
/* 52:63 */           table.addLocalVariableTable((StructLocalVariableTableAttribute)attribute);
/* 53:   */         }
/* 54:   */         else
/* 55:   */         {
/* 56:66 */           attributes.addWithKey(attribute, attribute.getName());
/* 57:   */         }
/* 58:   */       }
/* 59:   */     }
/* 60:71 */     return attributes;
/* 61:   */   }
/* 62:   */   
/* 63:   */   protected StructGeneralAttribute readAttribute(DataInputFullStream in, ConstantPool pool, String name)
/* 64:   */     throws IOException
/* 65:   */   {
/* 66:75 */     StructGeneralAttribute attribute = StructGeneralAttribute.createAttribute(name);
/* 67:76 */     if (attribute == null)
/* 68:   */     {
/* 69:77 */       in.discard(in.readInt());
/* 70:   */     }
/* 71:   */     else
/* 72:   */     {
/* 73:80 */       byte[] data = new byte[in.readInt()];
/* 74:81 */       in.readFull(data);
/* 75:82 */       attribute.setInfo(data);
/* 76:83 */       attribute.initContent(pool);
/* 77:   */     }
/* 78:85 */     return attribute;
/* 79:   */   }
/* 80:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.StructMember
 * JD-Core Version:    0.7.0.1
 */