package org.jetbrains.java.decompiler.struct;

public abstract interface IDecompiledData
{
  public abstract String getClassEntryName(StructClass paramStructClass, String paramString);
  
  public abstract String getClassContent(StructClass paramStructClass);
}


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.IDecompiledData
 * JD-Core Version:    0.7.0.1
 */