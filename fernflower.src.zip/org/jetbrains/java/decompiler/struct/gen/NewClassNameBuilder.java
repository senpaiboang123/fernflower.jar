package org.jetbrains.java.decompiler.struct.gen;

public abstract interface NewClassNameBuilder
{
  public abstract String buildNewClassname(String paramString);
}


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.NewClassNameBuilder
 * JD-Core Version:    0.7.0.1
 */