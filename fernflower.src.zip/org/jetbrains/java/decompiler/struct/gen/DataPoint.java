/*  1:   */ package org.jetbrains.java.decompiler.struct.gen;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  6:   */ import org.jetbrains.java.decompiler.util.ListStack;
/*  7:   */ 
/*  8:   */ public class DataPoint
/*  9:   */ {
/* 10:27 */   private List<VarType> localVariables = new ArrayList();
/* 11:29 */   private ListStack<VarType> stack = new ListStack();
/* 12:   */   
/* 13:   */   public void setVariable(int index, VarType value)
/* 14:   */   {
/* 15:33 */     if (index >= this.localVariables.size()) {
/* 16:34 */       for (int i = this.localVariables.size(); i <= index; i++) {
/* 17:35 */         this.localVariables.add(new VarType(14));
/* 18:   */       }
/* 19:   */     }
/* 20:39 */     this.localVariables.set(index, value);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public VarType getVariable(int index)
/* 24:   */   {
/* 25:43 */     if (index < this.localVariables.size()) {
/* 26:44 */       return (VarType)this.localVariables.get(index);
/* 27:   */     }
/* 28:46 */     if (index < 0) {
/* 29:47 */       throw new IndexOutOfBoundsException();
/* 30:   */     }
/* 31:50 */     return new VarType(14);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public DataPoint copy()
/* 35:   */   {
/* 36:55 */     DataPoint point = new DataPoint();
/* 37:56 */     point.setLocalVariables(new ArrayList(this.localVariables));
/* 38:57 */     point.setStack(this.stack.clone());
/* 39:58 */     return point;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static DataPoint getInitialDataPoint(StructMethod mt)
/* 43:   */   {
/* 44:63 */     DataPoint point = new DataPoint();
/* 45:   */     
/* 46:65 */     MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/* 47:   */     
/* 48:67 */     int k = 0;
/* 49:68 */     if (!mt.hasModifier(8)) {
/* 50:69 */       point.setVariable(k++, new VarType(8, 0, null));
/* 51:   */     }
/* 52:72 */     for (int i = 0; i < md.params.length; i++)
/* 53:   */     {
/* 54:73 */       VarType var = md.params[i];
/* 55:   */       
/* 56:75 */       point.setVariable(k++, var);
/* 57:76 */       if (var.stackSize == 2) {
/* 58:77 */         point.setVariable(k++, new VarType(12));
/* 59:   */       }
/* 60:   */     }
/* 61:81 */     return point;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public List<VarType> getLocalVariables()
/* 65:   */   {
/* 66:86 */     return this.localVariables;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void setLocalVariables(List<VarType> localVariables)
/* 70:   */   {
/* 71:90 */     this.localVariables = localVariables;
/* 72:   */   }
/* 73:   */   
/* 74:   */   public ListStack<VarType> getStack()
/* 75:   */   {
/* 76:94 */     return this.stack;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void setStack(ListStack<VarType> stack)
/* 80:   */   {
/* 81:98 */     this.stack = stack;
/* 82:   */   }
/* 83:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.DataPoint
 * JD-Core Version:    0.7.0.1
 */