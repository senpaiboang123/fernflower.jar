/*   1:    */ package org.jetbrains.java.decompiler.struct.gen;
/*   2:    */ 
/*   3:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*   4:    */ 
/*   5:    */ public class VarType
/*   6:    */ {
/*   7: 23 */   public static final VarType[] EMPTY_ARRAY = new VarType[0];
/*   8: 25 */   public static final VarType VARTYPE_UNKNOWN = new VarType(17);
/*   9: 26 */   public static final VarType VARTYPE_INT = new VarType(4);
/*  10: 27 */   public static final VarType VARTYPE_FLOAT = new VarType(3);
/*  11: 28 */   public static final VarType VARTYPE_LONG = new VarType(5);
/*  12: 29 */   public static final VarType VARTYPE_DOUBLE = new VarType(2);
/*  13: 30 */   public static final VarType VARTYPE_BYTE = new VarType(0);
/*  14: 31 */   public static final VarType VARTYPE_CHAR = new VarType(1);
/*  15: 32 */   public static final VarType VARTYPE_SHORT = new VarType(6);
/*  16: 33 */   public static final VarType VARTYPE_BOOLEAN = new VarType(7);
/*  17: 34 */   public static final VarType VARTYPE_BYTECHAR = new VarType(15);
/*  18: 35 */   public static final VarType VARTYPE_SHORTCHAR = new VarType(16);
/*  19: 37 */   public static final VarType VARTYPE_NULL = new VarType(13, 0, null);
/*  20: 38 */   public static final VarType VARTYPE_STRING = new VarType(8, 0, "java/lang/String");
/*  21: 39 */   public static final VarType VARTYPE_CLASS = new VarType(8, 0, "java/lang/Class");
/*  22: 40 */   public static final VarType VARTYPE_OBJECT = new VarType(8, 0, "java/lang/Object");
/*  23: 41 */   public static final VarType VARTYPE_VOID = new VarType(10);
/*  24:    */   public final int type;
/*  25:    */   public final int arrayDim;
/*  26:    */   public final String value;
/*  27:    */   public final int typeFamily;
/*  28:    */   public final int stackSize;
/*  29:    */   public final boolean falseBoolean;
/*  30:    */   
/*  31:    */   public VarType(int type)
/*  32:    */   {
/*  33: 51 */     this(type, 0);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public VarType(int type, int arrayDim)
/*  37:    */   {
/*  38: 55 */     this(type, arrayDim, getChar(type));
/*  39:    */   }
/*  40:    */   
/*  41:    */   public VarType(int type, int arrayDim, String value)
/*  42:    */   {
/*  43: 59 */     this(type, arrayDim, value, getFamily(type, arrayDim), getStackSize(type, arrayDim), false);
/*  44:    */   }
/*  45:    */   
/*  46:    */   private VarType(int type, int arrayDim, String value, int typeFamily, int stackSize, boolean falseBoolean)
/*  47:    */   {
/*  48: 63 */     this.type = type;
/*  49: 64 */     this.arrayDim = arrayDim;
/*  50: 65 */     this.value = value;
/*  51: 66 */     this.typeFamily = typeFamily;
/*  52: 67 */     this.stackSize = stackSize;
/*  53: 68 */     this.falseBoolean = falseBoolean;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public VarType(String signature)
/*  57:    */   {
/*  58: 72 */     this(signature, false);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public VarType(String signature, boolean clType)
/*  62:    */   {
/*  63: 76 */     int type = 0;
/*  64: 77 */     int arrayDim = 0;
/*  65: 78 */     String value = null;
/*  66: 81 */     for (int i = 0; i < signature.length(); i++)
/*  67:    */     {
/*  68: 82 */       switch (signature.charAt(i))
/*  69:    */       {
/*  70:    */       case '[': 
/*  71: 84 */         arrayDim++;
/*  72: 85 */         break;
/*  73:    */       case 'L': 
/*  74: 88 */         if (signature.charAt(signature.length() - 1) == ';')
/*  75:    */         {
/*  76: 89 */           type = 8;
/*  77: 90 */           value = signature.substring(i + 1, signature.length() - 1);
/*  78:    */         }
/*  79: 91 */         break;
/*  80:    */       }
/*  81: 95 */       value = signature.substring(i, signature.length());
/*  82: 96 */       if (((clType) && (i == 0)) || (value.length() > 1))
/*  83:    */       {
/*  84: 97 */         type = 8; break;
/*  85:    */       }
/*  86:100 */       type = getType(value.charAt(0));
/*  87:    */       
/*  88:102 */       break;
/*  89:    */     }
/*  90:106 */     this.type = type;
/*  91:107 */     this.arrayDim = arrayDim;
/*  92:108 */     this.value = value;
/*  93:109 */     this.typeFamily = getFamily(type, arrayDim);
/*  94:110 */     this.stackSize = getStackSize(type, arrayDim);
/*  95:111 */     this.falseBoolean = false;
/*  96:    */   }
/*  97:    */   
/*  98:    */   private static String getChar(int type)
/*  99:    */   {
/* 100:115 */     switch (type)
/* 101:    */     {
/* 102:    */     case 0: 
/* 103:117 */       return "B";
/* 104:    */     case 1: 
/* 105:119 */       return "C";
/* 106:    */     case 2: 
/* 107:121 */       return "D";
/* 108:    */     case 3: 
/* 109:123 */       return "F";
/* 110:    */     case 4: 
/* 111:125 */       return "I";
/* 112:    */     case 5: 
/* 113:127 */       return "J";
/* 114:    */     case 6: 
/* 115:129 */       return "S";
/* 116:    */     case 7: 
/* 117:131 */       return "Z";
/* 118:    */     case 10: 
/* 119:133 */       return "V";
/* 120:    */     case 12: 
/* 121:135 */       return "G";
/* 122:    */     case 14: 
/* 123:137 */       return "N";
/* 124:    */     case 9: 
/* 125:139 */       return "A";
/* 126:    */     case 15: 
/* 127:141 */       return "X";
/* 128:    */     case 16: 
/* 129:143 */       return "Y";
/* 130:    */     case 17: 
/* 131:145 */       return "U";
/* 132:    */     case 8: 
/* 133:    */     case 13: 
/* 134:148 */       return null;
/* 135:    */     }
/* 136:150 */     throw new RuntimeException("Invalid type");
/* 137:    */   }
/* 138:    */   
/* 139:    */   private static int getStackSize(int type, int arrayDim)
/* 140:    */   {
/* 141:155 */     if (arrayDim > 0) {
/* 142:156 */       return 1;
/* 143:    */     }
/* 144:159 */     switch (type)
/* 145:    */     {
/* 146:    */     case 2: 
/* 147:    */     case 5: 
/* 148:162 */       return 2;
/* 149:    */     case 10: 
/* 150:    */     case 12: 
/* 151:165 */       return 0;
/* 152:    */     }
/* 153:167 */     return 1;
/* 154:    */   }
/* 155:    */   
/* 156:    */   private static int getFamily(int type, int arrayDim)
/* 157:    */   {
/* 158:172 */     if (arrayDim > 0) {
/* 159:173 */       return 6;
/* 160:    */     }
/* 161:176 */     switch (type)
/* 162:    */     {
/* 163:    */     case 0: 
/* 164:    */     case 1: 
/* 165:    */     case 4: 
/* 166:    */     case 6: 
/* 167:    */     case 15: 
/* 168:    */     case 16: 
/* 169:183 */       return 2;
/* 170:    */     case 2: 
/* 171:185 */       return 5;
/* 172:    */     case 3: 
/* 173:187 */       return 3;
/* 174:    */     case 5: 
/* 175:189 */       return 4;
/* 176:    */     case 7: 
/* 177:191 */       return 1;
/* 178:    */     case 8: 
/* 179:    */     case 13: 
/* 180:194 */       return 6;
/* 181:    */     }
/* 182:196 */     return 0;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public VarType decreaseArrayDim()
/* 186:    */   {
/* 187:201 */     if (this.arrayDim > 0) {
/* 188:202 */       return new VarType(this.type, this.arrayDim - 1, this.value);
/* 189:    */     }
/* 190:206 */     return this;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public VarType resizeArrayDim(int newArrayDim)
/* 194:    */   {
/* 195:211 */     return new VarType(this.type, newArrayDim, this.value, this.typeFamily, this.stackSize, this.falseBoolean);
/* 196:    */   }
/* 197:    */   
/* 198:    */   public VarType copy()
/* 199:    */   {
/* 200:215 */     return copy(false);
/* 201:    */   }
/* 202:    */   
/* 203:    */   public VarType copy(boolean forceFalseBoolean)
/* 204:    */   {
/* 205:219 */     return new VarType(this.type, this.arrayDim, this.value, this.typeFamily, this.stackSize, (this.falseBoolean) || (forceFalseBoolean));
/* 206:    */   }
/* 207:    */   
/* 208:    */   public boolean isFalseBoolean()
/* 209:    */   {
/* 210:223 */     return this.falseBoolean;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public boolean isSuperset(VarType val)
/* 214:    */   {
/* 215:227 */     return (equals(val)) || (isStrictSuperset(val));
/* 216:    */   }
/* 217:    */   
/* 218:    */   public boolean isStrictSuperset(VarType val)
/* 219:    */   {
/* 220:231 */     int valType = val.type;
/* 221:233 */     if ((valType == 17) && (this.type != 17)) {
/* 222:234 */       return true;
/* 223:    */     }
/* 224:237 */     if (val.arrayDim > 0) {
/* 225:238 */       return equals(VARTYPE_OBJECT);
/* 226:    */     }
/* 227:240 */     if (this.arrayDim > 0) {
/* 228:241 */       return valType == 13;
/* 229:    */     }
/* 230:244 */     boolean res = false;
/* 231:246 */     switch (this.type)
/* 232:    */     {
/* 233:    */     case 4: 
/* 234:248 */       res = (valType == 6) || (valType == 1);
/* 235:    */     case 6: 
/* 236:250 */       res |= valType == 0;
/* 237:    */     case 1: 
/* 238:252 */       res |= valType == 16;
/* 239:    */     case 0: 
/* 240:    */     case 16: 
/* 241:255 */       res |= valType == 15;
/* 242:    */     case 15: 
/* 243:257 */       res |= valType == 7;
/* 244:258 */       break;
/* 245:    */     case 8: 
/* 246:261 */       if (valType == 13) {
/* 247:262 */         return true;
/* 248:    */       }
/* 249:264 */       if (equals(VARTYPE_OBJECT)) {
/* 250:265 */         return (valType == 8) && (!val.equals(VARTYPE_OBJECT));
/* 251:    */       }
/* 252:    */       break;
/* 253:    */     }
/* 254:269 */     return res;
/* 255:    */   }
/* 256:    */   
/* 257:    */   public boolean equals(Object o)
/* 258:    */   {
/* 259:274 */     if (o == this) {
/* 260:275 */       return true;
/* 261:    */     }
/* 262:278 */     if ((o == null) || (!(o instanceof VarType))) {
/* 263:279 */       return false;
/* 264:    */     }
/* 265:282 */     VarType vt = (VarType)o;
/* 266:283 */     return (this.type == vt.type) && (this.arrayDim == vt.arrayDim) && (InterpreterUtil.equalObjects(this.value, vt.value));
/* 267:    */   }
/* 268:    */   
/* 269:    */   public String toString()
/* 270:    */   {
/* 271:288 */     StringBuilder res = new StringBuilder();
/* 272:289 */     for (int i = 0; i < this.arrayDim; i++) {
/* 273:290 */       res.append('[');
/* 274:    */     }
/* 275:292 */     if (this.type == 8) {
/* 276:293 */       res.append('L').append(this.value).append(';');
/* 277:    */     } else {
/* 278:296 */       res.append(this.value);
/* 279:    */     }
/* 280:298 */     return res.toString();
/* 281:    */   }
/* 282:    */   
/* 283:    */   public static VarType getCommonMinType(VarType type1, VarType type2)
/* 284:    */   {
/* 285:303 */     if ((type1.type == 7) && (type2.type == 7)) {
/* 286:304 */       return type1.isFalseBoolean() ? type2 : type1;
/* 287:    */     }
/* 288:307 */     if (type1.isSuperset(type2)) {
/* 289:308 */       return type2;
/* 290:    */     }
/* 291:310 */     if (type2.isSuperset(type1)) {
/* 292:311 */       return type1;
/* 293:    */     }
/* 294:313 */     if (type1.typeFamily == type2.typeFamily) {
/* 295:314 */       switch (type1.typeFamily)
/* 296:    */       {
/* 297:    */       case 2: 
/* 298:316 */         if (((type1.type == 1) && (type2.type == 6)) || ((type1.type == 6) && (type2.type == 1))) {
/* 299:318 */           return VARTYPE_SHORTCHAR;
/* 300:    */         }
/* 301:321 */         return VARTYPE_BYTECHAR;
/* 302:    */       case 6: 
/* 303:324 */         return VARTYPE_NULL;
/* 304:    */       }
/* 305:    */     }
/* 306:328 */     return null;
/* 307:    */   }
/* 308:    */   
/* 309:    */   public static VarType getCommonSupertype(VarType type1, VarType type2)
/* 310:    */   {
/* 311:333 */     if ((type1.type == 7) && (type2.type == 7)) {
/* 312:334 */       return type1.isFalseBoolean() ? type1 : type2;
/* 313:    */     }
/* 314:337 */     if (type1.isSuperset(type2)) {
/* 315:338 */       return type1;
/* 316:    */     }
/* 317:340 */     if (type2.isSuperset(type1)) {
/* 318:341 */       return type2;
/* 319:    */     }
/* 320:343 */     if (type1.typeFamily == type2.typeFamily) {
/* 321:344 */       switch (type1.typeFamily)
/* 322:    */       {
/* 323:    */       case 2: 
/* 324:346 */         if (((type1.type == 16) && (type2.type == 0)) || ((type1.type == 0) && (type2.type == 16))) {
/* 325:348 */           return VARTYPE_SHORT;
/* 326:    */         }
/* 327:351 */         return VARTYPE_INT;
/* 328:    */       case 6: 
/* 329:354 */         return VARTYPE_OBJECT;
/* 330:    */       }
/* 331:    */     }
/* 332:358 */     return null;
/* 333:    */   }
/* 334:    */   
/* 335:    */   public static VarType getMinTypeInFamily(int family)
/* 336:    */   {
/* 337:362 */     switch (family)
/* 338:    */     {
/* 339:    */     case 1: 
/* 340:364 */       return VARTYPE_BOOLEAN;
/* 341:    */     case 2: 
/* 342:366 */       return VARTYPE_BYTECHAR;
/* 343:    */     case 6: 
/* 344:368 */       return VARTYPE_NULL;
/* 345:    */     case 3: 
/* 346:370 */       return VARTYPE_FLOAT;
/* 347:    */     case 4: 
/* 348:372 */       return VARTYPE_LONG;
/* 349:    */     case 5: 
/* 350:374 */       return VARTYPE_DOUBLE;
/* 351:    */     case 0: 
/* 352:376 */       return VARTYPE_UNKNOWN;
/* 353:    */     }
/* 354:378 */     throw new IllegalArgumentException("Invalid type family: " + family);
/* 355:    */   }
/* 356:    */   
/* 357:    */   public static int getType(char c)
/* 358:    */   {
/* 359:383 */     switch (c)
/* 360:    */     {
/* 361:    */     case 'B': 
/* 362:385 */       return 0;
/* 363:    */     case 'C': 
/* 364:387 */       return 1;
/* 365:    */     case 'D': 
/* 366:389 */       return 2;
/* 367:    */     case 'F': 
/* 368:391 */       return 3;
/* 369:    */     case 'I': 
/* 370:393 */       return 4;
/* 371:    */     case 'J': 
/* 372:395 */       return 5;
/* 373:    */     case 'S': 
/* 374:397 */       return 6;
/* 375:    */     case 'Z': 
/* 376:399 */       return 7;
/* 377:    */     case 'V': 
/* 378:401 */       return 10;
/* 379:    */     case 'G': 
/* 380:403 */       return 12;
/* 381:    */     case 'N': 
/* 382:405 */       return 14;
/* 383:    */     case 'A': 
/* 384:407 */       return 9;
/* 385:    */     case 'X': 
/* 386:409 */       return 15;
/* 387:    */     case 'Y': 
/* 388:411 */       return 16;
/* 389:    */     case 'U': 
/* 390:413 */       return 17;
/* 391:    */     }
/* 392:415 */     throw new IllegalArgumentException("Invalid type: " + c);
/* 393:    */   }
/* 394:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.VarType
 * JD-Core Version:    0.7.0.1
 */