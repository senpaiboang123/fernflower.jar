/*  1:   */ package org.jetbrains.java.decompiler.struct.gen;
/*  2:   */ 
/*  3:   */ public class FieldDescriptor
/*  4:   */ {
/*  5:22 */   public static final FieldDescriptor INTEGER_DESCRIPTOR = parseDescriptor("Ljava/lang/Integer;");
/*  6:23 */   public static final FieldDescriptor LONG_DESCRIPTOR = parseDescriptor("Ljava/lang/Long;");
/*  7:24 */   public static final FieldDescriptor FLOAT_DESCRIPTOR = parseDescriptor("Ljava/lang/Float;");
/*  8:25 */   public static final FieldDescriptor DOUBLE_DESCRIPTOR = parseDescriptor("Ljava/lang/Double;");
/*  9:   */   public final VarType type;
/* 10:   */   public final String descriptorString;
/* 11:   */   
/* 12:   */   private FieldDescriptor(String descriptor)
/* 13:   */   {
/* 14:31 */     this.type = new VarType(descriptor);
/* 15:32 */     this.descriptorString = descriptor;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static FieldDescriptor parseDescriptor(String descriptor)
/* 19:   */   {
/* 20:36 */     return new FieldDescriptor(descriptor);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String buildNewDescriptor(NewClassNameBuilder builder)
/* 24:   */   {
/* 25:40 */     if (this.type.type == 8)
/* 26:   */     {
/* 27:41 */       String newClassName = builder.buildNewClassname(this.type.value);
/* 28:42 */       if (newClassName != null) {
/* 29:43 */         return new VarType(this.type.type, this.type.arrayDim, newClassName).toString();
/* 30:   */       }
/* 31:   */     }
/* 32:47 */     return null;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public boolean equals(Object o)
/* 36:   */   {
/* 37:52 */     if (o == this) {
/* 38:52 */       return true;
/* 39:   */     }
/* 40:53 */     if ((o == null) || (!(o instanceof FieldDescriptor))) {
/* 41:53 */       return false;
/* 42:   */     }
/* 43:55 */     FieldDescriptor fd = (FieldDescriptor)o;
/* 44:56 */     return this.type.equals(fd.type);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public int hashCode()
/* 48:   */   {
/* 49:61 */     return this.type.hashCode();
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.FieldDescriptor
 * JD-Core Version:    0.7.0.1
 */