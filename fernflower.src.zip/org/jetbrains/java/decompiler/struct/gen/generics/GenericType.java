/*   1:    */ package org.jetbrains.java.decompiler.struct.gen.generics;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*   6:    */ 
/*   7:    */ public class GenericType
/*   8:    */ {
/*   9:    */   public static final int WILDCARD_EXTENDS = 1;
/*  10:    */   public static final int WILDCARD_SUPER = 2;
/*  11:    */   public static final int WILDCARD_UNBOUND = 3;
/*  12:    */   public static final int WILDCARD_NO = 4;
/*  13:    */   public final int type;
/*  14:    */   public final int arrayDim;
/*  15:    */   public final String value;
/*  16: 35 */   private final List<GenericType> enclosingClasses = new ArrayList();
/*  17: 36 */   private final List<GenericType> arguments = new ArrayList();
/*  18: 37 */   private final List<Integer> wildcards = new ArrayList();
/*  19:    */   
/*  20:    */   public GenericType(int type, int arrayDim, String value)
/*  21:    */   {
/*  22: 40 */     this.type = type;
/*  23: 41 */     this.arrayDim = arrayDim;
/*  24: 42 */     this.value = value;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public GenericType(String signature)
/*  28:    */   {
/*  29: 46 */     int type = 0;
/*  30: 47 */     int arrayDim = 0;
/*  31: 48 */     String value = null;
/*  32:    */     
/*  33: 50 */     int index = 0;
/*  34: 52 */     while (index < signature.length())
/*  35:    */     {
/*  36: 53 */       switch (signature.charAt(index))
/*  37:    */       {
/*  38:    */       case '[': 
/*  39: 55 */         arrayDim++;
/*  40: 56 */         break;
/*  41:    */       case 'T': 
/*  42: 59 */         type = 18;
/*  43: 60 */         value = signature.substring(index + 1, signature.length() - 1);
/*  44: 61 */         break;
/*  45:    */       case 'L': 
/*  46: 64 */         type = 8;
/*  47: 65 */         signature = signature.substring(index + 1, signature.length() - 1);
/*  48:    */         for (;;)
/*  49:    */         {
/*  50: 68 */           String cl = getNextClassSignature(signature);
/*  51:    */           
/*  52: 70 */           String name = cl;
/*  53: 71 */           String args = null;
/*  54:    */           
/*  55: 73 */           int argStart = cl.indexOf("<");
/*  56: 74 */           if (argStart >= 0)
/*  57:    */           {
/*  58: 75 */             name = cl.substring(0, argStart);
/*  59: 76 */             args = cl.substring(argStart + 1, cl.length() - 1);
/*  60:    */           }
/*  61: 79 */           if (cl.length() < signature.length())
/*  62:    */           {
/*  63: 80 */             signature = signature.substring(cl.length() + 1);
/*  64: 81 */             GenericType type11 = new GenericType(8, 0, name);
/*  65: 82 */             parseArgumentsList(args, type11);
/*  66: 83 */             this.enclosingClasses.add(type11);
/*  67:    */           }
/*  68:    */           else
/*  69:    */           {
/*  70: 86 */             value = name;
/*  71: 87 */             parseArgumentsList(args, this);
/*  72: 88 */             break;
/*  73:    */           }
/*  74:    */         }
/*  75:    */       default: 
/*  76: 95 */         value = signature.substring(index, index + 1);
/*  77: 96 */         type = VarType.getType(value.charAt(0));
/*  78:    */       }
/*  79: 99 */       index++;
/*  80:    */     }
/*  81:102 */     this.type = type;
/*  82:103 */     this.arrayDim = arrayDim;
/*  83:104 */     this.value = value;
/*  84:    */   }
/*  85:    */   
/*  86:    */   private static String getNextClassSignature(String value)
/*  87:    */   {
/*  88:108 */     int counter = 0;
/*  89:109 */     int index = 0;
/*  90:112 */     while (index < value.length())
/*  91:    */     {
/*  92:113 */       switch (value.charAt(index))
/*  93:    */       {
/*  94:    */       case '<': 
/*  95:115 */         counter++;
/*  96:116 */         break;
/*  97:    */       case '>': 
/*  98:118 */         counter--;
/*  99:119 */         break;
/* 100:    */       case '.': 
/* 101:121 */         if (counter == 0) {
/* 102:    */           break label77;
/* 103:    */         }
/* 104:    */       }
/* 105:126 */       index++;
/* 106:    */     }
/* 107:    */     label77:
/* 108:129 */     return value.substring(0, index);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private static void parseArgumentsList(String value, GenericType type)
/* 112:    */   {
/* 113:133 */     if (value == null) {
/* 114:134 */       return;
/* 115:    */     }
/* 116:137 */     while (value.length() > 0)
/* 117:    */     {
/* 118:138 */       String typeStr = getNextType(value);
/* 119:139 */       int len = typeStr.length();
/* 120:140 */       int wildcard = 4;
/* 121:142 */       switch (typeStr.charAt(0))
/* 122:    */       {
/* 123:    */       case '*': 
/* 124:144 */         wildcard = 3;
/* 125:145 */         break;
/* 126:    */       case '+': 
/* 127:147 */         wildcard = 1;
/* 128:148 */         break;
/* 129:    */       case '-': 
/* 130:150 */         wildcard = 2;
/* 131:    */       }
/* 132:154 */       type.getWildcards().add(Integer.valueOf(wildcard));
/* 133:156 */       if (wildcard != 4) {
/* 134:157 */         typeStr = typeStr.substring(1);
/* 135:    */       }
/* 136:160 */       type.getArguments().add(typeStr.length() == 0 ? null : new GenericType(typeStr));
/* 137:    */       
/* 138:162 */       value = value.substring(len);
/* 139:    */     }
/* 140:    */   }
/* 141:    */   
/* 142:    */   public static String getNextType(String value)
/* 143:    */   {
/* 144:167 */     int counter = 0;
/* 145:168 */     int index = 0;
/* 146:    */     
/* 147:170 */     boolean contMode = false;
/* 148:173 */     while (index < value.length())
/* 149:    */     {
/* 150:174 */       switch (value.charAt(index))
/* 151:    */       {
/* 152:    */       case '*': 
/* 153:176 */         if (contMode) {
/* 154:    */           break;
/* 155:    */         }
/* 156:177 */         break;
/* 157:    */       case 'L': 
/* 158:    */       case 'T': 
/* 159:182 */         if (!contMode) {
/* 160:183 */           contMode = true;
/* 161:    */         }
/* 162:    */       case '+': 
/* 163:    */       case '-': 
/* 164:    */       case '[': 
/* 165:    */         break;
/* 166:    */       default: 
/* 167:190 */         if (contMode) {
/* 168:    */           break;
/* 169:    */         }
/* 170:191 */         break;
/* 171:    */       case '<': 
/* 172:195 */         counter++;
/* 173:196 */         break;
/* 174:    */       case '>': 
/* 175:198 */         counter--;
/* 176:199 */         break;
/* 177:    */       }
/* 178:201 */       if (counter == 0) {
/* 179:    */         break;
/* 180:    */       }
/* 181:206 */       index++;
/* 182:    */     }
/* 183:209 */     return value.substring(0, index + 1);
/* 184:    */   }
/* 185:    */   
/* 186:    */   public GenericType decreaseArrayDim()
/* 187:    */   {
/* 188:213 */     assert (this.arrayDim > 0) : this;
/* 189:214 */     return new GenericType(this.type, this.arrayDim - 1, this.value);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public List<GenericType> getArguments()
/* 193:    */   {
/* 194:218 */     return this.arguments;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public List<GenericType> getEnclosingClasses()
/* 198:    */   {
/* 199:222 */     return this.enclosingClasses;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public List<Integer> getWildcards()
/* 203:    */   {
/* 204:226 */     return this.wildcards;
/* 205:    */   }
/* 206:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.generics.GenericType
 * JD-Core Version:    0.7.0.1
 */