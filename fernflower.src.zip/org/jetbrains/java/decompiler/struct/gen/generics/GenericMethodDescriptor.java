/*  1:   */ package org.jetbrains.java.decompiler.struct.gen.generics;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class GenericMethodDescriptor
/*  7:   */ {
/*  8:23 */   public final List<String> fparameters = new ArrayList();
/*  9:25 */   public final List<List<GenericType>> fbounds = new ArrayList();
/* 10:27 */   public final List<GenericType> params = new ArrayList();
/* 11:   */   public GenericType ret;
/* 12:31 */   public final List<GenericType> exceptions = new ArrayList();
/* 13:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.generics.GenericMethodDescriptor
 * JD-Core Version:    0.7.0.1
 */