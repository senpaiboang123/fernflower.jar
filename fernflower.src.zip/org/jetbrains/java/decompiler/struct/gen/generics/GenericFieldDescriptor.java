package org.jetbrains.java.decompiler.struct.gen.generics;

public class GenericFieldDescriptor
{
  public GenericType type;
}


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.generics.GenericFieldDescriptor
 * JD-Core Version:    0.7.0.1
 */