/*   1:    */ package org.jetbrains.java.decompiler.struct.gen.generics;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   6:    */ import org.jetbrains.java.decompiler.main.collectors.ImportCollector;
/*   7:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*   8:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*   9:    */ 
/*  10:    */ public class GenericMain
/*  11:    */ {
/*  12: 27 */   private static final String[] typeNames = { "byte", "char", "double", "float", "int", "long", "short", "boolean" };
/*  13:    */   
/*  14:    */   public static GenericClassDescriptor parseClassSignature(String signature)
/*  15:    */   {
/*  16: 39 */     String original = signature;
/*  17:    */     try
/*  18:    */     {
/*  19: 41 */       GenericClassDescriptor descriptor = new GenericClassDescriptor();
/*  20:    */       
/*  21: 43 */       signature = parseFormalParameters(signature, descriptor.fparameters, descriptor.fbounds);
/*  22:    */       
/*  23: 45 */       String superCl = GenericType.getNextType(signature);
/*  24: 46 */       descriptor.superclass = new GenericType(superCl);
/*  25:    */       
/*  26: 48 */       signature = signature.substring(superCl.length());
/*  27: 49 */       while (signature.length() > 0)
/*  28:    */       {
/*  29: 50 */         String superIf = GenericType.getNextType(signature);
/*  30: 51 */         descriptor.superinterfaces.add(new GenericType(superIf));
/*  31: 52 */         signature = signature.substring(superIf.length());
/*  32:    */       }
/*  33: 55 */       return descriptor;
/*  34:    */     }
/*  35:    */     catch (RuntimeException e)
/*  36:    */     {
/*  37: 58 */       DecompilerContext.getLogger().writeMessage("Invalid signature: " + original, IFernflowerLogger.Severity.WARN);
/*  38:    */     }
/*  39: 59 */     return null;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static GenericFieldDescriptor parseFieldSignature(String signature)
/*  43:    */   {
/*  44:    */     try
/*  45:    */     {
/*  46: 65 */       GenericFieldDescriptor descriptor = new GenericFieldDescriptor();
/*  47: 66 */       descriptor.type = new GenericType(signature);
/*  48: 67 */       return descriptor;
/*  49:    */     }
/*  50:    */     catch (RuntimeException e)
/*  51:    */     {
/*  52: 70 */       DecompilerContext.getLogger().writeMessage("Invalid signature: " + signature, IFernflowerLogger.Severity.WARN);
/*  53:    */     }
/*  54: 71 */     return null;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static GenericMethodDescriptor parseMethodSignature(String signature)
/*  58:    */   {
/*  59: 76 */     String original = signature;
/*  60:    */     try
/*  61:    */     {
/*  62: 78 */       GenericMethodDescriptor descriptor = new GenericMethodDescriptor();
/*  63:    */       
/*  64: 80 */       signature = parseFormalParameters(signature, descriptor.fparameters, descriptor.fbounds);
/*  65:    */       
/*  66: 82 */       int to = signature.indexOf(")");
/*  67: 83 */       String pars = signature.substring(1, to);
/*  68: 84 */       signature = signature.substring(to + 1);
/*  69: 86 */       while (pars.length() > 0)
/*  70:    */       {
/*  71: 87 */         String par = GenericType.getNextType(pars);
/*  72: 88 */         descriptor.params.add(new GenericType(par));
/*  73: 89 */         pars = pars.substring(par.length());
/*  74:    */       }
/*  75: 92 */       String par = GenericType.getNextType(signature);
/*  76: 93 */       descriptor.ret = new GenericType(par);
/*  77: 94 */       signature = signature.substring(par.length());
/*  78: 96 */       if (signature.length() > 0)
/*  79:    */       {
/*  80: 97 */         String[] exceptions = signature.split("\\^");
/*  81: 99 */         for (int i = 1; i < exceptions.length; i++) {
/*  82:100 */           descriptor.exceptions.add(new GenericType(exceptions[i]));
/*  83:    */         }
/*  84:    */       }
/*  85:104 */       return descriptor;
/*  86:    */     }
/*  87:    */     catch (RuntimeException e)
/*  88:    */     {
/*  89:107 */       DecompilerContext.getLogger().writeMessage("Invalid signature: " + original, IFernflowerLogger.Severity.WARN);
/*  90:    */     }
/*  91:108 */     return null;
/*  92:    */   }
/*  93:    */   
/*  94:    */   private static String parseFormalParameters(String signature, List<String> parameters, List<List<GenericType>> bounds)
/*  95:    */   {
/*  96:113 */     if (signature.charAt(0) != '<') {
/*  97:114 */       return signature;
/*  98:    */     }
/*  99:117 */     int counter = 1;
/* 100:118 */     int index = 1;
/* 101:121 */     while (index < signature.length())
/* 102:    */     {
/* 103:122 */       switch (signature.charAt(index))
/* 104:    */       {
/* 105:    */       case '<': 
/* 106:124 */         counter++;
/* 107:125 */         break;
/* 108:    */       case '>': 
/* 109:127 */         counter--;
/* 110:128 */         if (counter == 0) {
/* 111:    */           break label82;
/* 112:    */         }
/* 113:    */       }
/* 114:133 */       index++;
/* 115:    */     }
/* 116:    */     label82:
/* 117:136 */     String value = signature.substring(1, index);
/* 118:137 */     signature = signature.substring(index + 1);
/* 119:139 */     while (value.length() > 0)
/* 120:    */     {
/* 121:140 */       int to = value.indexOf(":");
/* 122:    */       
/* 123:142 */       String param = value.substring(0, to);
/* 124:143 */       value = value.substring(to + 1);
/* 125:    */       
/* 126:145 */       List<GenericType> lstBounds = new ArrayList();
/* 127:    */       for (;;)
/* 128:    */       {
/* 129:148 */         if (value.charAt(0) == ':') {
/* 130:150 */           value = value.substring(1);
/* 131:    */         }
/* 132:153 */         String bound = GenericType.getNextType(value);
/* 133:154 */         lstBounds.add(new GenericType(bound));
/* 134:155 */         value = value.substring(bound.length());
/* 135:158 */         if ((value.length() == 0) || (value.charAt(0) != ':')) {
/* 136:    */           break;
/* 137:    */         }
/* 138:162 */         value = value.substring(1);
/* 139:    */       }
/* 140:166 */       parameters.add(param);
/* 141:167 */       bounds.add(lstBounds);
/* 142:    */     }
/* 143:170 */     return signature;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public static String getGenericCastTypeName(GenericType type)
/* 147:    */   {
/* 148:174 */     String s = getTypeName(type);
/* 149:175 */     int dim = type.arrayDim;
/* 150:176 */     while (dim-- > 0) {
/* 151:177 */       s = s + "[]";
/* 152:    */     }
/* 153:179 */     return s;
/* 154:    */   }
/* 155:    */   
/* 156:    */   private static String getTypeName(GenericType type)
/* 157:    */   {
/* 158:183 */     int tp = type.type;
/* 159:184 */     if (tp <= 7) {
/* 160:185 */       return typeNames[tp];
/* 161:    */     }
/* 162:187 */     if (tp == 10) {
/* 163:188 */       return "void";
/* 164:    */     }
/* 165:190 */     if (tp == 18) {
/* 166:191 */       return type.value;
/* 167:    */     }
/* 168:193 */     if (tp == 8)
/* 169:    */     {
/* 170:194 */       StringBuilder buffer = new StringBuilder();
/* 171:195 */       appendClassName(type, buffer);
/* 172:196 */       return buffer.toString();
/* 173:    */     }
/* 174:199 */     throw new RuntimeException("Invalid type: " + type);
/* 175:    */   }
/* 176:    */   
/* 177:    */   private static void appendClassName(GenericType type, StringBuilder buffer)
/* 178:    */   {
/* 179:203 */     List<GenericType> enclosingClasses = type.getEnclosingClasses();
/* 180:205 */     if (enclosingClasses.isEmpty())
/* 181:    */     {
/* 182:206 */       String name = type.value.replace('/', '.');
/* 183:207 */       buffer.append(DecompilerContext.getImportCollector().getShortName(name));
/* 184:    */     }
/* 185:    */     else
/* 186:    */     {
/* 187:210 */       for (GenericType tp : enclosingClasses)
/* 188:    */       {
/* 189:211 */         if (buffer.length() == 0) {
/* 190:212 */           buffer.append(DecompilerContext.getImportCollector().getShortName(tp.value));
/* 191:    */         } else {
/* 192:215 */           buffer.append(tp.value);
/* 193:    */         }
/* 194:218 */         appendTypeArguments(tp, buffer);
/* 195:219 */         buffer.append('.');
/* 196:    */       }
/* 197:222 */       buffer.append(type.value);
/* 198:    */     }
/* 199:225 */     appendTypeArguments(type, buffer);
/* 200:    */   }
/* 201:    */   
/* 202:    */   private static void appendTypeArguments(GenericType type, StringBuilder buffer)
/* 203:    */   {
/* 204:229 */     if (!type.getArguments().isEmpty())
/* 205:    */     {
/* 206:230 */       buffer.append('<');
/* 207:232 */       for (int i = 0; i < type.getArguments().size(); i++)
/* 208:    */       {
/* 209:233 */         if (i > 0) {
/* 210:234 */           buffer.append(", ");
/* 211:    */         }
/* 212:237 */         int wildcard = ((Integer)type.getWildcards().get(i)).intValue();
/* 213:238 */         switch (wildcard)
/* 214:    */         {
/* 215:    */         case 3: 
/* 216:240 */           buffer.append('?');
/* 217:241 */           break;
/* 218:    */         case 1: 
/* 219:243 */           buffer.append("? extends ");
/* 220:244 */           break;
/* 221:    */         case 2: 
/* 222:246 */           buffer.append("? super ");
/* 223:    */         }
/* 224:250 */         GenericType genPar = (GenericType)type.getArguments().get(i);
/* 225:251 */         if (genPar != null) {
/* 226:252 */           buffer.append(getGenericCastTypeName(genPar));
/* 227:    */         }
/* 228:    */       }
/* 229:256 */       buffer.append(">");
/* 230:    */     }
/* 231:    */   }
/* 232:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.generics.GenericMain
 * JD-Core Version:    0.7.0.1
 */