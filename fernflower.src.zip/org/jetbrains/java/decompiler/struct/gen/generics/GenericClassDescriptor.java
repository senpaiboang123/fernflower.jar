/*  1:   */ package org.jetbrains.java.decompiler.struct.gen.generics;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class GenericClassDescriptor
/*  7:   */ {
/*  8:   */   public GenericType superclass;
/*  9:25 */   public final List<GenericType> superinterfaces = new ArrayList();
/* 10:27 */   public final List<String> fparameters = new ArrayList();
/* 11:29 */   public final List<List<GenericType>> fbounds = new ArrayList();
/* 12:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.generics.GenericClassDescriptor
 * JD-Core Version:    0.7.0.1
 */