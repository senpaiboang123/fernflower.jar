/*   1:    */ package org.jetbrains.java.decompiler.struct.gen;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.List;
/*   6:    */ 
/*   7:    */ public class MethodDescriptor
/*   8:    */ {
/*   9:    */   public final VarType[] params;
/*  10:    */   public final VarType ret;
/*  11:    */   
/*  12:    */   private MethodDescriptor(VarType[] params, VarType ret)
/*  13:    */   {
/*  14: 30 */     this.params = params;
/*  15: 31 */     this.ret = ret;
/*  16:    */   }
/*  17:    */   
/*  18:    */   public static MethodDescriptor parseDescriptor(String descriptor)
/*  19:    */   {
/*  20: 35 */     int parenth = descriptor.lastIndexOf(')');
/*  21: 36 */     if ((descriptor.length() < 2) || (parenth < 0) || (descriptor.charAt(0) != '(')) {
/*  22: 37 */       throw new IllegalArgumentException("Invalid descriptor: " + descriptor);
/*  23:    */     }
/*  24:    */     VarType[] params;
/*  25: 42 */     if (parenth > 1)
/*  26:    */     {
/*  27: 43 */       String parameters = descriptor.substring(1, parenth);
/*  28: 44 */       List<String> lst = new ArrayList();
/*  29:    */       
/*  30: 46 */       int indexFrom = -1;int len = parameters.length();int index = 0;
/*  31: 47 */       while (index < len)
/*  32:    */       {
/*  33: 48 */         switch (parameters.charAt(index))
/*  34:    */         {
/*  35:    */         case '[': 
/*  36: 50 */           if (indexFrom < 0) {
/*  37: 51 */             indexFrom = index;
/*  38:    */           }
/*  39:    */           break;
/*  40:    */         case 'L': 
/*  41: 55 */           int ind = parameters.indexOf(";", index);
/*  42: 56 */           lst.add(parameters.substring(indexFrom < 0 ? index : indexFrom, ind + 1));
/*  43: 57 */           index = ind;
/*  44: 58 */           indexFrom = -1;
/*  45: 59 */           break;
/*  46:    */         default: 
/*  47: 61 */           lst.add(parameters.substring(indexFrom < 0 ? index : indexFrom, index + 1));
/*  48: 62 */           indexFrom = -1;
/*  49:    */         }
/*  50: 64 */         index++;
/*  51:    */       }
/*  52: 67 */       VarType[] params = new VarType[lst.size()];
/*  53: 68 */       for (int i = 0; i < lst.size(); i++) {
/*  54: 69 */         params[i] = new VarType((String)lst.get(i));
/*  55:    */       }
/*  56:    */     }
/*  57:    */     else
/*  58:    */     {
/*  59: 73 */       params = VarType.EMPTY_ARRAY;
/*  60:    */     }
/*  61: 76 */     VarType ret = new VarType(descriptor.substring(parenth + 1));
/*  62:    */     
/*  63: 78 */     return new MethodDescriptor(params, ret);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public String buildNewDescriptor(NewClassNameBuilder builder)
/*  67:    */   {
/*  68: 82 */     boolean updated = false;
/*  69:    */     VarType[] newParams;
/*  70: 85 */     if (this.params.length > 0)
/*  71:    */     {
/*  72: 86 */       VarType[] newParams = new VarType[this.params.length];
/*  73: 87 */       System.arraycopy(this.params, 0, newParams, 0, this.params.length);
/*  74: 88 */       for (int i = 0; i < this.params.length; i++)
/*  75:    */       {
/*  76: 89 */         VarType substitute = buildNewType(this.params[i], builder);
/*  77: 90 */         if (substitute != null)
/*  78:    */         {
/*  79: 91 */           newParams[i] = substitute;
/*  80: 92 */           updated = true;
/*  81:    */         }
/*  82:    */       }
/*  83:    */     }
/*  84:    */     else
/*  85:    */     {
/*  86: 97 */       newParams = VarType.EMPTY_ARRAY;
/*  87:    */     }
/*  88:100 */     VarType newRet = this.ret;
/*  89:101 */     VarType substitute = buildNewType(this.ret, builder);
/*  90:102 */     if (substitute != null)
/*  91:    */     {
/*  92:103 */       newRet = substitute;
/*  93:104 */       updated = true;
/*  94:    */     }
/*  95:107 */     if (updated)
/*  96:    */     {
/*  97:108 */       StringBuilder res = new StringBuilder("(");
/*  98:109 */       for (VarType param : newParams) {
/*  99:110 */         res.append(param);
/* 100:    */       }
/* 101:112 */       res.append(")").append(newRet.toString());
/* 102:113 */       return res.toString();
/* 103:    */     }
/* 104:116 */     return null;
/* 105:    */   }
/* 106:    */   
/* 107:    */   private static VarType buildNewType(VarType type, NewClassNameBuilder builder)
/* 108:    */   {
/* 109:120 */     if (type.type == 8)
/* 110:    */     {
/* 111:121 */       String newClassName = builder.buildNewClassname(type.value);
/* 112:122 */       if (newClassName != null) {
/* 113:123 */         return new VarType(type.type, type.arrayDim, newClassName);
/* 114:    */       }
/* 115:    */     }
/* 116:126 */     return null;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public boolean equals(Object o)
/* 120:    */   {
/* 121:131 */     if (o == this) {
/* 122:131 */       return true;
/* 123:    */     }
/* 124:132 */     if ((o == null) || (!(o instanceof MethodDescriptor))) {
/* 125:132 */       return false;
/* 126:    */     }
/* 127:134 */     MethodDescriptor md = (MethodDescriptor)o;
/* 128:135 */     return (this.ret.equals(md.ret)) && (Arrays.equals(this.params, md.params));
/* 129:    */   }
/* 130:    */   
/* 131:    */   public int hashCode()
/* 132:    */   {
/* 133:140 */     int result = this.ret.hashCode();
/* 134:141 */     result = 31 * result + this.params.length;
/* 135:142 */     return result;
/* 136:    */   }
/* 137:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.gen.MethodDescriptor
 * JD-Core Version:    0.7.0.1
 */