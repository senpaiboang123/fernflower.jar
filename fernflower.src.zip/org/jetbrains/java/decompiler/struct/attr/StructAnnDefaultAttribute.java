/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  5:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  6:   */ 
/*  7:   */ public class StructAnnDefaultAttribute
/*  8:   */   extends StructGeneralAttribute
/*  9:   */ {
/* 10:   */   private Exprent defaultValue;
/* 11:   */   
/* 12:   */   public void initContent(ConstantPool pool)
/* 13:   */     throws IOException
/* 14:   */   {
/* 15:29 */     this.defaultValue = StructAnnotationAttribute.parseAnnotationElement(stream(), pool);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public Exprent getDefaultValue()
/* 19:   */   {
/* 20:33 */     return this.defaultValue;
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructAnnDefaultAttribute
 * JD-Core Version:    0.7.0.1
 */