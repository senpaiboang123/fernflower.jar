/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  5:   */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  6:   */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  7:   */ 
/*  8:   */ public class StructGenericSignatureAttribute
/*  9:   */   extends StructGeneralAttribute
/* 10:   */ {
/* 11:   */   private String signature;
/* 12:   */   
/* 13:   */   public void initContent(ConstantPool pool)
/* 14:   */     throws IOException
/* 15:   */   {
/* 16:28 */     int index = stream().readUnsignedShort();
/* 17:29 */     this.signature = pool.getPrimitiveConstant(index).getString();
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getSignature()
/* 21:   */   {
/* 22:33 */     return this.signature;
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructGenericSignatureAttribute
 * JD-Core Version:    0.7.0.1
 */