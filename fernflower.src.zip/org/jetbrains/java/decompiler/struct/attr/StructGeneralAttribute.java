/*   1:    */ package org.jetbrains.java.decompiler.struct.attr;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*   5:    */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*   6:    */ 
/*   7:    */ public class StructGeneralAttribute
/*   8:    */ {
/*   9:    */   public static final String ATTRIBUTE_CODE = "Code";
/*  10:    */   public static final String ATTRIBUTE_INNER_CLASSES = "InnerClasses";
/*  11:    */   public static final String ATTRIBUTE_SIGNATURE = "Signature";
/*  12:    */   public static final String ATTRIBUTE_ANNOTATION_DEFAULT = "AnnotationDefault";
/*  13:    */   public static final String ATTRIBUTE_EXCEPTIONS = "Exceptions";
/*  14:    */   public static final String ATTRIBUTE_ENCLOSING_METHOD = "EnclosingMethod";
/*  15:    */   public static final String ATTRIBUTE_RUNTIME_VISIBLE_ANNOTATIONS = "RuntimeVisibleAnnotations";
/*  16:    */   public static final String ATTRIBUTE_RUNTIME_INVISIBLE_ANNOTATIONS = "RuntimeInvisibleAnnotations";
/*  17:    */   public static final String ATTRIBUTE_RUNTIME_VISIBLE_PARAMETER_ANNOTATIONS = "RuntimeVisibleParameterAnnotations";
/*  18:    */   public static final String ATTRIBUTE_RUNTIME_INVISIBLE_PARAMETER_ANNOTATIONS = "RuntimeInvisibleParameterAnnotations";
/*  19:    */   public static final String ATTRIBUTE_RUNTIME_VISIBLE_TYPE_ANNOTATIONS = "RuntimeVisibleTypeAnnotations";
/*  20:    */   public static final String ATTRIBUTE_RUNTIME_INVISIBLE_TYPE_ANNOTATIONS = "RuntimeInvisibleTypeAnnotations";
/*  21:    */   public static final String ATTRIBUTE_LOCAL_VARIABLE_TABLE = "LocalVariableTable";
/*  22:    */   public static final String ATTRIBUTE_CONSTANT_VALUE = "ConstantValue";
/*  23:    */   public static final String ATTRIBUTE_BOOTSTRAP_METHODS = "BootstrapMethods";
/*  24:    */   public static final String ATTRIBUTE_SYNTHETIC = "Synthetic";
/*  25:    */   public static final String ATTRIBUTE_DEPRECATED = "Deprecated";
/*  26:    */   public static final String ATTRIBUTE_LINE_NUMBER_TABLE = "LineNumberTable";
/*  27:    */   public static final String ATTRIBUTE_SOURCE_FILE = "SourceFile";
/*  28:    */   private String name;
/*  29:    */   private byte[] info;
/*  30:    */   
/*  31:    */   public static StructGeneralAttribute createAttribute(String name)
/*  32:    */   {
/*  33:    */     StructGeneralAttribute attr;
/*  34: 58 */     if ("InnerClasses".equals(name))
/*  35:    */     {
/*  36: 59 */       attr = new StructInnerClassesAttribute();
/*  37:    */     }
/*  38:    */     else
/*  39:    */     {
/*  40:    */       StructGeneralAttribute attr;
/*  41: 61 */       if ("ConstantValue".equals(name))
/*  42:    */       {
/*  43: 62 */         attr = new StructConstantValueAttribute();
/*  44:    */       }
/*  45:    */       else
/*  46:    */       {
/*  47:    */         StructGeneralAttribute attr;
/*  48: 64 */         if ("Signature".equals(name))
/*  49:    */         {
/*  50: 65 */           attr = new StructGenericSignatureAttribute();
/*  51:    */         }
/*  52:    */         else
/*  53:    */         {
/*  54:    */           StructGeneralAttribute attr;
/*  55: 67 */           if ("AnnotationDefault".equals(name))
/*  56:    */           {
/*  57: 68 */             attr = new StructAnnDefaultAttribute();
/*  58:    */           }
/*  59:    */           else
/*  60:    */           {
/*  61:    */             StructGeneralAttribute attr;
/*  62: 70 */             if ("Exceptions".equals(name))
/*  63:    */             {
/*  64: 71 */               attr = new StructExceptionsAttribute();
/*  65:    */             }
/*  66:    */             else
/*  67:    */             {
/*  68:    */               StructGeneralAttribute attr;
/*  69: 73 */               if ("EnclosingMethod".equals(name))
/*  70:    */               {
/*  71: 74 */                 attr = new StructEnclosingMethodAttribute();
/*  72:    */               }
/*  73:    */               else
/*  74:    */               {
/*  75:    */                 StructGeneralAttribute attr;
/*  76: 76 */                 if (("RuntimeVisibleAnnotations".equals(name)) || ("RuntimeInvisibleAnnotations".equals(name)))
/*  77:    */                 {
/*  78: 78 */                   attr = new StructAnnotationAttribute();
/*  79:    */                 }
/*  80:    */                 else
/*  81:    */                 {
/*  82:    */                   StructGeneralAttribute attr;
/*  83: 80 */                   if (("RuntimeVisibleParameterAnnotations".equals(name)) || ("RuntimeInvisibleParameterAnnotations".equals(name)))
/*  84:    */                   {
/*  85: 82 */                     attr = new StructAnnotationParameterAttribute();
/*  86:    */                   }
/*  87:    */                   else
/*  88:    */                   {
/*  89:    */                     StructGeneralAttribute attr;
/*  90: 84 */                     if (("RuntimeVisibleTypeAnnotations".equals(name)) || ("RuntimeInvisibleTypeAnnotations".equals(name)))
/*  91:    */                     {
/*  92: 86 */                       attr = new StructAnnotationTypeAttribute();
/*  93:    */                     }
/*  94:    */                     else
/*  95:    */                     {
/*  96:    */                       StructGeneralAttribute attr;
/*  97: 88 */                       if ("LocalVariableTable".equals(name))
/*  98:    */                       {
/*  99: 89 */                         attr = new StructLocalVariableTableAttribute();
/* 100:    */                       }
/* 101:    */                       else
/* 102:    */                       {
/* 103:    */                         StructGeneralAttribute attr;
/* 104: 91 */                         if ("BootstrapMethods".equals(name))
/* 105:    */                         {
/* 106: 92 */                           attr = new StructBootstrapMethodsAttribute();
/* 107:    */                         }
/* 108:    */                         else
/* 109:    */                         {
/* 110:    */                           StructGeneralAttribute attr;
/* 111: 94 */                           if (("Synthetic".equals(name)) || ("Deprecated".equals(name)))
/* 112:    */                           {
/* 113: 96 */                             attr = new StructGeneralAttribute();
/* 114:    */                           }
/* 115:    */                           else
/* 116:    */                           {
/* 117:    */                             StructGeneralAttribute attr;
/* 118: 98 */                             if ("LineNumberTable".equals(name))
/* 119:    */                             {
/* 120: 99 */                               attr = new StructLineNumberTableAttribute();
/* 121:    */                             }
/* 122:    */                             else
/* 123:    */                             {
/* 124:    */                               StructGeneralAttribute attr;
/* 125:101 */                               if ("SourceFile".equals(name)) {
/* 126:102 */                                 attr = new StructSourceFileAttribute();
/* 127:    */                               } else {
/* 128:106 */                                 return null;
/* 129:    */                               }
/* 130:    */                             }
/* 131:    */                           }
/* 132:    */                         }
/* 133:    */                       }
/* 134:    */                     }
/* 135:    */                   }
/* 136:    */                 }
/* 137:    */               }
/* 138:    */             }
/* 139:    */           }
/* 140:    */         }
/* 141:    */       }
/* 142:    */     }
/* 143:    */     StructGeneralAttribute attr;
/* 144:109 */     attr.name = name;
/* 145:110 */     return attr;
/* 146:    */   }
/* 147:    */   
/* 148:    */   protected DataInputFullStream stream()
/* 149:    */   {
/* 150:114 */     return new DataInputFullStream(this.info);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void initContent(ConstantPool pool)
/* 154:    */     throws IOException
/* 155:    */   {}
/* 156:    */   
/* 157:    */   public void setInfo(byte[] info)
/* 158:    */   {
/* 159:120 */     this.info = info;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public String getName()
/* 163:    */   {
/* 164:124 */     return this.name;
/* 165:    */   }
/* 166:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructGeneralAttribute
 * JD-Core Version:    0.7.0.1
 */