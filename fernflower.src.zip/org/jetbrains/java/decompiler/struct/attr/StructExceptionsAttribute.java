/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.DataInputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.Collections;
/*  7:   */ import java.util.List;
/*  8:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  9:   */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/* 10:   */ 
/* 11:   */ public class StructExceptionsAttribute
/* 12:   */   extends StructGeneralAttribute
/* 13:   */ {
/* 14:   */   private List<Integer> throwsExceptions;
/* 15:   */   
/* 16:   */   public void initContent(ConstantPool pool)
/* 17:   */     throws IOException
/* 18:   */   {
/* 19:32 */     DataInputStream data = stream();
/* 20:33 */     int len = data.readUnsignedShort();
/* 21:34 */     if (len > 0)
/* 22:   */     {
/* 23:35 */       this.throwsExceptions = new ArrayList(len);
/* 24:36 */       for (int i = 0; i < len; i++) {
/* 25:37 */         this.throwsExceptions.add(Integer.valueOf(data.readUnsignedShort()));
/* 26:   */       }
/* 27:   */     }
/* 28:   */     else
/* 29:   */     {
/* 30:41 */       this.throwsExceptions = Collections.emptyList();
/* 31:   */     }
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getExcClassname(int index, ConstantPool pool)
/* 35:   */   {
/* 36:46 */     return pool.getPrimitiveConstant(((Integer)this.throwsExceptions.get(index)).intValue()).getString();
/* 37:   */   }
/* 38:   */   
/* 39:   */   public List<Integer> getThrowsExceptions()
/* 40:   */   {
/* 41:50 */     return this.throwsExceptions;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructExceptionsAttribute
 * JD-Core Version:    0.7.0.1
 */