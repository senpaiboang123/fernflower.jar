/*   1:    */ package org.jetbrains.java.decompiler.struct.attr;
/*   2:    */ 
/*   3:    */ import java.io.DataInputStream;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.Collections;
/*   7:    */ import java.util.List;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AnnotationExprent;
/*   9:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  10:    */ 
/*  11:    */ public class StructAnnotationTypeAttribute
/*  12:    */   extends StructGeneralAttribute
/*  13:    */ {
/*  14:    */   private static final int ANNOTATION_TARGET_TYPE_GENERIC_CLASS = 0;
/*  15:    */   private static final int ANNOTATION_TARGET_TYPE_GENERIC_METHOD = 1;
/*  16:    */   private static final int ANNOTATION_TARGET_TYPE_EXTENDS_IMPLEMENTS = 16;
/*  17:    */   private static final int ANNOTATION_TARGET_TYPE_GENERIC_CLASS_BOUND = 17;
/*  18:    */   private static final int ANNOTATION_TARGET_TYPE_GENERIC_METHOD_BOUND = 18;
/*  19:    */   private static final int ANNOTATION_TARGET_TYPE_FIELD = 19;
/*  20:    */   private static final int ANNOTATION_TARGET_TYPE_RETURN = 20;
/*  21:    */   private static final int ANNOTATION_TARGET_TYPE_RECEIVER = 21;
/*  22:    */   private static final int ANNOTATION_TARGET_TYPE_FORMAL = 22;
/*  23:    */   private static final int ANNOTATION_TARGET_TYPE_THROWS = 23;
/*  24:    */   private static final int ANNOTATION_TARGET_TYPE_LOCAL_VARIABLE = 64;
/*  25:    */   private static final int ANNOTATION_TARGET_TYPE_RESOURCE_VARIABLE = 65;
/*  26:    */   private static final int ANNOTATION_TARGET_TYPE_EXCEPTION = 66;
/*  27:    */   private static final int ANNOTATION_TARGET_TYPE_INSTANCEOF = 67;
/*  28:    */   private static final int ANNOTATION_TARGET_TYPE_NEW = 68;
/*  29:    */   private static final int ANNOTATION_TARGET_TYPE_DOUBLE_COLON_NEW = 69;
/*  30:    */   private static final int ANNOTATION_TARGET_TYPE_DOUBLE_COLON_ID = 70;
/*  31:    */   private static final int ANNOTATION_TARGET_TYPE_CAST = 71;
/*  32:    */   private static final int ANNOTATION_TARGET_TYPE_INVOCATION_CONSTRUCTOR = 72;
/*  33:    */   private static final int ANNOTATION_TARGET_TYPE_INVOCATION_METHOD = 73;
/*  34:    */   private static final int ANNOTATION_TARGET_TYPE_GENERIC_DOUBLE_COLON_NEW = 74;
/*  35:    */   private static final int ANNOTATION_TARGET_TYPE_GENERIC_DOUBLE_COLON_ID = 75;
/*  36:    */   private static final int ANNOTATION_TARGET_UNION_TYPE_PARAMETER = 1;
/*  37:    */   private static final int ANNOTATION_TARGET_UNION_SUPERTYPE = 2;
/*  38:    */   private static final int ANNOTATION_TARGET_UNION_TYPE_PARAMETER_BOUND = 3;
/*  39:    */   private static final int ANNOTATION_TARGET_UNION_EMPTY = 4;
/*  40:    */   private static final int ANNOTATION_TARGET_UNION_FORMAL_PARAMETER = 5;
/*  41:    */   private static final int ANNOTATION_TARGET_UNION_THROWS = 6;
/*  42:    */   private static final int ANNOTATION_TARGET_UNION_LOCAL_VAR = 7;
/*  43:    */   private static final int ANNOTATION_TARGET_UNION_CATCH = 8;
/*  44:    */   private static final int ANNOTATION_TARGET_UNION_OFFSET = 9;
/*  45:    */   private static final int ANNOTATION_TARGET_UNION_TYPE_ARGUMENT = 10;
/*  46:    */   private List<AnnotationLocation> locations;
/*  47:    */   private List<AnnotationExprent> annotations;
/*  48:    */   
/*  49:    */   public void initContent(ConstantPool pool)
/*  50:    */     throws IOException
/*  51:    */   {
/*  52: 68 */     DataInputStream data = stream();
/*  53:    */     
/*  54: 70 */     int len = data.readUnsignedByte();
/*  55: 71 */     if (len > 0)
/*  56:    */     {
/*  57: 72 */       this.locations = new ArrayList(len);
/*  58: 73 */       this.annotations = new ArrayList(len);
/*  59: 74 */       for (int i = 0; i < len; i++)
/*  60:    */       {
/*  61: 75 */         this.locations.add(parseAnnotationLocation(data));
/*  62: 76 */         this.annotations.add(StructAnnotationAttribute.parseAnnotation(data, pool));
/*  63:    */       }
/*  64:    */     }
/*  65:    */     else
/*  66:    */     {
/*  67: 80 */       this.locations = Collections.emptyList();
/*  68: 81 */       this.annotations = Collections.emptyList();
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   private static AnnotationLocation parseAnnotationLocation(DataInputStream data)
/*  73:    */     throws IOException
/*  74:    */   {
/*  75: 86 */     AnnotationLocation ann_location = new AnnotationLocation(null);
/*  76:    */     
/*  77:    */ 
/*  78: 89 */     ann_location.target_type = data.readUnsignedByte();
/*  79: 92 */     switch (ann_location.target_type)
/*  80:    */     {
/*  81:    */     case 0: 
/*  82:    */     case 1: 
/*  83: 95 */       ann_location.target_union = 1;
/*  84: 96 */       break;
/*  85:    */     case 16: 
/*  86: 98 */       ann_location.target_union = 2;
/*  87: 99 */       break;
/*  88:    */     case 17: 
/*  89:    */     case 18: 
/*  90:102 */       ann_location.target_union = 3;
/*  91:103 */       break;
/*  92:    */     case 19: 
/*  93:    */     case 20: 
/*  94:    */     case 21: 
/*  95:107 */       ann_location.target_union = 4;
/*  96:108 */       break;
/*  97:    */     case 22: 
/*  98:110 */       ann_location.target_union = 5;
/*  99:111 */       break;
/* 100:    */     case 23: 
/* 101:113 */       ann_location.target_union = 6;
/* 102:114 */       break;
/* 103:    */     case 64: 
/* 104:    */     case 65: 
/* 105:117 */       ann_location.target_union = 7;
/* 106:118 */       break;
/* 107:    */     case 66: 
/* 108:120 */       ann_location.target_union = 8;
/* 109:121 */       break;
/* 110:    */     case 67: 
/* 111:    */     case 68: 
/* 112:    */     case 69: 
/* 113:    */     case 70: 
/* 114:126 */       ann_location.target_union = 9;
/* 115:127 */       break;
/* 116:    */     case 71: 
/* 117:    */     case 72: 
/* 118:    */     case 73: 
/* 119:    */     case 74: 
/* 120:    */     case 75: 
/* 121:133 */       ann_location.target_union = 10;
/* 122:134 */       break;
/* 123:    */     case 2: 
/* 124:    */     case 3: 
/* 125:    */     case 4: 
/* 126:    */     case 5: 
/* 127:    */     case 6: 
/* 128:    */     case 7: 
/* 129:    */     case 8: 
/* 130:    */     case 9: 
/* 131:    */     case 10: 
/* 132:    */     case 11: 
/* 133:    */     case 12: 
/* 134:    */     case 13: 
/* 135:    */     case 14: 
/* 136:    */     case 15: 
/* 137:    */     case 24: 
/* 138:    */     case 25: 
/* 139:    */     case 26: 
/* 140:    */     case 27: 
/* 141:    */     case 28: 
/* 142:    */     case 29: 
/* 143:    */     case 30: 
/* 144:    */     case 31: 
/* 145:    */     case 32: 
/* 146:    */     case 33: 
/* 147:    */     case 34: 
/* 148:    */     case 35: 
/* 149:    */     case 36: 
/* 150:    */     case 37: 
/* 151:    */     case 38: 
/* 152:    */     case 39: 
/* 153:    */     case 40: 
/* 154:    */     case 41: 
/* 155:    */     case 42: 
/* 156:    */     case 43: 
/* 157:    */     case 44: 
/* 158:    */     case 45: 
/* 159:    */     case 46: 
/* 160:    */     case 47: 
/* 161:    */     case 48: 
/* 162:    */     case 49: 
/* 163:    */     case 50: 
/* 164:    */     case 51: 
/* 165:    */     case 52: 
/* 166:    */     case 53: 
/* 167:    */     case 54: 
/* 168:    */     case 55: 
/* 169:    */     case 56: 
/* 170:    */     case 57: 
/* 171:    */     case 58: 
/* 172:    */     case 59: 
/* 173:    */     case 60: 
/* 174:    */     case 61: 
/* 175:    */     case 62: 
/* 176:    */     case 63: 
/* 177:    */     default: 
/* 178:136 */       throw new RuntimeException("Unknown target type in a type annotation!");
/* 179:    */     }
/* 180:141 */     switch (ann_location.target_union)
/* 181:    */     {
/* 182:    */     case 1: 
/* 183:    */     case 5: 
/* 184:144 */       ann_location.data = new int[] { data.readUnsignedByte() };
/* 185:145 */       break;
/* 186:    */     case 2: 
/* 187:    */     case 6: 
/* 188:    */     case 8: 
/* 189:    */     case 9: 
/* 190:150 */       ann_location.data = new int[] { data.readUnsignedShort() };
/* 191:151 */       break;
/* 192:    */     case 3: 
/* 193:153 */       ann_location.data = new int[] { data.readUnsignedByte(), data.readUnsignedByte() };
/* 194:154 */       break;
/* 195:    */     case 4: 
/* 196:    */       break;
/* 197:    */     case 7: 
/* 198:158 */       int table_length = data.readUnsignedShort();
/* 199:    */       
/* 200:160 */       ann_location.data = new int[table_length * 3 + 1];
/* 201:161 */       ann_location.data[0] = table_length;
/* 202:163 */       for (int i = 0; i < table_length; i++)
/* 203:    */       {
/* 204:164 */         ann_location.data[(3 * i + 1)] = data.readUnsignedShort();
/* 205:165 */         ann_location.data[(3 * i + 2)] = data.readUnsignedShort();
/* 206:166 */         ann_location.data[(3 * i + 3)] = data.readUnsignedShort();
/* 207:    */       }
/* 208:168 */       break;
/* 209:    */     case 10: 
/* 210:170 */       ann_location.data = new int[] { data.readUnsignedShort(), data.readUnsignedByte() };
/* 211:    */     }
/* 212:174 */     int path_length = data.readUnsignedByte();
/* 213:    */     
/* 214:176 */     ann_location.target_path_kind = new int[path_length];
/* 215:177 */     ann_location.target_argument_index = new int[path_length];
/* 216:179 */     for (int i = 0; i < path_length; i++)
/* 217:    */     {
/* 218:180 */       ann_location.target_path_kind[i] = data.readUnsignedByte();
/* 219:181 */       ann_location.target_argument_index[i] = data.readUnsignedByte();
/* 220:    */     }
/* 221:184 */     return ann_location;
/* 222:    */   }
/* 223:    */   
/* 224:    */   private static class AnnotationLocation
/* 225:    */   {
/* 226:    */     public int target_type;
/* 227:    */     public int target_union;
/* 228:    */     public int[] data;
/* 229:    */     public int[] target_path_kind;
/* 230:    */     public int[] target_argument_index;
/* 231:    */   }
/* 232:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructAnnotationTypeAttribute
 * JD-Core Version:    0.7.0.1
 */