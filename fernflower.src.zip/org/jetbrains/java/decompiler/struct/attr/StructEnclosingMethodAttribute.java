/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.DataInputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  6:   */ import org.jetbrains.java.decompiler.struct.consts.LinkConstant;
/*  7:   */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  8:   */ 
/*  9:   */ public class StructEnclosingMethodAttribute
/* 10:   */   extends StructGeneralAttribute
/* 11:   */ {
/* 12:   */   private String className;
/* 13:   */   private String methodName;
/* 14:   */   private String methodDescriptor;
/* 15:   */   
/* 16:   */   public void initContent(ConstantPool pool)
/* 17:   */     throws IOException
/* 18:   */   {
/* 19:32 */     DataInputStream data = stream();
/* 20:33 */     int classIndex = data.readUnsignedShort();
/* 21:34 */     int methodIndex = data.readUnsignedShort();
/* 22:   */     
/* 23:36 */     this.className = pool.getPrimitiveConstant(classIndex).getString();
/* 24:37 */     if (methodIndex != 0)
/* 25:   */     {
/* 26:38 */       LinkConstant lk = pool.getLinkConstant(methodIndex);
/* 27:39 */       this.methodName = lk.elementname;
/* 28:40 */       this.methodDescriptor = lk.descriptor;
/* 29:   */     }
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String getClassName()
/* 33:   */   {
/* 34:45 */     return this.className;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String getMethodDescriptor()
/* 38:   */   {
/* 39:49 */     return this.methodDescriptor;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getMethodName()
/* 43:   */   {
/* 44:53 */     return this.methodName;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructEnclosingMethodAttribute
 * JD-Core Version:    0.7.0.1
 */