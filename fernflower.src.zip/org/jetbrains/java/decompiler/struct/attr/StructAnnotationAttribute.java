/*   1:    */ package org.jetbrains.java.decompiler.struct.attr;
/*   2:    */ 
/*   3:    */ import java.io.DataInputStream;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.Collections;
/*   7:    */ import java.util.List;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AnnotationExprent;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FieldExprent;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*  13:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  14:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  15:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  16:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  17:    */ 
/*  18:    */ public class StructAnnotationAttribute
/*  19:    */   extends StructGeneralAttribute
/*  20:    */ {
/*  21:    */   private List<AnnotationExprent> annotations;
/*  22:    */   
/*  23:    */   public void initContent(ConstantPool pool)
/*  24:    */     throws IOException
/*  25:    */   {
/*  26: 37 */     this.annotations = parseAnnotations(pool, stream());
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static List<AnnotationExprent> parseAnnotations(ConstantPool pool, DataInputStream data)
/*  30:    */     throws IOException
/*  31:    */   {
/*  32: 41 */     int len = data.readUnsignedShort();
/*  33: 42 */     if (len > 0)
/*  34:    */     {
/*  35: 43 */       List<AnnotationExprent> annotations = new ArrayList(len);
/*  36: 44 */       for (int i = 0; i < len; i++) {
/*  37: 45 */         annotations.add(parseAnnotation(data, pool));
/*  38:    */       }
/*  39: 47 */       return annotations;
/*  40:    */     }
/*  41: 50 */     return Collections.emptyList();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static AnnotationExprent parseAnnotation(DataInputStream data, ConstantPool pool)
/*  45:    */     throws IOException
/*  46:    */   {
/*  47: 55 */     String className = pool.getPrimitiveConstant(data.readUnsignedShort()).getString();
/*  48:    */     
/*  49:    */ 
/*  50:    */ 
/*  51: 59 */     int len = data.readUnsignedShort();
/*  52:    */     List<String> names;
/*  53:    */     List<Exprent> values;
/*  54: 60 */     if (len > 0)
/*  55:    */     {
/*  56: 61 */       List<String> names = new ArrayList(len);
/*  57: 62 */       List<Exprent> values = new ArrayList(len);
/*  58: 63 */       for (int i = 0; i < len; i++)
/*  59:    */       {
/*  60: 64 */         names.add(pool.getPrimitiveConstant(data.readUnsignedShort()).getString());
/*  61: 65 */         values.add(parseAnnotationElement(data, pool));
/*  62:    */       }
/*  63:    */     }
/*  64:    */     else
/*  65:    */     {
/*  66: 69 */       names = Collections.emptyList();
/*  67: 70 */       values = Collections.emptyList();
/*  68:    */     }
/*  69: 73 */     return new AnnotationExprent(new VarType(className).value, names, values);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static Exprent parseAnnotationElement(DataInputStream data, ConstantPool pool)
/*  73:    */     throws IOException
/*  74:    */   {
/*  75: 77 */     int tag = data.readUnsignedByte();
/*  76: 79 */     switch (tag)
/*  77:    */     {
/*  78:    */     case 101: 
/*  79: 81 */       String className = pool.getPrimitiveConstant(data.readUnsignedShort()).getString();
/*  80: 82 */       String constName = pool.getPrimitiveConstant(data.readUnsignedShort()).getString();
/*  81: 83 */       FieldDescriptor descr = FieldDescriptor.parseDescriptor(className);
/*  82: 84 */       return new FieldExprent(constName, descr.type.value, true, null, descr, null);
/*  83:    */     case 99: 
/*  84: 87 */       String descriptor = pool.getPrimitiveConstant(data.readUnsignedShort()).getString();
/*  85: 88 */       VarType type = FieldDescriptor.parseDescriptor(descriptor).type;
/*  86:    */       String value;
/*  87: 91 */       switch (type.type)
/*  88:    */       {
/*  89:    */       case 8: 
/*  90: 93 */         value = type.value;
/*  91: 94 */         break;
/*  92:    */       case 0: 
/*  93: 96 */         value = Byte.TYPE.getName();
/*  94: 97 */         break;
/*  95:    */       case 1: 
/*  96: 99 */         value = Character.TYPE.getName();
/*  97:100 */         break;
/*  98:    */       case 2: 
/*  99:102 */         value = Double.TYPE.getName();
/* 100:103 */         break;
/* 101:    */       case 3: 
/* 102:105 */         value = Float.TYPE.getName();
/* 103:106 */         break;
/* 104:    */       case 4: 
/* 105:108 */         value = Integer.TYPE.getName();
/* 106:109 */         break;
/* 107:    */       case 5: 
/* 108:111 */         value = Long.TYPE.getName();
/* 109:112 */         break;
/* 110:    */       case 6: 
/* 111:114 */         value = Short.TYPE.getName();
/* 112:115 */         break;
/* 113:    */       case 7: 
/* 114:117 */         value = Boolean.TYPE.getName();
/* 115:118 */         break;
/* 116:    */       case 10: 
/* 117:120 */         value = Void.TYPE.getName();
/* 118:121 */         break;
/* 119:    */       case 9: 
/* 120:    */       default: 
/* 121:123 */         throw new RuntimeException("invalid class type: " + type.type);
/* 122:    */       }
/* 123:125 */       return new ConstExprent(VarType.VARTYPE_CLASS, value, null);
/* 124:    */     case 91: 
/* 125:128 */       List<Exprent> elements = Collections.emptyList();
/* 126:129 */       int len = data.readUnsignedShort();
/* 127:130 */       if (len > 0)
/* 128:    */       {
/* 129:131 */         elements = new ArrayList(len);
/* 130:132 */         for (int i = 0; i < len; i++) {
/* 131:133 */           elements.add(parseAnnotationElement(data, pool));
/* 132:    */         }
/* 133:    */       }
/* 134:    */       VarType newType;
/* 135:    */       VarType newType;
/* 136:138 */       if (elements.isEmpty())
/* 137:    */       {
/* 138:139 */         newType = new VarType(8, 1, "java/lang/Object");
/* 139:    */       }
/* 140:    */       else
/* 141:    */       {
/* 142:142 */         VarType elementType = ((Exprent)elements.get(0)).getExprType();
/* 143:143 */         newType = new VarType(elementType.type, 1, elementType.value);
/* 144:    */       }
/* 145:146 */       NewExprent newExpr = new NewExprent(newType, Collections.emptyList(), null);
/* 146:147 */       newExpr.setDirectArrayInit(true);
/* 147:148 */       newExpr.setLstArrayElements(elements);
/* 148:149 */       return newExpr;
/* 149:    */     case 64: 
/* 150:152 */       return parseAnnotation(data, pool);
/* 151:    */     }
/* 152:155 */     PrimitiveConstant cn = pool.getPrimitiveConstant(data.readUnsignedShort());
/* 153:156 */     switch (tag)
/* 154:    */     {
/* 155:    */     case 66: 
/* 156:158 */       return new ConstExprent(VarType.VARTYPE_BYTE, cn.value, null);
/* 157:    */     case 67: 
/* 158:160 */       return new ConstExprent(VarType.VARTYPE_CHAR, cn.value, null);
/* 159:    */     case 68: 
/* 160:162 */       return new ConstExprent(VarType.VARTYPE_DOUBLE, cn.value, null);
/* 161:    */     case 70: 
/* 162:164 */       return new ConstExprent(VarType.VARTYPE_FLOAT, cn.value, null);
/* 163:    */     case 73: 
/* 164:166 */       return new ConstExprent(VarType.VARTYPE_INT, cn.value, null);
/* 165:    */     case 74: 
/* 166:168 */       return new ConstExprent(VarType.VARTYPE_LONG, cn.value, null);
/* 167:    */     case 83: 
/* 168:170 */       return new ConstExprent(VarType.VARTYPE_SHORT, cn.value, null);
/* 169:    */     case 90: 
/* 170:172 */       return new ConstExprent(VarType.VARTYPE_BOOLEAN, cn.value, null);
/* 171:    */     case 115: 
/* 172:174 */       return new ConstExprent(VarType.VARTYPE_STRING, cn.value, null);
/* 173:    */     }
/* 174:176 */     throw new RuntimeException("invalid element type!");
/* 175:    */   }
/* 176:    */   
/* 177:    */   public List<AnnotationExprent> getAnnotations()
/* 178:    */   {
/* 179:182 */     return this.annotations;
/* 180:    */   }
/* 181:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructAnnotationAttribute
 * JD-Core Version:    0.7.0.1
 */