/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  5:   */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  6:   */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  7:   */ 
/*  8:   */ public class StructLineNumberTableAttribute
/*  9:   */   extends StructGeneralAttribute
/* 10:   */ {
/* 11:33 */   private int[] myLineInfo = InterpreterUtil.EMPTY_INT_ARRAY;
/* 12:   */   
/* 13:   */   public void initContent(ConstantPool pool)
/* 14:   */     throws IOException
/* 15:   */   {
/* 16:37 */     DataInputFullStream data = stream();
/* 17:   */     
/* 18:39 */     int len = data.readUnsignedShort() * 2;
/* 19:40 */     if (len > 0)
/* 20:   */     {
/* 21:41 */       this.myLineInfo = new int[len];
/* 22:42 */       for (int i = 0; i < len; i += 2)
/* 23:   */       {
/* 24:43 */         this.myLineInfo[i] = data.readUnsignedShort();
/* 25:44 */         this.myLineInfo[(i + 1)] = data.readUnsignedShort();
/* 26:   */       }
/* 27:   */     }
/* 28:47 */     else if (this.myLineInfo.length > 0)
/* 29:   */     {
/* 30:48 */       this.myLineInfo = InterpreterUtil.EMPTY_INT_ARRAY;
/* 31:   */     }
/* 32:   */   }
/* 33:   */   
/* 34:   */   public int getFirstLine()
/* 35:   */   {
/* 36:53 */     return this.myLineInfo.length > 0 ? this.myLineInfo[1] : -1;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public int findLineNumber(int pc)
/* 40:   */   {
/* 41:57 */     if (this.myLineInfo.length >= 2) {
/* 42:58 */       for (int i = this.myLineInfo.length - 2; i >= 0; i -= 2) {
/* 43:59 */         if (pc >= this.myLineInfo[i]) {
/* 44:60 */           return this.myLineInfo[(i + 1)];
/* 45:   */         }
/* 46:   */       }
/* 47:   */     }
/* 48:64 */     return -1;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public int[] getRawData()
/* 52:   */   {
/* 53:68 */     return this.myLineInfo;
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructLineNumberTableAttribute
 * JD-Core Version:    0.7.0.1
 */