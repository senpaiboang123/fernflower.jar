/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.DataInputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.Collections;
/*  7:   */ import java.util.List;
/*  8:   */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AnnotationExprent;
/*  9:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/* 10:   */ 
/* 11:   */ public class StructAnnotationParameterAttribute
/* 12:   */   extends StructGeneralAttribute
/* 13:   */ {
/* 14:   */   private List<List<AnnotationExprent>> paramAnnotations;
/* 15:   */   
/* 16:   */   public void initContent(ConstantPool pool)
/* 17:   */     throws IOException
/* 18:   */   {
/* 19:33 */     DataInputStream data = stream();
/* 20:   */     
/* 21:35 */     int len = data.readUnsignedByte();
/* 22:36 */     if (len > 0)
/* 23:   */     {
/* 24:37 */       this.paramAnnotations = new ArrayList(len);
/* 25:38 */       for (int i = 0; i < len; i++)
/* 26:   */       {
/* 27:39 */         List<AnnotationExprent> annotations = StructAnnotationAttribute.parseAnnotations(pool, data);
/* 28:40 */         this.paramAnnotations.add(annotations);
/* 29:   */       }
/* 30:   */     }
/* 31:   */     else
/* 32:   */     {
/* 33:44 */       this.paramAnnotations = Collections.emptyList();
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:   */   public List<List<AnnotationExprent>> getParamAnnotations()
/* 38:   */   {
/* 39:49 */     return this.paramAnnotations;
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructAnnotationParameterAttribute
 * JD-Core Version:    0.7.0.1
 */