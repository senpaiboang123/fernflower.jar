/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.DataInputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.Collections;
/*  7:   */ import java.util.List;
/*  8:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  9:   */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/* 10:   */ 
/* 11:   */ public class StructInnerClassesAttribute
/* 12:   */   extends StructGeneralAttribute
/* 13:   */ {
/* 14:   */   private List<Entry> entries;
/* 15:   */   
/* 16:   */   public static class Entry
/* 17:   */   {
/* 18:   */     public final int innerNameIdx;
/* 19:   */     public final int outerNameIdx;
/* 20:   */     public final int simpleNameIdx;
/* 21:   */     public final int accessFlags;
/* 22:   */     public final String innerName;
/* 23:   */     public final String enclosingName;
/* 24:   */     public final String simpleName;
/* 25:   */     
/* 26:   */     private Entry(int innerNameIdx, int outerNameIdx, int simpleNameIdx, int accessFlags, String innerName, String enclosingName, String simpleName)
/* 27:   */     {
/* 28:37 */       this.innerNameIdx = innerNameIdx;
/* 29:38 */       this.outerNameIdx = outerNameIdx;
/* 30:39 */       this.simpleNameIdx = simpleNameIdx;
/* 31:40 */       this.accessFlags = accessFlags;
/* 32:41 */       this.innerName = innerName;
/* 33:42 */       this.enclosingName = enclosingName;
/* 34:43 */       this.simpleName = simpleName;
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void initContent(ConstantPool pool)
/* 39:   */     throws IOException
/* 40:   */   {
/* 41:51 */     DataInputStream data = stream();
/* 42:   */     
/* 43:53 */     int len = data.readUnsignedShort();
/* 44:54 */     if (len > 0)
/* 45:   */     {
/* 46:55 */       this.entries = new ArrayList(len);
/* 47:57 */       for (int i = 0; i < len; i++)
/* 48:   */       {
/* 49:58 */         int innerNameIdx = data.readUnsignedShort();
/* 50:59 */         int outerNameIdx = data.readUnsignedShort();
/* 51:60 */         int simpleNameIdx = data.readUnsignedShort();
/* 52:61 */         int accessFlags = data.readUnsignedShort();
/* 53:   */         
/* 54:63 */         String innerName = pool.getPrimitiveConstant(innerNameIdx).getString();
/* 55:64 */         String outerName = outerNameIdx != 0 ? pool.getPrimitiveConstant(outerNameIdx).getString() : null;
/* 56:65 */         String simpleName = simpleNameIdx != 0 ? pool.getPrimitiveConstant(simpleNameIdx).getString() : null;
/* 57:   */         
/* 58:67 */         this.entries.add(new Entry(innerNameIdx, outerNameIdx, simpleNameIdx, accessFlags, innerName, outerName, simpleName, null));
/* 59:   */       }
/* 60:   */     }
/* 61:   */     else
/* 62:   */     {
/* 63:71 */       this.entries = Collections.emptyList();
/* 64:   */     }
/* 65:   */   }
/* 66:   */   
/* 67:   */   public List<Entry> getEntries()
/* 68:   */   {
/* 69:76 */     return this.entries;
/* 70:   */   }
/* 71:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructInnerClassesAttribute
 * JD-Core Version:    0.7.0.1
 */