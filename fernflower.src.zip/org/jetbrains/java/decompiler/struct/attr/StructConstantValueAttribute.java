/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  5:   */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  6:   */ 
/*  7:   */ public class StructConstantValueAttribute
/*  8:   */   extends StructGeneralAttribute
/*  9:   */ {
/* 10:   */   private int index;
/* 11:   */   
/* 12:   */   public void initContent(ConstantPool pool)
/* 13:   */     throws IOException
/* 14:   */   {
/* 15:28 */     this.index = stream().readUnsignedShort();
/* 16:   */   }
/* 17:   */   
/* 18:   */   public int getIndex()
/* 19:   */   {
/* 20:32 */     return this.index;
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructConstantValueAttribute
 * JD-Core Version:    0.7.0.1
 */