/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.util.Collections;
/*  5:   */ import java.util.HashMap;
/*  6:   */ import java.util.Map;
/*  7:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  8:   */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  9:   */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/* 10:   */ 
/* 11:   */ public class StructLocalVariableTableAttribute
/* 12:   */   extends StructGeneralAttribute
/* 13:   */ {
/* 14:38 */   private Map<Integer, String> mapVarNames = Collections.emptyMap();
/* 15:   */   
/* 16:   */   public void initContent(ConstantPool pool)
/* 17:   */     throws IOException
/* 18:   */   {
/* 19:42 */     DataInputFullStream data = stream();
/* 20:   */     
/* 21:44 */     int len = data.readUnsignedShort();
/* 22:45 */     if (len > 0)
/* 23:   */     {
/* 24:46 */       this.mapVarNames = new HashMap(len);
/* 25:47 */       for (int i = 0; i < len; i++)
/* 26:   */       {
/* 27:48 */         data.discard(4);
/* 28:49 */         int nameIndex = data.readUnsignedShort();
/* 29:50 */         data.discard(2);
/* 30:51 */         int varIndex = data.readUnsignedShort();
/* 31:52 */         this.mapVarNames.put(Integer.valueOf(varIndex), pool.getPrimitiveConstant(nameIndex).getString());
/* 32:   */       }
/* 33:   */     }
/* 34:   */     else
/* 35:   */     {
/* 36:56 */       this.mapVarNames = Collections.emptyMap();
/* 37:   */     }
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void addLocalVariableTable(StructLocalVariableTableAttribute attr)
/* 41:   */   {
/* 42:61 */     this.mapVarNames.putAll(attr.getMapVarNames());
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Map<Integer, String> getMapVarNames()
/* 46:   */   {
/* 47:65 */     return this.mapVarNames;
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructLocalVariableTableAttribute
 * JD-Core Version:    0.7.0.1
 */