/*  1:   */ package org.jetbrains.java.decompiler.struct.attr;
/*  2:   */ 
/*  3:   */ import java.io.DataInputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.List;
/*  7:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  8:   */ import org.jetbrains.java.decompiler.struct.consts.LinkConstant;
/*  9:   */ import org.jetbrains.java.decompiler.struct.consts.PooledConstant;
/* 10:   */ 
/* 11:   */ public class StructBootstrapMethodsAttribute
/* 12:   */   extends StructGeneralAttribute
/* 13:   */ {
/* 14:29 */   private final List<LinkConstant> methodRefs = new ArrayList();
/* 15:30 */   private final List<List<PooledConstant>> methodArguments = new ArrayList();
/* 16:   */   
/* 17:   */   public void initContent(ConstantPool pool)
/* 18:   */     throws IOException
/* 19:   */   {
/* 20:34 */     DataInputStream data = stream();
/* 21:   */     
/* 22:36 */     int method_number = data.readUnsignedShort();
/* 23:38 */     for (int i = 0; i < method_number; i++)
/* 24:   */     {
/* 25:39 */       int bootstrap_method_ref = data.readUnsignedShort();
/* 26:40 */       int num_bootstrap_arguments = data.readUnsignedShort();
/* 27:   */       
/* 28:42 */       List<PooledConstant> list_arguments = new ArrayList();
/* 29:44 */       for (int j = 0; j < num_bootstrap_arguments; j++)
/* 30:   */       {
/* 31:45 */         int bootstrap_argument_ref = data.readUnsignedShort();
/* 32:   */         
/* 33:47 */         list_arguments.add(pool.getConstant(bootstrap_argument_ref));
/* 34:   */       }
/* 35:50 */       this.methodRefs.add(pool.getLinkConstant(bootstrap_method_ref));
/* 36:51 */       this.methodArguments.add(list_arguments);
/* 37:   */     }
/* 38:   */   }
/* 39:   */   
/* 40:   */   public int getMethodsNumber()
/* 41:   */   {
/* 42:56 */     return this.methodRefs.size();
/* 43:   */   }
/* 44:   */   
/* 45:   */   public LinkConstant getMethodReference(int index)
/* 46:   */   {
/* 47:60 */     return (LinkConstant)this.methodRefs.get(index);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public List<PooledConstant> getMethodArguments(int index)
/* 51:   */   {
/* 52:64 */     return (List)this.methodArguments.get(index);
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.attr.StructBootstrapMethodsAttribute
 * JD-Core Version:    0.7.0.1
 */