/*   1:    */ package org.jetbrains.java.decompiler.struct.lazy;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import org.jetbrains.java.decompiler.main.extern.IBytecodeProvider;
/*   7:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*   8:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*   9:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  10:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  11:    */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  12:    */ 
/*  13:    */ public class LazyLoader
/*  14:    */ {
/*  15: 30 */   private final Map<String, Link> mapClassLinks = new HashMap();
/*  16:    */   private final IBytecodeProvider provider;
/*  17:    */   
/*  18:    */   public LazyLoader(IBytecodeProvider provider)
/*  19:    */   {
/*  20: 34 */     this.provider = provider;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public void addClassLink(String classname, Link link)
/*  24:    */   {
/*  25: 38 */     this.mapClassLinks.put(classname, link);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void removeClassLink(String classname)
/*  29:    */   {
/*  30: 42 */     this.mapClassLinks.remove(classname);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public Link getClassLink(String classname)
/*  34:    */   {
/*  35: 46 */     return (Link)this.mapClassLinks.get(classname);
/*  36:    */   }
/*  37:    */   
/*  38:    */   /* Error */
/*  39:    */   public ConstantPool loadPool(String classname)
/*  40:    */   {
/*  41:    */     // Byte code:
/*  42:    */     //   0: aload_0
/*  43:    */     //   1: aload_1
/*  44:    */     //   2: invokevirtual 10	org/jetbrains/java/decompiler/struct/lazy/LazyLoader:getClassStream	(Ljava/lang/String;)Lorg/jetbrains/java/decompiler/util/DataInputFullStream;
/*  45:    */     //   5: astore_2
/*  46:    */     //   6: aload_2
/*  47:    */     //   7: ifnonnull +5 -> 12
/*  48:    */     //   10: aconst_null
/*  49:    */     //   11: areturn
/*  50:    */     //   12: aload_2
/*  51:    */     //   13: bipush 8
/*  52:    */     //   15: invokevirtual 11	org/jetbrains/java/decompiler/util/DataInputFullStream:discard	(I)V
/*  53:    */     //   18: new 12	org/jetbrains/java/decompiler/struct/consts/ConstantPool
/*  54:    */     //   21: dup
/*  55:    */     //   22: aload_2
/*  56:    */     //   23: invokespecial 13	org/jetbrains/java/decompiler/struct/consts/ConstantPool:<init>	(Ljava/io/DataInputStream;)V
/*  57:    */     //   26: astore_3
/*  58:    */     //   27: aload_2
/*  59:    */     //   28: invokevirtual 14	org/jetbrains/java/decompiler/util/DataInputFullStream:close	()V
/*  60:    */     //   31: aload_3
/*  61:    */     //   32: areturn
/*  62:    */     //   33: astore 4
/*  63:    */     //   35: aload_2
/*  64:    */     //   36: invokevirtual 14	org/jetbrains/java/decompiler/util/DataInputFullStream:close	()V
/*  65:    */     //   39: aload 4
/*  66:    */     //   41: athrow
/*  67:    */     //   42: astore_2
/*  68:    */     //   43: new 16	java/lang/RuntimeException
/*  69:    */     //   46: dup
/*  70:    */     //   47: aload_2
/*  71:    */     //   48: invokespecial 17	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*  72:    */     //   51: athrow
/*  73:    */     // Line number table:
/*  74:    */     //   Java source line #51	-> byte code offset #0
/*  75:    */     //   Java source line #52	-> byte code offset #6
/*  76:    */     //   Java source line #55	-> byte code offset #12
/*  77:    */     //   Java source line #56	-> byte code offset #18
/*  78:    */     //   Java source line #59	-> byte code offset #27
/*  79:    */     //   Java source line #62	-> byte code offset #42
/*  80:    */     //   Java source line #63	-> byte code offset #43
/*  81:    */     // Local variable table:
/*  82:    */     //   start	length	slot	name	signature
/*  83:    */     //   0	52	0	this	LazyLoader
/*  84:    */     //   0	52	1	classname	String
/*  85:    */     //   5	31	2	in	DataInputFullStream
/*  86:    */     //   42	6	2	ex	IOException
/*  87:    */     //   33	7	4	localObject	Object
/*  88:    */     // Exception table:
/*  89:    */     //   from	to	target	type
/*  90:    */     //   12	27	33	finally
/*  91:    */     //   33	35	33	finally
/*  92:    */     //   0	11	42	java/io/IOException
/*  93:    */     //   12	31	42	java/io/IOException
/*  94:    */     //   33	42	42	java/io/IOException
/*  95:    */   }
/*  96:    */   
/*  97:    */   public byte[] loadBytecode(StructMethod mt, int codeFullLength)
/*  98:    */   {
/*  99: 68 */     String className = mt.getClassStruct().qualifiedName;
/* 100:    */     try
/* 101:    */     {
/* 102: 71 */       DataInputFullStream in = getClassStream(className);
/* 103: 72 */       if (in == null) {
/* 104: 72 */         return null;
/* 105:    */       }
/* 106:    */       try
/* 107:    */       {
/* 108: 75 */         in.discard(8);
/* 109:    */         
/* 110: 77 */         ConstantPool pool = mt.getClassStruct().getPool();
/* 111: 78 */         if (pool == null) {
/* 112: 79 */           pool = new ConstantPool(in);
/* 113:    */         } else {
/* 114: 82 */           ConstantPool.skipPool(in);
/* 115:    */         }
/* 116: 85 */         in.discard(6);
/* 117:    */         
/* 118:    */ 
/* 119: 88 */         in.discard(in.readUnsignedShort() * 2);
/* 120:    */         
/* 121:    */ 
/* 122: 91 */         int size = in.readUnsignedShort();
/* 123: 92 */         for (int i = 0; i < size; i++)
/* 124:    */         {
/* 125: 93 */           in.discard(6);
/* 126: 94 */           skipAttributes(in);
/* 127:    */         }
/* 128: 98 */         size = in.readUnsignedShort();
/* 129: 99 */         for (int i = 0; i < size; i++)
/* 130:    */         {
/* 131:100 */           in.discard(2);
/* 132:    */           
/* 133:102 */           int nameIndex = in.readUnsignedShort();
/* 134:103 */           int descriptorIndex = in.readUnsignedShort();
/* 135:    */           
/* 136:105 */           String[] values = pool.getClassElement(2, className, nameIndex, descriptorIndex);
/* 137:106 */           if ((!mt.getName().equals(values[0])) || (!mt.getDescriptor().equals(values[1])))
/* 138:    */           {
/* 139:107 */             skipAttributes(in);
/* 140:    */           }
/* 141:    */           else
/* 142:    */           {
/* 143:111 */             int attrSize = in.readUnsignedShort();
/* 144:112 */             for (int j = 0; j < attrSize; j++)
/* 145:    */             {
/* 146:113 */               int attrNameIndex = in.readUnsignedShort();
/* 147:114 */               String attrName = pool.getPrimitiveConstant(attrNameIndex).getString();
/* 148:115 */               if (!"Code".equals(attrName))
/* 149:    */               {
/* 150:116 */                 in.discard(in.readInt());
/* 151:    */               }
/* 152:    */               else
/* 153:    */               {
/* 154:120 */                 in.discard(12);
/* 155:121 */                 byte[] code = new byte[codeFullLength];
/* 156:122 */                 in.readFull(code);
/* 157:123 */                 return code;
/* 158:    */               }
/* 159:    */             }
/* 160:126 */             break;
/* 161:    */           }
/* 162:    */         }
/* 163:    */       }
/* 164:    */       finally
/* 165:    */       {
/* 166:130 */         in.close();
/* 167:    */       }
/* 168:133 */       return null;
/* 169:    */     }
/* 170:    */     catch (IOException ex)
/* 171:    */     {
/* 172:136 */       throw new RuntimeException(ex);
/* 173:    */     }
/* 174:    */   }
/* 175:    */   
/* 176:    */   public DataInputFullStream getClassStream(String externalPath, String internalPath)
/* 177:    */     throws IOException
/* 178:    */   {
/* 179:141 */     byte[] bytes = this.provider.getBytecode(externalPath, internalPath);
/* 180:142 */     return new DataInputFullStream(bytes);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public DataInputFullStream getClassStream(String qualifiedClassName)
/* 184:    */     throws IOException
/* 185:    */   {
/* 186:146 */     Link link = (Link)this.mapClassLinks.get(qualifiedClassName);
/* 187:147 */     return link == null ? null : getClassStream(link.externalPath, link.internalPath);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public static void skipAttributes(DataInputFullStream in)
/* 191:    */     throws IOException
/* 192:    */   {
/* 193:151 */     int length = in.readUnsignedShort();
/* 194:152 */     for (int i = 0; i < length; i++)
/* 195:    */     {
/* 196:153 */       in.discard(2);
/* 197:154 */       in.discard(in.readInt());
/* 198:    */     }
/* 199:    */   }
/* 200:    */   
/* 201:    */   public static class Link
/* 202:    */   {
/* 203:    */     public static final int CLASS = 1;
/* 204:    */     public static final int ENTRY = 2;
/* 205:    */     public final int type;
/* 206:    */     public final String externalPath;
/* 207:    */     public final String internalPath;
/* 208:    */     
/* 209:    */     public Link(int type, String externalPath, String internalPath)
/* 210:    */     {
/* 211:168 */       this.type = type;
/* 212:169 */       this.externalPath = externalPath;
/* 213:170 */       this.internalPath = internalPath;
/* 214:    */     }
/* 215:    */   }
/* 216:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.lazy.LazyLoader
 * JD-Core Version:    0.7.0.1
 */