/*   1:    */ package org.jetbrains.java.decompiler.struct;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.util.Enumeration;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.jar.JarFile;
/*   9:    */ import java.util.zip.ZipEntry;
/*  10:    */ import java.util.zip.ZipFile;
/*  11:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  12:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*  13:    */ import org.jetbrains.java.decompiler.main.extern.IResultSaver;
/*  14:    */ import org.jetbrains.java.decompiler.struct.lazy.LazyLoader;
/*  15:    */ import org.jetbrains.java.decompiler.struct.lazy.LazyLoader.Link;
/*  16:    */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  17:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  18:    */ 
/*  19:    */ public class StructContext
/*  20:    */ {
/*  21:    */   private final IResultSaver saver;
/*  22:    */   private final IDecompiledData decompiledData;
/*  23:    */   private final LazyLoader loader;
/*  24: 38 */   private final Map<String, ContextUnit> units = new HashMap();
/*  25: 39 */   private final Map<String, StructClass> classes = new HashMap();
/*  26:    */   
/*  27:    */   public StructContext(IResultSaver saver, IDecompiledData decompiledData, LazyLoader loader)
/*  28:    */   {
/*  29: 42 */     this.saver = saver;
/*  30: 43 */     this.decompiledData = decompiledData;
/*  31: 44 */     this.loader = loader;
/*  32:    */     
/*  33: 46 */     ContextUnit defaultUnit = new ContextUnit(0, null, "", true, saver, decompiledData);
/*  34: 47 */     this.units.put("", defaultUnit);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public StructClass getClass(String name)
/*  38:    */   {
/*  39: 51 */     return (StructClass)this.classes.get(name);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void reloadContext()
/*  43:    */     throws IOException
/*  44:    */   {
/*  45: 55 */     for (ContextUnit unit : this.units.values())
/*  46:    */     {
/*  47: 56 */       for (StructClass cl : unit.getClasses()) {
/*  48: 57 */         this.classes.remove(cl.qualifiedName);
/*  49:    */       }
/*  50: 60 */       unit.reload(this.loader);
/*  51: 63 */       for (StructClass cl : unit.getClasses()) {
/*  52: 64 */         this.classes.put(cl.qualifiedName, cl);
/*  53:    */       }
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void saveContext()
/*  58:    */   {
/*  59: 70 */     for (ContextUnit unit : this.units.values()) {
/*  60: 71 */       if (unit.isOwn()) {
/*  61: 72 */         unit.save();
/*  62:    */       }
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void addSpace(File file, boolean isOwn)
/*  67:    */   {
/*  68: 78 */     addSpace("", file, isOwn, 0);
/*  69:    */   }
/*  70:    */   
/*  71:    */   private void addSpace(String path, File file, boolean isOwn, int level)
/*  72:    */   {
/*  73: 82 */     if (file.isDirectory())
/*  74:    */     {
/*  75: 83 */       if (level == 1) {
/*  76: 83 */         path = path + file.getName();
/*  77: 84 */       } else if (level > 1) {
/*  78: 84 */         path = path + "/" + file.getName();
/*  79:    */       }
/*  80: 86 */       File[] files = file.listFiles();
/*  81: 87 */       if (files != null) {
/*  82: 88 */         for (int i = files.length - 1; i >= 0; i--) {
/*  83: 89 */           addSpace(path, files[i], isOwn, level + 1);
/*  84:    */         }
/*  85:    */       }
/*  86:    */     }
/*  87:    */     else
/*  88:    */     {
/*  89: 94 */       String filename = file.getName();
/*  90:    */       
/*  91: 96 */       boolean isArchive = false;
/*  92:    */       try
/*  93:    */       {
/*  94: 98 */         if (filename.endsWith(".jar"))
/*  95:    */         {
/*  96: 99 */           isArchive = true;
/*  97:100 */           addArchive(path, file, 1, isOwn);
/*  98:    */         }
/*  99:102 */         else if (filename.endsWith(".zip"))
/* 100:    */         {
/* 101:103 */           isArchive = true;
/* 102:104 */           addArchive(path, file, 2, isOwn);
/* 103:    */         }
/* 104:    */       }
/* 105:    */       catch (IOException ex)
/* 106:    */       {
/* 107:108 */         String message = "Corrupted archive file: " + file;
/* 108:109 */         DecompilerContext.getLogger().writeMessage(message, ex);
/* 109:    */       }
/* 110:111 */       if (isArchive) {
/* 111:112 */         return;
/* 112:    */       }
/* 113:115 */       ContextUnit unit = (ContextUnit)this.units.get(path);
/* 114:116 */       if (unit == null)
/* 115:    */       {
/* 116:117 */         unit = new ContextUnit(0, null, path, isOwn, this.saver, this.decompiledData);
/* 117:118 */         this.units.put(path, unit);
/* 118:    */       }
/* 119:121 */       if (filename.endsWith(".class")) {
/* 120:    */         try
/* 121:    */         {
/* 122:123 */           DataInputFullStream in = this.loader.getClassStream(file.getAbsolutePath(), null);
/* 123:    */           try
/* 124:    */           {
/* 125:125 */             StructClass cl = new StructClass(in, isOwn, this.loader);
/* 126:126 */             this.classes.put(cl.qualifiedName, cl);
/* 127:127 */             unit.addClass(cl, filename);
/* 128:128 */             this.loader.addClassLink(cl.qualifiedName, new LazyLoader.Link(1, file.getAbsolutePath(), null));
/* 129:    */           }
/* 130:    */           finally
/* 131:    */           {
/* 132:131 */             in.close();
/* 133:    */           }
/* 134:    */         }
/* 135:    */         catch (IOException ex)
/* 136:    */         {
/* 137:135 */           String message = "Corrupted class file: " + file;
/* 138:136 */           DecompilerContext.getLogger().writeMessage(message, ex);
/* 139:    */         }
/* 140:    */       } else {
/* 141:140 */         unit.addOtherEntry(file.getAbsolutePath(), filename);
/* 142:    */       }
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   private void addArchive(String path, File file, int type, boolean isOwn)
/* 147:    */     throws IOException
/* 148:    */   {
/* 149:147 */     ZipFile archive = type == 1 ? new JarFile(file) : new ZipFile(file);
/* 150:    */     try
/* 151:    */     {
/* 152:150 */       Enumeration<? extends ZipEntry> entries = archive.entries();
/* 153:151 */       while (entries.hasMoreElements())
/* 154:    */       {
/* 155:152 */         ZipEntry entry = (ZipEntry)entries.nextElement();
/* 156:    */         
/* 157:154 */         ContextUnit unit = (ContextUnit)this.units.get(path + "/" + file.getName());
/* 158:155 */         if (unit == null)
/* 159:    */         {
/* 160:156 */           unit = new ContextUnit(type, path, file.getName(), isOwn, this.saver, this.decompiledData);
/* 161:157 */           if (type == 1) {
/* 162:158 */             unit.setManifest(((JarFile)archive).getManifest());
/* 163:    */           }
/* 164:160 */           this.units.put(path + "/" + file.getName(), unit);
/* 165:    */         }
/* 166:163 */         String name = entry.getName();
/* 167:164 */         if (!entry.isDirectory())
/* 168:    */         {
/* 169:165 */           if (name.endsWith(".class"))
/* 170:    */           {
/* 171:166 */             byte[] bytes = InterpreterUtil.getBytes(archive, entry);
/* 172:167 */             StructClass cl = new StructClass(bytes, isOwn, this.loader);
/* 173:168 */             this.classes.put(cl.qualifiedName, cl);
/* 174:169 */             unit.addClass(cl, name);
/* 175:170 */             this.loader.addClassLink(cl.qualifiedName, new LazyLoader.Link(2, file.getAbsolutePath(), name));
/* 176:    */           }
/* 177:    */           else
/* 178:    */           {
/* 179:173 */             unit.addOtherEntry(file.getAbsolutePath(), name);
/* 180:    */           }
/* 181:    */         }
/* 182:    */         else {
/* 183:177 */           unit.addDirEntry(name);
/* 184:    */         }
/* 185:    */       }
/* 186:    */     }
/* 187:    */     finally
/* 188:    */     {
/* 189:182 */       archive.close();
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   public Map<String, StructClass> getClasses()
/* 194:    */   {
/* 195:187 */     return this.classes;
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.StructContext
 * JD-Core Version:    0.7.0.1
 */