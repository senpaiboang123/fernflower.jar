/*   1:    */ package org.jetbrains.java.decompiler.struct;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*   5:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*   6:    */ import org.jetbrains.java.decompiler.struct.lazy.LazyLoader;
/*   7:    */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*   8:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*   9:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  10:    */ 
/*  11:    */ public class StructClass
/*  12:    */   extends StructMember
/*  13:    */ {
/*  14:    */   public final String qualifiedName;
/*  15:    */   public final PrimitiveConstant superClass;
/*  16:    */   private final boolean own;
/*  17:    */   private final LazyLoader loader;
/*  18:    */   private final int minorVersion;
/*  19:    */   private final int majorVersion;
/*  20:    */   private final int[] interfaces;
/*  21:    */   private final String[] interfaceNames;
/*  22:    */   private final VBStyleCollection<StructField, String> fields;
/*  23:    */   private final VBStyleCollection<StructMethod, String> methods;
/*  24:    */   private ConstantPool pool;
/*  25:    */   
/*  26:    */   public StructClass(byte[] bytes, boolean own, LazyLoader loader)
/*  27:    */     throws IOException
/*  28:    */   {
/*  29: 65 */     this(new DataInputFullStream(bytes), own, loader);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public StructClass(DataInputFullStream in, boolean own, LazyLoader loader)
/*  33:    */     throws IOException
/*  34:    */   {
/*  35: 69 */     this.own = own;
/*  36: 70 */     this.loader = loader;
/*  37:    */     
/*  38: 72 */     in.discard(4);
/*  39:    */     
/*  40: 74 */     this.minorVersion = in.readUnsignedShort();
/*  41: 75 */     this.majorVersion = in.readUnsignedShort();
/*  42:    */     
/*  43: 77 */     this.pool = new ConstantPool(in);
/*  44:    */     
/*  45: 79 */     this.accessFlags = in.readUnsignedShort();
/*  46: 80 */     int thisClassIdx = in.readUnsignedShort();
/*  47: 81 */     int superClassIdx = in.readUnsignedShort();
/*  48: 82 */     this.qualifiedName = this.pool.getPrimitiveConstant(thisClassIdx).getString();
/*  49: 83 */     this.superClass = this.pool.getPrimitiveConstant(superClassIdx);
/*  50:    */     
/*  51:    */ 
/*  52: 86 */     int length = in.readUnsignedShort();
/*  53: 87 */     this.interfaces = new int[length];
/*  54: 88 */     this.interfaceNames = new String[length];
/*  55: 89 */     for (int i = 0; i < length; i++)
/*  56:    */     {
/*  57: 90 */       this.interfaces[i] = in.readUnsignedShort();
/*  58: 91 */       this.interfaceNames[i] = this.pool.getPrimitiveConstant(this.interfaces[i]).getString();
/*  59:    */     }
/*  60: 95 */     length = in.readUnsignedShort();
/*  61: 96 */     this.fields = new VBStyleCollection();
/*  62: 97 */     for (int i = 0; i < length; i++)
/*  63:    */     {
/*  64: 98 */       StructField field = new StructField(in, this);
/*  65: 99 */       this.fields.addWithKey(field, InterpreterUtil.makeUniqueKey(field.getName(), field.getDescriptor()));
/*  66:    */     }
/*  67:103 */     length = in.readUnsignedShort();
/*  68:104 */     this.methods = new VBStyleCollection();
/*  69:105 */     for (int i = 0; i < length; i++)
/*  70:    */     {
/*  71:106 */       StructMethod method = new StructMethod(in, this);
/*  72:107 */       this.methods.addWithKey(method, InterpreterUtil.makeUniqueKey(method.getName(), method.getDescriptor()));
/*  73:    */     }
/*  74:111 */     this.attributes = readAttributes(in, this.pool);
/*  75:    */     
/*  76:113 */     releaseResources();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean hasField(String name, String descriptor)
/*  80:    */   {
/*  81:117 */     return getField(name, descriptor) != null;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public StructField getField(String name, String descriptor)
/*  85:    */   {
/*  86:121 */     return (StructField)this.fields.getWithKey(InterpreterUtil.makeUniqueKey(name, descriptor));
/*  87:    */   }
/*  88:    */   
/*  89:    */   public StructMethod getMethod(String key)
/*  90:    */   {
/*  91:125 */     return (StructMethod)this.methods.getWithKey(key);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public StructMethod getMethod(String name, String descriptor)
/*  95:    */   {
/*  96:129 */     return (StructMethod)this.methods.getWithKey(InterpreterUtil.makeUniqueKey(name, descriptor));
/*  97:    */   }
/*  98:    */   
/*  99:    */   public String getInterface(int i)
/* 100:    */   {
/* 101:133 */     return this.interfaceNames[i];
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void releaseResources()
/* 105:    */   {
/* 106:137 */     if (this.loader != null) {
/* 107:138 */       this.pool = null;
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */   public ConstantPool getPool()
/* 112:    */   {
/* 113:143 */     if ((this.pool == null) && (this.loader != null)) {
/* 114:144 */       this.pool = this.loader.loadPool(this.qualifiedName);
/* 115:    */     }
/* 116:146 */     return this.pool;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public int[] getInterfaces()
/* 120:    */   {
/* 121:150 */     return this.interfaces;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public String[] getInterfaceNames()
/* 125:    */   {
/* 126:154 */     return this.interfaceNames;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public VBStyleCollection<StructMethod, String> getMethods()
/* 130:    */   {
/* 131:158 */     return this.methods;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public VBStyleCollection<StructField, String> getFields()
/* 135:    */   {
/* 136:162 */     return this.fields;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public boolean isOwn()
/* 140:    */   {
/* 141:166 */     return this.own;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public LazyLoader getLoader()
/* 145:    */   {
/* 146:170 */     return this.loader;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public boolean isVersionGE_1_5()
/* 150:    */   {
/* 151:174 */     return (this.majorVersion > 48) || ((this.majorVersion == 48) && (this.minorVersion > 0));
/* 152:    */   }
/* 153:    */   
/* 154:    */   public boolean isVersionGE_1_7()
/* 155:    */   {
/* 156:178 */     return this.majorVersion >= 51;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public int getBytecodeVersion()
/* 160:    */   {
/* 161:182 */     switch (this.majorVersion)
/* 162:    */     {
/* 163:    */     case 52: 
/* 164:184 */       return 5;
/* 165:    */     case 51: 
/* 166:186 */       return 4;
/* 167:    */     case 50: 
/* 168:188 */       return 3;
/* 169:    */     case 49: 
/* 170:190 */       return 2;
/* 171:    */     }
/* 172:193 */     return 1;
/* 173:    */   }
/* 174:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.StructClass
 * JD-Core Version:    0.7.0.1
 */