/*   1:    */ package org.jetbrains.java.decompiler.struct;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.List;
/*   6:    */ import org.jetbrains.java.decompiler.code.ConstantsUtil;
/*   7:    */ import org.jetbrains.java.decompiler.code.ExceptionHandler;
/*   8:    */ import org.jetbrains.java.decompiler.code.ExceptionTable;
/*   9:    */ import org.jetbrains.java.decompiler.code.FullInstructionSequence;
/*  10:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*  11:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*  12:    */ import org.jetbrains.java.decompiler.struct.attr.StructGeneralAttribute;
/*  13:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  14:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  15:    */ import org.jetbrains.java.decompiler.struct.lazy.LazyLoader;
/*  16:    */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  17:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  18:    */ 
/*  19:    */ public class StructMethod
/*  20:    */   extends StructMember
/*  21:    */ {
/*  22: 41 */   private static final int[] opr_iconst = { -1, 0, 1, 2, 3, 4, 5 };
/*  23: 42 */   private static final int[] opr_loadstore = { 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3 };
/*  24: 43 */   private static final int[] opcs_load = { 21, 22, 23, 24, 25 };
/*  25: 44 */   private static final int[] opcs_store = { 54, 55, 56, 57, 58 };
/*  26:    */   private final StructClass classStruct;
/*  27:    */   private final String name;
/*  28:    */   private final String descriptor;
/*  29: 50 */   private boolean containsCode = false;
/*  30: 51 */   private int localVariables = 0;
/*  31: 52 */   private int codeLength = 0;
/*  32: 53 */   private int codeFullLength = 0;
/*  33:    */   private InstructionSequence seq;
/*  34: 55 */   private boolean expanded = false;
/*  35:    */   private VBStyleCollection<StructGeneralAttribute, String> codeAttributes;
/*  36:    */   
/*  37:    */   public StructMethod(DataInputFullStream in, StructClass clStruct)
/*  38:    */     throws IOException
/*  39:    */   {
/*  40: 59 */     this.classStruct = clStruct;
/*  41:    */     
/*  42: 61 */     this.accessFlags = in.readUnsignedShort();
/*  43: 62 */     int nameIndex = in.readUnsignedShort();
/*  44: 63 */     int descriptorIndex = in.readUnsignedShort();
/*  45:    */     
/*  46: 65 */     ConstantPool pool = clStruct.getPool();
/*  47: 66 */     String[] values = pool.getClassElement(2, clStruct.qualifiedName, nameIndex, descriptorIndex);
/*  48: 67 */     this.name = values[0];
/*  49: 68 */     this.descriptor = values[1];
/*  50:    */     
/*  51: 70 */     this.attributes = readAttributes(in, pool);
/*  52: 71 */     if (this.codeAttributes != null)
/*  53:    */     {
/*  54: 72 */       this.attributes.addAllWithKey(this.codeAttributes);
/*  55: 73 */       this.codeAttributes = null;
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected StructGeneralAttribute readAttribute(DataInputFullStream in, ConstantPool pool, String name)
/*  60:    */     throws IOException
/*  61:    */   {
/*  62: 79 */     if ("Code".equals(name))
/*  63:    */     {
/*  64: 80 */       if (!this.classStruct.isOwn())
/*  65:    */       {
/*  66: 82 */         in.discard(8);
/*  67: 83 */         in.discard(in.readInt());
/*  68: 84 */         in.discard(8 * in.readUnsignedShort());
/*  69:    */       }
/*  70:    */       else
/*  71:    */       {
/*  72: 87 */         this.containsCode = true;
/*  73: 88 */         in.discard(6);
/*  74: 89 */         this.localVariables = in.readUnsignedShort();
/*  75: 90 */         this.codeLength = in.readInt();
/*  76: 91 */         in.discard(this.codeLength);
/*  77: 92 */         int excLength = in.readUnsignedShort();
/*  78: 93 */         in.discard(excLength * 8);
/*  79: 94 */         this.codeFullLength = (this.codeLength + excLength * 8 + 2);
/*  80:    */       }
/*  81: 97 */       this.codeAttributes = readAttributes(in, pool);
/*  82:    */       
/*  83: 99 */       return null;
/*  84:    */     }
/*  85:102 */     return super.readAttribute(in, pool, name);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void expandData()
/*  89:    */     throws IOException
/*  90:    */   {
/*  91:106 */     if ((this.containsCode) && (!this.expanded))
/*  92:    */     {
/*  93:107 */       byte[] code = this.classStruct.getLoader().loadBytecode(this, this.codeFullLength);
/*  94:108 */       this.seq = parseBytecode(new DataInputFullStream(code), this.codeLength, this.classStruct.getPool());
/*  95:109 */       this.expanded = true;
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void releaseResources()
/* 100:    */     throws IOException
/* 101:    */   {
/* 102:114 */     if ((this.containsCode) && (this.expanded))
/* 103:    */     {
/* 104:115 */       this.seq = null;
/* 105:116 */       this.expanded = false;
/* 106:    */     }
/* 107:    */   }
/* 108:    */   
/* 109:    */   private InstructionSequence parseBytecode(DataInputFullStream in, int length, ConstantPool pool)
/* 110:    */     throws IOException
/* 111:    */   {
/* 112:122 */     VBStyleCollection<Instruction, Integer> instructions = new VBStyleCollection();
/* 113:    */     
/* 114:124 */     int bytecode_version = this.classStruct.getBytecodeVersion();
/* 115:126 */     for (int i = 0; i < length;)
/* 116:    */     {
/* 117:128 */       int offset = i;
/* 118:    */       
/* 119:130 */       int opcode = in.readUnsignedByte();
/* 120:131 */       int group = 1;
/* 121:    */       
/* 122:133 */       boolean wide = opcode == 196;
/* 123:135 */       if (wide)
/* 124:    */       {
/* 125:136 */         i++;
/* 126:137 */         opcode = in.readUnsignedByte();
/* 127:    */       }
/* 128:140 */       List<Integer> operands = new ArrayList();
/* 129:142 */       if ((opcode >= 2) && (opcode <= 8))
/* 130:    */       {
/* 131:143 */         operands.add(new Integer(opr_iconst[(opcode - 2)]));
/* 132:144 */         opcode = 16;
/* 133:    */       }
/* 134:146 */       else if ((opcode >= 26) && (opcode <= 45))
/* 135:    */       {
/* 136:147 */         operands.add(new Integer(opr_loadstore[(opcode - 26)]));
/* 137:148 */         opcode = opcs_load[((opcode - 26) / 4)];
/* 138:    */       }
/* 139:150 */       else if ((opcode >= 59) && (opcode <= 78))
/* 140:    */       {
/* 141:151 */         operands.add(new Integer(opr_loadstore[(opcode - 59)]));
/* 142:152 */         opcode = opcs_store[((opcode - 59) / 4)];
/* 143:    */       }
/* 144:    */       else
/* 145:    */       {
/* 146:155 */         switch (opcode)
/* 147:    */         {
/* 148:    */         case 16: 
/* 149:157 */           operands.add(new Integer(in.readByte()));
/* 150:158 */           i++;
/* 151:159 */           break;
/* 152:    */         case 18: 
/* 153:    */         case 188: 
/* 154:162 */           operands.add(new Integer(in.readUnsignedByte()));
/* 155:163 */           i++;
/* 156:164 */           break;
/* 157:    */         case 17: 
/* 158:    */         case 153: 
/* 159:    */         case 154: 
/* 160:    */         case 155: 
/* 161:    */         case 156: 
/* 162:    */         case 157: 
/* 163:    */         case 158: 
/* 164:    */         case 159: 
/* 165:    */         case 160: 
/* 166:    */         case 161: 
/* 167:    */         case 162: 
/* 168:    */         case 163: 
/* 169:    */         case 164: 
/* 170:    */         case 165: 
/* 171:    */         case 166: 
/* 172:    */         case 167: 
/* 173:    */         case 168: 
/* 174:    */         case 198: 
/* 175:    */         case 199: 
/* 176:184 */           if (opcode != 17) {
/* 177:185 */             group = 2;
/* 178:    */           }
/* 179:187 */           operands.add(new Integer(in.readShort()));
/* 180:188 */           i += 2;
/* 181:189 */           break;
/* 182:    */         case 19: 
/* 183:    */         case 20: 
/* 184:    */         case 178: 
/* 185:    */         case 179: 
/* 186:    */         case 180: 
/* 187:    */         case 181: 
/* 188:    */         case 182: 
/* 189:    */         case 183: 
/* 190:    */         case 184: 
/* 191:    */         case 187: 
/* 192:    */         case 189: 
/* 193:    */         case 192: 
/* 194:    */         case 193: 
/* 195:203 */           operands.add(new Integer(in.readUnsignedShort()));
/* 196:204 */           i += 2;
/* 197:205 */           if ((opcode >= 178) && (opcode <= 181)) {
/* 198:206 */             group = 5;
/* 199:208 */           } else if ((opcode >= 182) && (opcode <= 184)) {
/* 200:209 */             group = 4;
/* 201:    */           }
/* 202:    */           break;
/* 203:    */         case 186: 
/* 204:213 */           if (this.classStruct.isVersionGE_1_7())
/* 205:    */           {
/* 206:214 */             operands.add(new Integer(in.readUnsignedShort()));
/* 207:215 */             in.discard(2);
/* 208:216 */             group = 4;
/* 209:217 */             i += 4;
/* 210:    */           }
/* 211:    */           break;
/* 212:    */         case 21: 
/* 213:    */         case 22: 
/* 214:    */         case 23: 
/* 215:    */         case 24: 
/* 216:    */         case 25: 
/* 217:    */         case 54: 
/* 218:    */         case 55: 
/* 219:    */         case 56: 
/* 220:    */         case 57: 
/* 221:    */         case 58: 
/* 222:    */         case 169: 
/* 223:231 */           if (wide)
/* 224:    */           {
/* 225:232 */             operands.add(new Integer(in.readUnsignedShort()));
/* 226:233 */             i += 2;
/* 227:    */           }
/* 228:    */           else
/* 229:    */           {
/* 230:236 */             operands.add(new Integer(in.readUnsignedByte()));
/* 231:237 */             i++;
/* 232:    */           }
/* 233:239 */           if (opcode == 169) {
/* 234:240 */             group = 6;
/* 235:    */           }
/* 236:    */           break;
/* 237:    */         case 132: 
/* 238:244 */           if (wide)
/* 239:    */           {
/* 240:245 */             operands.add(new Integer(in.readUnsignedShort()));
/* 241:246 */             operands.add(new Integer(in.readShort()));
/* 242:247 */             i += 4;
/* 243:    */           }
/* 244:    */           else
/* 245:    */           {
/* 246:250 */             operands.add(new Integer(in.readUnsignedByte()));
/* 247:251 */             operands.add(new Integer(in.readByte()));
/* 248:252 */             i += 2;
/* 249:    */           }
/* 250:254 */           break;
/* 251:    */         case 200: 
/* 252:    */         case 201: 
/* 253:257 */           opcode = opcode == 201 ? 168 : 167;
/* 254:258 */           operands.add(new Integer(in.readInt()));
/* 255:259 */           group = 2;
/* 256:260 */           i += 4;
/* 257:261 */           break;
/* 258:    */         case 185: 
/* 259:263 */           operands.add(new Integer(in.readUnsignedShort()));
/* 260:264 */           operands.add(new Integer(in.readUnsignedByte()));
/* 261:265 */           in.discard(1);
/* 262:266 */           group = 4;
/* 263:267 */           i += 4;
/* 264:268 */           break;
/* 265:    */         case 197: 
/* 266:270 */           operands.add(new Integer(in.readUnsignedShort()));
/* 267:271 */           operands.add(new Integer(in.readUnsignedByte()));
/* 268:272 */           i += 3;
/* 269:273 */           break;
/* 270:    */         case 170: 
/* 271:275 */           in.discard((4 - (i + 1) % 4) % 4);
/* 272:276 */           i += (4 - (i + 1) % 4) % 4;
/* 273:277 */           operands.add(new Integer(in.readInt()));
/* 274:278 */           i += 4;
/* 275:279 */           int low = in.readInt();
/* 276:280 */           operands.add(new Integer(low));
/* 277:281 */           i += 4;
/* 278:282 */           int high = in.readInt();
/* 279:283 */           operands.add(new Integer(high));
/* 280:284 */           i += 4;
/* 281:286 */           for (int j = 0; j < high - low + 1; j++)
/* 282:    */           {
/* 283:287 */             operands.add(new Integer(in.readInt()));
/* 284:288 */             i += 4;
/* 285:    */           }
/* 286:290 */           group = 3;
/* 287:    */           
/* 288:292 */           break;
/* 289:    */         case 171: 
/* 290:294 */           in.discard((4 - (i + 1) % 4) % 4);
/* 291:295 */           i += (4 - (i + 1) % 4) % 4;
/* 292:296 */           operands.add(new Integer(in.readInt()));
/* 293:297 */           i += 4;
/* 294:298 */           int npairs = in.readInt();
/* 295:299 */           operands.add(new Integer(npairs));
/* 296:300 */           i += 4;
/* 297:302 */           for (int j = 0; j < npairs; j++)
/* 298:    */           {
/* 299:303 */             operands.add(new Integer(in.readInt()));
/* 300:304 */             i += 4;
/* 301:305 */             operands.add(new Integer(in.readInt()));
/* 302:306 */             i += 4;
/* 303:    */           }
/* 304:308 */           group = 3;
/* 305:309 */           break;
/* 306:    */         case 172: 
/* 307:    */         case 173: 
/* 308:    */         case 174: 
/* 309:    */         case 175: 
/* 310:    */         case 176: 
/* 311:    */         case 177: 
/* 312:    */         case 191: 
/* 313:317 */           group = 6;
/* 314:    */         }
/* 315:    */       }
/* 316:321 */       int[] ops = new int[operands.size()];
/* 317:322 */       for (int j = 0; j < operands.size(); j++) {
/* 318:323 */         ops[j] = ((Integer)operands.get(j)).intValue();
/* 319:    */       }
/* 320:326 */       Instruction instr = ConstantsUtil.getInstructionInstance(opcode, wide, group, bytecode_version, ops);
/* 321:    */       
/* 322:328 */       instructions.addWithKey(instr, new Integer(offset));
/* 323:    */       
/* 324:330 */       i++;
/* 325:    */     }
/* 326:334 */     List<ExceptionHandler> lstHandlers = new ArrayList();
/* 327:    */     
/* 328:336 */     int exception_count = in.readUnsignedShort();
/* 329:337 */     for (int i = 0; i < exception_count; i++)
/* 330:    */     {
/* 331:338 */       ExceptionHandler handler = new ExceptionHandler();
/* 332:339 */       handler.from = in.readUnsignedShort();
/* 333:340 */       handler.to = in.readUnsignedShort();
/* 334:341 */       handler.handler = in.readUnsignedShort();
/* 335:    */       
/* 336:343 */       int excclass = in.readUnsignedShort();
/* 337:344 */       handler.class_index = excclass;
/* 338:345 */       if (excclass != 0) {
/* 339:346 */         handler.exceptionClass = pool.getPrimitiveConstant(excclass).getString();
/* 340:    */       }
/* 341:349 */       lstHandlers.add(handler);
/* 342:    */     }
/* 343:352 */     InstructionSequence seq = new FullInstructionSequence(instructions, new ExceptionTable(lstHandlers));
/* 344:    */     
/* 345:    */ 
/* 346:355 */     int i = seq.length() - 1;
/* 347:356 */     seq.setPointer(i);
/* 348:358 */     while (i >= 0)
/* 349:    */     {
/* 350:359 */       Instruction instr = seq.getInstr(i--);
/* 351:360 */       if (instr.group != 1) {
/* 352:361 */         instr.initInstruction(seq);
/* 353:    */       }
/* 354:363 */       seq.addToPointer(-1);
/* 355:    */     }
/* 356:366 */     return seq;
/* 357:    */   }
/* 358:    */   
/* 359:    */   public StructClass getClassStruct()
/* 360:    */   {
/* 361:370 */     return this.classStruct;
/* 362:    */   }
/* 363:    */   
/* 364:    */   public String getName()
/* 365:    */   {
/* 366:374 */     return this.name;
/* 367:    */   }
/* 368:    */   
/* 369:    */   public String getDescriptor()
/* 370:    */   {
/* 371:378 */     return this.descriptor;
/* 372:    */   }
/* 373:    */   
/* 374:    */   public boolean containsCode()
/* 375:    */   {
/* 376:382 */     return this.containsCode;
/* 377:    */   }
/* 378:    */   
/* 379:    */   public int getLocalVariables()
/* 380:    */   {
/* 381:386 */     return this.localVariables;
/* 382:    */   }
/* 383:    */   
/* 384:    */   public InstructionSequence getInstructionSequence()
/* 385:    */   {
/* 386:390 */     return this.seq;
/* 387:    */   }
/* 388:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.StructMethod
 * JD-Core Version:    0.7.0.1
 */