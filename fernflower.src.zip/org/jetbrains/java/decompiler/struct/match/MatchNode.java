/*  1:   */ package org.jetbrains.java.decompiler.struct.match;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.HashMap;
/*  5:   */ import java.util.List;
/*  6:   */ import java.util.Map;
/*  7:   */ 
/*  8:   */ public class MatchNode
/*  9:   */ {
/* 10:   */   public static final int MATCHNODE_STATEMENT = 0;
/* 11:   */   public static final int MATCHNODE_EXPRENT = 1;
/* 12:   */   private final int type;
/* 13:   */   
/* 14:   */   public static class RuleValue
/* 15:   */   {
/* 16:   */     public final int parameter;
/* 17:   */     public final Object value;
/* 18:   */     
/* 19:   */     public RuleValue(int parameter, Object value)
/* 20:   */     {
/* 21:32 */       this.parameter = parameter;
/* 22:33 */       this.value = value;
/* 23:   */     }
/* 24:   */     
/* 25:   */     public boolean isVariable()
/* 26:   */     {
/* 27:37 */       String strValue = this.value.toString();
/* 28:38 */       return (strValue.charAt(0) == '$') && (strValue.charAt(strValue.length() - 1) == '$');
/* 29:   */     }
/* 30:   */     
/* 31:   */     public String toString()
/* 32:   */     {
/* 33:42 */       return this.value.toString();
/* 34:   */     }
/* 35:   */   }
/* 36:   */   
/* 37:51 */   private final Map<IMatchable.MatchProperties, RuleValue> rules = new HashMap();
/* 38:53 */   private final List<MatchNode> children = new ArrayList();
/* 39:   */   
/* 40:   */   public MatchNode(int type)
/* 41:   */   {
/* 42:57 */     this.type = type;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void addChild(MatchNode child)
/* 46:   */   {
/* 47:61 */     this.children.add(child);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void addRule(IMatchable.MatchProperties property, RuleValue value)
/* 51:   */   {
/* 52:65 */     this.rules.put(property, value);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public int getType()
/* 56:   */   {
/* 57:69 */     return this.type;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public List<MatchNode> getChildren()
/* 61:   */   {
/* 62:73 */     return this.children;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public Map<IMatchable.MatchProperties, RuleValue> getRules()
/* 66:   */   {
/* 67:77 */     return this.rules;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public Object getRuleValue(IMatchable.MatchProperties property)
/* 71:   */   {
/* 72:81 */     RuleValue rule = (RuleValue)this.rules.get(property);
/* 73:82 */     return rule == null ? null : rule.value;
/* 74:   */   }
/* 75:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.match.MatchNode
 * JD-Core Version:    0.7.0.1
 */