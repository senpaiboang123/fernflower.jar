/*  1:   */ package org.jetbrains.java.decompiler.struct.match;
/*  2:   */ 
/*  3:   */ public abstract interface IMatchable
/*  4:   */ {
/*  5:   */   public abstract IMatchable findObject(MatchNode paramMatchNode, int paramInt);
/*  6:   */   
/*  7:   */   public abstract boolean match(MatchNode paramMatchNode, MatchEngine paramMatchEngine);
/*  8:   */   
/*  9:   */   public static enum MatchProperties
/* 10:   */   {
/* 11:22 */     STATEMENT_TYPE,  STATEMENT_RET,  STATEMENT_STATSIZE,  STATEMENT_EXPRSIZE,  STATEMENT_POSITION,  STATEMENT_IFTYPE,  EXPRENT_TYPE,  EXPRENT_RET,  EXPRENT_POSITION,  EXPRENT_FUNCTYPE,  EXPRENT_EXITTYPE,  EXPRENT_CONSTTYPE,  EXPRENT_CONSTVALUE,  EXPRENT_INVOCATION_CLASS,  EXPRENT_INVOCATION_SIGNATURE,  EXPRENT_INVOCATION_PARAMETER,  EXPRENT_VAR_INDEX,  EXPRENT_FIELD_NAME;
/* 12:   */     
/* 13:   */     private MatchProperties() {}
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.match.IMatchable
 * JD-Core Version:    0.7.0.1
 */