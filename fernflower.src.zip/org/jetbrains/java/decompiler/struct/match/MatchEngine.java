/*   1:    */ package org.jetbrains.java.decompiler.struct.match;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.LinkedList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  10:    */ 
/*  11:    */ public class MatchEngine
/*  12:    */ {
/*  13: 37 */   private MatchNode rootNode = null;
/*  14: 39 */   private final Map<String, Object> variables = new HashMap();
/*  15: 41 */   private static final Map<String, IMatchable.MatchProperties> stat_properties = new HashMap();
/*  16: 42 */   private static final Map<String, IMatchable.MatchProperties> expr_properties = new HashMap();
/*  17: 43 */   private static final Map<String, Integer> stat_type = new HashMap();
/*  18: 44 */   private static final Map<String, Integer> expr_type = new HashMap();
/*  19: 45 */   private static final Map<String, Integer> expr_func_type = new HashMap();
/*  20: 46 */   private static final Map<String, Integer> expr_exit_type = new HashMap();
/*  21: 47 */   private static final Map<String, Integer> stat_if_type = new HashMap();
/*  22: 48 */   private static final Map<String, VarType> expr_const_type = new HashMap();
/*  23:    */   
/*  24:    */   static
/*  25:    */   {
/*  26: 51 */     stat_properties.put("type", IMatchable.MatchProperties.STATEMENT_TYPE);
/*  27: 52 */     stat_properties.put("ret", IMatchable.MatchProperties.STATEMENT_RET);
/*  28: 53 */     stat_properties.put("position", IMatchable.MatchProperties.STATEMENT_POSITION);
/*  29: 54 */     stat_properties.put("statsize", IMatchable.MatchProperties.STATEMENT_STATSIZE);
/*  30: 55 */     stat_properties.put("exprsize", IMatchable.MatchProperties.STATEMENT_EXPRSIZE);
/*  31: 56 */     stat_properties.put("iftype", IMatchable.MatchProperties.STATEMENT_IFTYPE);
/*  32:    */     
/*  33: 58 */     expr_properties.put("type", IMatchable.MatchProperties.EXPRENT_TYPE);
/*  34: 59 */     expr_properties.put("ret", IMatchable.MatchProperties.EXPRENT_RET);
/*  35: 60 */     expr_properties.put("position", IMatchable.MatchProperties.EXPRENT_POSITION);
/*  36: 61 */     expr_properties.put("functype", IMatchable.MatchProperties.EXPRENT_FUNCTYPE);
/*  37: 62 */     expr_properties.put("exittype", IMatchable.MatchProperties.EXPRENT_EXITTYPE);
/*  38: 63 */     expr_properties.put("consttype", IMatchable.MatchProperties.EXPRENT_CONSTTYPE);
/*  39: 64 */     expr_properties.put("constvalue", IMatchable.MatchProperties.EXPRENT_CONSTVALUE);
/*  40: 65 */     expr_properties.put("invclass", IMatchable.MatchProperties.EXPRENT_INVOCATION_CLASS);
/*  41: 66 */     expr_properties.put("signature", IMatchable.MatchProperties.EXPRENT_INVOCATION_SIGNATURE);
/*  42: 67 */     expr_properties.put("parameter", IMatchable.MatchProperties.EXPRENT_INVOCATION_PARAMETER);
/*  43: 68 */     expr_properties.put("index", IMatchable.MatchProperties.EXPRENT_VAR_INDEX);
/*  44: 69 */     expr_properties.put("name", IMatchable.MatchProperties.EXPRENT_FIELD_NAME);
/*  45:    */     
/*  46: 71 */     stat_type.put("if", Integer.valueOf(2));
/*  47: 72 */     stat_type.put("do", Integer.valueOf(5));
/*  48: 73 */     stat_type.put("switch", Integer.valueOf(6));
/*  49: 74 */     stat_type.put("trycatch", Integer.valueOf(7));
/*  50: 75 */     stat_type.put("basicblock", Integer.valueOf(8));
/*  51: 76 */     stat_type.put("sequence", Integer.valueOf(15));
/*  52:    */     
/*  53: 78 */     expr_type.put("array", Integer.valueOf(1));
/*  54: 79 */     expr_type.put("assignment", Integer.valueOf(2));
/*  55: 80 */     expr_type.put("constant", Integer.valueOf(3));
/*  56: 81 */     expr_type.put("exit", Integer.valueOf(4));
/*  57: 82 */     expr_type.put("field", Integer.valueOf(5));
/*  58: 83 */     expr_type.put("function", Integer.valueOf(6));
/*  59: 84 */     expr_type.put("if", Integer.valueOf(7));
/*  60: 85 */     expr_type.put("invocation", Integer.valueOf(8));
/*  61: 86 */     expr_type.put("monitor", Integer.valueOf(9));
/*  62: 87 */     expr_type.put("new", Integer.valueOf(10));
/*  63: 88 */     expr_type.put("switch", Integer.valueOf(11));
/*  64: 89 */     expr_type.put("var", Integer.valueOf(12));
/*  65: 90 */     expr_type.put("annotation", Integer.valueOf(13));
/*  66: 91 */     expr_type.put("assert", Integer.valueOf(14));
/*  67:    */     
/*  68: 93 */     expr_func_type.put("eq", Integer.valueOf(42));
/*  69:    */     
/*  70: 95 */     expr_exit_type.put("return", Integer.valueOf(0));
/*  71: 96 */     expr_exit_type.put("throw", Integer.valueOf(1));
/*  72:    */     
/*  73: 98 */     stat_if_type.put("if", Integer.valueOf(0));
/*  74: 99 */     stat_if_type.put("ifelse", Integer.valueOf(1));
/*  75:    */     
/*  76:101 */     expr_const_type.put("null", VarType.VARTYPE_NULL);
/*  77:102 */     expr_const_type.put("string", VarType.VARTYPE_STRING);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void parse(String description)
/*  81:    */   {
/*  82:109 */     String[] lines = description.split("\n");
/*  83:    */     
/*  84:111 */     int depth = 0;
/*  85:112 */     LinkedList<MatchNode> stack = new LinkedList();
/*  86:114 */     for (String line : lines)
/*  87:    */     {
/*  88:116 */       List<String> properties = new ArrayList(Arrays.asList(line.split("\\s+")));
/*  89:117 */       if (((String)properties.get(0)).isEmpty()) {
/*  90:118 */         properties.remove(0);
/*  91:    */       }
/*  92:121 */       int node_type = "statement".equals(properties.get(0)) ? 0 : 1;
/*  93:    */       
/*  94:    */ 
/*  95:124 */       MatchNode matchNode = new MatchNode(node_type);
/*  96:125 */       for (int i = 1; i < properties.size(); i++)
/*  97:    */       {
/*  98:126 */         String[] values = ((String)properties.get(i)).split(":");
/*  99:    */         
/* 100:128 */         IMatchable.MatchProperties property = (IMatchable.MatchProperties)(node_type == 0 ? stat_properties : expr_properties).get(values[0]);
/* 101:129 */         if (property == null) {
/* 102:130 */           throw new RuntimeException("Unknown matching property");
/* 103:    */         }
/* 104:133 */         Object value = null;
/* 105:134 */         int parameter = 0;
/* 106:    */         
/* 107:136 */         String strValue = values[1];
/* 108:137 */         if (values.length == 3)
/* 109:    */         {
/* 110:138 */           parameter = Integer.parseInt(values[1]);
/* 111:139 */           strValue = values[2];
/* 112:    */         }
/* 113:142 */         switch (1.$SwitchMap$org$jetbrains$java$decompiler$struct$match$IMatchable$MatchProperties[property.ordinal()])
/* 114:    */         {
/* 115:    */         case 1: 
/* 116:144 */           value = stat_type.get(strValue);
/* 117:145 */           break;
/* 118:    */         case 2: 
/* 119:    */         case 3: 
/* 120:148 */           value = Integer.valueOf(strValue);
/* 121:149 */           break;
/* 122:    */         case 4: 
/* 123:    */         case 5: 
/* 124:    */         case 6: 
/* 125:    */         case 7: 
/* 126:    */         case 8: 
/* 127:    */         case 9: 
/* 128:    */         case 10: 
/* 129:    */         case 11: 
/* 130:    */         case 12: 
/* 131:    */         case 13: 
/* 132:160 */           value = strValue;
/* 133:161 */           break;
/* 134:    */         case 14: 
/* 135:163 */           value = stat_if_type.get(strValue);
/* 136:164 */           break;
/* 137:    */         case 15: 
/* 138:166 */           value = expr_func_type.get(strValue);
/* 139:167 */           break;
/* 140:    */         case 16: 
/* 141:169 */           value = expr_exit_type.get(strValue);
/* 142:170 */           break;
/* 143:    */         case 17: 
/* 144:172 */           value = expr_const_type.get(strValue);
/* 145:173 */           break;
/* 146:    */         case 18: 
/* 147:175 */           value = expr_type.get(strValue);
/* 148:176 */           break;
/* 149:    */         default: 
/* 150:178 */           throw new RuntimeException("Unhandled matching property");
/* 151:    */         }
/* 152:181 */         matchNode.addRule(property, new MatchNode.RuleValue(parameter, value));
/* 153:    */       }
/* 154:185 */       if (stack.isEmpty())
/* 155:    */       {
/* 156:186 */         stack.push(matchNode);
/* 157:    */       }
/* 158:    */       else
/* 159:    */       {
/* 160:190 */         int new_depth = line.lastIndexOf(' ', depth) + 1;
/* 161:191 */         for (int i = new_depth; i <= depth; i++) {
/* 162:192 */           stack.pop();
/* 163:    */         }
/* 164:196 */         ((MatchNode)stack.getFirst()).addChild(matchNode);
/* 165:197 */         stack.push(matchNode);
/* 166:    */         
/* 167:199 */         depth = new_depth;
/* 168:    */       }
/* 169:    */     }
/* 170:203 */     this.rootNode = ((MatchNode)stack.getLast());
/* 171:    */   }
/* 172:    */   
/* 173:    */   public boolean match(IMatchable object)
/* 174:    */   {
/* 175:207 */     this.variables.clear();
/* 176:208 */     return match(this.rootNode, object);
/* 177:    */   }
/* 178:    */   
/* 179:    */   private boolean match(MatchNode matchNode, IMatchable object)
/* 180:    */   {
/* 181:213 */     if (!object.match(matchNode, this)) {
/* 182:214 */       return false;
/* 183:    */     }
/* 184:217 */     int expr_index = 0;
/* 185:218 */     int stat_index = 0;
/* 186:220 */     for (MatchNode childNode : matchNode.getChildren())
/* 187:    */     {
/* 188:221 */       boolean isStatement = childNode.getType() == 0;
/* 189:    */       
/* 190:223 */       IMatchable childObject = object.findObject(childNode, isStatement ? stat_index : expr_index);
/* 191:224 */       if ((childObject == null) || (!match(childNode, childObject))) {
/* 192:225 */         return false;
/* 193:    */       }
/* 194:228 */       if (isStatement) {
/* 195:229 */         stat_index++;
/* 196:    */       } else {
/* 197:231 */         expr_index++;
/* 198:    */       }
/* 199:    */     }
/* 200:235 */     return true;
/* 201:    */   }
/* 202:    */   
/* 203:    */   public boolean checkAndSetVariableValue(String name, Object value)
/* 204:    */   {
/* 205:240 */     Object old_value = this.variables.get(name);
/* 206:241 */     if (old_value == null) {
/* 207:242 */       this.variables.put(name, value);
/* 208:243 */     } else if (!old_value.equals(value)) {
/* 209:244 */       return false;
/* 210:    */     }
/* 211:247 */     return true;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public Object getVariableValue(String name)
/* 215:    */   {
/* 216:251 */     return this.variables.get(name);
/* 217:    */   }
/* 218:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.match.MatchEngine
 * JD-Core Version:    0.7.0.1
 */