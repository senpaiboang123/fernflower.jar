/*  1:   */ package org.jetbrains.java.decompiler.struct;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  5:   */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  6:   */ 
/*  7:   */ public class StructField
/*  8:   */   extends StructMember
/*  9:   */ {
/* 10:   */   private final String name;
/* 11:   */   private final String descriptor;
/* 12:   */   
/* 13:   */   public StructField(DataInputFullStream in, StructClass clStruct)
/* 14:   */     throws IOException
/* 15:   */   {
/* 16:39 */     this.accessFlags = in.readUnsignedShort();
/* 17:40 */     int nameIndex = in.readUnsignedShort();
/* 18:41 */     int descriptorIndex = in.readUnsignedShort();
/* 19:   */     
/* 20:43 */     ConstantPool pool = clStruct.getPool();
/* 21:44 */     String[] values = pool.getClassElement(1, clStruct.qualifiedName, nameIndex, descriptorIndex);
/* 22:45 */     this.name = values[0];
/* 23:46 */     this.descriptor = values[1];
/* 24:   */     
/* 25:48 */     this.attributes = readAttributes(in, pool);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getName()
/* 29:   */   {
/* 30:52 */     return this.name;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String getDescriptor()
/* 34:   */   {
/* 35:56 */     return this.descriptor;
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.StructField
 * JD-Core Version:    0.7.0.1
 */