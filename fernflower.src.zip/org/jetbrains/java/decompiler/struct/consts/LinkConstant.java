/*   1:    */ package org.jetbrains.java.decompiler.struct.consts;
/*   2:    */ 
/*   3:    */ import java.io.DataOutputStream;
/*   4:    */ import java.io.IOException;
/*   5:    */ 
/*   6:    */ public class LinkConstant
/*   7:    */   extends PooledConstant
/*   8:    */ {
/*   9:    */   public int index1;
/*  10:    */   public int index2;
/*  11:    */   public String classname;
/*  12:    */   public String elementname;
/*  13:    */   public String descriptor;
/*  14: 40 */   public int paramCount = 0;
/*  15: 42 */   public boolean isVoid = false;
/*  16: 44 */   public boolean returnCategory2 = false;
/*  17:    */   
/*  18:    */   public LinkConstant(int type, String classname, String elementname, String descriptor)
/*  19:    */   {
/*  20: 52 */     this.type = type;
/*  21: 53 */     this.classname = classname;
/*  22: 54 */     this.elementname = elementname;
/*  23: 55 */     this.descriptor = descriptor;
/*  24:    */     
/*  25: 57 */     initConstant();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public LinkConstant(int type, int index1, int index2)
/*  29:    */   {
/*  30: 61 */     this.type = type;
/*  31: 62 */     this.index1 = index1;
/*  32: 63 */     this.index2 = index2;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void resolveConstant(ConstantPool pool)
/*  36:    */   {
/*  37: 73 */     if (this.type == 12)
/*  38:    */     {
/*  39: 74 */       this.elementname = pool.getPrimitiveConstant(this.index1).getString();
/*  40: 75 */       this.descriptor = pool.getPrimitiveConstant(this.index2).getString();
/*  41:    */     }
/*  42: 77 */     else if (this.type == 15)
/*  43:    */     {
/*  44: 78 */       LinkConstant ref_info = pool.getLinkConstant(this.index2);
/*  45:    */       
/*  46: 80 */       this.classname = ref_info.classname;
/*  47: 81 */       this.elementname = ref_info.elementname;
/*  48: 82 */       this.descriptor = ref_info.descriptor;
/*  49:    */     }
/*  50:    */     else
/*  51:    */     {
/*  52: 85 */       if (this.type != 18) {
/*  53: 86 */         this.classname = pool.getPrimitiveConstant(this.index1).getString();
/*  54:    */       }
/*  55: 89 */       LinkConstant nametype = pool.getLinkConstant(this.index2);
/*  56: 90 */       this.elementname = nametype.elementname;
/*  57: 91 */       this.descriptor = nametype.descriptor;
/*  58:    */     }
/*  59: 94 */     initConstant();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void writeToStream(DataOutputStream out)
/*  63:    */     throws IOException
/*  64:    */   {
/*  65: 98 */     out.writeByte(this.type);
/*  66: 99 */     if (this.type == 15) {
/*  67:100 */       out.writeByte(this.index1);
/*  68:    */     } else {
/*  69:103 */       out.writeShort(this.index1);
/*  70:    */     }
/*  71:105 */     out.writeShort(this.index2);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean equals(Object o)
/*  75:    */   {
/*  76:110 */     if (o == this) {
/*  77:110 */       return true;
/*  78:    */     }
/*  79:111 */     if ((o == null) || (!(o instanceof LinkConstant))) {
/*  80:111 */       return false;
/*  81:    */     }
/*  82:113 */     LinkConstant cn = (LinkConstant)o;
/*  83:114 */     return (this.type == cn.type) && (this.elementname.equals(cn.elementname)) && (this.descriptor.equals(cn.descriptor)) && ((this.type != 12) || (this.classname.equals(cn.classname)));
/*  84:    */   }
/*  85:    */   
/*  86:    */   private void initConstant()
/*  87:    */   {
/*  88:126 */     if ((this.type == 10) || (this.type == 11) || (this.type == 18) || (this.type == 15)) {
/*  89:130 */       resolveDescriptor(this.descriptor);
/*  90:132 */     } else if (this.type == 9) {
/*  91:133 */       this.returnCategory2 = (("D".equals(this.descriptor)) || ("J".equals(this.descriptor)));
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   private void resolveDescriptor(String descr)
/*  96:    */   {
/*  97:139 */     String[] arr = descr.split("[()]");
/*  98:140 */     String par = arr[1];
/*  99:    */     
/* 100:142 */     int index = 0;int counter = 0;
/* 101:143 */     int len = par.length();
/* 102:145 */     while (index < len)
/* 103:    */     {
/* 104:147 */       char c = par.charAt(index);
/* 105:148 */       if (c == 'L')
/* 106:    */       {
/* 107:149 */         index = par.indexOf(";", index);
/* 108:    */       }
/* 109:151 */       else if (c == '[')
/* 110:    */       {
/* 111:152 */         index++;
/* 112:153 */         continue;
/* 113:    */       }
/* 114:156 */       counter++;
/* 115:157 */       index++;
/* 116:    */     }
/* 117:160 */     this.paramCount = counter;
/* 118:161 */     this.isVoid = "V".equals(arr[2]);
/* 119:162 */     this.returnCategory2 = (("D".equals(arr[2])) || ("J".equals(arr[2])));
/* 120:    */   }
/* 121:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.consts.LinkConstant
 * JD-Core Version:    0.7.0.1
 */