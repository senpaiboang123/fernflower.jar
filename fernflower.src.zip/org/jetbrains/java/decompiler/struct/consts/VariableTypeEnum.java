/*  1:   */ package org.jetbrains.java.decompiler.struct.consts;
/*  2:   */ 
/*  3:   */ public abstract interface VariableTypeEnum
/*  4:   */ {
/*  5:   */   public static final int BOOLEAN = 1;
/*  6:   */   public static final int BYTE = 2;
/*  7:   */   public static final int CHAR = 3;
/*  8:   */   public static final int SHORT = 4;
/*  9:   */   public static final int INT = 5;
/* 10:   */   public static final int FLOAT = 6;
/* 11:   */   public static final int LONG = 7;
/* 12:   */   public static final int DOUBLE = 8;
/* 13:   */   public static final int RETURN_ADDRESS = 9;
/* 14:   */   public static final int REFERENCE = 10;
/* 15:   */   public static final int INSTANCE_UNINITIALIZED = 11;
/* 16:   */   public static final int VALUE_UNKNOWN = 12;
/* 17:   */   public static final int VOID = 13;
/* 18:34 */   public static final Integer BOOLEAN_OBJ = new Integer(1);
/* 19:35 */   public static final Integer BYTE_OBJ = new Integer(2);
/* 20:36 */   public static final Integer CHAR_OBJ = new Integer(3);
/* 21:37 */   public static final Integer SHORT_OBJ = new Integer(4);
/* 22:38 */   public static final Integer INT_OBJ = new Integer(5);
/* 23:39 */   public static final Integer FLOAT_OBJ = new Integer(6);
/* 24:40 */   public static final Integer LONG_OBJ = new Integer(7);
/* 25:41 */   public static final Integer DOUBLE_OBJ = new Integer(8);
/* 26:42 */   public static final Integer RETURN_ADDRESS_OBJ = new Integer(9);
/* 27:43 */   public static final Integer REFERENCE_OBJ = new Integer(10);
/* 28:44 */   public static final Integer INSTANCE_UNINITIALIZED_OBJ = new Integer(11);
/* 29:45 */   public static final Integer VALUE_UNKNOWN_OBJ = new Integer(12);
/* 30:46 */   public static final Integer VOID_OBJ = new Integer(13);
/* 31:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.consts.VariableTypeEnum
 * JD-Core Version:    0.7.0.1
 */