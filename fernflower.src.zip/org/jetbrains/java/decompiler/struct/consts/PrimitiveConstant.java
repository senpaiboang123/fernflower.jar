/*   1:    */ package org.jetbrains.java.decompiler.struct.consts;
/*   2:    */ 
/*   3:    */ import java.io.DataOutputStream;
/*   4:    */ import java.io.IOException;
/*   5:    */ 
/*   6:    */ public class PrimitiveConstant
/*   7:    */   extends PooledConstant
/*   8:    */ {
/*   9:    */   public int index;
/*  10:    */   public Object value;
/*  11:    */   public boolean isArray;
/*  12:    */   
/*  13:    */   public PrimitiveConstant(int type, Object value)
/*  14:    */   {
/*  15: 42 */     this.type = type;
/*  16: 43 */     this.value = value;
/*  17:    */     
/*  18: 45 */     initConstant();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public PrimitiveConstant(int type, int index)
/*  22:    */   {
/*  23: 49 */     this.type = type;
/*  24: 50 */     this.index = index;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public int getInt()
/*  28:    */   {
/*  29: 58 */     return ((Integer)this.value).intValue();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public long getLong()
/*  33:    */   {
/*  34: 62 */     return ((Long)this.value).longValue();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public float getFloat()
/*  38:    */   {
/*  39: 66 */     return ((Float)this.value).floatValue();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public double getDouble()
/*  43:    */   {
/*  44: 70 */     return ((Double)this.value).doubleValue();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public String getString()
/*  48:    */   {
/*  49: 74 */     return (String)this.value;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void resolveConstant(ConstantPool pool)
/*  53:    */   {
/*  54: 79 */     if ((this.type == 7) || (this.type == 8) || (this.type == 16))
/*  55:    */     {
/*  56: 80 */       this.value = pool.getPrimitiveConstant(this.index).getString();
/*  57: 81 */       initConstant();
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void writeToStream(DataOutputStream out)
/*  62:    */     throws IOException
/*  63:    */   {
/*  64: 87 */     out.writeByte(this.type);
/*  65: 88 */     switch (this.type)
/*  66:    */     {
/*  67:    */     case 3: 
/*  68: 90 */       out.writeInt(getInt());
/*  69: 91 */       break;
/*  70:    */     case 4: 
/*  71: 93 */       out.writeFloat(getFloat());
/*  72: 94 */       break;
/*  73:    */     case 5: 
/*  74: 96 */       out.writeLong(getLong());
/*  75: 97 */       break;
/*  76:    */     case 6: 
/*  77: 99 */       out.writeDouble(getDouble());
/*  78:100 */       break;
/*  79:    */     case 1: 
/*  80:102 */       out.writeUTF(getString());
/*  81:103 */       break;
/*  82:    */     case 2: 
/*  83:    */     default: 
/*  84:105 */       out.writeShort(this.index);
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public boolean equals(Object o)
/*  89:    */   {
/*  90:110 */     if (o == this) {
/*  91:110 */       return true;
/*  92:    */     }
/*  93:111 */     if ((o == null) || (!(o instanceof PrimitiveConstant))) {
/*  94:111 */       return false;
/*  95:    */     }
/*  96:113 */     PrimitiveConstant cn = (PrimitiveConstant)o;
/*  97:114 */     return (this.type == cn.type) && (this.isArray == cn.isArray) && (this.value.equals(cn.value));
/*  98:    */   }
/*  99:    */   
/* 100:    */   private void initConstant()
/* 101:    */   {
/* 102:120 */     if (this.type == 7)
/* 103:    */     {
/* 104:121 */       String className = getString();
/* 105:122 */       this.isArray = ((className.length() > 0) && (className.charAt(0) == '['));
/* 106:    */     }
/* 107:    */   }
/* 108:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant
 * JD-Core Version:    0.7.0.1
 */