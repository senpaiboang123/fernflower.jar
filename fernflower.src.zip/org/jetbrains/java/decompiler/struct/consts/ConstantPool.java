/*   1:    */ package org.jetbrains.java.decompiler.struct.consts;
/*   2:    */ 
/*   3:    */ import java.io.DataInputStream;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.List;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ import org.jetbrains.java.decompiler.modules.renamer.PoolInterceptor;
/*   9:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  10:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  11:    */ import org.jetbrains.java.decompiler.struct.gen.NewClassNameBuilder;
/*  12:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  13:    */ import org.jetbrains.java.decompiler.util.DataInputFullStream;
/*  14:    */ 
/*  15:    */ public class ConstantPool
/*  16:    */   implements NewClassNameBuilder
/*  17:    */ {
/*  18:    */   public static final int FIELD = 1;
/*  19:    */   public static final int METHOD = 2;
/*  20: 37 */   private final List<PooledConstant> pool = new ArrayList();
/*  21:    */   private final PoolInterceptor interceptor;
/*  22:    */   
/*  23:    */   public ConstantPool(DataInputStream in)
/*  24:    */     throws IOException
/*  25:    */   {
/*  26: 42 */     int size = in.readUnsignedShort();
/*  27: 43 */     int[] pass = new int[size];
/*  28:    */     
/*  29:    */ 
/*  30: 46 */     this.pool.add(null);
/*  31: 49 */     for (int i = 1; i < size; i++)
/*  32:    */     {
/*  33: 50 */       byte tag = (byte)in.readUnsignedByte();
/*  34: 52 */       switch (tag)
/*  35:    */       {
/*  36:    */       case 1: 
/*  37: 54 */         this.pool.add(new PrimitiveConstant(1, in.readUTF()));
/*  38: 55 */         break;
/*  39:    */       case 3: 
/*  40: 57 */         this.pool.add(new PrimitiveConstant(3, new Integer(in.readInt())));
/*  41: 58 */         break;
/*  42:    */       case 4: 
/*  43: 60 */         this.pool.add(new PrimitiveConstant(4, new Float(in.readFloat())));
/*  44: 61 */         break;
/*  45:    */       case 5: 
/*  46: 63 */         this.pool.add(new PrimitiveConstant(5, new Long(in.readLong())));
/*  47: 64 */         this.pool.add(null);
/*  48: 65 */         i++;
/*  49: 66 */         break;
/*  50:    */       case 6: 
/*  51: 68 */         this.pool.add(new PrimitiveConstant(6, new Double(in.readDouble())));
/*  52: 69 */         this.pool.add(null);
/*  53: 70 */         i++;
/*  54: 71 */         break;
/*  55:    */       case 7: 
/*  56:    */       case 8: 
/*  57:    */       case 16: 
/*  58: 75 */         this.pool.add(new PrimitiveConstant(tag, in.readUnsignedShort()));
/*  59: 76 */         pass[i] = 1;
/*  60: 77 */         break;
/*  61:    */       case 9: 
/*  62:    */       case 10: 
/*  63:    */       case 11: 
/*  64:    */       case 12: 
/*  65:    */       case 18: 
/*  66: 83 */         this.pool.add(new LinkConstant(tag, in.readUnsignedShort(), in.readUnsignedShort()));
/*  67: 84 */         if (tag == 12) {
/*  68: 85 */           pass[i] = 1;
/*  69:    */         } else {
/*  70: 88 */           pass[i] = 2;
/*  71:    */         }
/*  72: 90 */         break;
/*  73:    */       case 15: 
/*  74: 92 */         this.pool.add(new LinkConstant(tag, in.readUnsignedByte(), in.readUnsignedShort()));
/*  75: 93 */         pass[i] = 3;
/*  76:    */       }
/*  77:    */     }
/*  78: 99 */     for (int passIndex = 1; passIndex <= 3; passIndex++) {
/*  79:100 */       for (int i = 1; i < size; i++) {
/*  80:101 */         if (pass[i] == passIndex) {
/*  81:102 */           ((PooledConstant)this.pool.get(i)).resolveConstant(this);
/*  82:    */         }
/*  83:    */       }
/*  84:    */     }
/*  85:108 */     this.interceptor = DecompilerContext.getPoolInterceptor();
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static void skipPool(DataInputFullStream in)
/*  89:    */     throws IOException
/*  90:    */   {
/*  91:112 */     int size = in.readUnsignedShort();
/*  92:114 */     for (int i = 1; i < size; i++) {
/*  93:115 */       switch (in.readUnsignedByte())
/*  94:    */       {
/*  95:    */       case 1: 
/*  96:117 */         in.readUTF();
/*  97:118 */         break;
/*  98:    */       case 3: 
/*  99:    */       case 4: 
/* 100:    */       case 9: 
/* 101:    */       case 10: 
/* 102:    */       case 11: 
/* 103:    */       case 12: 
/* 104:    */       case 18: 
/* 105:126 */         in.discard(4);
/* 106:127 */         break;
/* 107:    */       case 5: 
/* 108:    */       case 6: 
/* 109:130 */         in.discard(8);
/* 110:131 */         i++;
/* 111:132 */         break;
/* 112:    */       case 7: 
/* 113:    */       case 8: 
/* 114:    */       case 16: 
/* 115:136 */         in.discard(2);
/* 116:137 */         break;
/* 117:    */       case 15: 
/* 118:139 */         in.discard(3);
/* 119:    */       }
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */   public int size()
/* 124:    */   {
/* 125:145 */     return this.pool.size();
/* 126:    */   }
/* 127:    */   
/* 128:    */   public String[] getClassElement(int elementType, String className, int nameIndex, int descriptorIndex)
/* 129:    */   {
/* 130:149 */     String elementName = ((PrimitiveConstant)getConstant(nameIndex)).getString();
/* 131:150 */     String descriptor = ((PrimitiveConstant)getConstant(descriptorIndex)).getString();
/* 132:152 */     if (this.interceptor != null)
/* 133:    */     {
/* 134:153 */       String newElement = this.interceptor.getName(className + " " + elementName + " " + descriptor);
/* 135:154 */       if (newElement != null) {
/* 136:155 */         elementName = newElement.split(" ")[1];
/* 137:    */       }
/* 138:158 */       String newDescriptor = buildNewDescriptor(elementType == 1, descriptor);
/* 139:159 */       if (newDescriptor != null) {
/* 140:160 */         descriptor = newDescriptor;
/* 141:    */       }
/* 142:    */     }
/* 143:164 */     return new String[] { elementName, descriptor };
/* 144:    */   }
/* 145:    */   
/* 146:    */   public PooledConstant getConstant(int index)
/* 147:    */   {
/* 148:168 */     return (PooledConstant)this.pool.get(index);
/* 149:    */   }
/* 150:    */   
/* 151:    */   public PrimitiveConstant getPrimitiveConstant(int index)
/* 152:    */   {
/* 153:172 */     PrimitiveConstant cn = (PrimitiveConstant)getConstant(index);
/* 154:174 */     if ((cn != null) && (this.interceptor != null) && 
/* 155:175 */       (cn.type == 7))
/* 156:    */     {
/* 157:176 */       String newName = buildNewClassname(cn.getString());
/* 158:177 */       if (newName != null) {
/* 159:178 */         cn = new PrimitiveConstant(7, newName);
/* 160:    */       }
/* 161:    */     }
/* 162:183 */     return cn;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public LinkConstant getLinkConstant(int index)
/* 166:    */   {
/* 167:187 */     LinkConstant ln = (LinkConstant)getConstant(index);
/* 168:189 */     if ((ln != null) && (this.interceptor != null) && ((ln.type == 9) || (ln.type == 10) || (ln.type == 11)))
/* 169:    */     {
/* 170:193 */       String newClassName = buildNewClassname(ln.classname);
/* 171:194 */       String newElement = this.interceptor.getName(ln.classname + " " + ln.elementname + " " + ln.descriptor);
/* 172:195 */       String newDescriptor = buildNewDescriptor(ln.type == 9, ln.descriptor);
/* 173:197 */       if ((newClassName != null) || (newElement != null) || (newDescriptor != null))
/* 174:    */       {
/* 175:198 */         String className = newClassName == null ? ln.classname : newClassName;
/* 176:199 */         String elementName = newElement == null ? ln.elementname : newElement.split(" ")[1];
/* 177:200 */         String descriptor = newDescriptor == null ? ln.descriptor : newDescriptor;
/* 178:201 */         ln = new LinkConstant(ln.type, className, elementName, descriptor);
/* 179:    */       }
/* 180:    */     }
/* 181:205 */     return ln;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public String buildNewClassname(String className)
/* 185:    */   {
/* 186:210 */     VarType vt = new VarType(className, true);
/* 187:    */     
/* 188:212 */     String newName = this.interceptor.getName(vt.value);
/* 189:213 */     if (newName != null)
/* 190:    */     {
/* 191:214 */       StringBuilder buffer = new StringBuilder();
/* 192:216 */       if (vt.arrayDim > 0)
/* 193:    */       {
/* 194:217 */         for (int i = 0; i < vt.arrayDim; i++) {
/* 195:218 */           buffer.append("[");
/* 196:    */         }
/* 197:221 */         buffer.append("L").append(newName).append(";");
/* 198:    */       }
/* 199:    */       else
/* 200:    */       {
/* 201:224 */         buffer.append(newName);
/* 202:    */       }
/* 203:227 */       return buffer.toString();
/* 204:    */     }
/* 205:230 */     return null;
/* 206:    */   }
/* 207:    */   
/* 208:    */   private String buildNewDescriptor(boolean isField, String descriptor)
/* 209:    */   {
/* 210:234 */     if (isField) {
/* 211:235 */       return FieldDescriptor.parseDescriptor(descriptor).buildNewDescriptor(this);
/* 212:    */     }
/* 213:238 */     return MethodDescriptor.parseDescriptor(descriptor).buildNewDescriptor(this);
/* 214:    */   }
/* 215:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.consts.ConstantPool
 * JD-Core Version:    0.7.0.1
 */