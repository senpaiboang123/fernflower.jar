/*   1:    */ package org.jetbrains.java.decompiler.struct.consts;
/*   2:    */ 
/*   3:    */ import java.io.DataOutputStream;
/*   4:    */ import java.io.IOException;
/*   5:    */ import org.jetbrains.java.decompiler.code.CodeConstants;
/*   6:    */ 
/*   7:    */ public class PooledConstant
/*   8:    */   implements CodeConstants, VariableTypeEnum
/*   9:    */ {
/*  10:    */   public int type;
/*  11: 39 */   public boolean own = false;
/*  12:    */   public int returnType;
/*  13:    */   private Object[] values;
/*  14:    */   
/*  15:    */   public PooledConstant() {}
/*  16:    */   
/*  17:    */   public PooledConstant(int type, Object[] values)
/*  18:    */   {
/*  19: 58 */     this.type = type;
/*  20: 59 */     this.values = values;
/*  21: 60 */     this.returnType = poolTypeToIntern(type);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public PooledConstant(int type, boolean own, Object[] values)
/*  25:    */   {
/*  26: 64 */     this.type = type;
/*  27: 65 */     this.own = own;
/*  28: 66 */     this.values = values;
/*  29: 67 */     this.returnType = poolTypeToIntern(type);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void resolveConstant(ConstantPool pool) {}
/*  33:    */   
/*  34:    */   public void writeToStream(DataOutputStream out)
/*  35:    */     throws IOException
/*  36:    */   {}
/*  37:    */   
/*  38:    */   public int poolTypeToIntern(int type)
/*  39:    */   {
/*  40: 84 */     switch (type)
/*  41:    */     {
/*  42:    */     case 3: 
/*  43: 86 */       return 5;
/*  44:    */     case 4: 
/*  45: 88 */       return 6;
/*  46:    */     case 5: 
/*  47: 90 */       return 7;
/*  48:    */     case 6: 
/*  49: 92 */       return 8;
/*  50:    */     case 7: 
/*  51:    */     case 8: 
/*  52: 95 */       return 10;
/*  53:    */     }
/*  54: 97 */     throw new RuntimeException("Huh?? What are you trying to load?");
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Object getValue(int index)
/*  58:    */   {
/*  59:102 */     return this.values[index];
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Object[] getValues()
/*  63:    */   {
/*  64:111 */     return this.values;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setValues(Object[] values)
/*  68:    */   {
/*  69:115 */     this.values = values;
/*  70:    */   }
/*  71:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.struct.consts.PooledConstant
 * JD-Core Version:    0.7.0.1
 */