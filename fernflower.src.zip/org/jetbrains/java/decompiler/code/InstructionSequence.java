/*   1:    */ package org.jetbrains.java.decompiler.code;
/*   2:    */ 
/*   3:    */ import java.io.DataOutputStream;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.util.Collections;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.List;
/*   8:    */ import org.jetbrains.java.decompiler.code.interpreter.Util;
/*   9:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  10:    */ import org.jetbrains.java.decompiler.struct.StructContext;
/*  11:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  12:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  13:    */ 
/*  14:    */ public abstract class InstructionSequence
/*  15:    */ {
/*  16:    */   protected final VBStyleCollection<Instruction, Integer> collinstr;
/*  17: 39 */   protected int pointer = 0;
/*  18: 41 */   protected ExceptionTable exceptionTable = ExceptionTable.EMPTY;
/*  19:    */   
/*  20:    */   protected InstructionSequence()
/*  21:    */   {
/*  22: 44 */     this(new VBStyleCollection());
/*  23:    */   }
/*  24:    */   
/*  25:    */   protected InstructionSequence(VBStyleCollection<Instruction, Integer> collinstr)
/*  26:    */   {
/*  27: 48 */     this.collinstr = collinstr;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public InstructionSequence clone()
/*  31:    */   {
/*  32: 57 */     return null;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void clear()
/*  36:    */   {
/*  37: 61 */     this.collinstr.clear();
/*  38: 62 */     this.pointer = 0;
/*  39: 63 */     this.exceptionTable = ExceptionTable.EMPTY;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void addInstruction(Instruction inst, int offset)
/*  43:    */   {
/*  44: 67 */     this.collinstr.addWithKey(inst, Integer.valueOf(offset));
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void addInstruction(int index, Instruction inst, int offset)
/*  48:    */   {
/*  49: 71 */     this.collinstr.addWithKeyAndIndex(index, inst, Integer.valueOf(offset));
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void addSequence(InstructionSequence seq)
/*  53:    */   {
/*  54: 75 */     for (int i = 0; i < seq.length(); i++) {
/*  55: 76 */       addInstruction(seq.getInstr(i), -1);
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void removeInstruction(int index)
/*  60:    */   {
/*  61: 81 */     this.collinstr.remove(index);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void removeLast()
/*  65:    */   {
/*  66: 85 */     if (!this.collinstr.isEmpty()) {
/*  67: 86 */       this.collinstr.remove(this.collinstr.size() - 1);
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Instruction getCurrentInstr()
/*  72:    */   {
/*  73: 91 */     return (Instruction)this.collinstr.get(this.pointer);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Instruction getInstr(int index)
/*  77:    */   {
/*  78: 95 */     return (Instruction)this.collinstr.get(index);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public Instruction getLastInstr()
/*  82:    */   {
/*  83: 99 */     return (Instruction)this.collinstr.getLast();
/*  84:    */   }
/*  85:    */   
/*  86:    */   public int getCurrentOffset()
/*  87:    */   {
/*  88:103 */     return ((Integer)this.collinstr.getKey(this.pointer)).intValue();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public int getOffset(int index)
/*  92:    */   {
/*  93:107 */     return ((Integer)this.collinstr.getKey(index)).intValue();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public int getPointerByAbsOffset(int offset)
/*  97:    */   {
/*  98:111 */     Integer absoffset = new Integer(offset);
/*  99:112 */     if (this.collinstr.containsKey(absoffset)) {
/* 100:113 */       return this.collinstr.getIndexByKey(absoffset);
/* 101:    */     }
/* 102:116 */     return -1;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public int getPointerByRelOffset(int offset)
/* 106:    */   {
/* 107:121 */     Integer absoffset = new Integer(((Integer)this.collinstr.getKey(this.pointer)).intValue() + offset);
/* 108:122 */     if (this.collinstr.containsKey(absoffset)) {
/* 109:123 */       return this.collinstr.getIndexByKey(absoffset);
/* 110:    */     }
/* 111:126 */     return -1;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setPointerByAbsOffset(int offset)
/* 115:    */   {
/* 116:131 */     Integer absoffset = new Integer(((Integer)this.collinstr.getKey(this.pointer)).intValue() + offset);
/* 117:132 */     if (this.collinstr.containsKey(absoffset)) {
/* 118:133 */       this.pointer = this.collinstr.getIndexByKey(absoffset);
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:    */   public int length()
/* 123:    */   {
/* 124:138 */     return this.collinstr.size();
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean isEmpty()
/* 128:    */   {
/* 129:142 */     return this.collinstr.isEmpty();
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void addToPointer(int diff)
/* 133:    */   {
/* 134:146 */     this.pointer += diff;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public String toString()
/* 138:    */   {
/* 139:150 */     return toString(0);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public String toString(int indent)
/* 143:    */   {
/* 144:155 */     String new_line_separator = DecompilerContext.getNewLineSeparator();
/* 145:    */     
/* 146:157 */     StringBuilder buf = new StringBuilder();
/* 147:159 */     for (int i = 0; i < this.collinstr.size(); i++)
/* 148:    */     {
/* 149:160 */       buf.append(InterpreterUtil.getIndentString(indent));
/* 150:161 */       buf.append(((Integer)this.collinstr.getKey(i)).intValue());
/* 151:162 */       buf.append(": ");
/* 152:163 */       buf.append(((Instruction)this.collinstr.get(i)).toString());
/* 153:164 */       buf.append(new_line_separator);
/* 154:    */     }
/* 155:167 */     return buf.toString();
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void writeCodeToStream(DataOutputStream out)
/* 159:    */     throws IOException
/* 160:    */   {
/* 161:172 */     for (int i = 0; i < this.collinstr.size(); i++) {
/* 162:173 */       ((Instruction)this.collinstr.get(i)).writeToStream(out, ((Integer)this.collinstr.getKey(i)).intValue());
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   public void writeExceptionsToStream(DataOutputStream out)
/* 167:    */     throws IOException
/* 168:    */   {
/* 169:179 */     List<ExceptionHandler> handlers = this.exceptionTable.getHandlers();
/* 170:    */     
/* 171:181 */     out.writeShort(handlers.size());
/* 172:182 */     for (int i = 0; i < handlers.size(); i++) {
/* 173:183 */       ((ExceptionHandler)handlers.get(i)).writeToStream(out);
/* 174:    */     }
/* 175:    */   }
/* 176:    */   
/* 177:    */   public void sortHandlers(final StructContext context)
/* 178:    */   {
/* 179:189 */     Collections.sort(this.exceptionTable.getHandlers(), new Comparator()
/* 180:    */     {
/* 181:    */       public int compare(ExceptionHandler handler0, ExceptionHandler handler1)
/* 182:    */       {
/* 183:193 */         if (handler0.to == handler1.to)
/* 184:    */         {
/* 185:194 */           if (handler0.exceptionClass == null) {
/* 186:195 */             return 1;
/* 187:    */           }
/* 188:198 */           if (handler1.exceptionClass == null) {
/* 189:199 */             return -1;
/* 190:    */           }
/* 191:201 */           if (handler0.exceptionClass.equals(handler1.exceptionClass)) {
/* 192:202 */             return handler0.from > handler1.from ? -1 : 1;
/* 193:    */           }
/* 194:205 */           if (Util.instanceOf(context, handler0.exceptionClass, handler1.exceptionClass)) {
/* 195:206 */             return -1;
/* 196:    */           }
/* 197:209 */           return 1;
/* 198:    */         }
/* 199:215 */         return handler0.to > handler1.to ? 1 : -1;
/* 200:    */       }
/* 201:    */     });
/* 202:    */   }
/* 203:    */   
/* 204:    */   public int getPointer()
/* 205:    */   {
/* 206:227 */     return this.pointer;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public void setPointer(int pointer)
/* 210:    */   {
/* 211:231 */     this.pointer = pointer;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public ExceptionTable getExceptionTable()
/* 215:    */   {
/* 216:235 */     return this.exceptionTable;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void setExceptionTable(ExceptionTable exceptionTable)
/* 220:    */   {
/* 221:239 */     this.exceptionTable = exceptionTable;
/* 222:    */   }
/* 223:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.InstructionSequence
 * JD-Core Version:    0.7.0.1
 */