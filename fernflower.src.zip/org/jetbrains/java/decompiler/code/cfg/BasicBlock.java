/*   1:    */ package org.jetbrains.java.decompiler.code.cfg;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*   6:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*   7:    */ import org.jetbrains.java.decompiler.code.SimpleInstructionSequence;
/*   8:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.decompose.IGraphNode;
/*  10:    */ 
/*  11:    */ public class BasicBlock
/*  12:    */   implements IGraphNode
/*  13:    */ {
/*  14: 33 */   public int id = 0;
/*  15: 35 */   public int mark = 0;
/*  16: 41 */   private InstructionSequence seq = new SimpleInstructionSequence();
/*  17: 43 */   private List<BasicBlock> preds = new ArrayList();
/*  18: 45 */   private List<BasicBlock> succs = new ArrayList();
/*  19: 47 */   private final List<Integer> instrOldOffsets = new ArrayList();
/*  20: 49 */   private List<BasicBlock> predExceptions = new ArrayList();
/*  21: 51 */   private List<BasicBlock> succExceptions = new ArrayList();
/*  22:    */   
/*  23:    */   public BasicBlock(int id)
/*  24:    */   {
/*  25: 54 */     this.id = id;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public Object clone()
/*  29:    */   {
/*  30: 62 */     BasicBlock block = new BasicBlock(this.id);
/*  31:    */     
/*  32: 64 */     block.setSeq(this.seq.clone());
/*  33: 65 */     block.instrOldOffsets.addAll(this.instrOldOffsets);
/*  34:    */     
/*  35: 67 */     return block;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void free()
/*  39:    */   {
/*  40: 71 */     this.preds.clear();
/*  41: 72 */     this.succs.clear();
/*  42: 73 */     this.instrOldOffsets.clear();
/*  43: 74 */     this.succExceptions.clear();
/*  44: 75 */     this.seq = new SimpleInstructionSequence();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public Instruction getInstruction(int index)
/*  48:    */   {
/*  49: 79 */     return this.seq.getInstr(index);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public Instruction getLastInstruction()
/*  53:    */   {
/*  54: 83 */     if (this.seq.isEmpty()) {
/*  55: 84 */       return null;
/*  56:    */     }
/*  57: 87 */     return this.seq.getLastInstr();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Integer getOldOffset(int index)
/*  61:    */   {
/*  62: 92 */     if (index < this.instrOldOffsets.size()) {
/*  63: 93 */       return (Integer)this.instrOldOffsets.get(index);
/*  64:    */     }
/*  65: 95 */     return Integer.valueOf(-1);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public int size()
/*  69:    */   {
/*  70:100 */     return this.seq.length();
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void addPredecessor(BasicBlock block)
/*  74:    */   {
/*  75:104 */     this.preds.add(block);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void removePredecessor(BasicBlock block)
/*  79:    */   {
/*  80:108 */     while (this.preds.remove(block)) {}
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void addSuccessor(BasicBlock block)
/*  84:    */   {
/*  85:112 */     this.succs.add(block);
/*  86:113 */     block.addPredecessor(this);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void removeSuccessor(BasicBlock block)
/*  90:    */   {
/*  91:117 */     while (this.succs.remove(block)) {}
/*  92:118 */     block.removePredecessor(this);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void replaceSuccessor(BasicBlock oldBlock, BasicBlock newBlock)
/*  96:    */   {
/*  97:123 */     for (int i = 0; i < this.succs.size(); i++) {
/*  98:124 */       if (((BasicBlock)this.succs.get(i)).id == oldBlock.id)
/*  99:    */       {
/* 100:125 */         this.succs.set(i, newBlock);
/* 101:126 */         oldBlock.removePredecessor(this);
/* 102:127 */         newBlock.addPredecessor(this);
/* 103:    */       }
/* 104:    */     }
/* 105:131 */     for (int i = 0; i < this.succExceptions.size(); i++) {
/* 106:132 */       if (((BasicBlock)this.succExceptions.get(i)).id == oldBlock.id)
/* 107:    */       {
/* 108:133 */         this.succExceptions.set(i, newBlock);
/* 109:134 */         oldBlock.removePredecessorException(this);
/* 110:135 */         newBlock.addPredecessorException(this);
/* 111:    */       }
/* 112:    */     }
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void addPredecessorException(BasicBlock block)
/* 116:    */   {
/* 117:141 */     this.predExceptions.add(block);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void removePredecessorException(BasicBlock block)
/* 121:    */   {
/* 122:145 */     while (this.predExceptions.remove(block)) {}
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void addSuccessorException(BasicBlock block)
/* 126:    */   {
/* 127:149 */     if (!this.succExceptions.contains(block))
/* 128:    */     {
/* 129:150 */       this.succExceptions.add(block);
/* 130:151 */       block.addPredecessorException(this);
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void removeSuccessorException(BasicBlock block)
/* 135:    */   {
/* 136:156 */     while (this.succExceptions.remove(block)) {}
/* 137:157 */     block.removePredecessorException(this);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public String toString()
/* 141:    */   {
/* 142:161 */     return toString(0);
/* 143:    */   }
/* 144:    */   
/* 145:    */   public String toString(int indent)
/* 146:    */   {
/* 147:166 */     String new_line_separator = DecompilerContext.getNewLineSeparator();
/* 148:    */     
/* 149:168 */     return this.id + ":" + new_line_separator + this.seq.toString(indent);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public String toStringOldIndices()
/* 153:    */   {
/* 154:173 */     String new_line_separator = DecompilerContext.getNewLineSeparator();
/* 155:    */     
/* 156:175 */     StringBuilder buf = new StringBuilder();
/* 157:177 */     for (int i = 0; i < this.seq.length(); i++)
/* 158:    */     {
/* 159:178 */       if (i < this.instrOldOffsets.size()) {
/* 160:179 */         buf.append(this.instrOldOffsets.get(i));
/* 161:    */       } else {
/* 162:182 */         buf.append("-1");
/* 163:    */       }
/* 164:184 */       buf.append(": ");
/* 165:185 */       buf.append(this.seq.getInstr(i).toString());
/* 166:186 */       buf.append(new_line_separator);
/* 167:    */     }
/* 168:189 */     return buf.toString();
/* 169:    */   }
/* 170:    */   
/* 171:    */   public boolean isSuccessor(BasicBlock block)
/* 172:    */   {
/* 173:193 */     for (BasicBlock succ : this.succs) {
/* 174:194 */       if (succ.id == block.id) {
/* 175:195 */         return true;
/* 176:    */       }
/* 177:    */     }
/* 178:198 */     return false;
/* 179:    */   }
/* 180:    */   
/* 181:    */   public boolean isPredecessor(BasicBlock block)
/* 182:    */   {
/* 183:202 */     for (int i = 0; i < this.preds.size(); i++) {
/* 184:203 */       if (((BasicBlock)this.preds.get(i)).id == block.id) {
/* 185:204 */         return true;
/* 186:    */       }
/* 187:    */     }
/* 188:207 */     return false;
/* 189:    */   }
/* 190:    */   
/* 191:    */   public List<Integer> getInstrOldOffsets()
/* 192:    */   {
/* 193:215 */     return this.instrOldOffsets;
/* 194:    */   }
/* 195:    */   
/* 196:    */   public List<? extends IGraphNode> getPredecessors()
/* 197:    */   {
/* 198:219 */     List<BasicBlock> lst = new ArrayList(this.preds);
/* 199:220 */     lst.addAll(this.predExceptions);
/* 200:221 */     return lst;
/* 201:    */   }
/* 202:    */   
/* 203:    */   public List<BasicBlock> getPreds()
/* 204:    */   {
/* 205:225 */     return this.preds;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public void setPreds(List<BasicBlock> preds)
/* 209:    */   {
/* 210:229 */     this.preds = preds;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public InstructionSequence getSeq()
/* 214:    */   {
/* 215:233 */     return this.seq;
/* 216:    */   }
/* 217:    */   
/* 218:    */   public void setSeq(InstructionSequence seq)
/* 219:    */   {
/* 220:237 */     this.seq = seq;
/* 221:    */   }
/* 222:    */   
/* 223:    */   public List<BasicBlock> getSuccs()
/* 224:    */   {
/* 225:241 */     return this.succs;
/* 226:    */   }
/* 227:    */   
/* 228:    */   public void setSuccs(List<BasicBlock> succs)
/* 229:    */   {
/* 230:245 */     this.succs = succs;
/* 231:    */   }
/* 232:    */   
/* 233:    */   public List<BasicBlock> getSuccExceptions()
/* 234:    */   {
/* 235:250 */     return this.succExceptions;
/* 236:    */   }
/* 237:    */   
/* 238:    */   public void setSuccExceptions(List<BasicBlock> succExceptions)
/* 239:    */   {
/* 240:255 */     this.succExceptions = succExceptions;
/* 241:    */   }
/* 242:    */   
/* 243:    */   public List<BasicBlock> getPredExceptions()
/* 244:    */   {
/* 245:259 */     return this.predExceptions;
/* 246:    */   }
/* 247:    */   
/* 248:    */   public void setPredExceptions(List<BasicBlock> predExceptions)
/* 249:    */   {
/* 250:263 */     this.predExceptions = predExceptions;
/* 251:    */   }
/* 252:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.cfg.BasicBlock
 * JD-Core Version:    0.7.0.1
 */