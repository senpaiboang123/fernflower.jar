/*   1:    */ package org.jetbrains.java.decompiler.code.cfg;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.LinkedList;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Map;
/*  11:    */ import java.util.Map.Entry;
/*  12:    */ import java.util.Set;
/*  13:    */ import org.jetbrains.java.decompiler.code.CodeConstants;
/*  14:    */ import org.jetbrains.java.decompiler.code.ExceptionHandler;
/*  15:    */ import org.jetbrains.java.decompiler.code.ExceptionTable;
/*  16:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*  17:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*  18:    */ import org.jetbrains.java.decompiler.code.JumpInstruction;
/*  19:    */ import org.jetbrains.java.decompiler.code.SwitchInstruction;
/*  20:    */ import org.jetbrains.java.decompiler.code.interpreter.InstructionImpact;
/*  21:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  22:    */ import org.jetbrains.java.decompiler.modules.code.DeadCodeHelper;
/*  23:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  24:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  25:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  26:    */ import org.jetbrains.java.decompiler.struct.gen.DataPoint;
/*  27:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  28:    */ import org.jetbrains.java.decompiler.util.ListStack;
/*  29:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  30:    */ 
/*  31:    */ public class ControlFlowGraph
/*  32:    */   implements CodeConstants
/*  33:    */ {
/*  34: 34 */   public int last_id = 0;
/*  35:    */   private VBStyleCollection<BasicBlock, Integer> blocks;
/*  36:    */   private BasicBlock first;
/*  37:    */   private BasicBlock last;
/*  38:    */   private List<ExceptionRangeCFG> exceptions;
/*  39:    */   private Map<BasicBlock, BasicBlock> subroutines;
/*  40: 50 */   private Set<BasicBlock> finallyExits = new HashSet();
/*  41:    */   
/*  42:    */   public ControlFlowGraph(InstructionSequence seq)
/*  43:    */   {
/*  44: 57 */     buildBlocks(seq);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void free()
/*  48:    */   {
/*  49: 67 */     for (BasicBlock block : this.blocks) {
/*  50: 68 */       block.free();
/*  51:    */     }
/*  52: 71 */     this.blocks.clear();
/*  53: 72 */     this.first = null;
/*  54: 73 */     this.last = null;
/*  55: 74 */     this.exceptions.clear();
/*  56: 75 */     this.finallyExits.clear();
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void removeMarkers()
/*  60:    */   {
/*  61: 79 */     for (BasicBlock block : this.blocks) {
/*  62: 80 */       block.mark = 0;
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   public String toString()
/*  67:    */   {
/*  68: 85 */     if (this.blocks == null) {
/*  69: 85 */       return "Empty";
/*  70:    */     }
/*  71: 87 */     String new_line_separator = DecompilerContext.getNewLineSeparator();
/*  72:    */     
/*  73: 89 */     StringBuilder buf = new StringBuilder();
/*  74: 91 */     for (BasicBlock block : this.blocks)
/*  75:    */     {
/*  76: 92 */       buf.append("----- Block ").append(block.id).append(" -----").append(new_line_separator);
/*  77: 93 */       buf.append(block.toString());
/*  78: 94 */       buf.append("----- Edges -----").append(new_line_separator);
/*  79:    */       
/*  80: 96 */       List<BasicBlock> suc = block.getSuccs();
/*  81: 97 */       for (int j = 0; j < suc.size(); j++) {
/*  82: 98 */         buf.append(">>>>>>>>(regular) Block ").append(((BasicBlock)suc.get(j)).id).append(new_line_separator);
/*  83:    */       }
/*  84:100 */       suc = block.getSuccExceptions();
/*  85:    */       BasicBlock handler;
/*  86:101 */       for (int j = 0; j < suc.size(); j++)
/*  87:    */       {
/*  88:102 */         handler = (BasicBlock)suc.get(j);
/*  89:103 */         ExceptionRangeCFG range = getExceptionRange(handler, block);
/*  90:105 */         if (range == null)
/*  91:    */         {
/*  92:106 */           buf.append(">>>>>>>>(exception) Block ").append(handler.id).append("\t").append("ERROR: range not found!").append(new_line_separator);
/*  93:    */         }
/*  94:    */         else
/*  95:    */         {
/*  96:110 */           List<String> exceptionTypes = range.getExceptionTypes();
/*  97:111 */           if (exceptionTypes == null) {
/*  98:112 */             buf.append(">>>>>>>>(exception) Block ").append(handler.id).append("\t").append("NULL").append(new_line_separator);
/*  99:    */           } else {
/* 100:115 */             for (String exceptionType : exceptionTypes) {
/* 101:116 */               buf.append(">>>>>>>>(exception) Block ").append(handler.id).append("\t").append(exceptionType).append(new_line_separator);
/* 102:    */             }
/* 103:    */           }
/* 104:    */         }
/* 105:    */       }
/* 106:121 */       buf.append("----- ----- -----").append(new_line_separator);
/* 107:    */     }
/* 108:124 */     return buf.toString();
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void inlineJsr(StructMethod mt)
/* 112:    */   {
/* 113:128 */     processJsr();
/* 114:129 */     removeJsr(mt);
/* 115:    */     
/* 116:131 */     removeMarkers();
/* 117:    */     
/* 118:133 */     DeadCodeHelper.removeEmptyBlocks(this);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void removeBlock(BasicBlock block)
/* 122:    */   {
/* 123:138 */     while (block.getSuccs().size() > 0) {
/* 124:139 */       block.removeSuccessor((BasicBlock)block.getSuccs().get(0));
/* 125:    */     }
/* 126:142 */     while (block.getSuccExceptions().size() > 0) {
/* 127:143 */       block.removeSuccessorException((BasicBlock)block.getSuccExceptions().get(0));
/* 128:    */     }
/* 129:146 */     while (block.getPreds().size() > 0) {
/* 130:147 */       ((BasicBlock)block.getPreds().get(0)).removeSuccessor(block);
/* 131:    */     }
/* 132:150 */     while (block.getPredExceptions().size() > 0) {
/* 133:151 */       ((BasicBlock)block.getPredExceptions().get(0)).removeSuccessorException(block);
/* 134:    */     }
/* 135:154 */     this.last.removePredecessor(block);
/* 136:    */     
/* 137:156 */     this.blocks.removeWithKey(Integer.valueOf(block.id));
/* 138:158 */     for (int i = this.exceptions.size() - 1; i >= 0; i--)
/* 139:    */     {
/* 140:159 */       ExceptionRangeCFG range = (ExceptionRangeCFG)this.exceptions.get(i);
/* 141:160 */       if (range.getHandler() == block)
/* 142:    */       {
/* 143:161 */         this.exceptions.remove(i);
/* 144:    */       }
/* 145:    */       else
/* 146:    */       {
/* 147:164 */         List<BasicBlock> lstRange = range.getProtectedRange();
/* 148:165 */         lstRange.remove(block);
/* 149:167 */         if (lstRange.isEmpty()) {
/* 150:168 */           this.exceptions.remove(i);
/* 151:    */         }
/* 152:    */       }
/* 153:    */     }
/* 154:173 */     Iterator<Map.Entry<BasicBlock, BasicBlock>> it = this.subroutines.entrySet().iterator();
/* 155:174 */     while (it.hasNext())
/* 156:    */     {
/* 157:175 */       Map.Entry<BasicBlock, BasicBlock> ent = (Map.Entry)it.next();
/* 158:176 */       if ((ent.getKey() == block) || (ent.getValue() == block)) {
/* 159:177 */         it.remove();
/* 160:    */       }
/* 161:    */     }
/* 162:    */   }
/* 163:    */   
/* 164:    */   public ExceptionRangeCFG getExceptionRange(BasicBlock handler, BasicBlock block)
/* 165:    */   {
/* 166:186 */     for (int i = this.exceptions.size() - 1; i >= 0; i--)
/* 167:    */     {
/* 168:187 */       ExceptionRangeCFG range = (ExceptionRangeCFG)this.exceptions.get(i);
/* 169:188 */       if ((range.getHandler() == handler) && (range.getProtectedRange().contains(block))) {
/* 170:189 */         return range;
/* 171:    */       }
/* 172:    */     }
/* 173:194 */     return null;
/* 174:    */   }
/* 175:    */   
/* 176:    */   private void buildBlocks(InstructionSequence instrseq)
/* 177:    */   {
/* 178:226 */     short[] states = findStartInstructions(instrseq);
/* 179:    */     
/* 180:228 */     Map<Integer, BasicBlock> mapInstrBlocks = new HashMap();
/* 181:229 */     VBStyleCollection<BasicBlock, Integer> colBlocks = createBasicBlocks(states, instrseq, mapInstrBlocks);
/* 182:    */     
/* 183:231 */     this.blocks = colBlocks;
/* 184:    */     
/* 185:233 */     connectBlocks(colBlocks, mapInstrBlocks);
/* 186:    */     
/* 187:235 */     setExceptionEdges(instrseq, mapInstrBlocks);
/* 188:    */     
/* 189:237 */     setSubroutineEdges();
/* 190:    */     
/* 191:239 */     setFirstAndLastBlocks();
/* 192:    */   }
/* 193:    */   
/* 194:    */   private static short[] findStartInstructions(InstructionSequence seq)
/* 195:    */   {
/* 196:244 */     int len = seq.length();
/* 197:245 */     short[] inststates = new short[len];
/* 198:    */     
/* 199:247 */     Set<Integer> excSet = new HashSet();
/* 200:249 */     for (ExceptionHandler handler : seq.getExceptionTable().getHandlers())
/* 201:    */     {
/* 202:250 */       excSet.add(Integer.valueOf(handler.from_instr));
/* 203:251 */       excSet.add(Integer.valueOf(handler.to_instr));
/* 204:252 */       excSet.add(Integer.valueOf(handler.handler_instr));
/* 205:    */     }
/* 206:256 */     for (int i = 0; i < len; i++)
/* 207:    */     {
/* 208:259 */       if (excSet.contains(new Integer(i))) {
/* 209:260 */         inststates[i] = 1;
/* 210:    */       }
/* 211:263 */       Instruction instr = seq.getInstr(i);
/* 212:264 */       switch (instr.group)
/* 213:    */       {
/* 214:    */       case 2: 
/* 215:266 */         inststates[((JumpInstruction)instr).destination] = 1;
/* 216:    */       case 6: 
/* 217:268 */         if (i + 1 < len) {
/* 218:269 */           inststates[(i + 1)] = 1;
/* 219:    */         }
/* 220:    */         break;
/* 221:    */       case 3: 
/* 222:273 */         SwitchInstruction swinstr = (SwitchInstruction)instr;
/* 223:274 */         int[] dests = swinstr.getDestinations();
/* 224:275 */         for (int j = dests.length - 1; j >= 0; j--) {
/* 225:276 */           inststates[dests[j]] = 1;
/* 226:    */         }
/* 227:278 */         inststates[swinstr.getDefaultdest()] = 1;
/* 228:279 */         if (i + 1 < len) {
/* 229:280 */           inststates[(i + 1)] = 1;
/* 230:    */         }
/* 231:    */         break;
/* 232:    */       }
/* 233:    */     }
/* 234:286 */     inststates[0] = 1;
/* 235:    */     
/* 236:288 */     return inststates;
/* 237:    */   }
/* 238:    */   
/* 239:    */   private VBStyleCollection<BasicBlock, Integer> createBasicBlocks(short[] startblock, InstructionSequence instrseq, Map<Integer, BasicBlock> mapInstrBlocks)
/* 240:    */   {
/* 241:296 */     VBStyleCollection<BasicBlock, Integer> col = new VBStyleCollection();
/* 242:    */     
/* 243:298 */     InstructionSequence currseq = null;
/* 244:299 */     List<Integer> lstOffs = null;
/* 245:    */     
/* 246:301 */     int len = startblock.length;
/* 247:302 */     short counter = 0;
/* 248:303 */     int blockoffset = 0;
/* 249:    */     
/* 250:305 */     BasicBlock currentBlock = null;
/* 251:306 */     for (int i = 0; i < len; i++)
/* 252:    */     {
/* 253:308 */       if (startblock[i] == 1)
/* 254:    */       {
/* 255:309 */         counter = (short)(counter + 1);currentBlock = new BasicBlock(counter);
/* 256:    */         
/* 257:311 */         currseq = currentBlock.getSeq();
/* 258:312 */         lstOffs = currentBlock.getInstrOldOffsets();
/* 259:    */         
/* 260:314 */         col.addWithKey(currentBlock, Integer.valueOf(currentBlock.id));
/* 261:    */         
/* 262:316 */         blockoffset = instrseq.getOffset(i);
/* 263:    */       }
/* 264:319 */       startblock[i] = counter;
/* 265:320 */       mapInstrBlocks.put(Integer.valueOf(i), currentBlock);
/* 266:    */       
/* 267:322 */       currseq.addInstruction(instrseq.getInstr(i), instrseq.getOffset(i) - blockoffset);
/* 268:323 */       lstOffs.add(Integer.valueOf(instrseq.getOffset(i)));
/* 269:    */     }
/* 270:326 */     this.last_id = counter;
/* 271:    */     
/* 272:328 */     return col;
/* 273:    */   }
/* 274:    */   
/* 275:    */   private static void connectBlocks(List<BasicBlock> lstbb, Map<Integer, BasicBlock> mapInstrBlocks)
/* 276:    */   {
/* 277:334 */     for (int i = 0; i < lstbb.size(); i++)
/* 278:    */     {
/* 279:336 */       BasicBlock block = (BasicBlock)lstbb.get(i);
/* 280:337 */       Instruction instr = block.getLastInstruction();
/* 281:    */       
/* 282:339 */       boolean fallthrough = instr.canFallthrough();
/* 283:    */       BasicBlock bTemp;
/* 284:342 */       switch (instr.group)
/* 285:    */       {
/* 286:    */       case 2: 
/* 287:344 */         int dest = ((JumpInstruction)instr).destination;
/* 288:345 */         bTemp = (BasicBlock)mapInstrBlocks.get(Integer.valueOf(dest));
/* 289:346 */         block.addSuccessor(bTemp);
/* 290:    */         
/* 291:348 */         break;
/* 292:    */       case 3: 
/* 293:350 */         SwitchInstruction sinstr = (SwitchInstruction)instr;
/* 294:351 */         int[] dests = sinstr.getDestinations();
/* 295:    */         
/* 296:353 */         bTemp = (BasicBlock)mapInstrBlocks.get(Integer.valueOf(((SwitchInstruction)instr).getDefaultdest()));
/* 297:354 */         block.addSuccessor(bTemp);
/* 298:355 */         for (int j = 0; j < dests.length; j++)
/* 299:    */         {
/* 300:356 */           bTemp = (BasicBlock)mapInstrBlocks.get(Integer.valueOf(dests[j]));
/* 301:357 */           block.addSuccessor(bTemp);
/* 302:    */         }
/* 303:    */       }
/* 304:361 */       if ((fallthrough) && (i < lstbb.size() - 1))
/* 305:    */       {
/* 306:362 */         BasicBlock defaultBlock = (BasicBlock)lstbb.get(i + 1);
/* 307:363 */         block.addSuccessor(defaultBlock);
/* 308:    */       }
/* 309:    */     }
/* 310:    */   }
/* 311:    */   
/* 312:    */   private void setExceptionEdges(InstructionSequence instrseq, Map<Integer, BasicBlock> instrBlocks)
/* 313:    */   {
/* 314:370 */     this.exceptions = new ArrayList();
/* 315:    */     
/* 316:372 */     Map<String, ExceptionRangeCFG> mapRanges = new HashMap();
/* 317:374 */     for (ExceptionHandler handler : instrseq.getExceptionTable().getHandlers())
/* 318:    */     {
/* 319:376 */       BasicBlock from = (BasicBlock)instrBlocks.get(Integer.valueOf(handler.from_instr));
/* 320:377 */       BasicBlock to = (BasicBlock)instrBlocks.get(Integer.valueOf(handler.to_instr));
/* 321:378 */       BasicBlock handle = (BasicBlock)instrBlocks.get(Integer.valueOf(handler.handler_instr));
/* 322:    */       
/* 323:380 */       String key = from.id + ":" + to.id + ":" + handle.id;
/* 324:382 */       if (mapRanges.containsKey(key))
/* 325:    */       {
/* 326:383 */         ExceptionRangeCFG range = (ExceptionRangeCFG)mapRanges.get(key);
/* 327:384 */         range.addExceptionType(handler.exceptionClass);
/* 328:    */       }
/* 329:    */       else
/* 330:    */       {
/* 331:388 */         List<BasicBlock> protectedRange = new ArrayList();
/* 332:389 */         for (int j = from.id; j < to.id; j++)
/* 333:    */         {
/* 334:390 */           BasicBlock block = (BasicBlock)this.blocks.getWithKey(Integer.valueOf(j));
/* 335:391 */           protectedRange.add(block);
/* 336:392 */           block.addSuccessorException(handle);
/* 337:    */         }
/* 338:395 */         ExceptionRangeCFG range = new ExceptionRangeCFG(protectedRange, handle, handler.exceptionClass == null ? null : Collections.singletonList(handler.exceptionClass));
/* 339:    */         
/* 340:    */ 
/* 341:398 */         mapRanges.put(key, range);
/* 342:    */         
/* 343:400 */         this.exceptions.add(range);
/* 344:    */       }
/* 345:    */     }
/* 346:    */   }
/* 347:    */   
/* 348:    */   private void setSubroutineEdges()
/* 349:    */   {
/* 350:407 */     Map<BasicBlock, BasicBlock> subroutines = new HashMap();
/* 351:409 */     for (BasicBlock block : this.blocks) {
/* 352:411 */       if (block.getSeq().getLastInstr().opcode == 168)
/* 353:    */       {
/* 354:413 */         LinkedList<BasicBlock> stack = new LinkedList();
/* 355:414 */         LinkedList<LinkedList<BasicBlock>> stackJsrStacks = new LinkedList();
/* 356:    */         
/* 357:416 */         Set<BasicBlock> setVisited = new HashSet();
/* 358:    */         
/* 359:418 */         stack.add(block);
/* 360:419 */         stackJsrStacks.add(new LinkedList());
/* 361:    */         LinkedList<BasicBlock> jsrstack;
/* 362:421 */         while (!stack.isEmpty())
/* 363:    */         {
/* 364:423 */           BasicBlock node = (BasicBlock)stack.removeFirst();
/* 365:424 */           jsrstack = (LinkedList)stackJsrStacks.removeFirst();
/* 366:    */           
/* 367:426 */           setVisited.add(node);
/* 368:428 */           switch (node.getSeq().getLastInstr().opcode)
/* 369:    */           {
/* 370:    */           case 168: 
/* 371:430 */             jsrstack.add(node);
/* 372:431 */             break;
/* 373:    */           case 169: 
/* 374:433 */             BasicBlock enter = (BasicBlock)jsrstack.getLast();
/* 375:434 */             BasicBlock exit = (BasicBlock)this.blocks.getWithKey(Integer.valueOf(enter.id + 1));
/* 376:436 */             if (exit != null)
/* 377:    */             {
/* 378:437 */               if (!node.isSuccessor(exit)) {
/* 379:438 */                 node.addSuccessor(exit);
/* 380:    */               }
/* 381:440 */               jsrstack.removeLast();
/* 382:441 */               subroutines.put(enter, exit);
/* 383:    */             }
/* 384:    */             else
/* 385:    */             {
/* 386:444 */               throw new RuntimeException("ERROR: last instruction jsr");
/* 387:    */             }
/* 388:    */             break;
/* 389:    */           }
/* 390:448 */           if (!jsrstack.isEmpty()) {
/* 391:449 */             for (BasicBlock succ : node.getSuccs()) {
/* 392:450 */               if (!setVisited.contains(succ))
/* 393:    */               {
/* 394:451 */                 stack.add(succ);
/* 395:452 */                 stackJsrStacks.add(new LinkedList(jsrstack));
/* 396:    */               }
/* 397:    */             }
/* 398:    */           }
/* 399:    */         }
/* 400:    */       }
/* 401:    */     }
/* 402:460 */     this.subroutines = subroutines;
/* 403:    */   }
/* 404:    */   
/* 405:    */   private void processJsr()
/* 406:    */   {
/* 407:    */     for (;;)
/* 408:    */     {
/* 409:465 */       if (processJsrRanges() == 0) {
/* 410:    */         break;
/* 411:    */       }
/* 412:    */     }
/* 413:    */   }
/* 414:    */   
/* 415:    */   private static class JsrRecord
/* 416:    */   {
/* 417:    */     private final BasicBlock jsr;
/* 418:    */     private final Set<BasicBlock> range;
/* 419:    */     private final BasicBlock ret;
/* 420:    */     
/* 421:    */     private JsrRecord(BasicBlock jsr, Set<BasicBlock> range, BasicBlock ret)
/* 422:    */     {
/* 423:475 */       this.jsr = jsr;
/* 424:476 */       this.range = range;
/* 425:477 */       this.ret = ret;
/* 426:    */     }
/* 427:    */   }
/* 428:    */   
/* 429:    */   private int processJsrRanges()
/* 430:    */   {
/* 431:483 */     List<JsrRecord> lstJsrAll = new ArrayList();
/* 432:486 */     for (Map.Entry<BasicBlock, BasicBlock> ent : this.subroutines.entrySet())
/* 433:    */     {
/* 434:487 */       BasicBlock jsr = (BasicBlock)ent.getKey();
/* 435:488 */       BasicBlock ret = (BasicBlock)ent.getValue();
/* 436:    */       
/* 437:490 */       lstJsrAll.add(new JsrRecord(jsr, getJsrRange(jsr, ret), ret, null));
/* 438:    */     }
/* 439:495 */     List<JsrRecord> lstJsr = new ArrayList();
/* 440:496 */     for (JsrRecord arr : lstJsrAll)
/* 441:    */     {
/* 442:497 */       for (int i = 0; i < lstJsr.size(); i++)
/* 443:    */       {
/* 444:499 */         JsrRecord arrJsr = (JsrRecord)lstJsr.get(i);
/* 445:500 */         if (arrJsr.range.contains(arr.jsr)) {
/* 446:    */           break;
/* 447:    */         }
/* 448:    */       }
/* 449:504 */       lstJsr.add(i, arr);
/* 450:    */     }
/* 451:508 */     for (int i = 0; i < lstJsr.size(); i++)
/* 452:    */     {
/* 453:509 */       JsrRecord arr = (JsrRecord)lstJsr.get(i);
/* 454:510 */       Set<BasicBlock> set = arr.range;
/* 455:512 */       for (int j = i + 1; j < lstJsr.size(); j++)
/* 456:    */       {
/* 457:513 */         JsrRecord arr1 = (JsrRecord)lstJsr.get(j);
/* 458:514 */         Set<BasicBlock> set1 = arr1.range;
/* 459:516 */         if ((!set.contains(arr1.jsr)) && (!set1.contains(arr.jsr)))
/* 460:    */         {
/* 461:517 */           Set<BasicBlock> setc = new HashSet(set);
/* 462:518 */           setc.retainAll(set1);
/* 463:520 */           if (!setc.isEmpty())
/* 464:    */           {
/* 465:521 */             splitJsrRange(arr.jsr, arr.ret, setc);
/* 466:522 */             return 1;
/* 467:    */           }
/* 468:    */         }
/* 469:    */       }
/* 470:    */     }
/* 471:528 */     return 0;
/* 472:    */   }
/* 473:    */   
/* 474:    */   private Set<BasicBlock> getJsrRange(BasicBlock jsr, BasicBlock ret)
/* 475:    */   {
/* 476:533 */     Set<BasicBlock> blocks = new HashSet();
/* 477:    */     
/* 478:535 */     List<BasicBlock> lstNodes = new LinkedList();
/* 479:536 */     lstNodes.add(jsr);
/* 480:    */     
/* 481:538 */     BasicBlock dom = (BasicBlock)jsr.getSuccs().get(0);
/* 482:540 */     while (!lstNodes.isEmpty())
/* 483:    */     {
/* 484:542 */       BasicBlock node = (BasicBlock)lstNodes.remove(0);
/* 485:544 */       for (int j = 0; j < 2; j++)
/* 486:    */       {
/* 487:    */         List<BasicBlock> lst;
/* 488:    */         List<BasicBlock> lst;
/* 489:546 */         if (j == 0)
/* 490:    */         {
/* 491:547 */           if ((node.getLastInstruction().opcode == 169) && 
/* 492:548 */             (node.getSuccs().contains(ret))) {
/* 493:    */             continue;
/* 494:    */           }
/* 495:552 */           lst = node.getSuccs();
/* 496:    */         }
/* 497:    */         else
/* 498:    */         {
/* 499:555 */           if (node == jsr) {
/* 500:    */             continue;
/* 501:    */           }
/* 502:558 */           lst = node.getSuccExceptions();
/* 503:    */         }
/* 504:    */         label312:
/* 505:562 */         for (int i = lst.size() - 1; i >= 0; i--)
/* 506:    */         {
/* 507:564 */           BasicBlock child = (BasicBlock)lst.get(i);
/* 508:565 */           if (!blocks.contains(child))
/* 509:    */           {
/* 510:567 */             if (node != jsr)
/* 511:    */             {
/* 512:568 */               for (int k = 0; k < child.getPreds().size(); k++) {
/* 513:569 */                 if (!DeadCodeHelper.isDominator(this, (BasicBlock)child.getPreds().get(k), dom)) {
/* 514:    */                   break label312;
/* 515:    */                 }
/* 516:    */               }
/* 517:574 */               for (int k = 0; k < child.getPredExceptions().size(); k++) {
/* 518:575 */                 if (!DeadCodeHelper.isDominator(this, (BasicBlock)child.getPredExceptions().get(k), dom)) {
/* 519:    */                   break label312;
/* 520:    */                 }
/* 521:    */               }
/* 522:    */             }
/* 523:582 */             if (child != this.last) {
/* 524:583 */               blocks.add(child);
/* 525:    */             }
/* 526:586 */             lstNodes.add(child);
/* 527:    */           }
/* 528:    */         }
/* 529:    */       }
/* 530:    */     }
/* 531:592 */     return blocks;
/* 532:    */   }
/* 533:    */   
/* 534:    */   private void splitJsrRange(BasicBlock jsr, BasicBlock ret, Set<BasicBlock> common_blocks)
/* 535:    */   {
/* 536:597 */     List<BasicBlock> lstNodes = new LinkedList();
/* 537:598 */     Map<Integer, BasicBlock> mapNewNodes = new HashMap();
/* 538:    */     
/* 539:600 */     lstNodes.add(jsr);
/* 540:601 */     mapNewNodes.put(Integer.valueOf(jsr.id), jsr);
/* 541:603 */     while (!lstNodes.isEmpty())
/* 542:    */     {
/* 543:605 */       BasicBlock node = (BasicBlock)lstNodes.remove(0);
/* 544:607 */       for (int j = 0; j < 2; j++)
/* 545:    */       {
/* 546:    */         List<BasicBlock> lst;
/* 547:    */         List<BasicBlock> lst;
/* 548:609 */         if (j == 0)
/* 549:    */         {
/* 550:610 */           if ((node.getLastInstruction().opcode == 169) && 
/* 551:611 */             (node.getSuccs().contains(ret))) {
/* 552:    */             continue;
/* 553:    */           }
/* 554:615 */           lst = node.getSuccs();
/* 555:    */         }
/* 556:    */         else
/* 557:    */         {
/* 558:618 */           if (node == jsr) {
/* 559:    */             continue;
/* 560:    */           }
/* 561:621 */           lst = node.getSuccExceptions();
/* 562:    */         }
/* 563:625 */         for (int i = lst.size() - 1; i >= 0; i--)
/* 564:    */         {
/* 565:627 */           BasicBlock child = (BasicBlock)lst.get(i);
/* 566:628 */           Integer childid = Integer.valueOf(child.id);
/* 567:630 */           if (mapNewNodes.containsKey(childid))
/* 568:    */           {
/* 569:631 */             node.replaceSuccessor(child, (BasicBlock)mapNewNodes.get(childid));
/* 570:    */           }
/* 571:633 */           else if (common_blocks.contains(child))
/* 572:    */           {
/* 573:636 */             BasicBlock copy = (BasicBlock)child.clone();
/* 574:637 */             copy.id = (++this.last_id);
/* 575:639 */             if ((copy.getLastInstruction().opcode == 169) && (child.getSuccs().contains(ret)))
/* 576:    */             {
/* 577:641 */               copy.addSuccessor(ret);
/* 578:642 */               child.removeSuccessor(ret);
/* 579:    */             }
/* 580:    */             else
/* 581:    */             {
/* 582:645 */               for (int k = 0; k < child.getSuccs().size(); k++) {
/* 583:646 */                 copy.addSuccessor((BasicBlock)child.getSuccs().get(k));
/* 584:    */               }
/* 585:    */             }
/* 586:649 */             for (int k = 0; k < child.getSuccExceptions().size(); k++) {
/* 587:650 */               copy.addSuccessorException((BasicBlock)child.getSuccExceptions().get(k));
/* 588:    */             }
/* 589:653 */             lstNodes.add(copy);
/* 590:654 */             mapNewNodes.put(childid, copy);
/* 591:656 */             if (this.last.getPreds().contains(child)) {
/* 592:657 */               this.last.addPredecessor(copy);
/* 593:    */             }
/* 594:660 */             node.replaceSuccessor(child, copy);
/* 595:661 */             this.blocks.addWithKey(copy, Integer.valueOf(copy.id));
/* 596:    */           }
/* 597:    */           else
/* 598:    */           {
/* 599:666 */             mapNewNodes.put(childid, child);
/* 600:    */           }
/* 601:    */         }
/* 602:    */       }
/* 603:    */     }
/* 604:673 */     splitJsrExceptionRanges(common_blocks, mapNewNodes);
/* 605:    */   }
/* 606:    */   
/* 607:    */   private void splitJsrExceptionRanges(Set<BasicBlock> common_blocks, Map<Integer, BasicBlock> mapNewNodes)
/* 608:    */   {
/* 609:    */     List<BasicBlock> lstNewRange;
/* 610:678 */     for (int i = this.exceptions.size() - 1; i >= 0; i--)
/* 611:    */     {
/* 612:680 */       ExceptionRangeCFG range = (ExceptionRangeCFG)this.exceptions.get(i);
/* 613:681 */       List<BasicBlock> lstRange = range.getProtectedRange();
/* 614:    */       
/* 615:683 */       HashSet<BasicBlock> setBoth = new HashSet(common_blocks);
/* 616:684 */       setBoth.retainAll(lstRange);
/* 617:686 */       if (setBoth.size() > 0)
/* 618:    */       {
/* 619:689 */         if (setBoth.size() == lstRange.size())
/* 620:    */         {
/* 621:690 */           List<BasicBlock> lstNewRange = new ArrayList();
/* 622:691 */           ExceptionRangeCFG newRange = new ExceptionRangeCFG(lstNewRange, (BasicBlock)mapNewNodes.get(Integer.valueOf(range.getHandler().id)), range.getExceptionTypes());
/* 623:    */           
/* 624:693 */           this.exceptions.add(newRange);
/* 625:    */         }
/* 626:    */         else
/* 627:    */         {
/* 628:696 */           lstNewRange = lstRange;
/* 629:    */         }
/* 630:699 */         for (BasicBlock block : setBoth) {
/* 631:700 */           lstNewRange.add(mapNewNodes.get(Integer.valueOf(block.id)));
/* 632:    */         }
/* 633:    */       }
/* 634:    */     }
/* 635:    */   }
/* 636:    */   
/* 637:    */   private void removeJsr(StructMethod mt)
/* 638:    */   {
/* 639:707 */     removeJsrInstructions(mt.getClassStruct().getPool(), this.first, DataPoint.getInitialDataPoint(mt));
/* 640:    */   }
/* 641:    */   
/* 642:    */   private static void removeJsrInstructions(ConstantPool pool, BasicBlock block, DataPoint data)
/* 643:    */   {
/* 644:712 */     ListStack<VarType> stack = data.getStack();
/* 645:    */     
/* 646:714 */     InstructionSequence seq = block.getSeq();
/* 647:715 */     for (int i = 0; i < seq.length(); i++)
/* 648:    */     {
/* 649:716 */       Instruction instr = seq.getInstr(i);
/* 650:    */       
/* 651:718 */       VarType var = null;
/* 652:719 */       if ((instr.opcode == 58) || (instr.opcode == 87)) {
/* 653:720 */         var = (VarType)stack.getByOffset(-1);
/* 654:    */       }
/* 655:723 */       InstructionImpact.stepTypes(data, instr, pool);
/* 656:725 */       switch (instr.opcode)
/* 657:    */       {
/* 658:    */       case 168: 
/* 659:    */       case 169: 
/* 660:728 */         seq.removeInstruction(i);
/* 661:729 */         i--;
/* 662:730 */         break;
/* 663:    */       case 58: 
/* 664:    */       case 87: 
/* 665:733 */         if (var.type == 9)
/* 666:    */         {
/* 667:734 */           seq.removeInstruction(i);
/* 668:735 */           i--;
/* 669:    */         }
/* 670:    */         break;
/* 671:    */       }
/* 672:    */     }
/* 673:740 */     block.mark = 1;
/* 674:742 */     for (int i = 0; i < block.getSuccs().size(); i++)
/* 675:    */     {
/* 676:743 */       BasicBlock suc = (BasicBlock)block.getSuccs().get(i);
/* 677:744 */       if (suc.mark != 1) {
/* 678:745 */         removeJsrInstructions(pool, suc, data.copy());
/* 679:    */       }
/* 680:    */     }
/* 681:749 */     for (int i = 0; i < block.getSuccExceptions().size(); i++)
/* 682:    */     {
/* 683:750 */       BasicBlock suc = (BasicBlock)block.getSuccExceptions().get(i);
/* 684:751 */       if (suc.mark != 1)
/* 685:    */       {
/* 686:753 */         DataPoint point = new DataPoint();
/* 687:754 */         point.setLocalVariables(new ArrayList(data.getLocalVariables()));
/* 688:755 */         point.getStack().push(new VarType(8, 0, null));
/* 689:    */         
/* 690:757 */         removeJsrInstructions(pool, suc, point);
/* 691:    */       }
/* 692:    */     }
/* 693:    */   }
/* 694:    */   
/* 695:    */   private void setFirstAndLastBlocks()
/* 696:    */   {
/* 697:764 */     this.first = ((BasicBlock)this.blocks.get(0));
/* 698:    */     
/* 699:766 */     this.last = new BasicBlock(++this.last_id);
/* 700:768 */     for (BasicBlock block : this.blocks) {
/* 701:769 */       if (block.getSuccs().isEmpty()) {
/* 702:770 */         this.last.addPredecessor(block);
/* 703:    */       }
/* 704:    */     }
/* 705:    */   }
/* 706:    */   
/* 707:    */   public List<BasicBlock> getReversePostOrder()
/* 708:    */   {
/* 709:777 */     List<BasicBlock> res = new LinkedList();
/* 710:778 */     addToReversePostOrderListIterative(this.first, res);
/* 711:    */     
/* 712:780 */     return res;
/* 713:    */   }
/* 714:    */   
/* 715:    */   private static void addToReversePostOrderListIterative(BasicBlock root, List<BasicBlock> lst)
/* 716:    */   {
/* 717:785 */     LinkedList<BasicBlock> stackNode = new LinkedList();
/* 718:786 */     LinkedList<Integer> stackIndex = new LinkedList();
/* 719:    */     
/* 720:788 */     Set<BasicBlock> setVisited = new HashSet();
/* 721:    */     
/* 722:790 */     stackNode.add(root);
/* 723:791 */     stackIndex.add(Integer.valueOf(0));
/* 724:793 */     while (!stackNode.isEmpty())
/* 725:    */     {
/* 726:795 */       BasicBlock node = (BasicBlock)stackNode.getLast();
/* 727:796 */       int index = ((Integer)stackIndex.removeLast()).intValue();
/* 728:    */       
/* 729:798 */       setVisited.add(node);
/* 730:    */       
/* 731:800 */       List<BasicBlock> lstSuccs = new ArrayList(node.getSuccs());
/* 732:801 */       lstSuccs.addAll(node.getSuccExceptions());
/* 733:803 */       for (; index < lstSuccs.size(); index++)
/* 734:    */       {
/* 735:804 */         BasicBlock succ = (BasicBlock)lstSuccs.get(index);
/* 736:806 */         if (!setVisited.contains(succ))
/* 737:    */         {
/* 738:807 */           stackIndex.add(Integer.valueOf(index + 1));
/* 739:    */           
/* 740:809 */           stackNode.add(succ);
/* 741:810 */           stackIndex.add(Integer.valueOf(0));
/* 742:    */           
/* 743:812 */           break;
/* 744:    */         }
/* 745:    */       }
/* 746:816 */       if (index == lstSuccs.size())
/* 747:    */       {
/* 748:817 */         lst.add(0, node);
/* 749:    */         
/* 750:819 */         stackNode.removeLast();
/* 751:    */       }
/* 752:    */     }
/* 753:    */   }
/* 754:    */   
/* 755:    */   public VBStyleCollection<BasicBlock, Integer> getBlocks()
/* 756:    */   {
/* 757:830 */     return this.blocks;
/* 758:    */   }
/* 759:    */   
/* 760:    */   public void setBlocks(VBStyleCollection<BasicBlock, Integer> blocks)
/* 761:    */   {
/* 762:834 */     this.blocks = blocks;
/* 763:    */   }
/* 764:    */   
/* 765:    */   public BasicBlock getFirst()
/* 766:    */   {
/* 767:838 */     return this.first;
/* 768:    */   }
/* 769:    */   
/* 770:    */   public void setFirst(BasicBlock first)
/* 771:    */   {
/* 772:842 */     this.first = first;
/* 773:    */   }
/* 774:    */   
/* 775:    */   public List<BasicBlock> getEndBlocks()
/* 776:    */   {
/* 777:846 */     return this.last.getPreds();
/* 778:    */   }
/* 779:    */   
/* 780:    */   public List<ExceptionRangeCFG> getExceptions()
/* 781:    */   {
/* 782:850 */     return this.exceptions;
/* 783:    */   }
/* 784:    */   
/* 785:    */   public void setExceptions(List<ExceptionRangeCFG> exceptions)
/* 786:    */   {
/* 787:854 */     this.exceptions = exceptions;
/* 788:    */   }
/* 789:    */   
/* 790:    */   public BasicBlock getLast()
/* 791:    */   {
/* 792:858 */     return this.last;
/* 793:    */   }
/* 794:    */   
/* 795:    */   public void setLast(BasicBlock last)
/* 796:    */   {
/* 797:862 */     this.last = last;
/* 798:    */   }
/* 799:    */   
/* 800:    */   public Map<BasicBlock, BasicBlock> getSubroutines()
/* 801:    */   {
/* 802:866 */     return this.subroutines;
/* 803:    */   }
/* 804:    */   
/* 805:    */   public void setSubroutines(Map<BasicBlock, BasicBlock> subroutines)
/* 806:    */   {
/* 807:870 */     this.subroutines = subroutines;
/* 808:    */   }
/* 809:    */   
/* 810:    */   public Set<BasicBlock> getFinallyExits()
/* 811:    */   {
/* 812:874 */     return this.finallyExits;
/* 813:    */   }
/* 814:    */   
/* 815:    */   public void setFinallyExits(HashSet<BasicBlock> finallyExits)
/* 816:    */   {
/* 817:878 */     this.finallyExits = finallyExits;
/* 818:    */   }
/* 819:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.cfg.ControlFlowGraph
 * JD-Core Version:    0.7.0.1
 */