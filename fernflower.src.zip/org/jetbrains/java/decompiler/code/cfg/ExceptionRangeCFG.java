/*   1:    */ package org.jetbrains.java.decompiler.code.cfg;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ 
/*   9:    */ public class ExceptionRangeCFG
/*  10:    */ {
/*  11: 27 */   private List<BasicBlock> protectedRange = new ArrayList();
/*  12:    */   private BasicBlock handler;
/*  13:    */   private List<String> exceptionTypes;
/*  14:    */   
/*  15:    */   public ExceptionRangeCFG(List<BasicBlock> protectedRange, BasicBlock handler, List<String> exceptionType)
/*  16:    */   {
/*  17: 34 */     this.protectedRange = protectedRange;
/*  18: 35 */     this.handler = handler;
/*  19: 37 */     if (exceptionType != null) {
/*  20: 38 */       this.exceptionTypes = new ArrayList(exceptionType);
/*  21:    */     }
/*  22:    */   }
/*  23:    */   
/*  24:    */   public boolean isCircular()
/*  25:    */   {
/*  26: 43 */     return this.protectedRange.contains(this.handler);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public String toString()
/*  30:    */   {
/*  31: 48 */     String new_line_separator = DecompilerContext.getNewLineSeparator();
/*  32:    */     
/*  33: 50 */     StringBuilder buf = new StringBuilder();
/*  34:    */     
/*  35: 52 */     buf.append("exceptionType:");
/*  36: 53 */     for (String exception_type : this.exceptionTypes) {
/*  37: 54 */       buf.append(" ").append(exception_type);
/*  38:    */     }
/*  39: 56 */     buf.append(new_line_separator);
/*  40:    */     
/*  41: 58 */     buf.append("handler: ").append(this.handler.id).append(new_line_separator);
/*  42: 59 */     buf.append("range: ");
/*  43: 60 */     for (int i = 0; i < this.protectedRange.size(); i++) {
/*  44: 61 */       buf.append(((BasicBlock)this.protectedRange.get(i)).id).append(" ");
/*  45:    */     }
/*  46: 63 */     buf.append(new_line_separator);
/*  47:    */     
/*  48: 65 */     return buf.toString();
/*  49:    */   }
/*  50:    */   
/*  51:    */   public BasicBlock getHandler()
/*  52:    */   {
/*  53: 69 */     return this.handler;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setHandler(BasicBlock handler)
/*  57:    */   {
/*  58: 73 */     this.handler = handler;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public List<BasicBlock> getProtectedRange()
/*  62:    */   {
/*  63: 77 */     return this.protectedRange;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void setProtectedRange(List<BasicBlock> protectedRange)
/*  67:    */   {
/*  68: 81 */     this.protectedRange = protectedRange;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public List<String> getExceptionTypes()
/*  72:    */   {
/*  73: 85 */     return this.exceptionTypes;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void addExceptionType(String exceptionType)
/*  77:    */   {
/*  78: 90 */     if (this.exceptionTypes == null) {
/*  79: 91 */       return;
/*  80:    */     }
/*  81: 94 */     if (exceptionType == null) {
/*  82: 95 */       this.exceptionTypes = null;
/*  83:    */     } else {
/*  84: 98 */       this.exceptionTypes.add(exceptionType);
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public String getUniqueExceptionsString()
/*  89:    */   {
/*  90:104 */     if (this.exceptionTypes == null) {
/*  91:105 */       return null;
/*  92:    */     }
/*  93:108 */     Set<String> setExceptionStrings = new HashSet();
/*  94:110 */     for (String exceptionType : this.exceptionTypes) {
/*  95:111 */       setExceptionStrings.add(exceptionType);
/*  96:    */     }
/*  97:114 */     String ret = "";
/*  98:115 */     for (String exception : setExceptionStrings)
/*  99:    */     {
/* 100:116 */       if (!ret.isEmpty()) {
/* 101:117 */         ret = ret + ":";
/* 102:    */       }
/* 103:119 */       ret = ret + exception;
/* 104:    */     }
/* 105:122 */     return ret;
/* 106:    */   }
/* 107:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.cfg.ExceptionRangeCFG
 * JD-Core Version:    0.7.0.1
 */