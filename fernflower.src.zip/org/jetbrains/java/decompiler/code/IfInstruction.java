/*  1:   */ package org.jetbrains.java.decompiler.code;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ 
/*  6:   */ public class IfInstruction
/*  7:   */   extends JumpInstruction
/*  8:   */ {
/*  9:   */   public void writeToStream(DataOutputStream out, int offset)
/* 10:   */     throws IOException
/* 11:   */   {
/* 12:29 */     out.writeByte(this.opcode);
/* 13:30 */     out.writeShort(getOperand(0));
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int length()
/* 17:   */   {
/* 18:34 */     return 3;
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.IfInstruction
 * JD-Core Version:    0.7.0.1
 */