/*  1:   */ package org.jetbrains.java.decompiler.code;
/*  2:   */ 
/*  3:   */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  4:   */ 
/*  5:   */ public class FullInstructionSequence
/*  6:   */   extends InstructionSequence
/*  7:   */ {
/*  8:   */   public FullInstructionSequence(VBStyleCollection<Instruction, Integer> collinstr, ExceptionTable extable)
/*  9:   */   {
/* 10:28 */     super(collinstr);
/* 11:29 */     this.exceptionTable = extable;
/* 12:32 */     for (ExceptionHandler handler : extable.getHandlers())
/* 13:   */     {
/* 14:33 */       handler.from_instr = getPointerByAbsOffset(handler.from);
/* 15:34 */       handler.to_instr = getPointerByAbsOffset(handler.to);
/* 16:35 */       handler.handler_instr = getPointerByAbsOffset(handler.handler);
/* 17:   */     }
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.FullInstructionSequence
 * JD-Core Version:    0.7.0.1
 */