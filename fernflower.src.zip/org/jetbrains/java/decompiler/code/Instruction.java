/*   1:    */ package org.jetbrains.java.decompiler.code;
/*   2:    */ 
/*   3:    */ import java.io.DataOutputStream;
/*   4:    */ import java.io.IOException;
/*   5:    */ 
/*   6:    */ public class Instruction
/*   7:    */   implements CodeConstants
/*   8:    */ {
/*   9:    */   public int opcode;
/*  10: 29 */   public int group = 1;
/*  11: 31 */   public boolean wide = false;
/*  12: 33 */   public int bytecode_version = 1;
/*  13: 39 */   private int[] operands = null;
/*  14:    */   
/*  15:    */   public int length()
/*  16:    */   {
/*  17: 49 */     return 1;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public int operandsCount()
/*  21:    */   {
/*  22: 53 */     return this.operands == null ? 0 : this.operands.length;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public int getOperand(int index)
/*  26:    */   {
/*  27: 57 */     return this.operands[index];
/*  28:    */   }
/*  29:    */   
/*  30:    */   public Instruction clone()
/*  31:    */   {
/*  32: 61 */     return ConstantsUtil.getInstructionInstance(this.opcode, this.wide, this.group, this.bytecode_version, this.operands == null ? null : (int[])this.operands.clone());
/*  33:    */   }
/*  34:    */   
/*  35:    */   public String toString()
/*  36:    */   {
/*  37: 66 */     String res = this.wide ? "@wide " : "";
/*  38: 67 */     res = res + "@" + ConstantsUtil.getName(this.opcode);
/*  39:    */     
/*  40: 69 */     int len = operandsCount();
/*  41: 70 */     for (int i = 0; i < len; i++)
/*  42:    */     {
/*  43: 71 */       int op = this.operands[i];
/*  44: 72 */       if (op < 0) {
/*  45: 73 */         res = res + " -" + Integer.toHexString(-op);
/*  46:    */       } else {
/*  47: 76 */         res = res + " " + Integer.toHexString(op);
/*  48:    */       }
/*  49:    */     }
/*  50: 80 */     return res;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean canFallthrough()
/*  54:    */   {
/*  55: 84 */     return (this.opcode != 167) && (this.opcode != 200) && (this.opcode != 169) && ((this.opcode < 172) || (this.opcode > 177)) && (this.opcode != 191) && (this.opcode != 168) && (this.opcode != 170) && (this.opcode != 171);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public boolean equalsInstruction(Instruction instr)
/*  59:    */   {
/*  60: 90 */     if ((this.opcode != instr.opcode) || (this.wide != instr.wide) || (operandsCount() != instr.operandsCount())) {
/*  61: 92 */       return false;
/*  62:    */     }
/*  63: 95 */     if (this.operands != null) {
/*  64: 96 */       for (int i = 0; i < this.operands.length; i++) {
/*  65: 97 */         if (this.operands[i] != instr.getOperand(i)) {
/*  66: 98 */           return false;
/*  67:    */         }
/*  68:    */       }
/*  69:    */     }
/*  70:103 */     return true;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void initInstruction(InstructionSequence seq) {}
/*  74:    */   
/*  75:    */   public void writeToStream(DataOutputStream out, int offset)
/*  76:    */     throws IOException
/*  77:    */   {
/*  78:112 */     out.writeByte(this.opcode);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public int[] getOperands()
/*  82:    */   {
/*  83:120 */     return this.operands;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void setOperands(int[] operands)
/*  87:    */   {
/*  88:124 */     this.operands = operands;
/*  89:    */   }
/*  90:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.Instruction
 * JD-Core Version:    0.7.0.1
 */