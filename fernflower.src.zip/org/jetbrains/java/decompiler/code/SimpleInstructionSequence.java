/*  1:   */ package org.jetbrains.java.decompiler.code;
/*  2:   */ 
/*  3:   */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  4:   */ 
/*  5:   */ public class SimpleInstructionSequence
/*  6:   */   extends InstructionSequence
/*  7:   */ {
/*  8:   */   public SimpleInstructionSequence() {}
/*  9:   */   
/* 10:   */   public SimpleInstructionSequence(VBStyleCollection<Instruction, Integer> collinstr)
/* 11:   */   {
/* 12:26 */     super(collinstr);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public SimpleInstructionSequence clone()
/* 16:   */   {
/* 17:30 */     SimpleInstructionSequence newseq = new SimpleInstructionSequence(this.collinstr.clone());
/* 18:31 */     newseq.setPointer(getPointer());
/* 19:   */     
/* 20:33 */     return newseq;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void removeInstruction(int index)
/* 24:   */   {
/* 25:37 */     this.collinstr.remove(index);
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.SimpleInstructionSequence
 * JD-Core Version:    0.7.0.1
 */