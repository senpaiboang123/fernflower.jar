/*  1:   */ package org.jetbrains.java.decompiler.code;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  6:   */ 
/*  7:   */ public class ExceptionHandler
/*  8:   */ {
/*  9:25 */   public int from = 0;
/* 10:26 */   public int to = 0;
/* 11:27 */   public int handler = 0;
/* 12:29 */   public int from_instr = 0;
/* 13:30 */   public int to_instr = 0;
/* 14:31 */   public int handler_instr = 0;
/* 15:33 */   public int class_index = 0;
/* 16:34 */   public String exceptionClass = null;
/* 17:   */   
/* 18:   */   public ExceptionHandler() {}
/* 19:   */   
/* 20:   */   public ExceptionHandler(int from_raw, int to_raw, int handler_raw, String exceptionClass)
/* 21:   */   {
/* 22:40 */     this.from = from_raw;
/* 23:41 */     this.to = to_raw;
/* 24:42 */     this.handler = handler_raw;
/* 25:43 */     this.exceptionClass = exceptionClass;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void writeToStream(DataOutputStream out)
/* 29:   */     throws IOException
/* 30:   */   {
/* 31:47 */     out.writeShort(this.from);
/* 32:48 */     out.writeShort(this.to);
/* 33:49 */     out.writeShort(this.handler);
/* 34:50 */     out.writeShort(this.class_index);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String toString()
/* 38:   */   {
/* 39:55 */     String new_line_separator = DecompilerContext.getNewLineSeparator();
/* 40:   */     
/* 41:57 */     return "from: " + this.from + " to: " + this.to + " handler: " + this.handler + new_line_separator + "from_instr: " + this.from_instr + " to_instr: " + this.to_instr + " handler_instr: " + this.handler_instr + new_line_separator + "exceptionClass: " + this.exceptionClass + new_line_separator;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.ExceptionHandler
 * JD-Core Version:    0.7.0.1
 */