/*  1:   */ package org.jetbrains.java.decompiler.code;
/*  2:   */ 
/*  3:   */ public class SwitchInstruction
/*  4:   */   extends Instruction
/*  5:   */ {
/*  6:   */   private int[] destinations;
/*  7:   */   private int[] values;
/*  8:   */   private int defaultdest;
/*  9:   */   
/* 10:   */   public void initInstruction(InstructionSequence seq)
/* 11:   */   {
/* 12:36 */     int pref = this.opcode == 170 ? 3 : 2;
/* 13:37 */     int len = getOperands().length - pref;
/* 14:38 */     this.defaultdest = seq.getPointerByRelOffset(getOperand(0));
/* 15:   */     
/* 16:40 */     int low = 0;
/* 17:42 */     if (this.opcode == 171) {
/* 18:43 */       len /= 2;
/* 19:   */     } else {
/* 20:46 */       low = getOperand(1);
/* 21:   */     }
/* 22:49 */     this.destinations = new int[len];
/* 23:50 */     this.values = new int[len];
/* 24:   */     
/* 25:52 */     int i = 0;
/* 26:52 */     for (int k = 0; i < len; k++)
/* 27:   */     {
/* 28:53 */       if (this.opcode == 171)
/* 29:   */       {
/* 30:54 */         this.values[i] = getOperand(pref + k);
/* 31:55 */         k++;
/* 32:   */       }
/* 33:   */       else
/* 34:   */       {
/* 35:58 */         this.values[i] = (low + k);
/* 36:   */       }
/* 37:60 */       this.destinations[i] = seq.getPointerByRelOffset(getOperand(pref + k));i++;
/* 38:   */     }
/* 39:   */   }
/* 40:   */   
/* 41:   */   public SwitchInstruction clone()
/* 42:   */   {
/* 43:65 */     SwitchInstruction newinstr = (SwitchInstruction)super.clone();
/* 44:   */     
/* 45:67 */     newinstr.defaultdest = this.defaultdest;
/* 46:68 */     newinstr.destinations = ((int[])this.destinations.clone());
/* 47:69 */     newinstr.values = ((int[])this.values.clone());
/* 48:   */     
/* 49:71 */     return newinstr;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public int[] getDestinations()
/* 53:   */   {
/* 54:75 */     return this.destinations;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setDestinations(int[] destinations)
/* 58:   */   {
/* 59:79 */     this.destinations = destinations;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public int getDefaultdest()
/* 63:   */   {
/* 64:83 */     return this.defaultdest;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void setDefaultdest(int defaultdest)
/* 68:   */   {
/* 69:87 */     this.defaultdest = defaultdest;
/* 70:   */   }
/* 71:   */   
/* 72:   */   public int[] getValues()
/* 73:   */   {
/* 74:91 */     return this.values;
/* 75:   */   }
/* 76:   */   
/* 77:   */   public void setValues(int[] values)
/* 78:   */   {
/* 79:95 */     this.values = values;
/* 80:   */   }
/* 81:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.SwitchInstruction
 * JD-Core Version:    0.7.0.1
 */