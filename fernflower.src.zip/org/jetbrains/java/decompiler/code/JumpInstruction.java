/*  1:   */ package org.jetbrains.java.decompiler.code;
/*  2:   */ 
/*  3:   */ public class JumpInstruction
/*  4:   */   extends Instruction
/*  5:   */ {
/*  6:   */   public int destination;
/*  7:   */   
/*  8:   */   public void initInstruction(InstructionSequence seq)
/*  9:   */   {
/* 10:33 */     this.destination = seq.getPointerByRelOffset(getOperand(0));
/* 11:   */   }
/* 12:   */   
/* 13:   */   public JumpInstruction clone()
/* 14:   */   {
/* 15:37 */     JumpInstruction newinstr = (JumpInstruction)super.clone();
/* 16:   */     
/* 17:39 */     newinstr.destination = this.destination;
/* 18:40 */     return newinstr;
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.JumpInstruction
 * JD-Core Version:    0.7.0.1
 */