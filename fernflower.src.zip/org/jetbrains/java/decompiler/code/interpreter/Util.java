/*   1:    */ package org.jetbrains.java.decompiler.code.interpreter;
/*   2:    */ 
/*   3:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*   4:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*   5:    */ import org.jetbrains.java.decompiler.struct.StructContext;
/*   6:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*   7:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*   8:    */ 
/*   9:    */ public class Util
/*  10:    */ {
/*  11: 26 */   private static final String[][] runtime_exceptions = { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException", "java/lang/ArrayStoreException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, { "java/lang/NullPointerException", "java/lang/ArrayIndexOutOfBoundsException" }, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, { "java/lang/ArithmeticException" }, { "java/lang/ArithmeticException" }, null, null, { "java/lang/ArithmeticException" }, { "java/lang/ArithmeticException" }, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, { "java/lang/IllegalMonitorStateException" }, { "java/lang/IllegalMonitorStateException" }, { "java/lang/IllegalMonitorStateException" }, { "java/lang/IllegalMonitorStateException" }, { "java/lang/IllegalMonitorStateException" }, { "java/lang/IllegalMonitorStateException" }, null, null, { "java/lang/NullPointerException" }, { "java/lang/NullPointerException" }, { "java/lang/NullPointerException", "java/lang/AbstractMethodError", "java/lang/UnsatisfiedLinkError" }, { "java/lang/NullPointerException", "java/lang/UnsatisfiedLinkError" }, { "java/lang/UnsatisfiedLinkError" }, { "java/lang/NullPointerException", "java/lang/IncompatibleClassChangeError", "java/lang/IllegalAccessError", "java/lang/java/lang/AbstractMethodError", "java/lang/UnsatisfiedLinkError" }, null, null, { "java/lang/NegativeArraySizeException" }, { "java/lang/NegativeArraySizeException" }, { "java/lang/NullPointerException" }, { "java/lang/NullPointerException", "java/lang/IllegalMonitorStateException" }, { "java/lang/ClassCastException" }, null, { "java/lang/NullPointerException" }, { "java/lang/NullPointerException", "java/lang/IllegalMonitorStateException" }, null, { "java/lang/NegativeArraySizeException" }, null, null, null, null };
/*  12:    */   
/*  13:    */   public static boolean instanceOf(StructContext context, String valclass, String refclass)
/*  14:    */   {
/*  15:257 */     if (valclass.equals(refclass)) {
/*  16:258 */       return true;
/*  17:    */     }
/*  18:261 */     StructClass cl = context.getClass(valclass);
/*  19:262 */     if (cl == null) {
/*  20:263 */       return false;
/*  21:    */     }
/*  22:266 */     if ((cl.superClass != null) && (instanceOf(context, cl.superClass.getString(), refclass))) {
/*  23:267 */       return true;
/*  24:    */     }
/*  25:270 */     int[] interfaces = cl.getInterfaces();
/*  26:271 */     for (int i = 0; i < interfaces.length; i++)
/*  27:    */     {
/*  28:272 */       String intfc = cl.getPool().getPrimitiveConstant(interfaces[i]).getString();
/*  29:274 */       if (instanceOf(context, intfc, refclass)) {
/*  30:275 */         return true;
/*  31:    */       }
/*  32:    */     }
/*  33:279 */     return false;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static String[] getRuntimeExceptions(Instruction instr)
/*  37:    */   {
/*  38:284 */     return runtime_exceptions[instr.opcode];
/*  39:    */   }
/*  40:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.interpreter.Util
 * JD-Core Version:    0.7.0.1
 */