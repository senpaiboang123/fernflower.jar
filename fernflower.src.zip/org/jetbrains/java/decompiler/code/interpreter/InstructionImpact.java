/*   1:    */ package org.jetbrains.java.decompiler.code.interpreter;
/*   2:    */ 
/*   3:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*   4:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*   5:    */ import org.jetbrains.java.decompiler.struct.consts.LinkConstant;
/*   6:    */ import org.jetbrains.java.decompiler.struct.consts.PooledConstant;
/*   7:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*   8:    */ import org.jetbrains.java.decompiler.struct.gen.DataPoint;
/*   9:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  10:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  11:    */ import org.jetbrains.java.decompiler.util.ListStack;
/*  12:    */ 
/*  13:    */ public class InstructionImpact
/*  14:    */ {
/*  15: 32 */   private static final int[][][] stack_impact = { { null, null }, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, { null, { 5 } }, { null, { 5 } }, { null, { 3 } }, { null, { 3 } }, { null, { 3 } }, { null, { 2 } }, { null, { 2 } }, { null, { 4 } }, { null, { 4 } }, (int[][])null, (int[][])null, (int[][])null, { null, { 4 } }, { null, { 5 } }, { null, { 3 } }, { null, { 2 } }, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, { { 8, 4 }, { 4 } }, { { 8, 4 }, { 5 } }, { { 8, 4 }, { 3 } }, { { 8, 4 }, { 2 } }, (int[][])null, { { 8, 4 }, { 4 } }, { { 8, 4 }, { 4 } }, { { 8, 4 }, { 4 } }, { { 4 }, null }, { { 5 }, null }, { { 3 }, null }, { { 2 }, null }, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, { { 8, 4, 4 }, null }, { { 8, 4, 5 }, null }, { { 8, 4, 3 }, null }, { { 8, 4, 2 }, null }, { { 8, 4, 8 }, null }, { { 8, 4, 4 }, null }, { { 8, 4, 4 }, null }, { { 8, 4, 4 }, null }, { { 11 }, null }, { { 11, 11 }, null }, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, { { 4, 4 }, { 4 } }, { { 5, 5 }, { 5 } }, { { 3, 3 }, { 3 } }, { { 2, 2 }, { 2 } }, { { 4, 4 }, { 4 } }, { { 5, 5 }, { 5 } }, { { 3, 3 }, { 3 } }, { { 2, 2 }, { 2 } }, { { 4, 4 }, { 4 } }, { { 5, 5 }, { 5 } }, { { 3, 3 }, { 3 } }, { { 2, 2 }, { 2 } }, { { 4, 4 }, { 4 } }, { { 5, 5 }, { 5 } }, { { 3, 3 }, { 3 } }, { { 2, 2 }, { 2 } }, { { 4, 4 }, { 4 } }, { { 5, 5 }, { 5 } }, { { 3, 3 }, { 3 } }, { { 2, 2 }, { 2 } }, { { 4 }, { 4 } }, { { 5 }, { 5 } }, { { 3 }, { 3 } }, { { 2 }, { 2 } }, { { 4, 4 }, { 4 } }, { { 5, 4 }, { 5 } }, { { 4, 4 }, { 4 } }, { { 5, 4 }, { 5 } }, { { 4, 4 }, { 4 } }, { { 5, 4 }, { 5 } }, { { 4, 4 }, { 4 } }, { { 5, 5 }, { 5 } }, { { 4, 4 }, { 4 } }, { { 5, 5 }, { 5 } }, { { 4, 4 }, { 4 } }, { { 5, 5 }, { 5 } }, { null, null }, { { 4 }, { 5 } }, { { 4 }, { 3 } }, { { 4 }, { 2 } }, { { 5 }, { 4 } }, { { 5 }, { 3 } }, { { 5 }, { 2 } }, { { 3 }, { 4 } }, { { 3 }, { 5 } }, { { 3 }, { 2 } }, { { 2 }, { 4 } }, { { 2 }, { 5 } }, { { 2 }, { 3 } }, { { 4 }, { 4 } }, { { 4 }, { 4 } }, { { 4 }, { 4 } }, { { 5, 5 }, { 4 } }, { { 3, 3 }, { 4 } }, { { 3, 3 }, { 4 } }, { { 2, 2 }, { 4 } }, { { 2, 2 }, { 4 } }, { { 4 }, null }, { { 4 }, null }, { { 4 }, null }, { { 4 }, null }, { { 4 }, null }, { { 4 }, null }, { { 4, 4 }, null }, { { 4, 4 }, null }, { { 4, 4 }, null }, { { 4, 4 }, null }, { { 4, 4 }, null }, { { 4, 4 }, null }, { { 8, 8 }, null }, { { 8, 8 }, null }, { null, null }, { null, { 9 } }, { null, null }, { { 4 }, null }, { { 4 }, null }, { { 4 }, null }, { { 5 }, null }, { { 3 }, null }, { { 2 }, null }, { { 8 }, null }, { null, null }, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, (int[][])null, { { 8 }, { 4 } }, (int[][])null, (int[][])null, (int[][])null, { { 8 }, null }, { { 8 }, null }, (int[][])null, (int[][])null, { { 8 }, null }, { { 8 }, null }, { null, null }, { null, { 9 } } };
/*  16:297 */   private static final int[] arr_type = { 7, 1, 3, 2, 0, 6, 4, 5 };
/*  17:    */   
/*  18:    */   public static void stepTypes(DataPoint data, Instruction instr, ConstantPool pool)
/*  19:    */   {
/*  20:343 */     ListStack<VarType> stack = data.getStack();
/*  21:344 */     int[][] arr = stack_impact[instr.opcode];
/*  22:346 */     if (arr != null)
/*  23:    */     {
/*  24:349 */       int[] read = arr[0];
/*  25:350 */       int[] write = arr[1];
/*  26:352 */       if (read != null)
/*  27:    */       {
/*  28:353 */         int depth = 0;
/*  29:354 */         for (int i = 0; i < read.length; i++)
/*  30:    */         {
/*  31:355 */           int type = read[i];
/*  32:356 */           depth++;
/*  33:357 */           if ((type == 5) || (type == 2)) {
/*  34:359 */             depth++;
/*  35:    */           }
/*  36:    */         }
/*  37:363 */         stack.removeMultiple(depth);
/*  38:    */       }
/*  39:366 */       if (write != null) {
/*  40:367 */         for (int i = 0; i < write.length; i++)
/*  41:    */         {
/*  42:368 */           int type = write[i];
/*  43:369 */           stack.push(new VarType(type));
/*  44:370 */           if ((type == 5) || (type == 2)) {
/*  45:372 */             stack.push(new VarType(12));
/*  46:    */           }
/*  47:    */         }
/*  48:    */       }
/*  49:    */     }
/*  50:    */     else
/*  51:    */     {
/*  52:379 */       processSpecialInstructions(data, instr, pool);
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   private static void processSpecialInstructions(DataPoint data, Instruction instr, ConstantPool pool)
/*  57:    */   {
/*  58:389 */     ListStack<VarType> stack = data.getStack();
/*  59:    */     VarType var1;
/*  60:    */     LinkConstant ck;
/*  61:    */     PrimitiveConstant cn;
/*  62:391 */     switch (instr.opcode)
/*  63:    */     {
/*  64:    */     case 1: 
/*  65:393 */       stack.push(new VarType(13, 0, null));
/*  66:394 */       break;
/*  67:    */     case 18: 
/*  68:    */     case 19: 
/*  69:    */     case 20: 
/*  70:398 */       PooledConstant constant = pool.getConstant(instr.getOperand(0));
/*  71:399 */       switch (constant.type)
/*  72:    */       {
/*  73:    */       case 3: 
/*  74:401 */         stack.push(new VarType(4));
/*  75:402 */         break;
/*  76:    */       case 4: 
/*  77:404 */         stack.push(new VarType(3));
/*  78:405 */         break;
/*  79:    */       case 5: 
/*  80:407 */         stack.push(new VarType(5));
/*  81:408 */         stack.push(new VarType(12));
/*  82:409 */         break;
/*  83:    */       case 6: 
/*  84:411 */         stack.push(new VarType(2));
/*  85:412 */         stack.push(new VarType(12));
/*  86:413 */         break;
/*  87:    */       case 8: 
/*  88:415 */         stack.push(new VarType(8, 0, "java/lang/String"));
/*  89:416 */         break;
/*  90:    */       case 7: 
/*  91:418 */         stack.push(new VarType(8, 0, "java/lang/Class"));
/*  92:419 */         break;
/*  93:    */       case 15: 
/*  94:421 */         stack.push(new VarType(((LinkConstant)constant).descriptor));
/*  95:    */       }
/*  96:424 */       break;
/*  97:    */     case 25: 
/*  98:426 */       var1 = data.getVariable(instr.getOperand(0));
/*  99:427 */       if (var1 != null) {
/* 100:428 */         stack.push(var1);
/* 101:    */       } else {
/* 102:431 */         stack.push(new VarType(8, 0, null));
/* 103:    */       }
/* 104:433 */       break;
/* 105:    */     case 50: 
/* 106:435 */       var1 = (VarType)stack.pop(2);
/* 107:436 */       stack.push(new VarType(var1.type, var1.arrayDim - 1, var1.value));
/* 108:437 */       break;
/* 109:    */     case 58: 
/* 110:439 */       data.setVariable(instr.getOperand(0), (VarType)stack.pop());
/* 111:440 */       break;
/* 112:    */     case 89: 
/* 113:    */     case 90: 
/* 114:    */     case 91: 
/* 115:444 */       int depth1 = 88 - instr.opcode;
/* 116:445 */       stack.insertByOffset(depth1, ((VarType)stack.getByOffset(-1)).copy());
/* 117:446 */       break;
/* 118:    */     case 92: 
/* 119:    */     case 93: 
/* 120:    */     case 94: 
/* 121:450 */       int depth2 = 90 - instr.opcode;
/* 122:451 */       stack.insertByOffset(depth2, ((VarType)stack.getByOffset(-2)).copy());
/* 123:452 */       stack.insertByOffset(depth2, ((VarType)stack.getByOffset(-1)).copy());
/* 124:453 */       break;
/* 125:    */     case 95: 
/* 126:455 */       var1 = (VarType)stack.pop();
/* 127:456 */       stack.insertByOffset(-1, var1);
/* 128:457 */       break;
/* 129:    */     case 180: 
/* 130:459 */       stack.pop();
/* 131:    */     case 178: 
/* 132:461 */       ck = pool.getLinkConstant(instr.getOperand(0));
/* 133:462 */       var1 = new VarType(ck.descriptor);
/* 134:463 */       stack.push(var1);
/* 135:464 */       if (var1.stackSize == 2) {
/* 136:465 */         stack.push(new VarType(12));
/* 137:    */       }
/* 138:    */       break;
/* 139:    */     case 181: 
/* 140:469 */       stack.pop();
/* 141:    */     case 179: 
/* 142:471 */       ck = pool.getLinkConstant(instr.getOperand(0));
/* 143:472 */       var1 = new VarType(ck.descriptor);
/* 144:473 */       stack.pop(var1.stackSize);
/* 145:474 */       break;
/* 146:    */     case 182: 
/* 147:    */     case 183: 
/* 148:    */     case 185: 
/* 149:478 */       stack.pop();
/* 150:    */     case 184: 
/* 151:    */     case 186: 
/* 152:481 */       if ((instr.opcode != 186) || (instr.bytecode_version >= 4))
/* 153:    */       {
/* 154:482 */         ck = pool.getLinkConstant(instr.getOperand(0));
/* 155:483 */         MethodDescriptor md = MethodDescriptor.parseDescriptor(ck.descriptor);
/* 156:484 */         for (int i = 0; i < md.params.length; i++) {
/* 157:485 */           stack.pop(md.params[i].stackSize);
/* 158:    */         }
/* 159:487 */         if (md.ret.type != 10)
/* 160:    */         {
/* 161:488 */           stack.push(md.ret);
/* 162:489 */           if (md.ret.stackSize == 2) {
/* 163:490 */             stack.push(new VarType(12));
/* 164:    */           }
/* 165:    */         }
/* 166:    */       }
/* 167:493 */       break;
/* 168:    */     case 187: 
/* 169:496 */       cn = pool.getPrimitiveConstant(instr.getOperand(0));
/* 170:497 */       stack.push(new VarType(8, 0, cn.getString()));
/* 171:498 */       break;
/* 172:    */     case 188: 
/* 173:500 */       stack.pop();
/* 174:501 */       stack.push(new VarType(arr_type[(instr.getOperand(0) - 4)], 1).resizeArrayDim(1));
/* 175:502 */       break;
/* 176:    */     case 191: 
/* 177:504 */       var1 = (VarType)stack.pop();
/* 178:505 */       stack.clear();
/* 179:506 */       stack.push(var1);
/* 180:507 */       break;
/* 181:    */     case 192: 
/* 182:    */     case 193: 
/* 183:510 */       stack.pop();
/* 184:511 */       cn = pool.getPrimitiveConstant(instr.getOperand(0));
/* 185:512 */       stack.push(new VarType(8, 0, cn.getString()));
/* 186:513 */       break;
/* 187:    */     case 189: 
/* 188:    */     case 197: 
/* 189:516 */       int dimensions = instr.opcode == 189 ? 1 : instr.getOperand(1);
/* 190:517 */       stack.pop(dimensions);
/* 191:518 */       cn = pool.getPrimitiveConstant(instr.getOperand(0));
/* 192:519 */       if (cn.isArray)
/* 193:    */       {
/* 194:520 */         var1 = new VarType(8, 0, cn.getString());
/* 195:521 */         var1 = var1.resizeArrayDim(var1.arrayDim + dimensions);
/* 196:522 */         stack.push(var1);
/* 197:    */       }
/* 198:    */       else
/* 199:    */       {
/* 200:525 */         stack.push(new VarType(8, dimensions, cn.getString()));
/* 201:    */       }
/* 202:    */       break;
/* 203:    */     }
/* 204:    */   }
/* 205:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.interpreter.InstructionImpact
 * JD-Core Version:    0.7.0.1
 */