/*  1:   */ package org.jetbrains.java.decompiler.code;
/*  2:   */ 
/*  3:   */ import java.util.Collections;
/*  4:   */ import java.util.List;
/*  5:   */ import org.jetbrains.java.decompiler.code.interpreter.Util;
/*  6:   */ import org.jetbrains.java.decompiler.struct.StructContext;
/*  7:   */ 
/*  8:   */ public class ExceptionTable
/*  9:   */ {
/* 10:25 */   public static final ExceptionTable EMPTY = new ExceptionTable(null)
/* 11:   */   {
/* 12:   */     public List<ExceptionHandler> getHandlers()
/* 13:   */     {
/* 14:28 */       return Collections.emptyList();
/* 15:   */     }
/* 16:   */   };
/* 17:   */   private final List<ExceptionHandler> handlers;
/* 18:   */   
/* 19:   */   public ExceptionTable(List<ExceptionHandler> handlers)
/* 20:   */   {
/* 21:35 */     this.handlers = handlers;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public ExceptionHandler getHandlerByClass(StructContext context, int line, String valclass, boolean withany)
/* 25:   */   {
/* 26:41 */     ExceptionHandler res = null;
/* 27:43 */     for (ExceptionHandler handler : this.handlers) {
/* 28:44 */       if ((handler.from <= line) && (handler.to > line))
/* 29:   */       {
/* 30:45 */         String name = handler.exceptionClass;
/* 31:47 */         if (((withany) && (name == null)) || ((name != null) && (Util.instanceOf(context, valclass, name))))
/* 32:   */         {
/* 33:49 */           res = handler;
/* 34:50 */           break;
/* 35:   */         }
/* 36:   */       }
/* 37:   */     }
/* 38:55 */     return res;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public List<ExceptionHandler> getHandlers()
/* 42:   */   {
/* 43:59 */     return this.handlers;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.ExceptionTable
 * JD-Core Version:    0.7.0.1
 */