/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.Instruction;
/*  6:   */ 
/*  7:   */ public class BIPUSH
/*  8:   */   extends Instruction
/*  9:   */ {
/* 10:25 */   private static final int[] opcodes = { 2, 3, 4, 5, 6, 7, 8 };
/* 11:   */   
/* 12:   */   public void writeToStream(DataOutputStream out, int offset)
/* 13:   */     throws IOException
/* 14:   */   {
/* 15:29 */     int value = getOperand(0);
/* 16:30 */     if ((value < -1) || (value > 5))
/* 17:   */     {
/* 18:31 */       out.writeByte(16);
/* 19:32 */       out.writeByte(value);
/* 20:   */     }
/* 21:   */     else
/* 22:   */     {
/* 23:35 */       out.writeByte(opcodes[(value + 1)]);
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public int length()
/* 28:   */   {
/* 29:40 */     int value = getOperand(0);
/* 30:41 */     if ((value < -1) || (value > 5)) {
/* 31:42 */       return 2;
/* 32:   */     }
/* 33:45 */     return 1;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.BIPUSH
 * JD-Core Version:    0.7.0.1
 */