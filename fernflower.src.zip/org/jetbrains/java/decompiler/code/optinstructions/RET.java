/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.Instruction;
/*  6:   */ 
/*  7:   */ public class RET
/*  8:   */   extends Instruction
/*  9:   */ {
/* 10:   */   public void writeToStream(DataOutputStream out, int offset)
/* 11:   */     throws IOException
/* 12:   */   {
/* 13:26 */     if (this.wide) {
/* 14:27 */       out.writeByte(196);
/* 15:   */     }
/* 16:29 */     out.writeByte(169);
/* 17:30 */     if (this.wide) {
/* 18:31 */       out.writeShort(getOperand(0));
/* 19:   */     } else {
/* 20:34 */       out.writeByte(getOperand(0));
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   public int length()
/* 25:   */   {
/* 26:39 */     return this.wide ? 4 : 2;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.RET
 * JD-Core Version:    0.7.0.1
 */