/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.JumpInstruction;
/*  6:   */ 
/*  7:   */ public class JSR
/*  8:   */   extends JumpInstruction
/*  9:   */ {
/* 10:   */   public void writeToStream(DataOutputStream out, int offset)
/* 11:   */     throws IOException
/* 12:   */   {
/* 13:26 */     int operand = getOperand(0);
/* 14:27 */     if ((operand < -32768) || (operand > 32767))
/* 15:   */     {
/* 16:28 */       out.writeByte(201);
/* 17:29 */       out.writeInt(operand);
/* 18:   */     }
/* 19:   */     else
/* 20:   */     {
/* 21:32 */       out.writeByte(168);
/* 22:33 */       out.writeShort(operand);
/* 23:   */     }
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int length()
/* 27:   */   {
/* 28:38 */     int operand = getOperand(0);
/* 29:39 */     if ((operand < -32768) || (operand > 32767)) {
/* 30:40 */       return 5;
/* 31:   */     }
/* 32:43 */     return 3;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.JSR
 * JD-Core Version:    0.7.0.1
 */