/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.Instruction;
/*  6:   */ 
/*  7:   */ public class DLOAD
/*  8:   */   extends Instruction
/*  9:   */ {
/* 10:25 */   private static final int[] opcodes = { 38, 39, 40, 41 };
/* 11:   */   
/* 12:   */   public void writeToStream(DataOutputStream out, int offset)
/* 13:   */     throws IOException
/* 14:   */   {
/* 15:28 */     int index = getOperand(0);
/* 16:29 */     if (index > 3)
/* 17:   */     {
/* 18:30 */       if (this.wide) {
/* 19:31 */         out.writeByte(196);
/* 20:   */       }
/* 21:33 */       out.writeByte(24);
/* 22:34 */       if (this.wide) {
/* 23:35 */         out.writeShort(index);
/* 24:   */       } else {
/* 25:38 */         out.writeByte(index);
/* 26:   */       }
/* 27:   */     }
/* 28:   */     else
/* 29:   */     {
/* 30:42 */       out.writeByte(opcodes[index]);
/* 31:   */     }
/* 32:   */   }
/* 33:   */   
/* 34:   */   public int length()
/* 35:   */   {
/* 36:47 */     int index = getOperand(0);
/* 37:48 */     if (index > 3)
/* 38:   */     {
/* 39:49 */       if (this.wide) {
/* 40:50 */         return 4;
/* 41:   */       }
/* 42:53 */       return 2;
/* 43:   */     }
/* 44:57 */     return 1;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.DLOAD
 * JD-Core Version:    0.7.0.1
 */