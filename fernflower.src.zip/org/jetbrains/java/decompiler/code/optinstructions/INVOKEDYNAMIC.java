/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.Instruction;
/*  6:   */ 
/*  7:   */ public class INVOKEDYNAMIC
/*  8:   */   extends Instruction
/*  9:   */ {
/* 10:   */   public void writeToStream(DataOutputStream out, int offset)
/* 11:   */     throws IOException
/* 12:   */   {
/* 13:26 */     out.writeByte(186);
/* 14:27 */     out.writeShort(getOperand(0));
/* 15:28 */     out.writeByte(0);
/* 16:29 */     out.writeByte(0);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int length()
/* 20:   */   {
/* 21:33 */     return 5;
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.INVOKEDYNAMIC
 * JD-Core Version:    0.7.0.1
 */