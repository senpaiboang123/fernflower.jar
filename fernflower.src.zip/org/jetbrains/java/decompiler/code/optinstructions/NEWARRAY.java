/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.Instruction;
/*  6:   */ 
/*  7:   */ public class NEWARRAY
/*  8:   */   extends Instruction
/*  9:   */ {
/* 10:   */   public void writeToStream(DataOutputStream out, int offset)
/* 11:   */     throws IOException
/* 12:   */   {
/* 13:26 */     out.writeByte(188);
/* 14:27 */     out.writeByte(getOperand(0));
/* 15:   */   }
/* 16:   */   
/* 17:   */   public int length()
/* 18:   */   {
/* 19:31 */     return 2;
/* 20:   */   }
/* 21:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.NEWARRAY
 * JD-Core Version:    0.7.0.1
 */