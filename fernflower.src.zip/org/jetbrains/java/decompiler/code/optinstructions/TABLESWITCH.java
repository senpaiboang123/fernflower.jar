/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.SwitchInstruction;
/*  6:   */ 
/*  7:   */ public class TABLESWITCH
/*  8:   */   extends SwitchInstruction
/*  9:   */ {
/* 10:   */   public void writeToStream(DataOutputStream out, int offset)
/* 11:   */     throws IOException
/* 12:   */   {
/* 13:27 */     out.writeByte(170);
/* 14:   */     
/* 15:29 */     int padding = 3 - offset % 4;
/* 16:30 */     for (int i = 0; i < padding; i++) {
/* 17:31 */       out.writeByte(0);
/* 18:   */     }
/* 19:34 */     for (int i = 0; i < operandsCount(); i++) {
/* 20:35 */       out.writeInt(getOperand(i));
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   public int length()
/* 25:   */   {
/* 26:40 */     return 1 + operandsCount() * 4;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.TABLESWITCH
 * JD-Core Version:    0.7.0.1
 */