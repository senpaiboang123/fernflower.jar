/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.Instruction;
/*  6:   */ 
/*  7:   */ public class IINC
/*  8:   */   extends Instruction
/*  9:   */ {
/* 10:   */   public void writeToStream(DataOutputStream out, int offset)
/* 11:   */     throws IOException
/* 12:   */   {
/* 13:26 */     if (this.wide) {
/* 14:27 */       out.writeByte(196);
/* 15:   */     }
/* 16:29 */     out.writeByte(132);
/* 17:30 */     if (this.wide)
/* 18:   */     {
/* 19:31 */       out.writeShort(getOperand(0));
/* 20:32 */       out.writeShort(getOperand(1));
/* 21:   */     }
/* 22:   */     else
/* 23:   */     {
/* 24:35 */       out.writeByte(getOperand(0));
/* 25:36 */       out.writeByte(getOperand(1));
/* 26:   */     }
/* 27:   */   }
/* 28:   */   
/* 29:   */   public int length()
/* 30:   */   {
/* 31:41 */     return this.wide ? 6 : 3;
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.IINC
 * JD-Core Version:    0.7.0.1
 */