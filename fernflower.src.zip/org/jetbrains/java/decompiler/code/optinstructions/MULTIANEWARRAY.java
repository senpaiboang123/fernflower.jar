/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.Instruction;
/*  6:   */ 
/*  7:   */ public class MULTIANEWARRAY
/*  8:   */   extends Instruction
/*  9:   */ {
/* 10:   */   public void writeToStream(DataOutputStream out, int offset)
/* 11:   */     throws IOException
/* 12:   */   {
/* 13:26 */     out.writeByte(197);
/* 14:27 */     out.writeShort(getOperand(0));
/* 15:28 */     out.writeByte(getOperand(1));
/* 16:   */   }
/* 17:   */   
/* 18:   */   public int length()
/* 19:   */   {
/* 20:32 */     return 4;
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.MULTIANEWARRAY
 * JD-Core Version:    0.7.0.1
 */