/*  1:   */ package org.jetbrains.java.decompiler.code.optinstructions;
/*  2:   */ 
/*  3:   */ import java.io.DataOutputStream;
/*  4:   */ import java.io.IOException;
/*  5:   */ import org.jetbrains.java.decompiler.code.JumpInstruction;
/*  6:   */ 
/*  7:   */ public class GOTO_W
/*  8:   */   extends JumpInstruction
/*  9:   */ {
/* 10:   */   public void writeToStream(DataOutputStream out, int offset)
/* 11:   */     throws IOException
/* 12:   */   {
/* 13:26 */     out.writeByte(200);
/* 14:27 */     out.writeInt(getOperand(0));
/* 15:   */   }
/* 16:   */   
/* 17:   */   public int length()
/* 18:   */   {
/* 19:31 */     return 5;
/* 20:   */   }
/* 21:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.code.optinstructions.GOTO_W
 * JD-Core Version:    0.7.0.1
 */