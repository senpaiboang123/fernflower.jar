/*   1:    */ package org.jetbrains.java.decompiler.util;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.Set;
/*   7:    */ 
/*   8:    */ public class FastSparseSetFactory<E>
/*   9:    */ {
/*  10: 25 */   private final VBStyleCollection<int[], E> colValuesInternal = new VBStyleCollection();
/*  11:    */   private int lastBlock;
/*  12:    */   private int lastMask;
/*  13:    */   
/*  14:    */   public FastSparseSetFactory(Collection<E> set)
/*  15:    */   {
/*  16: 33 */     int block = -1;
/*  17: 34 */     int mask = -1;
/*  18: 35 */     int index = 0;
/*  19: 37 */     for (E element : set)
/*  20:    */     {
/*  21: 39 */       block = index / 32;
/*  22: 41 */       if (index % 32 == 0) {
/*  23: 42 */         mask = 1;
/*  24:    */       } else {
/*  25: 45 */         mask <<= 1;
/*  26:    */       }
/*  27: 48 */       this.colValuesInternal.putWithKey(new int[] { block, mask }, element);
/*  28:    */       
/*  29: 50 */       index++;
/*  30:    */     }
/*  31: 53 */     this.lastBlock = block;
/*  32: 54 */     this.lastMask = mask;
/*  33:    */   }
/*  34:    */   
/*  35:    */   private int[] addElement(E element)
/*  36:    */   {
/*  37: 59 */     if ((this.lastMask == -1) || (this.lastMask == -2147483648))
/*  38:    */     {
/*  39: 60 */       this.lastMask = 1;
/*  40: 61 */       this.lastBlock += 1;
/*  41:    */     }
/*  42:    */     else
/*  43:    */     {
/*  44: 64 */       this.lastMask <<= 1;
/*  45:    */     }
/*  46: 67 */     int[] pointer = { this.lastBlock, this.lastMask };
/*  47: 68 */     this.colValuesInternal.putWithKey(pointer, element);
/*  48:    */     
/*  49: 70 */     return pointer;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public FastSparseSet<E> spawnEmptySet()
/*  53:    */   {
/*  54: 74 */     return new FastSparseSet(this, null);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public int getLastBlock()
/*  58:    */   {
/*  59: 78 */     return this.lastBlock;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public int getLastMask()
/*  63:    */   {
/*  64: 82 */     return this.lastMask;
/*  65:    */   }
/*  66:    */   
/*  67:    */   private VBStyleCollection<int[], E> getInternalValuesCollection()
/*  68:    */   {
/*  69: 86 */     return this.colValuesInternal;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static class FastSparseSet<E>
/*  73:    */     implements Iterable<E>
/*  74:    */   {
/*  75: 91 */     public static final FastSparseSet[] EMPTY_ARRAY = new FastSparseSet[0];
/*  76:    */     private final FastSparseSetFactory<E> factory;
/*  77:    */     private final VBStyleCollection<int[], E> colValuesInternal;
/*  78:    */     private int[] data;
/*  79:    */     private int[] next;
/*  80:    */     
/*  81:    */     private FastSparseSet(FastSparseSetFactory<E> factory)
/*  82:    */     {
/*  83:101 */       this.factory = factory;
/*  84:102 */       this.colValuesInternal = factory.getInternalValuesCollection();
/*  85:    */       
/*  86:104 */       int length = factory.getLastBlock() + 1;
/*  87:105 */       this.data = new int[length];
/*  88:106 */       this.next = new int[length];
/*  89:    */     }
/*  90:    */     
/*  91:    */     private FastSparseSet(FastSparseSetFactory<E> factory, int[] data, int[] next)
/*  92:    */     {
/*  93:110 */       this.factory = factory;
/*  94:111 */       this.colValuesInternal = factory.getInternalValuesCollection();
/*  95:    */       
/*  96:113 */       this.data = data;
/*  97:114 */       this.next = next;
/*  98:    */     }
/*  99:    */     
/* 100:    */     public FastSparseSet<E> getCopy()
/* 101:    */     {
/* 102:119 */       int arrlength = this.data.length;
/* 103:120 */       int[] cpdata = new int[arrlength];
/* 104:121 */       int[] cpnext = new int[arrlength];
/* 105:    */       
/* 106:123 */       System.arraycopy(this.data, 0, cpdata, 0, arrlength);
/* 107:124 */       System.arraycopy(this.next, 0, cpnext, 0, arrlength);
/* 108:    */       
/* 109:126 */       return new FastSparseSet(this.factory, cpdata, cpnext);
/* 110:    */     }
/* 111:    */     
/* 112:    */     private int[] ensureCapacity(int index)
/* 113:    */     {
/* 114:131 */       int newlength = this.data.length;
/* 115:132 */       if (newlength == 0) {
/* 116:133 */         newlength = 1;
/* 117:    */       }
/* 118:136 */       while (newlength <= index) {
/* 119:137 */         newlength *= 2;
/* 120:    */       }
/* 121:140 */       int[] newdata = new int[newlength];
/* 122:141 */       System.arraycopy(this.data, 0, newdata, 0, this.data.length);
/* 123:142 */       this.data = newdata;
/* 124:    */       
/* 125:144 */       int[] newnext = new int[newlength];
/* 126:145 */       System.arraycopy(this.next, 0, newnext, 0, this.next.length);
/* 127:146 */       this.next = newnext;
/* 128:    */       
/* 129:148 */       return newdata;
/* 130:    */     }
/* 131:    */     
/* 132:    */     public void add(E element)
/* 133:    */     {
/* 134:152 */       int[] index = (int[])this.colValuesInternal.getWithKey(element);
/* 135:154 */       if (index == null) {
/* 136:155 */         index = this.factory.addElement(element);
/* 137:    */       }
/* 138:158 */       int block = index[0];
/* 139:159 */       if (block >= this.data.length) {
/* 140:160 */         ensureCapacity(block);
/* 141:    */       }
/* 142:163 */       this.data[block] |= index[1];
/* 143:    */       
/* 144:165 */       changeNext(this.next, block, this.next[block], block);
/* 145:    */     }
/* 146:    */     
/* 147:    */     public void setAllElements()
/* 148:    */     {
/* 149:170 */       int lastblock = this.factory.getLastBlock();
/* 150:171 */       int lastmask = this.factory.getLastMask();
/* 151:173 */       if (lastblock >= this.data.length) {
/* 152:174 */         ensureCapacity(lastblock);
/* 153:    */       }
/* 154:177 */       for (int i = lastblock - 1; i >= 0; i--)
/* 155:    */       {
/* 156:178 */         this.data[i] = -1;
/* 157:179 */         this.next[i] = (i + 1);
/* 158:    */       }
/* 159:182 */       this.data[lastblock] = (lastmask | lastmask - 1);
/* 160:183 */       this.next[lastblock] = 0;
/* 161:    */     }
/* 162:    */     
/* 163:    */     public void addAll(Set<E> set)
/* 164:    */     {
/* 165:187 */       for (E element : set) {
/* 166:188 */         add(element);
/* 167:    */       }
/* 168:    */     }
/* 169:    */     
/* 170:    */     public void remove(E element)
/* 171:    */     {
/* 172:193 */       int[] index = (int[])this.colValuesInternal.getWithKey(element);
/* 173:195 */       if (index == null) {
/* 174:196 */         index = this.factory.addElement(element);
/* 175:    */       }
/* 176:199 */       int block = index[0];
/* 177:200 */       if (block < this.data.length)
/* 178:    */       {
/* 179:201 */         this.data[block] &= (index[1] ^ 0xFFFFFFFF);
/* 180:203 */         if (this.data[block] == 0) {
/* 181:204 */           changeNext(this.next, block, block, this.next[block]);
/* 182:    */         }
/* 183:    */       }
/* 184:    */     }
/* 185:    */     
/* 186:    */     public void removeAll(Set<E> set)
/* 187:    */     {
/* 188:210 */       for (E element : set) {
/* 189:211 */         remove(element);
/* 190:    */       }
/* 191:    */     }
/* 192:    */     
/* 193:    */     public boolean contains(E element)
/* 194:    */     {
/* 195:216 */       int[] index = (int[])this.colValuesInternal.getWithKey(element);
/* 196:218 */       if (index == null) {
/* 197:219 */         index = this.factory.addElement(element);
/* 198:    */       }
/* 199:222 */       return (index[0] < this.data.length) && ((this.data[index[0]] & index[1]) != 0);
/* 200:    */     }
/* 201:    */     
/* 202:    */     public boolean contains(FastSparseSet<E> set)
/* 203:    */     {
/* 204:226 */       int[] extdata = set.getData();
/* 205:227 */       int[] intdata = this.data;
/* 206:    */       
/* 207:229 */       int minlength = Math.min(extdata.length, intdata.length);
/* 208:231 */       for (int i = minlength - 1; i >= 0; i--) {
/* 209:232 */         if ((extdata[i] & (intdata[i] ^ 0xFFFFFFFF)) != 0) {
/* 210:233 */           return false;
/* 211:    */         }
/* 212:    */       }
/* 213:237 */       for (int i = extdata.length - 1; i >= minlength; i--) {
/* 214:238 */         if (extdata[i] != 0) {
/* 215:239 */           return false;
/* 216:    */         }
/* 217:    */       }
/* 218:243 */       return true;
/* 219:    */     }
/* 220:    */     
/* 221:    */     private void setNext()
/* 222:    */     {
/* 223:248 */       int link = 0;
/* 224:249 */       for (int i = this.data.length - 1; i >= 0; i--)
/* 225:    */       {
/* 226:250 */         this.next[i] = link;
/* 227:251 */         if (this.data[i] != 0) {
/* 228:252 */           link = i;
/* 229:    */         }
/* 230:    */       }
/* 231:    */     }
/* 232:    */     
/* 233:    */     private static void changeNext(int[] arrnext, int key, int oldnext, int newnext)
/* 234:    */     {
/* 235:258 */       for (int i = key - 1; i >= 0; i--)
/* 236:    */       {
/* 237:259 */         if (arrnext[i] != oldnext) {
/* 238:    */           break;
/* 239:    */         }
/* 240:260 */         arrnext[i] = newnext;
/* 241:    */       }
/* 242:    */     }
/* 243:    */     
/* 244:    */     public void union(FastSparseSet<E> set)
/* 245:    */     {
/* 246:270 */       int[] extdata = set.getData();
/* 247:271 */       int[] extnext = set.getNext();
/* 248:272 */       int[] intdata = this.data;
/* 249:273 */       int intlength = intdata.length;
/* 250:    */       
/* 251:275 */       int pointer = 0;
/* 252:    */       do
/* 253:    */       {
/* 254:277 */         if (pointer >= intlength) {
/* 255:278 */           intdata = ensureCapacity(extdata.length - 1);
/* 256:    */         }
/* 257:281 */         boolean nextrec = intdata[pointer] == 0;
/* 258:282 */         intdata[pointer] |= extdata[pointer];
/* 259:284 */         if (nextrec) {
/* 260:285 */           changeNext(this.next, pointer, this.next[pointer], pointer);
/* 261:    */         }
/* 262:288 */         pointer = extnext[pointer];
/* 263:290 */       } while (pointer != 0);
/* 264:    */     }
/* 265:    */     
/* 266:    */     public void intersection(FastSparseSet<E> set)
/* 267:    */     {
/* 268:294 */       int[] extdata = set.getData();
/* 269:295 */       int[] intdata = this.data;
/* 270:    */       
/* 271:297 */       int minlength = Math.min(extdata.length, intdata.length);
/* 272:299 */       for (int i = minlength - 1; i >= 0; i--) {
/* 273:300 */         intdata[i] &= extdata[i];
/* 274:    */       }
/* 275:303 */       for (int i = intdata.length - 1; i >= minlength; i--) {
/* 276:304 */         intdata[i] = 0;
/* 277:    */       }
/* 278:307 */       setNext();
/* 279:    */     }
/* 280:    */     
/* 281:    */     public void symdiff(FastSparseSet<E> set)
/* 282:    */     {
/* 283:311 */       int[] extdata = set.getData();
/* 284:312 */       int[] intdata = this.data;
/* 285:    */       
/* 286:314 */       int minlength = Math.min(extdata.length, intdata.length);
/* 287:316 */       for (int i = minlength - 1; i >= 0; i--) {
/* 288:317 */         intdata[i] ^= extdata[i];
/* 289:    */       }
/* 290:320 */       boolean expanded = false;
/* 291:321 */       for (int i = extdata.length - 1; i >= minlength; i--) {
/* 292:322 */         if (extdata[i] != 0)
/* 293:    */         {
/* 294:323 */           if (!expanded) {
/* 295:324 */             intdata = ensureCapacity(extdata.length - 1);
/* 296:    */           }
/* 297:326 */           intdata[i] = extdata[i];
/* 298:    */         }
/* 299:    */       }
/* 300:330 */       setNext();
/* 301:    */     }
/* 302:    */     
/* 303:    */     public void complement(FastSparseSet<E> set)
/* 304:    */     {
/* 305:335 */       int[] extdata = set.getData();
/* 306:336 */       int[] intdata = this.data;
/* 307:337 */       int extlength = extdata.length;
/* 308:    */       
/* 309:339 */       int pointer = 0;
/* 310:    */       do
/* 311:    */       {
/* 312:341 */         if (pointer >= extlength) {
/* 313:    */           break;
/* 314:    */         }
/* 315:345 */         intdata[pointer] &= (extdata[pointer] ^ 0xFFFFFFFF);
/* 316:346 */         if (intdata[pointer] == 0) {
/* 317:347 */           changeNext(this.next, pointer, pointer, this.next[pointer]);
/* 318:    */         }
/* 319:350 */         pointer = this.next[pointer];
/* 320:352 */       } while (pointer != 0);
/* 321:    */     }
/* 322:    */     
/* 323:    */     public boolean equals(Object o)
/* 324:    */     {
/* 325:357 */       if (o == this) {
/* 326:357 */         return true;
/* 327:    */       }
/* 328:358 */       if ((o == null) || (!(o instanceof FastSparseSet))) {
/* 329:358 */         return false;
/* 330:    */       }
/* 331:360 */       int[] longdata = ((FastSparseSet)o).getData();
/* 332:361 */       int[] shortdata = this.data;
/* 333:363 */       if (this.data.length > longdata.length)
/* 334:    */       {
/* 335:364 */         shortdata = longdata;
/* 336:365 */         longdata = this.data;
/* 337:    */       }
/* 338:368 */       for (int i = shortdata.length - 1; i >= 0; i--) {
/* 339:369 */         if (shortdata[i] != longdata[i]) {
/* 340:370 */           return false;
/* 341:    */         }
/* 342:    */       }
/* 343:374 */       for (int i = longdata.length - 1; i >= shortdata.length; i--) {
/* 344:375 */         if (longdata[i] != 0) {
/* 345:376 */           return false;
/* 346:    */         }
/* 347:    */       }
/* 348:380 */       return true;
/* 349:    */     }
/* 350:    */     
/* 351:    */     public int getCardinality()
/* 352:    */     {
/* 353:385 */       boolean found = false;
/* 354:386 */       int[] intdata = this.data;
/* 355:388 */       for (int i = intdata.length - 1; i >= 0; i--)
/* 356:    */       {
/* 357:389 */         int block = intdata[i];
/* 358:390 */         if (block != 0)
/* 359:    */         {
/* 360:391 */           if (found) {
/* 361:392 */             return 2;
/* 362:    */           }
/* 363:395 */           if ((block & block - 1) == 0) {
/* 364:396 */             found = true;
/* 365:    */           } else {
/* 366:399 */             return 2;
/* 367:    */           }
/* 368:    */         }
/* 369:    */       }
/* 370:405 */       return found ? 1 : 0;
/* 371:    */     }
/* 372:    */     
/* 373:    */     public boolean isEmpty()
/* 374:    */     {
/* 375:409 */       return (this.data.length == 0) || ((this.next[0] == 0) && (this.data[0] == 0));
/* 376:    */     }
/* 377:    */     
/* 378:    */     public Iterator<E> iterator()
/* 379:    */     {
/* 380:413 */       return new FastSparseSetFactory.FastSparseSetIterator(this, null);
/* 381:    */     }
/* 382:    */     
/* 383:    */     public Set<E> toPlainSet()
/* 384:    */     {
/* 385:417 */       HashSet<E> set = new HashSet();
/* 386:    */       
/* 387:419 */       int[] intdata = this.data;
/* 388:    */       
/* 389:421 */       int size = this.data.length * 32;
/* 390:422 */       if (size > this.colValuesInternal.size()) {
/* 391:423 */         size = this.colValuesInternal.size();
/* 392:    */       }
/* 393:426 */       for (int i = size - 1; i >= 0; i--)
/* 394:    */       {
/* 395:427 */         int[] index = (int[])this.colValuesInternal.get(i);
/* 396:429 */         if ((intdata[index[0]] & index[1]) != 0) {
/* 397:430 */           set.add(this.colValuesInternal.getKey(i));
/* 398:    */         }
/* 399:    */       }
/* 400:434 */       return set;
/* 401:    */     }
/* 402:    */     
/* 403:    */     public String toString()
/* 404:    */     {
/* 405:438 */       return toPlainSet().toString();
/* 406:    */     }
/* 407:    */     
/* 408:    */     public String toBinary()
/* 409:    */     {
/* 410:443 */       StringBuilder buffer = new StringBuilder();
/* 411:444 */       int[] intdata = this.data;
/* 412:446 */       for (int i = 0; i < intdata.length; i++) {
/* 413:447 */         buffer.append(" ").append(Integer.toBinaryString(intdata[i]));
/* 414:    */       }
/* 415:450 */       return buffer.toString();
/* 416:    */     }
/* 417:    */     
/* 418:    */     private int[] getData()
/* 419:    */     {
/* 420:454 */       return this.data;
/* 421:    */     }
/* 422:    */     
/* 423:    */     private int[] getNext()
/* 424:    */     {
/* 425:458 */       return this.next;
/* 426:    */     }
/* 427:    */     
/* 428:    */     public int[] getLoad()
/* 429:    */     {
/* 430:462 */       int[] intdata = this.data;
/* 431:463 */       int notempty = 0;
/* 432:465 */       for (int i = 0; i < intdata.length; i++) {
/* 433:466 */         if (intdata[i] != 0) {
/* 434:467 */           notempty++;
/* 435:    */         }
/* 436:    */       }
/* 437:471 */       return new int[] { intdata.length, notempty };
/* 438:    */     }
/* 439:    */     
/* 440:    */     public FastSparseSetFactory<E> getFactory()
/* 441:    */     {
/* 442:475 */       return this.factory;
/* 443:    */     }
/* 444:    */   }
/* 445:    */   
/* 446:    */   public static class FastSparseSetIterator<E>
/* 447:    */     implements Iterator<E>
/* 448:    */   {
/* 449:    */     private final VBStyleCollection<int[], E> colValuesInternal;
/* 450:    */     private final int[] data;
/* 451:    */     private final int[] next;
/* 452:    */     private final int size;
/* 453:486 */     private int pointer = -1;
/* 454:487 */     private int next_pointer = -1;
/* 455:    */     
/* 456:    */     private FastSparseSetIterator(FastSparseSetFactory.FastSparseSet<E> set)
/* 457:    */     {
/* 458:490 */       this.colValuesInternal = set.getFactory().getInternalValuesCollection();
/* 459:491 */       this.data = FastSparseSetFactory.FastSparseSet.access$400(set);
/* 460:492 */       this.next = FastSparseSetFactory.FastSparseSet.access$500(set);
/* 461:493 */       this.size = this.colValuesInternal.size();
/* 462:    */     }
/* 463:    */     
/* 464:    */     private int getNextIndex(int index)
/* 465:    */     {
/* 466:498 */       index++;
/* 467:499 */       int bindex = index >>> 5;
/* 468:500 */       int dindex = index & 0x1F;
/* 469:502 */       while (bindex < this.data.length)
/* 470:    */       {
/* 471:503 */         int block = this.data[bindex];
/* 472:505 */         if (block != 0)
/* 473:    */         {
/* 474:506 */           block >>>= dindex;
/* 475:507 */           while (dindex < 32)
/* 476:    */           {
/* 477:508 */             if ((block & 0x1) != 0) {
/* 478:509 */               return (bindex << 5) + dindex;
/* 479:    */             }
/* 480:511 */             block >>>= 1;
/* 481:512 */             dindex++;
/* 482:    */           }
/* 483:    */         }
/* 484:516 */         dindex = 0;
/* 485:517 */         bindex = this.next[bindex];
/* 486:519 */         if (bindex == 0) {
/* 487:    */           break;
/* 488:    */         }
/* 489:    */       }
/* 490:524 */       return -1;
/* 491:    */     }
/* 492:    */     
/* 493:    */     public boolean hasNext()
/* 494:    */     {
/* 495:528 */       this.next_pointer = getNextIndex(this.pointer);
/* 496:529 */       return this.next_pointer >= 0;
/* 497:    */     }
/* 498:    */     
/* 499:    */     public E next()
/* 500:    */     {
/* 501:533 */       if (this.next_pointer >= 0)
/* 502:    */       {
/* 503:534 */         this.pointer = this.next_pointer;
/* 504:    */       }
/* 505:    */       else
/* 506:    */       {
/* 507:537 */         this.pointer = getNextIndex(this.pointer);
/* 508:538 */         if (this.pointer == -1) {
/* 509:539 */           this.pointer = this.size;
/* 510:    */         }
/* 511:    */       }
/* 512:543 */       this.next_pointer = -1;
/* 513:544 */       return this.pointer < this.size ? this.colValuesInternal.getKey(this.pointer) : null;
/* 514:    */     }
/* 515:    */     
/* 516:    */     public void remove()
/* 517:    */     {
/* 518:548 */       int[] index = (int[])this.colValuesInternal.get(this.pointer);
/* 519:549 */       this.data[index[0]] &= (index[1] ^ 0xFFFFFFFF);
/* 520:    */     }
/* 521:    */   }
/* 522:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.util.FastSparseSetFactory
 * JD-Core Version:    0.7.0.1
 */