/*  1:   */ package org.jetbrains.java.decompiler.util;
/*  2:   */ 
/*  3:   */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*  4:   */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  5:   */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  6:   */ import org.jetbrains.java.decompiler.main.collectors.ImportCollector;
/*  7:   */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  8:   */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  9:   */ 
/* 10:   */ public class TextUtil
/* 11:   */ {
/* 12:   */   public static void writeQualifiedSuper(TextBuffer buf, String qualifier)
/* 13:   */   {
/* 14:25 */     ClassesProcessor.ClassNode classNode = (ClassesProcessor.ClassNode)DecompilerContext.getProperty("CURRENT_CLASS_NODE");
/* 15:26 */     if (!qualifier.equals(classNode.classStruct.qualifiedName)) {
/* 16:27 */       buf.append(DecompilerContext.getImportCollector().getShortName(ExprProcessor.buildJavaClassName(qualifier))).append('.');
/* 17:   */     }
/* 18:29 */     buf.append("super");
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.util.TextUtil
 * JD-Core Version:    0.7.0.1
 */