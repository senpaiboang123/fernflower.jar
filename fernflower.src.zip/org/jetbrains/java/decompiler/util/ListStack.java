/*  1:   */ package org.jetbrains.java.decompiler.util;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ 
/*  5:   */ public class ListStack<T>
/*  6:   */   extends ArrayList<T>
/*  7:   */ {
/*  8:22 */   protected int pointer = 0;
/*  9:   */   
/* 10:   */   public ListStack() {}
/* 11:   */   
/* 12:   */   public ListStack(ArrayList<T> list)
/* 13:   */   {
/* 14:29 */     super(list);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public ListStack<T> clone()
/* 18:   */   {
/* 19:33 */     ListStack<T> newstack = new ListStack(this);
/* 20:34 */     newstack.pointer = this.pointer;
/* 21:35 */     return newstack;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public T push(T item)
/* 25:   */   {
/* 26:39 */     add(item);
/* 27:40 */     this.pointer += 1;
/* 28:41 */     return item;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public T pop()
/* 32:   */   {
/* 33:45 */     this.pointer -= 1;
/* 34:46 */     T o = get(this.pointer);
/* 35:47 */     remove(this.pointer);
/* 36:48 */     return o;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public T pop(int count)
/* 40:   */   {
/* 41:52 */     T o = null;
/* 42:53 */     for (int i = count; i > 0; i--) {
/* 43:54 */       o = pop();
/* 44:   */     }
/* 45:56 */     return o;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void remove()
/* 49:   */   {
/* 50:60 */     this.pointer -= 1;
/* 51:61 */     remove(this.pointer);
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void removeMultiple(int count)
/* 55:   */   {
/* 56:65 */     while (count > 0)
/* 57:   */     {
/* 58:66 */       this.pointer -= 1;
/* 59:67 */       remove(this.pointer);
/* 60:68 */       count--;
/* 61:   */     }
/* 62:   */   }
/* 63:   */   
/* 64:   */   public boolean empty()
/* 65:   */   {
/* 66:73 */     return this.pointer == 0;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public int getPointer()
/* 70:   */   {
/* 71:77 */     return this.pointer;
/* 72:   */   }
/* 73:   */   
/* 74:   */   public T getByOffset(int offset)
/* 75:   */   {
/* 76:81 */     return get(this.pointer + offset);
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void insertByOffset(int offset, T item)
/* 80:   */   {
/* 81:85 */     add(this.pointer + offset, item);
/* 82:86 */     this.pointer += 1;
/* 83:   */   }
/* 84:   */   
/* 85:   */   public void clear()
/* 86:   */   {
/* 87:90 */     super.clear();
/* 88:91 */     this.pointer = 0;
/* 89:   */   }
/* 90:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.util.ListStack
 * JD-Core Version:    0.7.0.1
 */