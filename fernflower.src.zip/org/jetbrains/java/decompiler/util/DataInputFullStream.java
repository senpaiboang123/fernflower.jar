/*  1:   */ package org.jetbrains.java.decompiler.util;
/*  2:   */ 
/*  3:   */ import java.io.ByteArrayInputStream;
/*  4:   */ import java.io.DataInputStream;
/*  5:   */ import java.io.IOException;
/*  6:   */ 
/*  7:   */ public class DataInputFullStream
/*  8:   */   extends DataInputStream
/*  9:   */ {
/* 10:   */   public DataInputFullStream(byte[] bytes)
/* 11:   */   {
/* 12:25 */     super(new ByteArrayInputStream(bytes));
/* 13:   */   }
/* 14:   */   
/* 15:   */   public int readFull(byte[] b)
/* 16:   */     throws IOException
/* 17:   */   {
/* 18:29 */     int length = b.length;
/* 19:30 */     byte[] temp = new byte[length];
/* 20:31 */     int pos = 0;
/* 21:   */     for (;;)
/* 22:   */     {
/* 23:35 */       int bytes_read = read(temp, 0, length - pos);
/* 24:36 */       if (bytes_read == -1) {
/* 25:37 */         return -1;
/* 26:   */       }
/* 27:40 */       System.arraycopy(temp, 0, b, pos, bytes_read);
/* 28:41 */       pos += bytes_read;
/* 29:42 */       if (pos == length) {
/* 30:   */         break;
/* 31:   */       }
/* 32:   */     }
/* 33:47 */     return length;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void discard(int n)
/* 37:   */     throws IOException
/* 38:   */   {
/* 39:51 */     if (super.skip(n) != n) {
/* 40:52 */       throw new IOException("Skip failed");
/* 41:   */     }
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.util.DataInputFullStream
 * JD-Core Version:    0.7.0.1
 */