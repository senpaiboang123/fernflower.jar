/*   1:    */ package org.jetbrains.java.decompiler.util;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileInputStream;
/*   5:    */ import java.io.FileOutputStream;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ import java.nio.channels.FileChannel;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.HashSet;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.zip.ZipEntry;
/*  14:    */ import java.util.zip.ZipFile;
/*  15:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  16:    */ 
/*  17:    */ public class InterpreterUtil
/*  18:    */ {
/*  19: 30 */   public static final boolean IS_WINDOWS = System.getProperty("os.name", "").startsWith("Windows");
/*  20: 32 */   public static final int[] EMPTY_INT_ARRAY = new int[0];
/*  21: 34 */   private static final int CHANNEL_WINDOW_SIZE = IS_WINDOWS ? 67076096 : 67108864;
/*  22:    */   private static final int BUFFER_SIZE = 16384;
/*  23:    */   
/*  24:    */   public static void copyFile(File in, File out)
/*  25:    */     throws IOException
/*  26:    */   {
/*  27: 38 */     FileInputStream inStream = new FileInputStream(in);
/*  28:    */     try
/*  29:    */     {
/*  30: 40 */       FileOutputStream outStream = new FileOutputStream(out);
/*  31:    */       try
/*  32:    */       {
/*  33: 42 */         FileChannel inChannel = inStream.getChannel();
/*  34: 43 */         FileChannel outChannel = outStream.getChannel();
/*  35: 44 */         long size = inChannel.size();long position = 0L;
/*  36: 45 */         while (position < size) {
/*  37: 46 */           position += inChannel.transferTo(position, CHANNEL_WINDOW_SIZE, outChannel);
/*  38:    */         }
/*  39:    */       }
/*  40:    */       finally {}
/*  41:    */     }
/*  42:    */     finally
/*  43:    */     {
/*  44: 54 */       inStream.close();
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static void copyStream(InputStream in, OutputStream out)
/*  49:    */     throws IOException
/*  50:    */   {
/*  51: 59 */     byte[] buffer = new byte[16384];
/*  52:    */     int len;
/*  53: 61 */     while ((len = in.read(buffer)) >= 0) {
/*  54: 62 */       out.write(buffer, 0, len);
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static byte[] getBytes(ZipFile archive, ZipEntry entry)
/*  59:    */     throws IOException
/*  60:    */   {
/*  61: 67 */     return readAndClose(archive.getInputStream(entry), (int)entry.getSize());
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static byte[] getBytes(File file)
/*  65:    */     throws IOException
/*  66:    */   {
/*  67: 71 */     return readAndClose(new FileInputStream(file), (int)file.length());
/*  68:    */   }
/*  69:    */   
/*  70:    */   private static byte[] readAndClose(InputStream stream, int length)
/*  71:    */     throws IOException
/*  72:    */   {
/*  73:    */     try
/*  74:    */     {
/*  75: 76 */       byte[] bytes = new byte[length];
/*  76: 77 */       int n = 0;int off = 0;
/*  77:    */       int count;
/*  78: 78 */       while (n < length)
/*  79:    */       {
/*  80: 79 */         count = stream.read(bytes, off + n, length - n);
/*  81: 80 */         if (count < 0) {
/*  82: 81 */           throw new IOException("premature end of stream");
/*  83:    */         }
/*  84: 83 */         n += count;
/*  85:    */       }
/*  86: 85 */       return bytes;
/*  87:    */     }
/*  88:    */     finally
/*  89:    */     {
/*  90: 88 */       stream.close();
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static String getIndentString(int length)
/*  95:    */   {
/*  96: 93 */     if (length == 0) {
/*  97: 93 */       return "";
/*  98:    */     }
/*  99: 94 */     StringBuilder buf = new StringBuilder();
/* 100: 95 */     String indent = (String)DecompilerContext.getProperty("ind");
/* 101: 96 */     while (length-- > 0) {
/* 102: 97 */       buf.append(indent);
/* 103:    */     }
/* 104: 99 */     return buf.toString();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static boolean equalSets(Collection<?> c1, Collection<?> c2)
/* 108:    */   {
/* 109:103 */     if (c1 == null) {
/* 110:104 */       return c2 == null;
/* 111:    */     }
/* 112:106 */     if (c2 == null) {
/* 113:107 */       return false;
/* 114:    */     }
/* 115:110 */     if (c1.size() != c2.size()) {
/* 116:111 */       return false;
/* 117:    */     }
/* 118:114 */     HashSet<Object> set = new HashSet(c1);
/* 119:115 */     set.removeAll(c2);
/* 120:116 */     return set.size() == 0;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public static boolean equalObjects(Object first, Object second)
/* 124:    */   {
/* 125:120 */     return first == null ? false : second == null ? true : first.equals(second);
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static boolean equalLists(List<?> first, List<?> second)
/* 129:    */   {
/* 130:124 */     if (first == null) {
/* 131:125 */       return second == null;
/* 132:    */     }
/* 133:127 */     if (second == null) {
/* 134:128 */       return false;
/* 135:    */     }
/* 136:131 */     if (first.size() == second.size())
/* 137:    */     {
/* 138:132 */       for (int i = 0; i < first.size(); i++) {
/* 139:133 */         if (!equalObjects(first.get(i), second.get(i))) {
/* 140:134 */           return false;
/* 141:    */         }
/* 142:    */       }
/* 143:137 */       return true;
/* 144:    */     }
/* 145:140 */     return false;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public static boolean isPrintableUnicode(char c)
/* 149:    */   {
/* 150:144 */     int t = Character.getType(c);
/* 151:145 */     return (t != 0) && (t != 13) && (t != 14) && (t != 15) && (t != 16) && (t != 18) && (t != 19);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public static String charToUnicodeLiteral(int value)
/* 155:    */   {
/* 156:150 */     String sTemp = Integer.toHexString(value);
/* 157:151 */     sTemp = ("0000" + sTemp).substring(sTemp.length());
/* 158:152 */     return "\\u" + sTemp;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public static String makeUniqueKey(String name, String descriptor)
/* 162:    */   {
/* 163:156 */     return name + ' ' + descriptor;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public static String makeUniqueKey(String name, String descriptor1, String descriptor2)
/* 167:    */   {
/* 168:160 */     return name + ' ' + descriptor1 + ' ' + descriptor2;
/* 169:    */   }
/* 170:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.util.InterpreterUtil
 * JD-Core Version:    0.7.0.1
 */