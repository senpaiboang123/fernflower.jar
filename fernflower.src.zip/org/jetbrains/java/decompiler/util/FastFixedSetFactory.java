/*   1:    */ package org.jetbrains.java.decompiler.util;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Set;
/*   9:    */ 
/*  10:    */ public class FastFixedSetFactory<E>
/*  11:    */ {
/*  12: 22 */   private final VBStyleCollection<int[], E> colValuesInternal = new VBStyleCollection();
/*  13:    */   private final int dataLength;
/*  14:    */   
/*  15:    */   public FastFixedSetFactory(Collection<E> set)
/*  16:    */   {
/*  17: 28 */     this.dataLength = (set.size() / 32 + 1);
/*  18:    */     
/*  19: 30 */     int index = 0;
/*  20: 31 */     int mask = 1;
/*  21: 33 */     for (E element : set)
/*  22:    */     {
/*  23: 35 */       int block = index / 32;
/*  24: 37 */       if (index % 32 == 0) {
/*  25: 38 */         mask = 1;
/*  26:    */       }
/*  27: 41 */       this.colValuesInternal.putWithKey(new int[] { block, mask }, element);
/*  28:    */       
/*  29: 43 */       index++;
/*  30: 44 */       mask <<= 1;
/*  31:    */     }
/*  32:    */   }
/*  33:    */   
/*  34:    */   public FastFixedSet<E> spawnEmptySet()
/*  35:    */   {
/*  36: 49 */     return new FastFixedSet(this, null);
/*  37:    */   }
/*  38:    */   
/*  39:    */   private int getDataLength()
/*  40:    */   {
/*  41: 53 */     return this.dataLength;
/*  42:    */   }
/*  43:    */   
/*  44:    */   private VBStyleCollection<int[], E> getInternalValuesCollection()
/*  45:    */   {
/*  46: 57 */     return this.colValuesInternal;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static class FastFixedSet<E>
/*  50:    */     implements Iterable<E>
/*  51:    */   {
/*  52:    */     private final FastFixedSetFactory<E> factory;
/*  53:    */     private final VBStyleCollection<int[], E> colValuesInternal;
/*  54:    */     private int[] data;
/*  55:    */     
/*  56:    */     private FastFixedSet(FastFixedSetFactory<E> factory)
/*  57:    */     {
/*  58: 70 */       this.factory = factory;
/*  59: 71 */       this.colValuesInternal = factory.getInternalValuesCollection();
/*  60: 72 */       this.data = new int[factory.getDataLength()];
/*  61:    */     }
/*  62:    */     
/*  63:    */     public FastFixedSet<E> getCopy()
/*  64:    */     {
/*  65: 77 */       FastFixedSet<E> copy = new FastFixedSet(this.factory);
/*  66:    */       
/*  67: 79 */       int arrlength = this.data.length;
/*  68: 80 */       int[] cpdata = new int[arrlength];
/*  69: 81 */       System.arraycopy(this.data, 0, cpdata, 0, arrlength);
/*  70: 82 */       copy.setData(cpdata);
/*  71:    */       
/*  72: 84 */       return copy;
/*  73:    */     }
/*  74:    */     
/*  75:    */     public void setAllElements()
/*  76:    */     {
/*  77: 89 */       int[] lastindex = (int[])this.colValuesInternal.get(this.colValuesInternal.size() - 1);
/*  78: 91 */       for (int i = lastindex[0] - 1; i >= 0; i--) {
/*  79: 92 */         this.data[i] = -1;
/*  80:    */       }
/*  81: 95 */       this.data[lastindex[0]] = (lastindex[1] | lastindex[1] - 1);
/*  82:    */     }
/*  83:    */     
/*  84:    */     public void add(E element)
/*  85:    */     {
/*  86: 99 */       int[] index = (int[])this.colValuesInternal.getWithKey(element);
/*  87:100 */       this.data[index[0]] |= index[1];
/*  88:    */     }
/*  89:    */     
/*  90:    */     public void addAll(Collection<E> set)
/*  91:    */     {
/*  92:104 */       for (E element : set) {
/*  93:105 */         add(element);
/*  94:    */       }
/*  95:    */     }
/*  96:    */     
/*  97:    */     public void remove(E element)
/*  98:    */     {
/*  99:110 */       int[] index = (int[])this.colValuesInternal.getWithKey(element);
/* 100:111 */       this.data[index[0]] &= (index[1] ^ 0xFFFFFFFF);
/* 101:    */     }
/* 102:    */     
/* 103:    */     public void removeAll(Collection<E> set)
/* 104:    */     {
/* 105:115 */       for (E element : set) {
/* 106:116 */         remove(element);
/* 107:    */       }
/* 108:    */     }
/* 109:    */     
/* 110:    */     public boolean contains(E element)
/* 111:    */     {
/* 112:121 */       int[] index = (int[])this.colValuesInternal.getWithKey(element);
/* 113:122 */       return (this.data[index[0]] & index[1]) != 0;
/* 114:    */     }
/* 115:    */     
/* 116:    */     public boolean contains(FastFixedSet<E> set)
/* 117:    */     {
/* 118:126 */       int[] extdata = set.getData();
/* 119:127 */       int[] intdata = this.data;
/* 120:129 */       for (int i = intdata.length - 1; i >= 0; i--) {
/* 121:130 */         if ((extdata[i] & (intdata[i] ^ 0xFFFFFFFF)) != 0) {
/* 122:131 */           return false;
/* 123:    */         }
/* 124:    */       }
/* 125:135 */       return true;
/* 126:    */     }
/* 127:    */     
/* 128:    */     public void union(FastFixedSet<E> set)
/* 129:    */     {
/* 130:139 */       int[] extdata = set.getData();
/* 131:140 */       int[] intdata = this.data;
/* 132:142 */       for (int i = intdata.length - 1; i >= 0; i--) {
/* 133:143 */         intdata[i] |= extdata[i];
/* 134:    */       }
/* 135:    */     }
/* 136:    */     
/* 137:    */     public void intersection(FastFixedSet<E> set)
/* 138:    */     {
/* 139:148 */       int[] extdata = set.getData();
/* 140:149 */       int[] intdata = this.data;
/* 141:151 */       for (int i = intdata.length - 1; i >= 0; i--) {
/* 142:152 */         intdata[i] &= extdata[i];
/* 143:    */       }
/* 144:    */     }
/* 145:    */     
/* 146:    */     public void symdiff(FastFixedSet<E> set)
/* 147:    */     {
/* 148:157 */       int[] extdata = set.getData();
/* 149:158 */       int[] intdata = this.data;
/* 150:160 */       for (int i = intdata.length - 1; i >= 0; i--) {
/* 151:161 */         intdata[i] ^= extdata[i];
/* 152:    */       }
/* 153:    */     }
/* 154:    */     
/* 155:    */     public void complement(FastFixedSet<E> set)
/* 156:    */     {
/* 157:166 */       int[] extdata = set.getData();
/* 158:167 */       int[] intdata = this.data;
/* 159:169 */       for (int i = intdata.length - 1; i >= 0; i--) {
/* 160:170 */         intdata[i] &= (extdata[i] ^ 0xFFFFFFFF);
/* 161:    */       }
/* 162:    */     }
/* 163:    */     
/* 164:    */     public boolean equals(Object o)
/* 165:    */     {
/* 166:176 */       if (o == this) {
/* 167:176 */         return true;
/* 168:    */       }
/* 169:177 */       if ((o == null) || (!(o instanceof FastFixedSet))) {
/* 170:177 */         return false;
/* 171:    */       }
/* 172:179 */       int[] extdata = ((FastFixedSet)o).getData();
/* 173:180 */       int[] intdata = this.data;
/* 174:182 */       for (int i = intdata.length - 1; i >= 0; i--) {
/* 175:183 */         if (intdata[i] != extdata[i]) {
/* 176:184 */           return false;
/* 177:    */         }
/* 178:    */       }
/* 179:188 */       return true;
/* 180:    */     }
/* 181:    */     
/* 182:    */     public boolean isEmpty()
/* 183:    */     {
/* 184:192 */       int[] intdata = this.data;
/* 185:194 */       for (int i = intdata.length - 1; i >= 0; i--) {
/* 186:195 */         if (intdata[i] != 0) {
/* 187:196 */           return false;
/* 188:    */         }
/* 189:    */       }
/* 190:200 */       return true;
/* 191:    */     }
/* 192:    */     
/* 193:    */     public Iterator<E> iterator()
/* 194:    */     {
/* 195:204 */       return new FastFixedSetFactory.FastFixedSetIterator(this, null);
/* 196:    */     }
/* 197:    */     
/* 198:    */     public Set<E> toPlainSet()
/* 199:    */     {
/* 200:208 */       return (Set)toPlainCollection(new HashSet());
/* 201:    */     }
/* 202:    */     
/* 203:    */     public List<E> toPlainList()
/* 204:    */     {
/* 205:212 */       return (List)toPlainCollection(new ArrayList());
/* 206:    */     }
/* 207:    */     
/* 208:    */     private <T extends Collection<E>> T toPlainCollection(T cl)
/* 209:    */     {
/* 210:218 */       int[] intdata = this.data;
/* 211:219 */       for (int bindex = 0; bindex < intdata.length; bindex++)
/* 212:    */       {
/* 213:220 */         int block = intdata[bindex];
/* 214:221 */         if (block != 0)
/* 215:    */         {
/* 216:222 */           int index = bindex << 5;
/* 217:223 */           for (int i = 31; i >= 0; i--)
/* 218:    */           {
/* 219:224 */             if ((block & 0x1) != 0) {
/* 220:225 */               cl.add(this.colValuesInternal.getKey(index));
/* 221:    */             }
/* 222:227 */             index++;
/* 223:228 */             block >>>= 1;
/* 224:    */           }
/* 225:    */         }
/* 226:    */       }
/* 227:233 */       return cl;
/* 228:    */     }
/* 229:    */     
/* 230:    */     public String toBinary()
/* 231:    */     {
/* 232:238 */       StringBuilder buffer = new StringBuilder();
/* 233:239 */       int[] intdata = this.data;
/* 234:241 */       for (int i = 0; i < intdata.length; i++) {
/* 235:242 */         buffer.append(" ").append(Integer.toBinaryString(intdata[i]));
/* 236:    */       }
/* 237:245 */       return buffer.toString();
/* 238:    */     }
/* 239:    */     
/* 240:    */     public String toString()
/* 241:    */     {
/* 242:250 */       StringBuilder buffer = new StringBuilder("{");
/* 243:    */       
/* 244:252 */       int[] intdata = this.data;
/* 245:253 */       boolean first = true;
/* 246:255 */       for (int i = this.colValuesInternal.size() - 1; i >= 0; i--)
/* 247:    */       {
/* 248:256 */         int[] index = (int[])this.colValuesInternal.get(i);
/* 249:258 */         if ((intdata[index[0]] & index[1]) != 0)
/* 250:    */         {
/* 251:259 */           if (first) {
/* 252:260 */             first = false;
/* 253:    */           } else {
/* 254:263 */             buffer.append(",");
/* 255:    */           }
/* 256:265 */           buffer.append(this.colValuesInternal.getKey(i));
/* 257:    */         }
/* 258:    */       }
/* 259:269 */       buffer.append("}");
/* 260:    */       
/* 261:271 */       return buffer.toString();
/* 262:    */     }
/* 263:    */     
/* 264:    */     private int[] getData()
/* 265:    */     {
/* 266:275 */       return this.data;
/* 267:    */     }
/* 268:    */     
/* 269:    */     private void setData(int[] data)
/* 270:    */     {
/* 271:279 */       this.data = data;
/* 272:    */     }
/* 273:    */     
/* 274:    */     public FastFixedSetFactory<E> getFactory()
/* 275:    */     {
/* 276:283 */       return this.factory;
/* 277:    */     }
/* 278:    */   }
/* 279:    */   
/* 280:    */   public static class FastFixedSetIterator<E>
/* 281:    */     implements Iterator<E>
/* 282:    */   {
/* 283:    */     private final VBStyleCollection<int[], E> colValuesInternal;
/* 284:    */     private final int[] data;
/* 285:    */     private final int size;
/* 286:293 */     private int pointer = -1;
/* 287:294 */     private int next_pointer = -1;
/* 288:    */     
/* 289:    */     private FastFixedSetIterator(FastFixedSetFactory.FastFixedSet<E> set)
/* 290:    */     {
/* 291:297 */       this.colValuesInternal = set.getFactory().getInternalValuesCollection();
/* 292:298 */       this.data = FastFixedSetFactory.FastFixedSet.access$400(set);
/* 293:299 */       this.size = this.colValuesInternal.size();
/* 294:    */     }
/* 295:    */     
/* 296:    */     private int getNextIndex(int index)
/* 297:    */     {
/* 298:304 */       index++;
/* 299:305 */       int ret = index;
/* 300:306 */       int bindex = index / 32;
/* 301:307 */       int dindex = index % 32;
/* 302:309 */       while (bindex < this.data.length)
/* 303:    */       {
/* 304:310 */         int block = this.data[bindex];
/* 305:312 */         if (block != 0)
/* 306:    */         {
/* 307:313 */           block >>>= dindex;
/* 308:314 */           while (dindex < 32)
/* 309:    */           {
/* 310:315 */             if ((block & 0x1) != 0) {
/* 311:316 */               return ret;
/* 312:    */             }
/* 313:318 */             block >>>= 1;
/* 314:319 */             dindex++;
/* 315:320 */             ret++;
/* 316:    */           }
/* 317:    */         }
/* 318:324 */         ret += 32 - dindex;
/* 319:    */         
/* 320:    */ 
/* 321:327 */         dindex = 0;
/* 322:328 */         bindex++;
/* 323:    */       }
/* 324:331 */       return -1;
/* 325:    */     }
/* 326:    */     
/* 327:    */     public boolean hasNext()
/* 328:    */     {
/* 329:335 */       this.next_pointer = getNextIndex(this.pointer);
/* 330:336 */       return this.next_pointer >= 0;
/* 331:    */     }
/* 332:    */     
/* 333:    */     public E next()
/* 334:    */     {
/* 335:340 */       if (this.next_pointer >= 0)
/* 336:    */       {
/* 337:341 */         this.pointer = this.next_pointer;
/* 338:    */       }
/* 339:    */       else
/* 340:    */       {
/* 341:344 */         this.pointer = getNextIndex(this.pointer);
/* 342:345 */         if (this.pointer == -1) {
/* 343:346 */           this.pointer = this.size;
/* 344:    */         }
/* 345:    */       }
/* 346:350 */       this.next_pointer = -1;
/* 347:351 */       return this.pointer < this.size ? this.colValuesInternal.getKey(this.pointer) : null;
/* 348:    */     }
/* 349:    */     
/* 350:    */     public void remove()
/* 351:    */     {
/* 352:355 */       int[] index = (int[])this.colValuesInternal.get(this.pointer);
/* 353:356 */       this.data[index[0]] &= (index[1] ^ 0xFFFFFFFF);
/* 354:    */     }
/* 355:    */   }
/* 356:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.util.FastFixedSetFactory
 * JD-Core Version:    0.7.0.1
 */