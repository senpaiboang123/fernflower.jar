/*   1:    */ package org.jetbrains.java.decompiler.util;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import java.util.Set;
/*   7:    */ 
/*   8:    */ public class SFormsFastMapDirect
/*   9:    */ {
/*  10:    */   private int size;
/*  11: 30 */   private final FastSparseSetFactory.FastSparseSet<Integer>[][] elements = new FastSparseSetFactory.FastSparseSet[3][];
/*  12: 32 */   private final int[][] next = new int[3][];
/*  13:    */   
/*  14:    */   public SFormsFastMapDirect()
/*  15:    */   {
/*  16: 35 */     this(true);
/*  17:    */   }
/*  18:    */   
/*  19:    */   private SFormsFastMapDirect(boolean initialize)
/*  20:    */   {
/*  21: 39 */     if (initialize) {
/*  22: 40 */       for (int i = 2; i >= 0; i--)
/*  23:    */       {
/*  24: 41 */         FastSparseSetFactory.FastSparseSet<Integer>[] empty = FastSparseSetFactory.FastSparseSet.EMPTY_ARRAY;
/*  25: 42 */         this.elements[i] = empty;
/*  26: 43 */         this.next[i] = InterpreterUtil.EMPTY_INT_ARRAY;
/*  27:    */       }
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31:    */   public SFormsFastMapDirect(SFormsFastMapDirect map)
/*  32:    */   {
/*  33: 49 */     for (int i = 2; i >= 0; i--)
/*  34:    */     {
/*  35: 50 */       FastSparseSetFactory.FastSparseSet<Integer>[] arr = map.elements[i];
/*  36: 51 */       int[] arrnext = map.next[i];
/*  37:    */       
/*  38: 53 */       int length = arr.length;
/*  39: 54 */       FastSparseSetFactory.FastSparseSet<Integer>[] arrnew = new FastSparseSetFactory.FastSparseSet[length];
/*  40: 55 */       int[] arrnextnew = new int[length];
/*  41:    */       
/*  42: 57 */       System.arraycopy(arr, 0, arrnew, 0, length);
/*  43: 58 */       System.arraycopy(arrnext, 0, arrnextnew, 0, length);
/*  44:    */       
/*  45: 60 */       this.elements[i] = arrnew;
/*  46: 61 */       this.next[i] = arrnextnew;
/*  47:    */       
/*  48: 63 */       this.size = map.size;
/*  49:    */     }
/*  50:    */   }
/*  51:    */   
/*  52:    */   public SFormsFastMapDirect getCopy()
/*  53:    */   {
/*  54: 69 */     SFormsFastMapDirect map = new SFormsFastMapDirect(false);
/*  55: 70 */     map.size = this.size;
/*  56:    */     
/*  57: 72 */     FastSparseSetFactory.FastSparseSet[][] mapelements = map.elements;
/*  58: 73 */     int[][] mapnext = map.next;
/*  59: 75 */     for (int i = 2; i >= 0; i--)
/*  60:    */     {
/*  61: 76 */       FastSparseSetFactory.FastSparseSet<Integer>[] arr = this.elements[i];
/*  62: 77 */       int length = arr.length;
/*  63: 79 */       if (length > 0)
/*  64:    */       {
/*  65: 80 */         int[] arrnext = this.next[i];
/*  66:    */         
/*  67: 82 */         FastSparseSetFactory.FastSparseSet<Integer>[] arrnew = new FastSparseSetFactory.FastSparseSet[length];
/*  68: 83 */         int[] arrnextnew = new int[length];
/*  69:    */         
/*  70: 85 */         System.arraycopy(arrnext, 0, arrnextnew, 0, length);
/*  71:    */         
/*  72: 87 */         mapelements[i] = arrnew;
/*  73: 88 */         mapnext[i] = arrnextnew;
/*  74:    */         
/*  75: 90 */         int pointer = 0;
/*  76:    */         do
/*  77:    */         {
/*  78: 92 */           FastSparseSetFactory.FastSparseSet<Integer> set = arr[pointer];
/*  79: 93 */           if (set != null) {
/*  80: 94 */             arrnew[pointer] = set.getCopy();
/*  81:    */           }
/*  82: 97 */           pointer = arrnext[pointer];
/*  83: 99 */         } while (pointer != 0);
/*  84:    */       }
/*  85:    */       else
/*  86:    */       {
/*  87:102 */         mapelements[i] = FastSparseSetFactory.FastSparseSet.EMPTY_ARRAY;
/*  88:103 */         mapnext[i] = InterpreterUtil.EMPTY_INT_ARRAY;
/*  89:    */       }
/*  90:    */     }
/*  91:107 */     return map;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public int size()
/*  95:    */   {
/*  96:111 */     return this.size;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean isEmpty()
/* 100:    */   {
/* 101:115 */     return this.size == 0;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void put(int key, FastSparseSetFactory.FastSparseSet<Integer> value)
/* 105:    */   {
/* 106:119 */     putInternal(key, value, false);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void remove(int key)
/* 110:    */   {
/* 111:123 */     putInternal(key, null, true);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void removeAllFields()
/* 115:    */   {
/* 116:127 */     FastSparseSetFactory.FastSparseSet<Integer>[] arr = this.elements[2];
/* 117:128 */     int[] arrnext = this.next[2];
/* 118:130 */     for (int i = arr.length - 1; i >= 0; i--)
/* 119:    */     {
/* 120:131 */       FastSparseSetFactory.FastSparseSet<Integer> val = arr[i];
/* 121:132 */       if (val != null)
/* 122:    */       {
/* 123:133 */         arr[i] = null;
/* 124:134 */         this.size -= 1;
/* 125:    */       }
/* 126:136 */       arrnext[i] = 0;
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void putInternal(int key, FastSparseSetFactory.FastSparseSet<Integer> value, boolean remove)
/* 131:    */   {
/* 132:142 */     int index = 0;
/* 133:143 */     int ikey = key;
/* 134:144 */     if (ikey < 0)
/* 135:    */     {
/* 136:145 */       index = 2;
/* 137:146 */       ikey = -ikey;
/* 138:    */     }
/* 139:148 */     else if (ikey >= 10000)
/* 140:    */     {
/* 141:149 */       index = 1;
/* 142:150 */       ikey -= 10000;
/* 143:    */     }
/* 144:153 */     FastSparseSetFactory.FastSparseSet<Integer>[] arr = this.elements[index];
/* 145:154 */     if (ikey >= arr.length)
/* 146:    */     {
/* 147:155 */       if (remove) {
/* 148:156 */         return;
/* 149:    */       }
/* 150:159 */       arr = ensureCapacity(index, ikey + 1, false);
/* 151:    */     }
/* 152:163 */     FastSparseSetFactory.FastSparseSet<Integer> oldval = arr[ikey];
/* 153:164 */     arr[ikey] = value;
/* 154:    */     
/* 155:166 */     int[] arrnext = this.next[index];
/* 156:168 */     if ((oldval == null) && (value != null))
/* 157:    */     {
/* 158:169 */       this.size += 1;
/* 159:170 */       changeNext(arrnext, ikey, arrnext[ikey], ikey);
/* 160:    */     }
/* 161:172 */     else if ((oldval != null) && (value == null))
/* 162:    */     {
/* 163:173 */       this.size -= 1;
/* 164:174 */       changeNext(arrnext, ikey, ikey, arrnext[ikey]);
/* 165:    */     }
/* 166:    */   }
/* 167:    */   
/* 168:    */   private static void changeNext(int[] arrnext, int key, int oldnext, int newnext)
/* 169:    */   {
/* 170:179 */     for (int i = key - 1; i >= 0; i--)
/* 171:    */     {
/* 172:180 */       if (arrnext[i] != oldnext) {
/* 173:    */         break;
/* 174:    */       }
/* 175:181 */       arrnext[i] = newnext;
/* 176:    */     }
/* 177:    */   }
/* 178:    */   
/* 179:    */   public boolean containsKey(int key)
/* 180:    */   {
/* 181:190 */     return get(key) != null;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public FastSparseSetFactory.FastSparseSet<Integer> get(int key)
/* 185:    */   {
/* 186:195 */     int index = 0;
/* 187:196 */     if (key < 0)
/* 188:    */     {
/* 189:197 */       index = 2;
/* 190:198 */       key = -key;
/* 191:    */     }
/* 192:200 */     else if (key >= 10000)
/* 193:    */     {
/* 194:201 */       index = 1;
/* 195:202 */       key -= 10000;
/* 196:    */     }
/* 197:205 */     FastSparseSetFactory.FastSparseSet<Integer>[] arr = this.elements[index];
/* 198:207 */     if (key < arr.length) {
/* 199:208 */       return arr[key];
/* 200:    */     }
/* 201:210 */     return null;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void complement(SFormsFastMapDirect map)
/* 205:    */   {
/* 206:215 */     for (int i = 2; i >= 0; i--)
/* 207:    */     {
/* 208:216 */       FastSparseSetFactory.FastSparseSet<Integer>[] lstOwn = this.elements[i];
/* 209:218 */       if (lstOwn.length != 0)
/* 210:    */       {
/* 211:222 */         FastSparseSetFactory.FastSparseSet<Integer>[] lstExtern = map.elements[i];
/* 212:223 */         int[] arrnext = this.next[i];
/* 213:    */         
/* 214:225 */         int pointer = 0;
/* 215:    */         do
/* 216:    */         {
/* 217:227 */           FastSparseSetFactory.FastSparseSet<Integer> first = lstOwn[pointer];
/* 218:229 */           if (first != null)
/* 219:    */           {
/* 220:230 */             if (pointer >= lstExtern.length) {
/* 221:    */               break;
/* 222:    */             }
/* 223:233 */             FastSparseSetFactory.FastSparseSet<Integer> second = lstExtern[pointer];
/* 224:235 */             if (second != null)
/* 225:    */             {
/* 226:236 */               first.complement(second);
/* 227:237 */               if (first.isEmpty())
/* 228:    */               {
/* 229:238 */                 lstOwn[pointer] = null;
/* 230:239 */                 this.size -= 1;
/* 231:240 */                 changeNext(arrnext, pointer, pointer, arrnext[pointer]);
/* 232:    */               }
/* 233:    */             }
/* 234:    */           }
/* 235:245 */           pointer = arrnext[pointer];
/* 236:247 */         } while (pointer != 0);
/* 237:    */       }
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void intersection(SFormsFastMapDirect map)
/* 242:    */   {
/* 243:253 */     for (int i = 2; i >= 0; i--)
/* 244:    */     {
/* 245:254 */       FastSparseSetFactory.FastSparseSet<Integer>[] lstOwn = this.elements[i];
/* 246:256 */       if (lstOwn.length != 0)
/* 247:    */       {
/* 248:260 */         FastSparseSetFactory.FastSparseSet<Integer>[] lstExtern = map.elements[i];
/* 249:261 */         int[] arrnext = this.next[i];
/* 250:    */         
/* 251:263 */         int pointer = 0;
/* 252:    */         do
/* 253:    */         {
/* 254:265 */           FastSparseSetFactory.FastSparseSet<Integer> first = lstOwn[pointer];
/* 255:267 */           if (first != null)
/* 256:    */           {
/* 257:268 */             FastSparseSetFactory.FastSparseSet<Integer> second = null;
/* 258:269 */             if (pointer < lstExtern.length) {
/* 259:270 */               second = lstExtern[pointer];
/* 260:    */             }
/* 261:273 */             if (second != null) {
/* 262:274 */               first.intersection(second);
/* 263:    */             }
/* 264:277 */             if ((second == null) || (first.isEmpty()))
/* 265:    */             {
/* 266:278 */               lstOwn[pointer] = null;
/* 267:279 */               this.size -= 1;
/* 268:280 */               changeNext(arrnext, pointer, pointer, arrnext[pointer]);
/* 269:    */             }
/* 270:    */           }
/* 271:284 */           pointer = arrnext[pointer];
/* 272:286 */         } while (pointer != 0);
/* 273:    */       }
/* 274:    */     }
/* 275:    */   }
/* 276:    */   
/* 277:    */   public void union(SFormsFastMapDirect map)
/* 278:    */   {
/* 279:292 */     for (int i = 2; i >= 0; i--)
/* 280:    */     {
/* 281:293 */       FastSparseSetFactory.FastSparseSet<Integer>[] lstExtern = map.elements[i];
/* 282:295 */       if (lstExtern.length != 0)
/* 283:    */       {
/* 284:299 */         FastSparseSetFactory.FastSparseSet<Integer>[] lstOwn = this.elements[i];
/* 285:300 */         int[] arrnext = this.next[i];
/* 286:301 */         int[] arrnextExtern = map.next[i];
/* 287:    */         
/* 288:303 */         int pointer = 0;
/* 289:    */         do
/* 290:    */         {
/* 291:305 */           if (pointer >= lstOwn.length)
/* 292:    */           {
/* 293:306 */             lstOwn = ensureCapacity(i, lstExtern.length, true);
/* 294:307 */             arrnext = this.next[i];
/* 295:    */           }
/* 296:310 */           FastSparseSetFactory.FastSparseSet<Integer> second = lstExtern[pointer];
/* 297:312 */           if (second != null)
/* 298:    */           {
/* 299:313 */             FastSparseSetFactory.FastSparseSet<Integer> first = lstOwn[pointer];
/* 300:315 */             if (first == null)
/* 301:    */             {
/* 302:316 */               lstOwn[pointer] = second.getCopy();
/* 303:317 */               this.size += 1;
/* 304:318 */               changeNext(arrnext, pointer, arrnext[pointer], pointer);
/* 305:    */             }
/* 306:    */             else
/* 307:    */             {
/* 308:321 */               first.union(second);
/* 309:    */             }
/* 310:    */           }
/* 311:325 */           pointer = arrnextExtern[pointer];
/* 312:327 */         } while (pointer != 0);
/* 313:    */       }
/* 314:    */     }
/* 315:    */   }
/* 316:    */   
/* 317:    */   public String toString()
/* 318:    */   {
/* 319:333 */     StringBuilder buffer = new StringBuilder("{");
/* 320:    */     
/* 321:335 */     List<Map.Entry<Integer, FastSparseSetFactory.FastSparseSet<Integer>>> lst = entryList();
/* 322:    */     boolean first;
/* 323:336 */     if (lst != null)
/* 324:    */     {
/* 325:337 */       first = true;
/* 326:338 */       for (Map.Entry<Integer, FastSparseSetFactory.FastSparseSet<Integer>> entry : lst)
/* 327:    */       {
/* 328:339 */         if (!first) {
/* 329:340 */           buffer.append(", ");
/* 330:    */         } else {
/* 331:343 */           first = false;
/* 332:    */         }
/* 333:346 */         Set<Integer> set = ((FastSparseSetFactory.FastSparseSet)entry.getValue()).toPlainSet();
/* 334:347 */         buffer.append(entry.getKey()).append("={").append(set.toString()).append("}");
/* 335:    */       }
/* 336:    */     }
/* 337:351 */     buffer.append("}");
/* 338:352 */     return buffer.toString();
/* 339:    */   }
/* 340:    */   
/* 341:    */   public List<Map.Entry<Integer, FastSparseSetFactory.FastSparseSet<Integer>>> entryList()
/* 342:    */   {
/* 343:356 */     List<Map.Entry<Integer, FastSparseSetFactory.FastSparseSet<Integer>>> list = new ArrayList();
/* 344:358 */     for (int i = 2; i >= 0; i--)
/* 345:    */     {
/* 346:359 */       int ikey = 0;
/* 347:360 */       for (final FastSparseSetFactory.FastSparseSet<Integer> ent : this.elements[i])
/* 348:    */       {
/* 349:361 */         if (ent != null)
/* 350:    */         {
/* 351:362 */           final int key = i == 1 ? ikey + 10000 : i == 0 ? ikey : -ikey;
/* 352:    */           
/* 353:364 */           list.add(new Map.Entry()
/* 354:    */           {
/* 355:366 */             private final Integer var = Integer.valueOf(key);
/* 356:367 */             private final FastSparseSetFactory.FastSparseSet<Integer> val = ent;
/* 357:    */             
/* 358:    */             public Integer getKey()
/* 359:    */             {
/* 360:370 */               return this.var;
/* 361:    */             }
/* 362:    */             
/* 363:    */             public FastSparseSetFactory.FastSparseSet<Integer> getValue()
/* 364:    */             {
/* 365:374 */               return this.val;
/* 366:    */             }
/* 367:    */             
/* 368:    */             public FastSparseSetFactory.FastSparseSet<Integer> setValue(FastSparseSetFactory.FastSparseSet<Integer> newvalue)
/* 369:    */             {
/* 370:378 */               return null;
/* 371:    */             }
/* 372:    */           });
/* 373:    */         }
/* 374:383 */         ikey++;
/* 375:    */       }
/* 376:    */     }
/* 377:387 */     return list;
/* 378:    */   }
/* 379:    */   
/* 380:    */   private FastSparseSetFactory.FastSparseSet<Integer>[] ensureCapacity(int index, int size, boolean exact)
/* 381:    */   {
/* 382:392 */     FastSparseSetFactory.FastSparseSet<Integer>[] arr = this.elements[index];
/* 383:393 */     int[] arrnext = this.next[index];
/* 384:    */     
/* 385:395 */     int minsize = size;
/* 386:396 */     if (!exact)
/* 387:    */     {
/* 388:397 */       minsize = 2 * arr.length / 3 + 1;
/* 389:398 */       if (size > minsize) {
/* 390:399 */         minsize = size;
/* 391:    */       }
/* 392:    */     }
/* 393:403 */     FastSparseSetFactory.FastSparseSet<Integer>[] arrnew = new FastSparseSetFactory.FastSparseSet[minsize];
/* 394:404 */     System.arraycopy(arr, 0, arrnew, 0, arr.length);
/* 395:    */     
/* 396:406 */     int[] arrnextnew = new int[minsize];
/* 397:407 */     System.arraycopy(arrnext, 0, arrnextnew, 0, arrnext.length);
/* 398:    */     
/* 399:409 */     this.elements[index] = arrnew;
/* 400:410 */     this.next[index] = arrnextnew;
/* 401:    */     
/* 402:412 */     return arrnew;
/* 403:    */   }
/* 404:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.util.SFormsFastMapDirect
 * JD-Core Version:    0.7.0.1
 */