/*   1:    */ package org.jetbrains.java.decompiler.util;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.Collections;
/*   6:    */ import java.util.HashMap;
/*   7:    */ 
/*   8:    */ public class VBStyleCollection<E, K>
/*   9:    */   extends ArrayList<E>
/*  10:    */ {
/*  11: 25 */   private HashMap<K, Integer> map = new HashMap();
/*  12: 27 */   private ArrayList<K> lstKeys = new ArrayList();
/*  13:    */   
/*  14:    */   public VBStyleCollection() {}
/*  15:    */   
/*  16:    */   public VBStyleCollection(int initialCapacity)
/*  17:    */   {
/*  18: 34 */     super(initialCapacity);
/*  19: 35 */     this.lstKeys = new ArrayList(initialCapacity);
/*  20: 36 */     this.map = new HashMap(initialCapacity);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public VBStyleCollection(Collection<E> c)
/*  24:    */   {
/*  25: 40 */     super(c);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public boolean add(E element)
/*  29:    */   {
/*  30: 44 */     this.lstKeys.add(null);
/*  31: 45 */     super.add(element);
/*  32: 46 */     return true;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public boolean remove(Object element)
/*  36:    */   {
/*  37: 50 */     throw new RuntimeException("not implemented!");
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean addAll(Collection<? extends E> c)
/*  41:    */   {
/*  42: 54 */     for (int i = c.size() - 1; i >= 0; i--) {
/*  43: 55 */       this.lstKeys.add(null);
/*  44:    */     }
/*  45: 57 */     return super.addAll(c);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void addAllWithKey(VBStyleCollection<E, K> c)
/*  49:    */   {
/*  50: 61 */     for (int i = 0; i < c.size(); i++) {
/*  51: 62 */       addWithKey(c.get(i), c.getKey(i));
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void addAllWithKey(Collection<E> elements, Collection<K> keys)
/*  56:    */   {
/*  57: 67 */     int index = super.size();
/*  58: 69 */     for (K key : keys) {
/*  59: 70 */       this.map.put(key, Integer.valueOf(index++));
/*  60:    */     }
/*  61: 73 */     super.addAll(elements);
/*  62: 74 */     this.lstKeys.addAll(keys);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void addWithKey(E element, K key)
/*  66:    */   {
/*  67: 78 */     this.map.put(key, Integer.valueOf(super.size()));
/*  68: 79 */     super.add(element);
/*  69: 80 */     this.lstKeys.add(key);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public E putWithKey(E element, K key)
/*  73:    */   {
/*  74: 85 */     Integer index = (Integer)this.map.get(key);
/*  75: 86 */     if (index == null) {
/*  76: 87 */       addWithKey(element, key);
/*  77:    */     } else {
/*  78: 90 */       return super.set(index.intValue(), element);
/*  79:    */     }
/*  80: 92 */     return null;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void add(int index, E element)
/*  84:    */   {
/*  85: 96 */     addToListIndex(index, 1);
/*  86: 97 */     this.lstKeys.add(index, null);
/*  87: 98 */     super.add(index, element);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void addWithKeyAndIndex(int index, E element, K key)
/*  91:    */   {
/*  92:102 */     addToListIndex(index, 1);
/*  93:103 */     this.map.put(key, new Integer(index));
/*  94:104 */     super.add(index, element);
/*  95:105 */     this.lstKeys.add(index, key);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void removeWithKey(K key)
/*  99:    */   {
/* 100:109 */     int index = ((Integer)this.map.get(key)).intValue();
/* 101:110 */     addToListIndex(index + 1, -1);
/* 102:111 */     super.remove(index);
/* 103:112 */     this.lstKeys.remove(index);
/* 104:113 */     this.map.remove(key);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public E remove(int index)
/* 108:    */   {
/* 109:117 */     addToListIndex(index + 1, -1);
/* 110:118 */     K obj = this.lstKeys.get(index);
/* 111:119 */     if (obj != null) {
/* 112:120 */       this.map.remove(obj);
/* 113:    */     }
/* 114:122 */     this.lstKeys.remove(index);
/* 115:123 */     return super.remove(index);
/* 116:    */   }
/* 117:    */   
/* 118:    */   public E getWithKey(K key)
/* 119:    */   {
/* 120:127 */     Integer index = (Integer)this.map.get(key);
/* 121:128 */     if (index == null) {
/* 122:129 */       return null;
/* 123:    */     }
/* 124:131 */     return super.get(index.intValue());
/* 125:    */   }
/* 126:    */   
/* 127:    */   public int getIndexByKey(K key)
/* 128:    */   {
/* 129:135 */     return ((Integer)this.map.get(key)).intValue();
/* 130:    */   }
/* 131:    */   
/* 132:    */   public E getLast()
/* 133:    */   {
/* 134:139 */     return super.get(super.size() - 1);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public boolean containsKey(K key)
/* 138:    */   {
/* 139:143 */     return this.map.containsKey(key);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void clear()
/* 143:    */   {
/* 144:147 */     this.map.clear();
/* 145:148 */     this.lstKeys.clear();
/* 146:149 */     super.clear();
/* 147:    */   }
/* 148:    */   
/* 149:    */   public VBStyleCollection<E, K> clone()
/* 150:    */   {
/* 151:153 */     VBStyleCollection<E, K> c = new VBStyleCollection();
/* 152:154 */     c.addAll(new ArrayList(this));
/* 153:155 */     c.setMap(new HashMap(this.map));
/* 154:156 */     c.setLstKeys(new ArrayList(this.lstKeys));
/* 155:157 */     return c;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void swap(int index1, int index2)
/* 159:    */   {
/* 160:162 */     Collections.swap(this, index1, index2);
/* 161:163 */     Collections.swap(this.lstKeys, index1, index2);
/* 162:    */     
/* 163:165 */     K key = this.lstKeys.get(index1);
/* 164:166 */     if (key != null) {
/* 165:167 */       this.map.put(key, new Integer(index1));
/* 166:    */     }
/* 167:170 */     key = this.lstKeys.get(index2);
/* 168:171 */     if (key != null) {
/* 169:172 */       this.map.put(key, new Integer(index2));
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   public HashMap<K, Integer> getMap()
/* 174:    */   {
/* 175:177 */     return this.map;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public void setMap(HashMap<K, Integer> map)
/* 179:    */   {
/* 180:181 */     this.map = map;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public K getKey(int index)
/* 184:    */   {
/* 185:185 */     return this.lstKeys.get(index);
/* 186:    */   }
/* 187:    */   
/* 188:    */   public ArrayList<K> getLstKeys()
/* 189:    */   {
/* 190:189 */     return this.lstKeys;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public void setLstKeys(ArrayList<K> lstKeys)
/* 194:    */   {
/* 195:193 */     this.lstKeys = lstKeys;
/* 196:    */   }
/* 197:    */   
/* 198:    */   private void addToListIndex(int index, int diff)
/* 199:    */   {
/* 200:197 */     for (int i = this.lstKeys.size() - 1; i >= index; i--)
/* 201:    */     {
/* 202:198 */       K obj = this.lstKeys.get(i);
/* 203:199 */       if (obj != null) {
/* 204:200 */         this.map.put(obj, new Integer(i + diff));
/* 205:    */       }
/* 206:    */     }
/* 207:    */   }
/* 208:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.util.VBStyleCollection
 * JD-Core Version:    0.7.0.1
 */