/*   1:    */ package org.jetbrains.java.decompiler.util;
/*   2:    */ 
/*   3:    */ import java.util.Collection;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.Set;
/*   7:    */ 
/*   8:    */ public class FastSetFactory<E>
/*   9:    */ {
/*  10: 25 */   private final VBStyleCollection<int[], E> colValuesInternal = new VBStyleCollection();
/*  11:    */   private int lastBlock;
/*  12:    */   private int lastMask;
/*  13:    */   
/*  14:    */   public FastSetFactory(Collection<E> set)
/*  15:    */   {
/*  16: 33 */     int block = -1;
/*  17: 34 */     int mask = -1;
/*  18: 35 */     int index = 0;
/*  19: 37 */     for (E element : set)
/*  20:    */     {
/*  21: 39 */       block = index / 32;
/*  22: 41 */       if (index % 32 == 0) {
/*  23: 42 */         mask = 1;
/*  24:    */       } else {
/*  25: 45 */         mask <<= 1;
/*  26:    */       }
/*  27: 48 */       this.colValuesInternal.putWithKey(new int[] { block, mask }, element);
/*  28:    */       
/*  29: 50 */       index++;
/*  30:    */     }
/*  31: 53 */     this.lastBlock = block;
/*  32: 54 */     this.lastMask = mask;
/*  33:    */   }
/*  34:    */   
/*  35:    */   private int[] addElement(E element)
/*  36:    */   {
/*  37: 59 */     if ((this.lastMask == -1) || (this.lastMask == -2147483648))
/*  38:    */     {
/*  39: 60 */       this.lastMask = 1;
/*  40: 61 */       this.lastBlock += 1;
/*  41:    */     }
/*  42:    */     else
/*  43:    */     {
/*  44: 64 */       this.lastMask <<= 1;
/*  45:    */     }
/*  46: 67 */     int[] pointer = { this.lastBlock, this.lastMask };
/*  47: 68 */     this.colValuesInternal.putWithKey(pointer, element);
/*  48:    */     
/*  49: 70 */     return pointer;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public FastSet<E> spawnEmptySet()
/*  53:    */   {
/*  54: 74 */     return new FastSet(this, null);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public int getLastBlock()
/*  58:    */   {
/*  59: 78 */     return this.lastBlock;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public int getLastMask()
/*  63:    */   {
/*  64: 82 */     return this.lastMask;
/*  65:    */   }
/*  66:    */   
/*  67:    */   private VBStyleCollection<int[], E> getInternalValuesCollection()
/*  68:    */   {
/*  69: 86 */     return this.colValuesInternal;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static class FastSet<E>
/*  73:    */     implements Iterable<E>
/*  74:    */   {
/*  75:    */     private final FastSetFactory<E> factory;
/*  76:    */     private final VBStyleCollection<int[], E> colValuesInternal;
/*  77:    */     private int[] data;
/*  78:    */     
/*  79:    */     private FastSet(FastSetFactory<E> factory)
/*  80:    */     {
/*  81: 99 */       this.factory = factory;
/*  82:100 */       this.colValuesInternal = factory.getInternalValuesCollection();
/*  83:101 */       this.data = new int[factory.getLastBlock() + 1];
/*  84:    */     }
/*  85:    */     
/*  86:    */     public FastSet<E> getCopy()
/*  87:    */     {
/*  88:106 */       FastSet<E> copy = new FastSet(this.factory);
/*  89:    */       
/*  90:108 */       int arrlength = this.data.length;
/*  91:109 */       int[] cpdata = new int[arrlength];
/*  92:    */       
/*  93:111 */       System.arraycopy(this.data, 0, cpdata, 0, arrlength);
/*  94:112 */       copy.setData(cpdata);
/*  95:    */       
/*  96:114 */       return copy;
/*  97:    */     }
/*  98:    */     
/*  99:    */     private int[] ensureCapacity(int index)
/* 100:    */     {
/* 101:119 */       int newlength = this.data.length;
/* 102:120 */       if (newlength == 0) {
/* 103:121 */         newlength = 1;
/* 104:    */       }
/* 105:124 */       while (newlength <= index) {
/* 106:125 */         newlength *= 2;
/* 107:    */       }
/* 108:128 */       int[] newdata = new int[newlength];
/* 109:129 */       System.arraycopy(this.data, 0, newdata, 0, this.data.length);
/* 110:    */       
/* 111:131 */       return this.data = newdata;
/* 112:    */     }
/* 113:    */     
/* 114:    */     public void add(E element)
/* 115:    */     {
/* 116:135 */       int[] index = (int[])this.colValuesInternal.getWithKey(element);
/* 117:137 */       if (index == null) {
/* 118:138 */         index = this.factory.addElement(element);
/* 119:    */       }
/* 120:141 */       if (index[0] >= this.data.length) {
/* 121:142 */         ensureCapacity(index[0]);
/* 122:    */       }
/* 123:145 */       this.data[index[0]] |= index[1];
/* 124:    */     }
/* 125:    */     
/* 126:    */     public void setAllElements()
/* 127:    */     {
/* 128:150 */       int lastblock = this.factory.getLastBlock();
/* 129:151 */       int lastmask = this.factory.getLastMask();
/* 130:153 */       if (lastblock >= this.data.length) {
/* 131:154 */         ensureCapacity(lastblock);
/* 132:    */       }
/* 133:157 */       for (int i = lastblock - 1; i >= 0; i--) {
/* 134:158 */         this.data[i] = -1;
/* 135:    */       }
/* 136:161 */       this.data[lastblock] = (lastmask | lastmask - 1);
/* 137:    */     }
/* 138:    */     
/* 139:    */     public void addAll(Set<E> set)
/* 140:    */     {
/* 141:165 */       for (E element : set) {
/* 142:166 */         add(element);
/* 143:    */       }
/* 144:    */     }
/* 145:    */     
/* 146:    */     public void remove(E element)
/* 147:    */     {
/* 148:171 */       int[] index = (int[])this.colValuesInternal.getWithKey(element);
/* 149:173 */       if (index == null) {
/* 150:174 */         index = this.factory.addElement(element);
/* 151:    */       }
/* 152:177 */       if (index[0] < this.data.length) {
/* 153:178 */         this.data[index[0]] &= (index[1] ^ 0xFFFFFFFF);
/* 154:    */       }
/* 155:    */     }
/* 156:    */     
/* 157:    */     public void removeAll(Set<E> set)
/* 158:    */     {
/* 159:183 */       for (E element : set) {
/* 160:184 */         remove(element);
/* 161:    */       }
/* 162:    */     }
/* 163:    */     
/* 164:    */     public boolean contains(E element)
/* 165:    */     {
/* 166:189 */       int[] index = (int[])this.colValuesInternal.getWithKey(element);
/* 167:191 */       if (index == null) {
/* 168:192 */         index = this.factory.addElement(element);
/* 169:    */       }
/* 170:195 */       return (index[0] < this.data.length) && ((this.data[index[0]] & index[1]) != 0);
/* 171:    */     }
/* 172:    */     
/* 173:    */     public boolean contains(FastSet<E> set)
/* 174:    */     {
/* 175:199 */       int[] extdata = set.getData();
/* 176:200 */       int[] intdata = this.data;
/* 177:    */       
/* 178:202 */       int minlength = Math.min(extdata.length, intdata.length);
/* 179:204 */       for (int i = minlength - 1; i >= 0; i--) {
/* 180:205 */         if ((extdata[i] & (intdata[i] ^ 0xFFFFFFFF)) != 0) {
/* 181:206 */           return false;
/* 182:    */         }
/* 183:    */       }
/* 184:210 */       for (int i = extdata.length - 1; i >= minlength; i--) {
/* 185:211 */         if (extdata[i] != 0) {
/* 186:212 */           return false;
/* 187:    */         }
/* 188:    */       }
/* 189:216 */       return true;
/* 190:    */     }
/* 191:    */     
/* 192:    */     public void union(FastSet<E> set)
/* 193:    */     {
/* 194:221 */       int[] extdata = set.getData();
/* 195:222 */       int[] intdata = this.data;
/* 196:    */       
/* 197:224 */       int minlength = Math.min(extdata.length, intdata.length);
/* 198:226 */       for (int i = minlength - 1; i >= 0; i--) {
/* 199:227 */         intdata[i] |= extdata[i];
/* 200:    */       }
/* 201:230 */       boolean expanded = false;
/* 202:231 */       for (int i = extdata.length - 1; i >= minlength; i--) {
/* 203:232 */         if (extdata[i] != 0)
/* 204:    */         {
/* 205:233 */           if (!expanded) {
/* 206:234 */             intdata = ensureCapacity(extdata.length - 1);
/* 207:    */           }
/* 208:236 */           intdata[i] = extdata[i];
/* 209:    */         }
/* 210:    */       }
/* 211:    */     }
/* 212:    */     
/* 213:    */     public void intersection(FastSet<E> set)
/* 214:    */     {
/* 215:242 */       int[] extdata = set.getData();
/* 216:243 */       int[] intdata = this.data;
/* 217:    */       
/* 218:245 */       int minlength = Math.min(extdata.length, intdata.length);
/* 219:247 */       for (int i = minlength - 1; i >= 0; i--) {
/* 220:248 */         intdata[i] &= extdata[i];
/* 221:    */       }
/* 222:251 */       for (int i = intdata.length - 1; i >= minlength; i--) {
/* 223:252 */         intdata[i] = 0;
/* 224:    */       }
/* 225:    */     }
/* 226:    */     
/* 227:    */     public void symdiff(FastSet<E> set)
/* 228:    */     {
/* 229:257 */       int[] extdata = set.getData();
/* 230:258 */       int[] intdata = this.data;
/* 231:    */       
/* 232:260 */       int minlength = Math.min(extdata.length, intdata.length);
/* 233:262 */       for (int i = minlength - 1; i >= 0; i--) {
/* 234:263 */         intdata[i] ^= extdata[i];
/* 235:    */       }
/* 236:266 */       boolean expanded = false;
/* 237:267 */       for (int i = extdata.length - 1; i >= minlength; i--) {
/* 238:268 */         if (extdata[i] != 0)
/* 239:    */         {
/* 240:269 */           if (!expanded) {
/* 241:270 */             intdata = ensureCapacity(extdata.length - 1);
/* 242:    */           }
/* 243:272 */           intdata[i] = extdata[i];
/* 244:    */         }
/* 245:    */       }
/* 246:    */     }
/* 247:    */     
/* 248:    */     public void complement(FastSet<E> set)
/* 249:    */     {
/* 250:278 */       int[] extdata = set.getData();
/* 251:279 */       int[] intdata = this.data;
/* 252:    */       
/* 253:281 */       int minlength = Math.min(extdata.length, intdata.length);
/* 254:283 */       for (int i = minlength - 1; i >= 0; i--) {
/* 255:284 */         intdata[i] &= (extdata[i] ^ 0xFFFFFFFF);
/* 256:    */       }
/* 257:    */     }
/* 258:    */     
/* 259:    */     public boolean equals(Object o)
/* 260:    */     {
/* 261:290 */       if (o == this) {
/* 262:290 */         return true;
/* 263:    */       }
/* 264:291 */       if ((o == null) || (!(o instanceof FastSet))) {
/* 265:291 */         return false;
/* 266:    */       }
/* 267:293 */       int[] longdata = ((FastSet)o).getData();
/* 268:294 */       int[] shortdata = this.data;
/* 269:296 */       if (this.data.length > longdata.length)
/* 270:    */       {
/* 271:297 */         shortdata = longdata;
/* 272:298 */         longdata = this.data;
/* 273:    */       }
/* 274:301 */       for (int i = shortdata.length - 1; i >= 0; i--) {
/* 275:302 */         if (shortdata[i] != longdata[i]) {
/* 276:303 */           return false;
/* 277:    */         }
/* 278:    */       }
/* 279:307 */       for (int i = longdata.length - 1; i >= shortdata.length; i--) {
/* 280:308 */         if (longdata[i] != 0) {
/* 281:309 */           return false;
/* 282:    */         }
/* 283:    */       }
/* 284:313 */       return true;
/* 285:    */     }
/* 286:    */     
/* 287:    */     public int getCardinality()
/* 288:    */     {
/* 289:318 */       boolean found = false;
/* 290:319 */       int[] intdata = this.data;
/* 291:321 */       for (int i = intdata.length - 1; i >= 0; i--)
/* 292:    */       {
/* 293:322 */         int block = intdata[i];
/* 294:323 */         if (block != 0)
/* 295:    */         {
/* 296:324 */           if (found) {
/* 297:325 */             return 2;
/* 298:    */           }
/* 299:328 */           if ((block & block - 1) == 0) {
/* 300:329 */             found = true;
/* 301:    */           } else {
/* 302:332 */             return 2;
/* 303:    */           }
/* 304:    */         }
/* 305:    */       }
/* 306:338 */       return found ? 1 : 0;
/* 307:    */     }
/* 308:    */     
/* 309:    */     public int size()
/* 310:    */     {
/* 311:343 */       int size = 0;
/* 312:344 */       int[] intdata = this.data;
/* 313:346 */       for (int i = intdata.length - 1; i >= 0; i--) {
/* 314:347 */         size += Integer.bitCount(intdata[i]);
/* 315:    */       }
/* 316:350 */       return size;
/* 317:    */     }
/* 318:    */     
/* 319:    */     public boolean isEmpty()
/* 320:    */     {
/* 321:354 */       int[] intdata = this.data;
/* 322:356 */       for (int i = intdata.length - 1; i >= 0; i--) {
/* 323:357 */         if (intdata[i] != 0) {
/* 324:358 */           return false;
/* 325:    */         }
/* 326:    */       }
/* 327:362 */       return true;
/* 328:    */     }
/* 329:    */     
/* 330:    */     public Iterator<E> iterator()
/* 331:    */     {
/* 332:366 */       return new FastSetFactory.FastSetIterator(this, null);
/* 333:    */     }
/* 334:    */     
/* 335:    */     public Set<E> toPlainSet()
/* 336:    */     {
/* 337:370 */       HashSet<E> set = new HashSet();
/* 338:    */       
/* 339:372 */       int[] intdata = this.data;
/* 340:    */       
/* 341:374 */       int size = this.data.length * 32;
/* 342:375 */       if (size > this.colValuesInternal.size()) {
/* 343:376 */         size = this.colValuesInternal.size();
/* 344:    */       }
/* 345:379 */       for (int i = size - 1; i >= 0; i--)
/* 346:    */       {
/* 347:380 */         int[] index = (int[])this.colValuesInternal.get(i);
/* 348:382 */         if ((intdata[index[0]] & index[1]) != 0) {
/* 349:383 */           set.add(this.colValuesInternal.getKey(i));
/* 350:    */         }
/* 351:    */       }
/* 352:387 */       return set;
/* 353:    */     }
/* 354:    */     
/* 355:    */     public String toBinary()
/* 356:    */     {
/* 357:392 */       StringBuilder buffer = new StringBuilder();
/* 358:393 */       int[] intdata = this.data;
/* 359:395 */       for (int i = 0; i < intdata.length; i++) {
/* 360:396 */         buffer.append(" ").append(Integer.toBinaryString(intdata[i]));
/* 361:    */       }
/* 362:399 */       return buffer.toString();
/* 363:    */     }
/* 364:    */     
/* 365:    */     private int[] getData()
/* 366:    */     {
/* 367:403 */       return this.data;
/* 368:    */     }
/* 369:    */     
/* 370:    */     private void setData(int[] data)
/* 371:    */     {
/* 372:407 */       this.data = data;
/* 373:    */     }
/* 374:    */     
/* 375:    */     public int[] getLoad()
/* 376:    */     {
/* 377:411 */       int[] intdata = this.data;
/* 378:412 */       int notempty = 0;
/* 379:414 */       for (int i = 0; i < intdata.length; i++) {
/* 380:415 */         if (intdata[i] != 0) {
/* 381:416 */           notempty++;
/* 382:    */         }
/* 383:    */       }
/* 384:420 */       return new int[] { intdata.length, notempty };
/* 385:    */     }
/* 386:    */     
/* 387:    */     public FastSetFactory<E> getFactory()
/* 388:    */     {
/* 389:424 */       return this.factory;
/* 390:    */     }
/* 391:    */   }
/* 392:    */   
/* 393:    */   public static class FastSetIterator<E>
/* 394:    */     implements Iterator<E>
/* 395:    */   {
/* 396:    */     private final VBStyleCollection<int[], E> colValuesInternal;
/* 397:    */     private final int[] data;
/* 398:    */     private int size;
/* 399:434 */     private int pointer = -1;
/* 400:435 */     private int next_pointer = -1;
/* 401:    */     
/* 402:    */     private FastSetIterator(FastSetFactory.FastSet<E> set)
/* 403:    */     {
/* 404:438 */       this.colValuesInternal = set.getFactory().getInternalValuesCollection();
/* 405:439 */       this.data = FastSetFactory.FastSet.access$400(set);
/* 406:    */       
/* 407:441 */       this.size = this.colValuesInternal.size();
/* 408:442 */       int datasize = this.data.length * 32;
/* 409:444 */       if (datasize < this.size) {
/* 410:445 */         this.size = datasize;
/* 411:    */       }
/* 412:    */     }
/* 413:    */     
/* 414:    */     public boolean hasNext()
/* 415:    */     {
/* 416:451 */       this.next_pointer = this.pointer;
/* 417:453 */       while (++this.next_pointer < this.size)
/* 418:    */       {
/* 419:454 */         int[] index = (int[])this.colValuesInternal.get(this.next_pointer);
/* 420:455 */         if ((this.data[index[0]] & index[1]) != 0) {
/* 421:456 */           return true;
/* 422:    */         }
/* 423:    */       }
/* 424:460 */       this.next_pointer = -1;
/* 425:461 */       return false;
/* 426:    */     }
/* 427:    */     
/* 428:    */     public E next()
/* 429:    */     {
/* 430:465 */       if (this.next_pointer >= 0) {
/* 431:466 */         this.pointer = this.next_pointer;
/* 432:    */       } else {
/* 433:469 */         while (++this.pointer < this.size)
/* 434:    */         {
/* 435:470 */           int[] index = (int[])this.colValuesInternal.get(this.pointer);
/* 436:471 */           if ((this.data[index[0]] & index[1]) != 0) {
/* 437:    */             break;
/* 438:    */           }
/* 439:    */         }
/* 440:    */       }
/* 441:477 */       this.next_pointer = -1;
/* 442:478 */       return this.pointer < this.size ? this.colValuesInternal.getKey(this.pointer) : null;
/* 443:    */     }
/* 444:    */     
/* 445:    */     public void remove()
/* 446:    */     {
/* 447:482 */       int[] index = (int[])this.colValuesInternal.get(this.pointer);
/* 448:483 */       this.data[index[0]] &= (index[1] ^ 0xFFFFFFFF);
/* 449:    */       
/* 450:485 */       this.pointer -= 1;
/* 451:    */     }
/* 452:    */   }
/* 453:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.util.FastSetFactory
 * JD-Core Version:    0.7.0.1
 */