/*  1:   */ package org.jetbrains.java.decompiler.main;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  5:   */ import org.jetbrains.java.decompiler.main.extern.IBytecodeProvider;
/*  6:   */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*  7:   */ import org.jetbrains.java.decompiler.main.extern.IResultSaver;
/*  8:   */ import org.jetbrains.java.decompiler.modules.renamer.IdentifierConverter;
/*  9:   */ import org.jetbrains.java.decompiler.struct.IDecompiledData;
/* 10:   */ import org.jetbrains.java.decompiler.struct.StructClass;
/* 11:   */ import org.jetbrains.java.decompiler.struct.StructContext;
/* 12:   */ import org.jetbrains.java.decompiler.struct.lazy.LazyLoader;
/* 13:   */ 
/* 14:   */ public class Fernflower
/* 15:   */   implements IDecompiledData
/* 16:   */ {
/* 17:   */   private final StructContext structContext;
/* 18:   */   private ClassesProcessor classesProcessor;
/* 19:   */   
/* 20:   */   public Fernflower(IBytecodeProvider provider, IResultSaver saver, Map<String, Object> options, IFernflowerLogger logger)
/* 21:   */   {
/* 22:38 */     this.structContext = new StructContext(saver, this, new LazyLoader(provider));
/* 23:39 */     DecompilerContext.initContext(options);
/* 24:40 */     DecompilerContext.setCounterContainer(new CounterContainer());
/* 25:41 */     DecompilerContext.setLogger(logger);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void decompileContext()
/* 29:   */   {
/* 30:45 */     if (DecompilerContext.getOption("ren")) {
/* 31:46 */       new IdentifierConverter().rename(this.structContext);
/* 32:   */     }
/* 33:49 */     this.classesProcessor = new ClassesProcessor(this.structContext);
/* 34:   */     
/* 35:51 */     DecompilerContext.setClassProcessor(this.classesProcessor);
/* 36:52 */     DecompilerContext.setStructContext(this.structContext);
/* 37:   */     
/* 38:54 */     this.structContext.saveContext();
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void clearContext()
/* 42:   */   {
/* 43:58 */     DecompilerContext.setCurrentContext(null);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public StructContext getStructContext()
/* 47:   */   {
/* 48:62 */     return this.structContext;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public String getClassEntryName(StructClass cl, String entryName)
/* 52:   */   {
/* 53:67 */     ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)this.classesProcessor.getMapRootClasses().get(cl.qualifiedName);
/* 54:68 */     if (node.type != 0) {
/* 55:69 */       return null;
/* 56:   */     }
/* 57:72 */     if (DecompilerContext.getOption("ren"))
/* 58:   */     {
/* 59:73 */       String simple_classname = cl.qualifiedName.substring(cl.qualifiedName.lastIndexOf('/') + 1);
/* 60:74 */       return entryName.substring(0, entryName.lastIndexOf('/') + 1) + simple_classname + ".java";
/* 61:   */     }
/* 62:77 */     return entryName.substring(0, entryName.lastIndexOf(".class")) + ".java";
/* 63:   */   }
/* 64:   */   
/* 65:   */   public String getClassContent(StructClass cl)
/* 66:   */   {
/* 67:   */     try
/* 68:   */     {
/* 69:85 */       TextBuffer buffer = new TextBuffer(16384);
/* 70:86 */       buffer.append(DecompilerContext.getProperty("ban").toString());
/* 71:87 */       this.classesProcessor.writeClass(cl, buffer);
/* 72:88 */       return buffer.toString();
/* 73:   */     }
/* 74:   */     catch (Throwable ex)
/* 75:   */     {
/* 76:91 */       DecompilerContext.getLogger().writeMessage("Class " + cl.qualifiedName + " couldn't be fully decompiled.", ex);
/* 77:   */     }
/* 78:92 */     return null;
/* 79:   */   }
/* 80:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.Fernflower
 * JD-Core Version:    0.7.0.1
 */