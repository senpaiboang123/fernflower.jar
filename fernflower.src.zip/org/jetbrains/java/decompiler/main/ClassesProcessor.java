/*   1:    */ package org.jetbrains.java.decompiler.main;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.LinkedList;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Map;
/*  11:    */ import java.util.Map.Entry;
/*  12:    */ import java.util.Set;
/*  13:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeSourceMapper;
/*  14:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  15:    */ import org.jetbrains.java.decompiler.main.collectors.ImportCollector;
/*  16:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*  17:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*  18:    */ import org.jetbrains.java.decompiler.main.extern.IIdentifierRenamer;
/*  19:    */ import org.jetbrains.java.decompiler.main.extern.IIdentifierRenamer.Type;
/*  20:    */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*  21:    */ import org.jetbrains.java.decompiler.main.rels.LambdaProcessor;
/*  22:    */ import org.jetbrains.java.decompiler.main.rels.NestedClassProcessor;
/*  23:    */ import org.jetbrains.java.decompiler.main.rels.NestedMemberAccess;
/*  24:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*  25:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  26:    */ import org.jetbrains.java.decompiler.modules.renamer.PoolInterceptor;
/*  27:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  28:    */ import org.jetbrains.java.decompiler.struct.StructContext;
/*  29:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  30:    */ import org.jetbrains.java.decompiler.struct.attr.StructInnerClassesAttribute;
/*  31:    */ import org.jetbrains.java.decompiler.struct.attr.StructInnerClassesAttribute.Entry;
/*  32:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  33:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  34:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  35:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  36:    */ 
/*  37:    */ public class ClassesProcessor
/*  38:    */ {
/*  39:    */   public static final int AVERAGE_CLASS_SIZE = 16384;
/*  40: 45 */   private final Map<String, ClassNode> mapRootClasses = new HashMap();
/*  41:    */   
/*  42:    */   private static class Inner
/*  43:    */   {
/*  44:    */     private String simpleName;
/*  45:    */     private int type;
/*  46:    */     private int accessFlags;
/*  47:    */     
/*  48:    */     private static boolean equal(Inner o1, Inner o2)
/*  49:    */     {
/*  50: 53 */       return (o1.type == o2.type) && (o1.accessFlags == o2.accessFlags) && (InterpreterUtil.equalObjects(o1.simpleName, o2.simpleName));
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   public ClassesProcessor(StructContext context)
/*  55:    */   {
/*  56: 58 */     Map<String, Inner> mapInnerClasses = new HashMap();
/*  57: 59 */     Map<String, Set<String>> mapNestedClassReferences = new HashMap();
/*  58: 60 */     Map<String, Set<String>> mapEnclosingClassReferences = new HashMap();
/*  59: 61 */     Map<String, String> mapNewSimpleNames = new HashMap();
/*  60:    */     
/*  61: 63 */     boolean bDecompileInner = DecompilerContext.getOption("din");
/*  62: 66 */     for (StructClass cl : context.getClasses().values()) {
/*  63: 67 */       if ((cl.isOwn()) && (!this.mapRootClasses.containsKey(cl.qualifiedName)))
/*  64:    */       {
/*  65: 68 */         if (bDecompileInner)
/*  66:    */         {
/*  67: 69 */           StructInnerClassesAttribute inner = (StructInnerClassesAttribute)cl.getAttributes().getWithKey("InnerClasses");
/*  68: 71 */           if (inner != null) {
/*  69: 72 */             for (StructInnerClassesAttribute.Entry entry : inner.getEntries())
/*  70:    */             {
/*  71: 73 */               String innerName = entry.innerName;
/*  72:    */               
/*  73:    */ 
/*  74: 76 */               String simpleName = entry.simpleName;
/*  75: 77 */               String savedName = (String)mapNewSimpleNames.get(innerName);
/*  76: 78 */               if (savedName != null)
/*  77:    */               {
/*  78: 79 */                 simpleName = savedName;
/*  79:    */               }
/*  80: 81 */               else if ((simpleName != null) && (DecompilerContext.getOption("ren")))
/*  81:    */               {
/*  82: 82 */                 IIdentifierRenamer renamer = DecompilerContext.getPoolInterceptor().getHelper();
/*  83: 83 */                 if (renamer.toBeRenamed(IIdentifierRenamer.Type.ELEMENT_CLASS, simpleName, null, null))
/*  84:    */                 {
/*  85: 84 */                   simpleName = renamer.getNextClassName(innerName, simpleName);
/*  86: 85 */                   mapNewSimpleNames.put(innerName, simpleName);
/*  87:    */                 }
/*  88:    */               }
/*  89: 89 */               Inner rec = new Inner(null);
/*  90: 90 */               rec.simpleName = simpleName;
/*  91: 91 */               rec.type = (entry.simpleNameIdx != 0 ? 4 : entry.outerNameIdx != 0 ? 1 : 2);
/*  92: 92 */               rec.accessFlags = entry.accessFlags;
/*  93:    */               String enclClassName;
/*  94:    */               String enclClassName;
/*  95: 96 */               if (entry.outerNameIdx != 0) {
/*  96: 97 */                 enclClassName = entry.enclosingName;
/*  97:    */               } else {
/*  98:100 */                 enclClassName = cl.qualifiedName;
/*  99:    */               }
/* 100:103 */               if (!innerName.equals(enclClassName))
/* 101:    */               {
/* 102:104 */                 StructClass enclosing_class = (StructClass)context.getClasses().get(enclClassName);
/* 103:105 */                 if ((enclosing_class != null) && (enclosing_class.isOwn()))
/* 104:    */                 {
/* 105:107 */                   Inner existingRec = (Inner)mapInnerClasses.get(innerName);
/* 106:108 */                   if (existingRec == null)
/* 107:    */                   {
/* 108:109 */                     mapInnerClasses.put(innerName, rec);
/* 109:    */                   }
/* 110:111 */                   else if (!Inner.equal(existingRec, rec))
/* 111:    */                   {
/* 112:112 */                     String message = "Inconsistent inner class entries for " + innerName + "!";
/* 113:113 */                     DecompilerContext.getLogger().writeMessage(message, IFernflowerLogger.Severity.WARN);
/* 114:    */                   }
/* 115:117 */                   Set<String> set = (Set)mapNestedClassReferences.get(enclClassName);
/* 116:118 */                   if (set == null) {
/* 117:119 */                     mapNestedClassReferences.put(enclClassName, set = new HashSet());
/* 118:    */                   }
/* 119:121 */                   set.add(innerName);
/* 120:    */                   
/* 121:    */ 
/* 122:124 */                   set = (Set)mapEnclosingClassReferences.get(innerName);
/* 123:125 */                   if (set == null) {
/* 124:126 */                     mapEnclosingClassReferences.put(innerName, set = new HashSet());
/* 125:    */                   }
/* 126:128 */                   set.add(enclClassName);
/* 127:    */                 }
/* 128:    */               }
/* 129:    */             }
/* 130:    */           }
/* 131:    */         }
/* 132:135 */         ClassNode node = new ClassNode(0, cl);
/* 133:136 */         node.access = cl.getAccessFlags();
/* 134:137 */         this.mapRootClasses.put(cl.qualifiedName, node);
/* 135:    */       }
/* 136:    */     }
/* 137:141 */     if (bDecompileInner) {
/* 138:143 */       for (Map.Entry<String, ClassNode> ent : this.mapRootClasses.entrySet()) {
/* 139:145 */         if (!mapInnerClasses.containsKey(ent.getKey()))
/* 140:    */         {
/* 141:146 */           Set<String> setVisited = new HashSet();
/* 142:147 */           LinkedList<String> stack = new LinkedList();
/* 143:    */           
/* 144:149 */           stack.add(ent.getKey());
/* 145:150 */           setVisited.add(ent.getKey());
/* 146:    */           ClassNode superNode;
/* 147:    */           Set<String> setNestedClasses;
/* 148:152 */           while (!stack.isEmpty())
/* 149:    */           {
/* 150:153 */             String superClass = (String)stack.removeFirst();
/* 151:154 */             superNode = (ClassNode)this.mapRootClasses.get(superClass);
/* 152:    */             
/* 153:156 */             setNestedClasses = (Set)mapNestedClassReferences.get(superClass);
/* 154:157 */             if (setNestedClasses != null)
/* 155:    */             {
/* 156:159 */               StructClass scl = superNode.classStruct;
/* 157:160 */               StructInnerClassesAttribute inner = (StructInnerClassesAttribute)scl.getAttributes().getWithKey("InnerClasses");
/* 158:162 */               if ((inner == null) || (inner.getEntries().isEmpty())) {
/* 159:163 */                 DecompilerContext.getLogger().writeMessage(superClass + " does not contain inner classes!", IFernflowerLogger.Severity.WARN);
/* 160:    */               } else {
/* 161:167 */                 for (StructInnerClassesAttribute.Entry entry : inner.getEntries())
/* 162:    */                 {
/* 163:168 */                   String nestedClass = entry.innerName;
/* 164:169 */                   if ((setNestedClasses.contains(nestedClass)) && 
/* 165:    */                   
/* 166:    */ 
/* 167:    */ 
/* 168:173 */                     (setVisited.add(nestedClass)))
/* 169:    */                   {
/* 170:177 */                     ClassNode nestedNode = (ClassNode)this.mapRootClasses.get(nestedClass);
/* 171:178 */                     if (nestedNode == null)
/* 172:    */                     {
/* 173:179 */                       DecompilerContext.getLogger().writeMessage("Nested class " + nestedClass + " missing!", IFernflowerLogger.Severity.WARN);
/* 174:    */                     }
/* 175:    */                     else
/* 176:    */                     {
/* 177:183 */                       Inner rec = (Inner)mapInnerClasses.get(nestedClass);
/* 178:    */                       
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:189 */                       nestedNode.simpleName = rec.simpleName;
/* 184:190 */                       nestedNode.type = rec.type;
/* 185:191 */                       nestedNode.access = rec.accessFlags;
/* 186:193 */                       if (nestedNode.type == 2)
/* 187:    */                       {
/* 188:194 */                         StructClass cl = nestedNode.classStruct;
/* 189:    */                         
/* 190:    */ 
/* 191:197 */                         nestedNode.access &= 0xFFFFFFF7;
/* 192:    */                         
/* 193:199 */                         int[] interfaces = cl.getInterfaces();
/* 194:201 */                         if (interfaces.length > 0)
/* 195:    */                         {
/* 196:202 */                           if (interfaces.length > 1)
/* 197:    */                           {
/* 198:203 */                             String message = "Inconsistent anonymous class definition: " + cl.qualifiedName;
/* 199:204 */                             DecompilerContext.getLogger().writeMessage(message, IFernflowerLogger.Severity.WARN);
/* 200:    */                           }
/* 201:206 */                           nestedNode.anonymousClassType = new VarType(cl.getInterface(0), true);
/* 202:    */                         }
/* 203:    */                         else
/* 204:    */                         {
/* 205:209 */                           nestedNode.anonymousClassType = new VarType(cl.superClass.getString(), true);
/* 206:    */                         }
/* 207:    */                       }
/* 208:212 */                       else if (nestedNode.type == 4)
/* 209:    */                       {
/* 210:214 */                         nestedNode.access &= 0x410;
/* 211:    */                       }
/* 212:217 */                       superNode.nested.add(nestedNode);
/* 213:218 */                       nestedNode.parent = superNode;
/* 214:    */                       
/* 215:220 */                       nestedNode.enclosingClasses.addAll((Collection)mapEnclosingClassReferences.get(nestedClass));
/* 216:    */                       
/* 217:222 */                       stack.add(nestedClass);
/* 218:    */                     }
/* 219:    */                   }
/* 220:    */                 }
/* 221:    */               }
/* 222:    */             }
/* 223:    */           }
/* 224:    */         }
/* 225:    */       }
/* 226:    */     }
/* 227:    */   }
/* 228:    */   
/* 229:    */   public void writeClass(StructClass cl, TextBuffer buffer)
/* 230:    */     throws IOException
/* 231:    */   {
/* 232:232 */     ClassNode root = (ClassNode)this.mapRootClasses.get(cl.qualifiedName);
/* 233:233 */     if (root.type != 0) {
/* 234:234 */       return;
/* 235:    */     }
/* 236:237 */     DecompilerContext.getLogger().startReadingClass(cl.qualifiedName);
/* 237:    */     try
/* 238:    */     {
/* 239:239 */       ImportCollector importCollector = new ImportCollector(root);
/* 240:240 */       DecompilerContext.setImportCollector(importCollector);
/* 241:241 */       DecompilerContext.setCounterContainer(new CounterContainer());
/* 242:242 */       DecompilerContext.setBytecodeSourceMapper(new BytecodeSourceMapper());
/* 243:    */       
/* 244:244 */       new LambdaProcessor().processClass(root);
/* 245:    */       
/* 246:    */ 
/* 247:247 */       addClassnameToImport(root, importCollector);
/* 248:    */       
/* 249:    */ 
/* 250:250 */       initWrappers(root);
/* 251:    */       
/* 252:252 */       new NestedClassProcessor().processClass(root, root);
/* 253:    */       
/* 254:254 */       new NestedMemberAccess().propagateMemberAccess(root);
/* 255:    */       
/* 256:256 */       TextBuffer classBuffer = new TextBuffer(16384);
/* 257:257 */       new ClassWriter().classToJava(root, classBuffer, 0, null);
/* 258:    */       
/* 259:259 */       int index = cl.qualifiedName.lastIndexOf("/");
/* 260:260 */       if (index >= 0)
/* 261:    */       {
/* 262:261 */         String packageName = cl.qualifiedName.substring(0, index).replace('/', '.');
/* 263:    */         
/* 264:263 */         buffer.append("package ");
/* 265:264 */         buffer.append(packageName);
/* 266:265 */         buffer.append(";");
/* 267:266 */         buffer.appendLineSeparator();
/* 268:267 */         buffer.appendLineSeparator();
/* 269:    */       }
/* 270:270 */       int import_lines_written = importCollector.writeImports(buffer);
/* 271:271 */       if (import_lines_written > 0) {
/* 272:272 */         buffer.appendLineSeparator();
/* 273:    */       }
/* 274:275 */       int offsetLines = buffer.countLines();
/* 275:    */       
/* 276:277 */       buffer.append(classBuffer);
/* 277:279 */       if (DecompilerContext.getOption("bsm"))
/* 278:    */       {
/* 279:280 */         BytecodeSourceMapper mapper = DecompilerContext.getBytecodeSourceMapper();
/* 280:281 */         mapper.addTotalOffset(offsetLines);
/* 281:282 */         if (DecompilerContext.getOption("__dump_original_lines__")) {
/* 282:283 */           buffer.dumpOriginalLineNumbers(mapper.getOriginalLinesMapping());
/* 283:    */         }
/* 284:285 */         if (DecompilerContext.getOption("__unit_test_mode__"))
/* 285:    */         {
/* 286:286 */           buffer.appendLineSeparator();
/* 287:287 */           mapper.dumpMapping(buffer, true);
/* 288:    */         }
/* 289:    */       }
/* 290:    */     }
/* 291:    */     finally
/* 292:    */     {
/* 293:292 */       destroyWrappers(root);
/* 294:293 */       DecompilerContext.getLogger().endReadingClass();
/* 295:    */     }
/* 296:    */   }
/* 297:    */   
/* 298:    */   private static void initWrappers(ClassNode node)
/* 299:    */     throws IOException
/* 300:    */   {
/* 301:298 */     if (node.type == 8) {
/* 302:299 */       return;
/* 303:    */     }
/* 304:302 */     ClassWrapper wrapper = new ClassWrapper(node.classStruct);
/* 305:303 */     wrapper.init();
/* 306:    */     
/* 307:305 */     node.wrapper = wrapper;
/* 308:307 */     for (ClassNode nd : node.nested) {
/* 309:308 */       initWrappers(nd);
/* 310:    */     }
/* 311:    */   }
/* 312:    */   
/* 313:    */   private static void addClassnameToImport(ClassNode node, ImportCollector imp)
/* 314:    */   {
/* 315:313 */     if ((node.simpleName != null) && (node.simpleName.length() > 0)) {
/* 316:314 */       imp.getShortName(node.type == 0 ? node.classStruct.qualifiedName : node.simpleName, false);
/* 317:    */     }
/* 318:317 */     for (ClassNode nd : node.nested) {
/* 319:318 */       addClassnameToImport(nd, imp);
/* 320:    */     }
/* 321:    */   }
/* 322:    */   
/* 323:    */   private static void destroyWrappers(ClassNode node)
/* 324:    */   {
/* 325:323 */     node.wrapper = null;
/* 326:324 */     node.classStruct.releaseResources();
/* 327:326 */     for (ClassNode nd : node.nested) {
/* 328:327 */       destroyWrappers(nd);
/* 329:    */     }
/* 330:    */   }
/* 331:    */   
/* 332:    */   public Map<String, ClassNode> getMapRootClasses()
/* 333:    */   {
/* 334:332 */     return this.mapRootClasses;
/* 335:    */   }
/* 336:    */   
/* 337:    */   public static class ClassNode
/* 338:    */   {
/* 339:    */     public static final int CLASS_ROOT = 0;
/* 340:    */     public static final int CLASS_MEMBER = 1;
/* 341:    */     public static final int CLASS_ANONYMOUS = 2;
/* 342:    */     public static final int CLASS_LOCAL = 4;
/* 343:    */     public static final int CLASS_LAMBDA = 8;
/* 344:    */     public int type;
/* 345:    */     public int access;
/* 346:    */     public String simpleName;
/* 347:    */     public final StructClass classStruct;
/* 348:    */     private ClassWrapper wrapper;
/* 349:    */     public String enclosingMethod;
/* 350:    */     public InvocationExprent superInvocation;
/* 351:350 */     public final Map<String, VarVersionPair> mapFieldsToVars = new HashMap();
/* 352:    */     public VarType anonymousClassType;
/* 353:352 */     public final List<ClassNode> nested = new ArrayList();
/* 354:353 */     public final Set<String> enclosingClasses = new HashSet();
/* 355:    */     public ClassNode parent;
/* 356:    */     public LambdaInformation lambdaInformation;
/* 357:356 */     public boolean namelessConstructorStub = false;
/* 358:    */     
/* 359:    */     public ClassNode(String content_class_name, String content_method_name, String content_method_descriptor, int content_method_invocation_type, String lambda_class_name, String lambda_method_name, String lambda_method_descriptor, StructClass classStruct)
/* 360:    */     {
/* 361:366 */       this.type = 8;
/* 362:367 */       this.classStruct = classStruct;
/* 363:    */       
/* 364:369 */       this.lambdaInformation = new LambdaInformation();
/* 365:    */       
/* 366:371 */       this.lambdaInformation.class_name = lambda_class_name;
/* 367:372 */       this.lambdaInformation.method_name = lambda_method_name;
/* 368:373 */       this.lambdaInformation.method_descriptor = lambda_method_descriptor;
/* 369:    */       
/* 370:375 */       this.lambdaInformation.content_class_name = content_class_name;
/* 371:376 */       this.lambdaInformation.content_method_name = content_method_name;
/* 372:377 */       this.lambdaInformation.content_method_descriptor = content_method_descriptor;
/* 373:378 */       this.lambdaInformation.content_method_invocation_type = content_method_invocation_type;
/* 374:    */       
/* 375:380 */       this.lambdaInformation.content_method_key = InterpreterUtil.makeUniqueKey(this.lambdaInformation.content_method_name, this.lambdaInformation.content_method_descriptor);
/* 376:    */       
/* 377:    */ 
/* 378:383 */       this.anonymousClassType = new VarType(lambda_class_name, true);
/* 379:    */       
/* 380:385 */       boolean is_method_reference = content_class_name != classStruct.qualifiedName;
/* 381:386 */       if (!is_method_reference)
/* 382:    */       {
/* 383:387 */         StructMethod mt = classStruct.getMethod(content_method_name, content_method_descriptor);
/* 384:388 */         is_method_reference = !mt.isSynthetic();
/* 385:    */       }
/* 386:391 */       this.lambdaInformation.is_method_reference = is_method_reference;
/* 387:392 */       this.lambdaInformation.is_content_method_static = (this.lambdaInformation.content_method_invocation_type == 6);
/* 388:    */     }
/* 389:    */     
/* 390:    */     public ClassNode(int type, StructClass classStruct)
/* 391:    */     {
/* 392:397 */       this.type = type;
/* 393:398 */       this.classStruct = classStruct;
/* 394:    */       
/* 395:400 */       this.simpleName = classStruct.qualifiedName.substring(classStruct.qualifiedName.lastIndexOf('/') + 1);
/* 396:    */     }
/* 397:    */     
/* 398:    */     public ClassNode getClassNode(String qualifiedName)
/* 399:    */     {
/* 400:404 */       for (ClassNode node : this.nested) {
/* 401:405 */         if (qualifiedName.equals(node.classStruct.qualifiedName)) {
/* 402:406 */           return node;
/* 403:    */         }
/* 404:    */       }
/* 405:409 */       return null;
/* 406:    */     }
/* 407:    */     
/* 408:    */     public ClassWrapper getWrapper()
/* 409:    */     {
/* 410:413 */       ClassNode node = this;
/* 411:414 */       while (node.type == 8) {
/* 412:415 */         node = node.parent;
/* 413:    */       }
/* 414:417 */       return node.wrapper;
/* 415:    */     }
/* 416:    */     
/* 417:    */     public static class LambdaInformation
/* 418:    */     {
/* 419:    */       public String class_name;
/* 420:    */       public String method_name;
/* 421:    */       public String method_descriptor;
/* 422:    */       public String content_class_name;
/* 423:    */       public String content_method_name;
/* 424:    */       public String content_method_descriptor;
/* 425:    */       public int content_method_invocation_type;
/* 426:    */       public String content_method_key;
/* 427:    */       public boolean is_method_reference;
/* 428:    */       public boolean is_content_method_static;
/* 429:    */     }
/* 430:    */   }
/* 431:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.ClassesProcessor
 * JD-Core Version:    0.7.0.1
 */