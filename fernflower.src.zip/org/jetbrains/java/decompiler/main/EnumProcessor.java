/*   1:    */ package org.jetbrains.java.decompiler.main;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*   7:    */ import org.jetbrains.java.decompiler.main.rels.MethodWrapper;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  14:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  15:    */ import org.jetbrains.java.decompiler.struct.StructField;
/*  16:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  17:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  18:    */ 
/*  19:    */ public class EnumProcessor
/*  20:    */ {
/*  21:    */   public static void clearEnum(ClassWrapper wrapper)
/*  22:    */   {
/*  23: 34 */     StructClass cl = wrapper.getClassStruct();
/*  24: 37 */     for (MethodWrapper method : wrapper.getMethods())
/*  25:    */     {
/*  26: 38 */       StructMethod mt = method.methodStruct;
/*  27: 39 */       String name = mt.getName();
/*  28: 40 */       String descriptor = mt.getDescriptor();
/*  29: 42 */       if ("values".equals(name))
/*  30:    */       {
/*  31: 43 */         if (descriptor.equals("()[L" + cl.qualifiedName + ";")) {
/*  32: 44 */           wrapper.getHiddenMembers().add(InterpreterUtil.makeUniqueKey(name, descriptor));
/*  33:    */         }
/*  34:    */       }
/*  35: 47 */       else if ("valueOf".equals(name))
/*  36:    */       {
/*  37: 48 */         if (descriptor.equals("(Ljava/lang/String;)L" + cl.qualifiedName + ";")) {
/*  38: 49 */           wrapper.getHiddenMembers().add(InterpreterUtil.makeUniqueKey(name, descriptor));
/*  39:    */         }
/*  40:    */       }
/*  41: 52 */       else if ("<init>".equals(name))
/*  42:    */       {
/*  43: 53 */         Statement firstData = findFirstData(method.root);
/*  44: 54 */         if ((firstData != null) && (!firstData.getExprents().isEmpty()))
/*  45:    */         {
/*  46: 55 */           Exprent exprent = (Exprent)firstData.getExprents().get(0);
/*  47: 56 */           if (exprent.type == 8)
/*  48:    */           {
/*  49: 57 */             InvocationExprent invexpr = (InvocationExprent)exprent;
/*  50: 58 */             if (isInvocationSuperConstructor(invexpr, method, wrapper)) {
/*  51: 59 */               firstData.getExprents().remove(0);
/*  52:    */             }
/*  53:    */           }
/*  54:    */         }
/*  55:    */       }
/*  56:    */     }
/*  57: 67 */     for (StructField fd : cl.getFields())
/*  58:    */     {
/*  59: 68 */       String descriptor = fd.getDescriptor();
/*  60: 69 */       if ((fd.isSynthetic()) && (descriptor.equals("[L" + cl.qualifiedName + ";"))) {
/*  61: 70 */         wrapper.getHiddenMembers().add(InterpreterUtil.makeUniqueKey(fd.getName(), descriptor));
/*  62:    */       }
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   private static Statement findFirstData(Statement stat)
/*  67:    */   {
/*  68: 78 */     if (stat.getExprents() != null) {
/*  69: 79 */       return stat;
/*  70:    */     }
/*  71: 82 */     if (stat.isLabeled()) {
/*  72: 83 */       return null;
/*  73:    */     }
/*  74: 86 */     switch (stat.type)
/*  75:    */     {
/*  76:    */     case 2: 
/*  77:    */     case 6: 
/*  78:    */     case 10: 
/*  79:    */     case 13: 
/*  80:    */     case 15: 
/*  81: 92 */       return findFirstData(stat.getFirst());
/*  82:    */     }
/*  83: 94 */     return null;
/*  84:    */   }
/*  85:    */   
/*  86:    */   private static boolean isInvocationSuperConstructor(InvocationExprent inv, MethodWrapper meth, ClassWrapper wrapper)
/*  87:    */   {
/*  88:102 */     if ((inv.getFunctype() == 2) && 
/*  89:103 */       (inv.getInstance().type == 12))
/*  90:    */     {
/*  91:104 */       VarExprent instvar = (VarExprent)inv.getInstance();
/*  92:105 */       VarVersionPair varpaar = new VarVersionPair(instvar);
/*  93:    */       
/*  94:107 */       String classname = (String)meth.varproc.getThisVars().get(varpaar);
/*  95:109 */       if ((classname != null) && 
/*  96:110 */         (!wrapper.getClassStruct().qualifiedName.equals(inv.getClassname()))) {
/*  97:111 */         return true;
/*  98:    */       }
/*  99:    */     }
/* 100:117 */     return false;
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.EnumProcessor
 * JD-Core Version:    0.7.0.1
 */