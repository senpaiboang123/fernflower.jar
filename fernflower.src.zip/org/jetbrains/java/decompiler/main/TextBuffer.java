/*   1:    */ package org.jetbrains.java.decompiler.main;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.Collections;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.LinkedList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import java.util.TreeSet;
/*  13:    */ 
/*  14:    */ public class TextBuffer
/*  15:    */ {
/*  16: 28 */   private final String myLineSeparator = DecompilerContext.getNewLineSeparator();
/*  17: 29 */   private final String myIndent = (String)DecompilerContext.getProperty("ind");
/*  18:    */   private final StringBuilder myStringBuilder;
/*  19: 31 */   private Map<Integer, Integer> myLineToOffsetMapping = null;
/*  20:    */   
/*  21:    */   public TextBuffer()
/*  22:    */   {
/*  23: 34 */     this.myStringBuilder = new StringBuilder();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public TextBuffer(int size)
/*  27:    */   {
/*  28: 38 */     this.myStringBuilder = new StringBuilder(size);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public TextBuffer(String text)
/*  32:    */   {
/*  33: 42 */     this.myStringBuilder = new StringBuilder(text);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public TextBuffer append(String str)
/*  37:    */   {
/*  38: 46 */     this.myStringBuilder.append(str);
/*  39: 47 */     return this;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public TextBuffer append(char ch)
/*  43:    */   {
/*  44: 51 */     this.myStringBuilder.append(ch);
/*  45: 52 */     return this;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public TextBuffer append(int i)
/*  49:    */   {
/*  50: 56 */     this.myStringBuilder.append(i);
/*  51: 57 */     return this;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public TextBuffer appendLineSeparator()
/*  55:    */   {
/*  56: 61 */     this.myStringBuilder.append(this.myLineSeparator);
/*  57: 62 */     return this;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public TextBuffer appendIndent(int length)
/*  61:    */   {
/*  62: 66 */     while (length-- > 0) {
/*  63: 67 */       append(this.myIndent);
/*  64:    */     }
/*  65: 69 */     return this;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public TextBuffer prepend(String s)
/*  69:    */   {
/*  70: 73 */     insert(0, s);
/*  71: 74 */     return this;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public TextBuffer enclose(String left, String right)
/*  75:    */   {
/*  76: 78 */     prepend(left);
/*  77: 79 */     append(right);
/*  78: 80 */     return this;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public boolean containsOnlyWhitespaces()
/*  82:    */   {
/*  83: 84 */     for (int i = 0; i < this.myStringBuilder.length(); i++) {
/*  84: 85 */       if (this.myStringBuilder.charAt(i) != ' ') {
/*  85: 86 */         return false;
/*  86:    */       }
/*  87:    */     }
/*  88: 89 */     return true;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public String toString()
/*  92:    */   {
/*  93: 94 */     String original = this.myStringBuilder.toString();
/*  94: 95 */     if ((this.myLineToOffsetMapping == null) || (this.myLineToOffsetMapping.isEmpty()))
/*  95:    */     {
/*  96: 96 */       if (this.myLineMapping != null) {
/*  97: 97 */         return addOriginalLineNumbers();
/*  98:    */       }
/*  99: 99 */       return original;
/* 100:    */     }
/* 101:102 */     StringBuilder res = new StringBuilder();
/* 102:103 */     String[] srcLines = original.split(this.myLineSeparator);
/* 103:104 */     int currentLineStartOffset = 0;
/* 104:105 */     int currentLine = 0;
/* 105:106 */     int previousMarkLine = 0;
/* 106:107 */     int dumpedLines = 0;
/* 107:108 */     ArrayList<Integer> linesWithMarks = new ArrayList(this.myLineToOffsetMapping.keySet());
/* 108:109 */     Collections.sort(linesWithMarks);
/* 109:110 */     for (Integer markLine : linesWithMarks)
/* 110:    */     {
/* 111:111 */       Integer markOffset = (Integer)this.myLineToOffsetMapping.get(markLine);
/* 112:112 */       while (currentLine < srcLines.length)
/* 113:    */       {
/* 114:113 */         String line = srcLines[currentLine];
/* 115:114 */         int lineEnd = currentLineStartOffset + line.length() + this.myLineSeparator.length();
/* 116:115 */         if (markOffset.intValue() <= lineEnd)
/* 117:    */         {
/* 118:116 */           int requiredLine = markLine.intValue() - 1;
/* 119:117 */           int linesToAdd = requiredLine - dumpedLines;
/* 120:118 */           dumpedLines = requiredLine;
/* 121:119 */           appendLines(res, srcLines, previousMarkLine, currentLine, linesToAdd);
/* 122:120 */           previousMarkLine = currentLine;
/* 123:121 */           break;
/* 124:    */         }
/* 125:123 */         currentLineStartOffset = lineEnd;
/* 126:124 */         currentLine++;
/* 127:    */       }
/* 128:    */     }
/* 129:127 */     if (previousMarkLine < srcLines.length) {
/* 130:128 */       appendLines(res, srcLines, previousMarkLine, srcLines.length, srcLines.length - previousMarkLine);
/* 131:    */     }
/* 132:131 */     return res.toString();
/* 133:    */   }
/* 134:    */   
/* 135:    */   private String addOriginalLineNumbers()
/* 136:    */   {
/* 137:136 */     StringBuilder sb = new StringBuilder();
/* 138:137 */     int lineStart = 0;
/* 139:138 */     int count = 0;int length = this.myLineSeparator.length();
/* 140:    */     int lineEnd;
/* 141:139 */     while ((lineEnd = this.myStringBuilder.indexOf(this.myLineSeparator, lineStart)) > 0)
/* 142:    */     {
/* 143:140 */       count++;
/* 144:141 */       sb.append(this.myStringBuilder.substring(lineStart, lineEnd));
/* 145:142 */       Set<Integer> integers = (Set)this.myLineMapping.get(Integer.valueOf(count));
/* 146:143 */       if (integers != null)
/* 147:    */       {
/* 148:144 */         sb.append("//");
/* 149:145 */         for (Integer integer : integers) {
/* 150:146 */           sb.append(' ').append(integer);
/* 151:    */         }
/* 152:    */       }
/* 153:149 */       sb.append(this.myLineSeparator);
/* 154:150 */       lineStart = lineEnd + length;
/* 155:    */     }
/* 156:152 */     if (lineStart < this.myStringBuilder.length()) {
/* 157:153 */       sb.append(this.myStringBuilder.substring(lineStart));
/* 158:    */     }
/* 159:155 */     return sb.toString();
/* 160:    */   }
/* 161:    */   
/* 162:    */   private void appendLines(StringBuilder res, String[] srcLines, int from, int to, int requiredLineNumber)
/* 163:    */   {
/* 164:159 */     if (to - from > requiredLineNumber)
/* 165:    */     {
/* 166:160 */       List<String> strings = compactLines(Arrays.asList(srcLines).subList(from, to), requiredLineNumber);
/* 167:161 */       int separatorsRequired = requiredLineNumber - 1;
/* 168:162 */       for (String s : strings)
/* 169:    */       {
/* 170:163 */         res.append(s);
/* 171:164 */         if (separatorsRequired-- > 0) {
/* 172:165 */           res.append(this.myLineSeparator);
/* 173:    */         }
/* 174:    */       }
/* 175:168 */       res.append(this.myLineSeparator);
/* 176:    */     }
/* 177:170 */     else if (to - from <= requiredLineNumber)
/* 178:    */     {
/* 179:171 */       for (int i = from; i < to; i++) {
/* 180:172 */         res.append(srcLines[i]).append(this.myLineSeparator);
/* 181:    */       }
/* 182:174 */       for (int i = 0; i < requiredLineNumber - to + from; i++) {
/* 183:175 */         res.append(this.myLineSeparator);
/* 184:    */       }
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   public int length()
/* 189:    */   {
/* 190:181 */     return this.myStringBuilder.length();
/* 191:    */   }
/* 192:    */   
/* 193:    */   public String substring(int start)
/* 194:    */   {
/* 195:185 */     return this.myStringBuilder.substring(start);
/* 196:    */   }
/* 197:    */   
/* 198:    */   public TextBuffer setStart(int position)
/* 199:    */   {
/* 200:189 */     this.myStringBuilder.delete(0, position);
/* 201:190 */     shiftMapping(0, -position);
/* 202:191 */     return this;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public void setLength(int position)
/* 206:    */   {
/* 207:195 */     this.myStringBuilder.setLength(position);
/* 208:196 */     if (this.myLineToOffsetMapping != null)
/* 209:    */     {
/* 210:197 */       HashMap<Integer, Integer> newMap = new HashMap();
/* 211:198 */       for (Map.Entry<Integer, Integer> entry : this.myLineToOffsetMapping.entrySet()) {
/* 212:199 */         if (((Integer)entry.getValue()).intValue() <= position) {
/* 213:200 */           newMap.put(entry.getKey(), entry.getValue());
/* 214:    */         }
/* 215:    */       }
/* 216:203 */       this.myLineToOffsetMapping = newMap;
/* 217:    */     }
/* 218:    */   }
/* 219:    */   
/* 220:    */   public TextBuffer append(TextBuffer buffer)
/* 221:    */   {
/* 222:208 */     if ((buffer.myLineToOffsetMapping != null) && (!buffer.myLineToOffsetMapping.isEmpty()))
/* 223:    */     {
/* 224:209 */       checkMapCreated();
/* 225:210 */       for (Map.Entry<Integer, Integer> entry : buffer.myLineToOffsetMapping.entrySet()) {
/* 226:211 */         this.myLineToOffsetMapping.put(entry.getKey(), Integer.valueOf(((Integer)entry.getValue()).intValue() + this.myStringBuilder.length()));
/* 227:    */       }
/* 228:    */     }
/* 229:214 */     this.myStringBuilder.append(buffer.myStringBuilder);
/* 230:215 */     return this;
/* 231:    */   }
/* 232:    */   
/* 233:    */   private void shiftMapping(int startOffset, int shiftOffset)
/* 234:    */   {
/* 235:219 */     if (this.myLineToOffsetMapping != null)
/* 236:    */     {
/* 237:220 */       HashMap<Integer, Integer> newMap = new HashMap();
/* 238:221 */       for (Map.Entry<Integer, Integer> entry : this.myLineToOffsetMapping.entrySet())
/* 239:    */       {
/* 240:222 */         int newValue = ((Integer)entry.getValue()).intValue();
/* 241:223 */         if (newValue >= startOffset) {
/* 242:224 */           newValue += shiftOffset;
/* 243:    */         }
/* 244:226 */         if (newValue >= 0) {
/* 245:227 */           newMap.put(entry.getKey(), Integer.valueOf(newValue));
/* 246:    */         }
/* 247:    */       }
/* 248:230 */       this.myLineToOffsetMapping = newMap;
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   private void checkMapCreated()
/* 253:    */   {
/* 254:235 */     if (this.myLineToOffsetMapping == null) {
/* 255:236 */       this.myLineToOffsetMapping = new HashMap();
/* 256:    */     }
/* 257:    */   }
/* 258:    */   
/* 259:    */   public TextBuffer insert(int offset, String s)
/* 260:    */   {
/* 261:241 */     this.myStringBuilder.insert(offset, s);
/* 262:242 */     shiftMapping(offset, s.length());
/* 263:243 */     return this;
/* 264:    */   }
/* 265:    */   
/* 266:    */   public int countLines()
/* 267:    */   {
/* 268:247 */     return countLines(0);
/* 269:    */   }
/* 270:    */   
/* 271:    */   public int countLines(int from)
/* 272:    */   {
/* 273:251 */     return count(this.myLineSeparator, from);
/* 274:    */   }
/* 275:    */   
/* 276:    */   public int count(String substring, int from)
/* 277:    */   {
/* 278:255 */     int count = 0;int length = substring.length();int p = from;
/* 279:256 */     while ((p = this.myStringBuilder.indexOf(substring, p)) > 0)
/* 280:    */     {
/* 281:257 */       count++;
/* 282:258 */       p += length;
/* 283:    */     }
/* 284:260 */     return count;
/* 285:    */   }
/* 286:    */   
/* 287:    */   private static List<String> compactLines(List<String> srcLines, int requiredLineNumber)
/* 288:    */   {
/* 289:264 */     if ((srcLines.size() < 2) || (srcLines.size() <= requiredLineNumber)) {
/* 290:265 */       return srcLines;
/* 291:    */     }
/* 292:267 */     List<String> res = new LinkedList(srcLines);
/* 293:269 */     for (int i = res.size() - 1; i > 0; i--)
/* 294:    */     {
/* 295:270 */       String s = (String)res.get(i);
/* 296:271 */       if ((s.trim().equals("{")) || (s.trim().equals("}")))
/* 297:    */       {
/* 298:272 */         res.set(i - 1, ((String)res.get(i - 1)).concat(s));
/* 299:273 */         res.remove(i);
/* 300:    */       }
/* 301:275 */       if (res.size() <= requiredLineNumber) {
/* 302:276 */         return res;
/* 303:    */       }
/* 304:    */     }
/* 305:280 */     for (int i = res.size() - 1; i > 0; i--)
/* 306:    */     {
/* 307:281 */       String s = (String)res.get(i);
/* 308:282 */       if (s.trim().isEmpty())
/* 309:    */       {
/* 310:283 */         res.set(i - 1, ((String)res.get(i - 1)).concat(s));
/* 311:284 */         res.remove(i);
/* 312:    */       }
/* 313:286 */       if (res.size() <= requiredLineNumber) {
/* 314:287 */         return res;
/* 315:    */       }
/* 316:    */     }
/* 317:290 */     return res;
/* 318:    */   }
/* 319:    */   
/* 320:293 */   private Map<Integer, Set<Integer>> myLineMapping = null;
/* 321:    */   
/* 322:    */   public void dumpOriginalLineNumbers(int[] lineMapping)
/* 323:    */   {
/* 324:296 */     if (lineMapping.length > 0)
/* 325:    */     {
/* 326:297 */       this.myLineMapping = new HashMap();
/* 327:298 */       for (int i = 0; i < lineMapping.length; i += 2)
/* 328:    */       {
/* 329:299 */         int key = lineMapping[(i + 1)];
/* 330:300 */         Set<Integer> existing = (Set)this.myLineMapping.get(Integer.valueOf(key));
/* 331:301 */         if (existing == null)
/* 332:    */         {
/* 333:302 */           existing = new TreeSet();
/* 334:303 */           this.myLineMapping.put(Integer.valueOf(key), existing);
/* 335:    */         }
/* 336:305 */         existing.add(Integer.valueOf(lineMapping[i]));
/* 337:    */       }
/* 338:    */     }
/* 339:    */   }
/* 340:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.TextBuffer
 * JD-Core Version:    0.7.0.1
 */