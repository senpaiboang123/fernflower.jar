/*   1:    */ package org.jetbrains.java.decompiler.main.decompiler;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileOutputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.OutputStreamWriter;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.io.Writer;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.HashSet;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.Set;
/*  16:    */ import java.util.jar.JarOutputStream;
/*  17:    */ import java.util.jar.Manifest;
/*  18:    */ import java.util.zip.ZipEntry;
/*  19:    */ import java.util.zip.ZipFile;
/*  20:    */ import java.util.zip.ZipOutputStream;
/*  21:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  22:    */ import org.jetbrains.java.decompiler.main.Fernflower;
/*  23:    */ import org.jetbrains.java.decompiler.main.extern.IBytecodeProvider;
/*  24:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*  25:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*  26:    */ import org.jetbrains.java.decompiler.main.extern.IResultSaver;
/*  27:    */ import org.jetbrains.java.decompiler.struct.StructContext;
/*  28:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  29:    */ 
/*  30:    */ public class ConsoleDecompiler
/*  31:    */   implements IBytecodeProvider, IResultSaver
/*  32:    */ {
/*  33:    */   private final File root;
/*  34:    */   private final Fernflower fernflower;
/*  35:    */   
/*  36:    */   public static void main(String[] args)
/*  37:    */   {
/*  38: 37 */     if (args.length < 2)
/*  39:    */     {
/*  40: 38 */       System.out.println("Usage: java -jar fernflower.jar [-<option>=<value>]* [<source>]+ <destination>\nExample: java -jar fernflower.jar -dgs=true c:\\my\\source\\ c:\\my.jar d:\\decompiled\\");
/*  41:    */       
/*  42:    */ 
/*  43: 41 */       return;
/*  44:    */     }
/*  45: 44 */     Map<String, Object> mapOptions = new HashMap();
/*  46: 45 */     List<File> lstSources = new ArrayList();
/*  47: 46 */     List<File> lstLibraries = new ArrayList();
/*  48:    */     
/*  49: 48 */     boolean isOption = true;
/*  50: 49 */     for (int i = 0; i < args.length - 1; i++)
/*  51:    */     {
/*  52: 50 */       String arg = args[i];
/*  53: 52 */       if ((isOption) && (arg.length() > 5) && (arg.charAt(0) == '-') && (arg.charAt(4) == '='))
/*  54:    */       {
/*  55: 53 */         String value = arg.substring(5);
/*  56: 54 */         if ("true".equalsIgnoreCase(value)) {
/*  57: 55 */           value = "1";
/*  58: 57 */         } else if ("false".equalsIgnoreCase(value)) {
/*  59: 58 */           value = "0";
/*  60:    */         }
/*  61: 61 */         mapOptions.put(arg.substring(1, 4), value);
/*  62:    */       }
/*  63:    */       else
/*  64:    */       {
/*  65: 64 */         isOption = false;
/*  66: 66 */         if (arg.startsWith("-e=")) {
/*  67: 67 */           addPath(lstLibraries, arg.substring(3));
/*  68:    */         } else {
/*  69: 70 */           addPath(lstSources, arg);
/*  70:    */         }
/*  71:    */       }
/*  72:    */     }
/*  73: 75 */     if (lstSources.isEmpty())
/*  74:    */     {
/*  75: 76 */       System.out.println("error: no sources given");
/*  76: 77 */       return;
/*  77:    */     }
/*  78: 80 */     File destination = new File(args[(args.length - 1)]);
/*  79: 81 */     if (!destination.isDirectory())
/*  80:    */     {
/*  81: 82 */       System.out.println("error: destination '" + destination + "' is not a directory");
/*  82: 83 */       return;
/*  83:    */     }
/*  84: 86 */     PrintStreamLogger logger = new PrintStreamLogger(System.out);
/*  85: 87 */     ConsoleDecompiler decompiler = new ConsoleDecompiler(destination, mapOptions, logger);
/*  86: 89 */     for (File source : lstSources) {
/*  87: 90 */       decompiler.addSpace(source, true);
/*  88:    */     }
/*  89: 92 */     for (File library : lstLibraries) {
/*  90: 93 */       decompiler.addSpace(library, false);
/*  91:    */     }
/*  92: 96 */     decompiler.decompileContext();
/*  93:    */   }
/*  94:    */   
/*  95:    */   private static void addPath(List<File> list, String path)
/*  96:    */   {
/*  97:101 */     File file = new File(path);
/*  98:102 */     if (file.exists()) {
/*  99:103 */       list.add(file);
/* 100:    */     } else {
/* 101:106 */       System.out.println("warn: missing '" + path + "', ignored");
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:116 */   private final Map<String, ZipOutputStream> mapArchiveStreams = new HashMap();
/* 106:117 */   private final Map<String, Set<String>> mapArchiveEntries = new HashMap();
/* 107:    */   
/* 108:    */   public ConsoleDecompiler(File destination, Map<String, Object> options)
/* 109:    */   {
/* 110:121 */     this(destination, options, new PrintStreamLogger(System.out));
/* 111:    */   }
/* 112:    */   
/* 113:    */   public ConsoleDecompiler(File destination, Map<String, Object> options, IFernflowerLogger logger)
/* 114:    */   {
/* 115:125 */     this.root = destination;
/* 116:126 */     this.fernflower = new Fernflower(this, this, options, logger);
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void addSpace(File file, boolean isOwn)
/* 120:    */   {
/* 121:130 */     this.fernflower.getStructContext().addSpace(file, isOwn);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void decompileContext()
/* 125:    */   {
/* 126:    */     try
/* 127:    */     {
/* 128:135 */       this.fernflower.decompileContext();
/* 129:    */     }
/* 130:    */     finally
/* 131:    */     {
/* 132:138 */       this.fernflower.clearContext();
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   public byte[] getBytecode(String externalPath, String internalPath)
/* 137:    */     throws IOException
/* 138:    */   {
/* 139:148 */     File file = new File(externalPath);
/* 140:149 */     if (internalPath == null) {
/* 141:150 */       return InterpreterUtil.getBytes(file);
/* 142:    */     }
/* 143:153 */     ZipFile archive = new ZipFile(file);
/* 144:    */     try
/* 145:    */     {
/* 146:155 */       ZipEntry entry = archive.getEntry(internalPath);
/* 147:156 */       if (entry == null) {
/* 148:157 */         throw new IOException("Entry not found: " + internalPath);
/* 149:    */       }
/* 150:159 */       return InterpreterUtil.getBytes(archive, entry);
/* 151:    */     }
/* 152:    */     finally
/* 153:    */     {
/* 154:162 */       archive.close();
/* 155:    */     }
/* 156:    */   }
/* 157:    */   
/* 158:    */   private String getAbsolutePath(String path)
/* 159:    */   {
/* 160:172 */     return new File(this.root, path).getAbsolutePath();
/* 161:    */   }
/* 162:    */   
/* 163:    */   public void saveFolder(String path)
/* 164:    */   {
/* 165:177 */     File dir = new File(getAbsolutePath(path));
/* 166:178 */     if ((!dir.mkdirs()) && (!dir.isDirectory())) {
/* 167:179 */       throw new RuntimeException("Cannot create directory " + dir);
/* 168:    */     }
/* 169:    */   }
/* 170:    */   
/* 171:    */   public void copyFile(String source, String path, String entryName)
/* 172:    */   {
/* 173:    */     try
/* 174:    */     {
/* 175:186 */       InterpreterUtil.copyFile(new File(source), new File(getAbsolutePath(path), entryName));
/* 176:    */     }
/* 177:    */     catch (IOException ex)
/* 178:    */     {
/* 179:189 */       DecompilerContext.getLogger().writeMessage("Cannot copy " + source + " to " + entryName, ex);
/* 180:    */     }
/* 181:    */   }
/* 182:    */   
/* 183:    */   public void saveClassFile(String path, String qualifiedName, String entryName, String content, int[] mapping)
/* 184:    */   {
/* 185:195 */     File file = new File(getAbsolutePath(path), entryName);
/* 186:    */     try
/* 187:    */     {
/* 188:197 */       Writer out = new OutputStreamWriter(new FileOutputStream(file), "UTF8");
/* 189:    */       try
/* 190:    */       {
/* 191:199 */         out.write(content);
/* 192:    */       }
/* 193:    */       finally
/* 194:    */       {
/* 195:202 */         out.close();
/* 196:    */       }
/* 197:    */     }
/* 198:    */     catch (IOException ex)
/* 199:    */     {
/* 200:206 */       DecompilerContext.getLogger().writeMessage("Cannot write class file " + file, ex);
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void createArchive(String path, String archiveName, Manifest manifest)
/* 205:    */   {
/* 206:212 */     File file = new File(getAbsolutePath(path), archiveName);
/* 207:    */     try
/* 208:    */     {
/* 209:214 */       if ((!file.createNewFile()) && (!file.isFile())) {
/* 210:215 */         throw new IOException("Cannot create file " + file);
/* 211:    */       }
/* 212:218 */       FileOutputStream fileStream = new FileOutputStream(file);
/* 213:    */       
/* 214:220 */       ZipOutputStream zipStream = manifest != null ? new JarOutputStream(fileStream, manifest) : new ZipOutputStream(fileStream);
/* 215:221 */       this.mapArchiveStreams.put(file.getPath(), zipStream);
/* 216:    */     }
/* 217:    */     catch (IOException ex)
/* 218:    */     {
/* 219:224 */       DecompilerContext.getLogger().writeMessage("Cannot create archive " + file, ex);
/* 220:    */     }
/* 221:    */   }
/* 222:    */   
/* 223:    */   public void saveDirEntry(String path, String archiveName, String entryName)
/* 224:    */   {
/* 225:230 */     saveClassEntry(path, archiveName, null, entryName, null);
/* 226:    */   }
/* 227:    */   
/* 228:    */   public void copyEntry(String source, String path, String archiveName, String entryName)
/* 229:    */   {
/* 230:235 */     String file = new File(getAbsolutePath(path), archiveName).getPath();
/* 231:237 */     if (!checkEntry(entryName, file)) {
/* 232:238 */       return;
/* 233:    */     }
/* 234:    */     try
/* 235:    */     {
/* 236:242 */       ZipFile srcArchive = new ZipFile(new File(source));
/* 237:    */       try
/* 238:    */       {
/* 239:244 */         ZipEntry entry = srcArchive.getEntry(entryName);
/* 240:245 */         if (entry != null)
/* 241:    */         {
/* 242:246 */           InputStream in = srcArchive.getInputStream(entry);
/* 243:247 */           ZipOutputStream out = (ZipOutputStream)this.mapArchiveStreams.get(file);
/* 244:248 */           out.putNextEntry(new ZipEntry(entryName));
/* 245:249 */           InterpreterUtil.copyStream(in, out);
/* 246:250 */           in.close();
/* 247:    */         }
/* 248:    */       }
/* 249:    */       finally
/* 250:    */       {
/* 251:254 */         srcArchive.close();
/* 252:    */       }
/* 253:    */     }
/* 254:    */     catch (IOException ex)
/* 255:    */     {
/* 256:258 */       String message = "Cannot copy entry " + entryName + " from " + source + " to " + file;
/* 257:259 */       DecompilerContext.getLogger().writeMessage(message, ex);
/* 258:    */     }
/* 259:    */   }
/* 260:    */   
/* 261:    */   public void saveClassEntry(String path, String archiveName, String qualifiedName, String entryName, String content)
/* 262:    */   {
/* 263:265 */     String file = new File(getAbsolutePath(path), archiveName).getPath();
/* 264:267 */     if (!checkEntry(entryName, file)) {
/* 265:268 */       return;
/* 266:    */     }
/* 267:    */     try
/* 268:    */     {
/* 269:272 */       ZipOutputStream out = (ZipOutputStream)this.mapArchiveStreams.get(file);
/* 270:273 */       out.putNextEntry(new ZipEntry(entryName));
/* 271:274 */       if (content != null) {
/* 272:275 */         out.write(content.getBytes("UTF-8"));
/* 273:    */       }
/* 274:    */     }
/* 275:    */     catch (IOException ex)
/* 276:    */     {
/* 277:279 */       String message = "Cannot write entry " + entryName + " to " + file;
/* 278:280 */       DecompilerContext.getLogger().writeMessage(message, ex);
/* 279:    */     }
/* 280:    */   }
/* 281:    */   
/* 282:    */   private boolean checkEntry(String entryName, String file)
/* 283:    */   {
/* 284:285 */     Set<String> set = (Set)this.mapArchiveEntries.get(file);
/* 285:286 */     if (set == null) {
/* 286:287 */       this.mapArchiveEntries.put(file, set = new HashSet());
/* 287:    */     }
/* 288:290 */     boolean added = set.add(entryName);
/* 289:291 */     if (!added)
/* 290:    */     {
/* 291:292 */       String message = "Zip entry " + entryName + " already exists in " + file;
/* 292:293 */       DecompilerContext.getLogger().writeMessage(message, IFernflowerLogger.Severity.WARN);
/* 293:    */     }
/* 294:295 */     return added;
/* 295:    */   }
/* 296:    */   
/* 297:    */   public void closeArchive(String path, String archiveName)
/* 298:    */   {
/* 299:300 */     String file = new File(getAbsolutePath(path), archiveName).getPath();
/* 300:    */     try
/* 301:    */     {
/* 302:302 */       this.mapArchiveEntries.remove(file);
/* 303:303 */       ((ZipOutputStream)this.mapArchiveStreams.remove(file)).close();
/* 304:    */     }
/* 305:    */     catch (IOException ex)
/* 306:    */     {
/* 307:306 */       DecompilerContext.getLogger().writeMessage("Cannot close " + file, IFernflowerLogger.Severity.WARN);
/* 308:    */     }
/* 309:    */   }
/* 310:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.decompiler.ConsoleDecompiler
 * JD-Core Version:    0.7.0.1
 */