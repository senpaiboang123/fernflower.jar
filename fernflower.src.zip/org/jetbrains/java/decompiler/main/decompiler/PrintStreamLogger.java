/*   1:    */ package org.jetbrains.java.decompiler.main.decompiler;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*   5:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*   6:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*   7:    */ 
/*   8:    */ public class PrintStreamLogger
/*   9:    */   extends IFernflowerLogger
/*  10:    */ {
/*  11:    */   private final PrintStream stream;
/*  12:    */   private int indent;
/*  13:    */   
/*  14:    */   public PrintStreamLogger(PrintStream printStream)
/*  15:    */   {
/*  16: 29 */     this.stream = printStream;
/*  17: 30 */     this.indent = 0;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public void writeMessage(String message, IFernflowerLogger.Severity severity)
/*  21:    */   {
/*  22: 35 */     if (accepts(severity)) {
/*  23: 36 */       this.stream.println(severity.prefix + InterpreterUtil.getIndentString(this.indent) + message);
/*  24:    */     }
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void writeMessage(String message, Throwable t)
/*  28:    */   {
/*  29: 42 */     if (accepts(IFernflowerLogger.Severity.ERROR))
/*  30:    */     {
/*  31: 43 */       writeMessage(message, IFernflowerLogger.Severity.ERROR);
/*  32: 44 */       t.printStackTrace(this.stream);
/*  33:    */     }
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void startReadingClass(String className)
/*  37:    */   {
/*  38: 50 */     if (accepts(IFernflowerLogger.Severity.INFO))
/*  39:    */     {
/*  40: 51 */       writeMessage("Decompiling class " + className, IFernflowerLogger.Severity.INFO);
/*  41: 52 */       this.indent += 1;
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void endReadingClass()
/*  46:    */   {
/*  47: 58 */     if (accepts(IFernflowerLogger.Severity.INFO))
/*  48:    */     {
/*  49: 59 */       this.indent -= 1;
/*  50: 60 */       writeMessage("... done", IFernflowerLogger.Severity.INFO);
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void startClass(String className)
/*  55:    */   {
/*  56: 66 */     if (accepts(IFernflowerLogger.Severity.INFO))
/*  57:    */     {
/*  58: 67 */       writeMessage("Processing class " + className, IFernflowerLogger.Severity.TRACE);
/*  59: 68 */       this.indent += 1;
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void endClass()
/*  64:    */   {
/*  65: 74 */     if (accepts(IFernflowerLogger.Severity.INFO))
/*  66:    */     {
/*  67: 75 */       this.indent -= 1;
/*  68: 76 */       writeMessage("... proceeded", IFernflowerLogger.Severity.TRACE);
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void startMethod(String methodName)
/*  73:    */   {
/*  74: 82 */     if (accepts(IFernflowerLogger.Severity.INFO))
/*  75:    */     {
/*  76: 83 */       writeMessage("Processing method " + methodName, IFernflowerLogger.Severity.TRACE);
/*  77: 84 */       this.indent += 1;
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void endMethod()
/*  82:    */   {
/*  83: 89 */     if (accepts(IFernflowerLogger.Severity.INFO))
/*  84:    */     {
/*  85: 90 */       this.indent -= 1;
/*  86: 91 */       writeMessage("... proceeded", IFernflowerLogger.Severity.TRACE);
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void startWriteClass(String className)
/*  91:    */   {
/*  92: 97 */     if (accepts(IFernflowerLogger.Severity.INFO))
/*  93:    */     {
/*  94: 98 */       writeMessage("Writing class " + className, IFernflowerLogger.Severity.TRACE);
/*  95: 99 */       this.indent += 1;
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void endWriteClass()
/* 100:    */   {
/* 101:105 */     if (accepts(IFernflowerLogger.Severity.INFO))
/* 102:    */     {
/* 103:106 */       this.indent -= 1;
/* 104:107 */       writeMessage("... written", IFernflowerLogger.Severity.TRACE);
/* 105:    */     }
/* 106:    */   }
/* 107:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.decompiler.PrintStreamLogger
 * JD-Core Version:    0.7.0.1
 */