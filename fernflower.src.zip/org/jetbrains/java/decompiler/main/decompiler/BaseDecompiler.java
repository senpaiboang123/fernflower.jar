/*  1:   */ package org.jetbrains.java.decompiler.main.decompiler;
/*  2:   */ 
/*  3:   */ import java.io.File;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.util.Map;
/*  6:   */ import org.jetbrains.java.decompiler.main.Fernflower;
/*  7:   */ import org.jetbrains.java.decompiler.main.extern.IBytecodeProvider;
/*  8:   */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*  9:   */ import org.jetbrains.java.decompiler.main.extern.IResultSaver;
/* 10:   */ import org.jetbrains.java.decompiler.struct.StructContext;
/* 11:   */ 
/* 12:   */ public class BaseDecompiler
/* 13:   */ {
/* 14:   */   private final Fernflower fernflower;
/* 15:   */   
/* 16:   */   public BaseDecompiler(IBytecodeProvider provider, IResultSaver saver, Map<String, Object> options, IFernflowerLogger logger)
/* 17:   */   {
/* 18:32 */     this.fernflower = new Fernflower(provider, saver, options, logger);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void addSpace(File file, boolean isOwn)
/* 22:   */     throws IOException
/* 23:   */   {
/* 24:36 */     this.fernflower.getStructContext().addSpace(file, isOwn);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void decompileContext()
/* 28:   */   {
/* 29:   */     try
/* 30:   */     {
/* 31:41 */       this.fernflower.decompileContext();
/* 32:   */     }
/* 33:   */     finally
/* 34:   */     {
/* 35:44 */       this.fernflower.clearContext();
/* 36:   */     }
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.decompiler.BaseDecompiler
 * JD-Core Version:    0.7.0.1
 */