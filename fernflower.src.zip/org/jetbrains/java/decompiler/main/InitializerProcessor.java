/*   1:    */ package org.jetbrains.java.decompiler.main;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*   9:    */ import org.jetbrains.java.decompiler.main.rels.MethodWrapper;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FieldExprent;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  19:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  20:    */ import org.jetbrains.java.decompiler.struct.StructField;
/*  21:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  22:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  23:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  24:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  25:    */ 
/*  26:    */ public class InitializerProcessor
/*  27:    */ {
/*  28:    */   public static void extractInitializers(ClassWrapper wrapper)
/*  29:    */   {
/*  30: 39 */     MethodWrapper meth = wrapper.getMethodWrapper("<clinit>", "()V");
/*  31: 40 */     if ((meth != null) && (meth.root != null)) {
/*  32: 41 */       extractStaticInitializers(wrapper, meth);
/*  33:    */     }
/*  34: 44 */     extractDynamicInitializers(wrapper);
/*  35:    */     
/*  36:    */ 
/*  37:    */ 
/*  38: 48 */     liftConstructor(wrapper);
/*  39: 50 */     if (DecompilerContext.getOption("hes")) {
/*  40: 51 */       hideEmptySuper(wrapper);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   private static void liftConstructor(ClassWrapper wrapper)
/*  45:    */   {
/*  46: 58 */     for (Iterator i$ = wrapper.getMethods().iterator(); i$.hasNext();)
/*  47:    */     {
/*  48: 58 */       meth = (MethodWrapper)i$.next();
/*  49: 59 */       if (("<init>".equals(meth.methodStruct.getName())) && (meth.root != null))
/*  50:    */       {
/*  51: 60 */         Statement firstdata = findFirstData(meth.root);
/*  52: 61 */         if (firstdata == null) {
/*  53: 62 */           return;
/*  54:    */         }
/*  55: 66 */         index = 0;
/*  56: 67 */         lstExprents = firstdata.getExprents();
/*  57: 69 */         for (Exprent exprent : lstExprents)
/*  58:    */         {
/*  59: 71 */           int action = 0;
/*  60: 73 */           if (exprent.type == 2)
/*  61:    */           {
/*  62: 74 */             AssignmentExprent asexpr = (AssignmentExprent)exprent;
/*  63: 75 */             if ((asexpr.getLeft().type == 5) && (asexpr.getRight().type == 12))
/*  64:    */             {
/*  65: 76 */               FieldExprent fexpr = (FieldExprent)asexpr.getLeft();
/*  66: 77 */               if (fexpr.getClassname().equals(wrapper.getClassStruct().qualifiedName))
/*  67:    */               {
/*  68: 78 */                 StructField structField = wrapper.getClassStruct().getField(fexpr.getName(), fexpr.getDescriptor().descriptorString);
/*  69: 79 */                 if ((structField != null) && (structField.hasModifier(16))) {
/*  70: 80 */                   action = 1;
/*  71:    */                 }
/*  72:    */               }
/*  73:    */             }
/*  74:    */           }
/*  75: 85 */           else if ((index > 0) && (exprent.type == 8) && (isInvocationInitConstructor((InvocationExprent)exprent, meth, wrapper, true)))
/*  76:    */           {
/*  77: 88 */             lstExprents.add(0, lstExprents.remove(index));
/*  78: 89 */             action = 2;
/*  79:    */           }
/*  80: 92 */           if (action != 1) {
/*  81:    */             break;
/*  82:    */           }
/*  83: 96 */           index++;
/*  84:    */         }
/*  85:    */       }
/*  86:    */     }
/*  87:    */     MethodWrapper meth;
/*  88:    */     int index;
/*  89:    */     List<Exprent> lstExprents;
/*  90:    */   }
/*  91:    */   
/*  92:    */   private static void hideEmptySuper(ClassWrapper wrapper)
/*  93:    */   {
/*  94:105 */     for (MethodWrapper meth : wrapper.getMethods()) {
/*  95:106 */       if (("<init>".equals(meth.methodStruct.getName())) && (meth.root != null))
/*  96:    */       {
/*  97:107 */         Statement firstdata = findFirstData(meth.root);
/*  98:108 */         if ((firstdata == null) || (firstdata.getExprents().isEmpty())) {
/*  99:109 */           return;
/* 100:    */         }
/* 101:112 */         Exprent exprent = (Exprent)firstdata.getExprents().get(0);
/* 102:113 */         if (exprent.type == 8)
/* 103:    */         {
/* 104:114 */           InvocationExprent invexpr = (InvocationExprent)exprent;
/* 105:115 */           if ((isInvocationInitConstructor(invexpr, meth, wrapper, false)) && (invexpr.getLstParameters().isEmpty())) {
/* 106:116 */             firstdata.getExprents().remove(0);
/* 107:    */           }
/* 108:    */         }
/* 109:    */       }
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   private static void extractStaticInitializers(ClassWrapper wrapper, MethodWrapper meth)
/* 114:    */   {
/* 115:125 */     RootStatement root = meth.root;
/* 116:126 */     StructClass cl = wrapper.getClassStruct();
/* 117:    */     
/* 118:128 */     Statement firstdata = findFirstData(root);
/* 119:129 */     if (firstdata != null) {
/* 120:130 */       while (!firstdata.getExprents().isEmpty())
/* 121:    */       {
/* 122:131 */         Exprent exprent = (Exprent)firstdata.getExprents().get(0);
/* 123:    */         
/* 124:133 */         boolean found = false;
/* 125:135 */         if (exprent.type == 2)
/* 126:    */         {
/* 127:136 */           AssignmentExprent asexpr = (AssignmentExprent)exprent;
/* 128:137 */           if (asexpr.getLeft().type == 5)
/* 129:    */           {
/* 130:138 */             FieldExprent fexpr = (FieldExprent)asexpr.getLeft();
/* 131:139 */             if ((fexpr.isStatic()) && (fexpr.getClassname().equals(cl.qualifiedName)) && (cl.hasField(fexpr.getName(), fexpr.getDescriptor().descriptorString))) {
/* 132:142 */               if (isExprentIndependent(asexpr.getRight(), meth))
/* 133:    */               {
/* 134:144 */                 String keyField = InterpreterUtil.makeUniqueKey(fexpr.getName(), fexpr.getDescriptor().descriptorString);
/* 135:145 */                 if (!wrapper.getStaticFieldInitializers().containsKey(keyField))
/* 136:    */                 {
/* 137:146 */                   wrapper.getStaticFieldInitializers().addWithKey(asexpr.getRight(), keyField);
/* 138:147 */                   firstdata.getExprents().remove(0);
/* 139:148 */                   found = true;
/* 140:    */                 }
/* 141:    */               }
/* 142:    */             }
/* 143:    */           }
/* 144:    */         }
/* 145:155 */         if (!found) {
/* 146:    */           break;
/* 147:    */         }
/* 148:    */       }
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   private static void extractDynamicInitializers(ClassWrapper wrapper)
/* 153:    */   {
/* 154:164 */     StructClass cl = wrapper.getClassStruct();
/* 155:    */     
/* 156:166 */     boolean isAnonymous = ((ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(cl.qualifiedName)).type == 2;
/* 157:    */     
/* 158:168 */     List<List<Exprent>> lstFirst = new ArrayList();
/* 159:169 */     List<MethodWrapper> lstMethWrappers = new ArrayList();
/* 160:171 */     for (MethodWrapper meth : wrapper.getMethods()) {
/* 161:172 */       if (("<init>".equals(meth.methodStruct.getName())) && (meth.root != null))
/* 162:    */       {
/* 163:173 */         Statement firstdata = findFirstData(meth.root);
/* 164:174 */         if ((firstdata == null) || (firstdata.getExprents().isEmpty())) {
/* 165:175 */           return;
/* 166:    */         }
/* 167:177 */         lstFirst.add(firstdata.getExprents());
/* 168:178 */         lstMethWrappers.add(meth);
/* 169:    */         
/* 170:180 */         Exprent exprent = (Exprent)firstdata.getExprents().get(0);
/* 171:181 */         if ((!isAnonymous) && (
/* 172:182 */           (exprent.type != 8) || (!isInvocationInitConstructor((InvocationExprent)exprent, meth, wrapper, false)))) {
/* 173:184 */           return;
/* 174:    */         }
/* 175:    */       }
/* 176:    */     }
/* 177:190 */     if (lstFirst.isEmpty()) {
/* 178:191 */       return;
/* 179:    */     }
/* 180:    */     for (;;)
/* 181:    */     {
/* 182:196 */       String fieldWithDescr = null;
/* 183:197 */       Exprent value = null;
/* 184:199 */       for (int i = 0; i < lstFirst.size(); i++)
/* 185:    */       {
/* 186:201 */         List<Exprent> lst = (List)lstFirst.get(i);
/* 187:203 */         if (lst.size() < (isAnonymous ? 1 : 2)) {
/* 188:204 */           return;
/* 189:    */         }
/* 190:207 */         Exprent exprent = (Exprent)lst.get(isAnonymous ? 0 : 1);
/* 191:    */         
/* 192:209 */         boolean found = false;
/* 193:211 */         if (exprent.type == 2)
/* 194:    */         {
/* 195:212 */           AssignmentExprent asexpr = (AssignmentExprent)exprent;
/* 196:213 */           if (asexpr.getLeft().type == 5)
/* 197:    */           {
/* 198:214 */             FieldExprent fexpr = (FieldExprent)asexpr.getLeft();
/* 199:215 */             if ((!fexpr.isStatic()) && (fexpr.getClassname().equals(cl.qualifiedName)) && (cl.hasField(fexpr.getName(), fexpr.getDescriptor().descriptorString))) {
/* 200:219 */               if (isExprentIndependent(asexpr.getRight(), (MethodWrapper)lstMethWrappers.get(i)))
/* 201:    */               {
/* 202:220 */                 String fieldKey = InterpreterUtil.makeUniqueKey(fexpr.getName(), fexpr.getDescriptor().descriptorString);
/* 203:221 */                 if (fieldWithDescr == null)
/* 204:    */                 {
/* 205:222 */                   fieldWithDescr = fieldKey;
/* 206:223 */                   value = asexpr.getRight();
/* 207:    */                 }
/* 208:226 */                 else if ((!fieldWithDescr.equals(fieldKey)) || (!value.equals(asexpr.getRight())))
/* 209:    */                 {
/* 210:228 */                   return;
/* 211:    */                 }
/* 212:231 */                 found = true;
/* 213:    */               }
/* 214:    */             }
/* 215:    */           }
/* 216:    */         }
/* 217:237 */         if (!found) {
/* 218:238 */           return;
/* 219:    */         }
/* 220:    */       }
/* 221:242 */       if (!wrapper.getDynamicFieldInitializers().containsKey(fieldWithDescr))
/* 222:    */       {
/* 223:243 */         wrapper.getDynamicFieldInitializers().addWithKey(value, fieldWithDescr);
/* 224:245 */         for (List<Exprent> lst : lstFirst) {
/* 225:246 */           lst.remove(isAnonymous ? 0 : 1);
/* 226:    */         }
/* 227:    */       }
/* 228:    */       else
/* 229:    */       {
/* 230:250 */         return;
/* 231:    */       }
/* 232:    */     }
/* 233:    */   }
/* 234:    */   
/* 235:    */   private static boolean isExprentIndependent(Exprent exprent, MethodWrapper meth)
/* 236:    */   {
/* 237:257 */     List<Exprent> lst = exprent.getAllExprents(true);
/* 238:258 */     lst.add(exprent);
/* 239:260 */     for (Exprent expr : lst) {
/* 240:261 */       switch (expr.type)
/* 241:    */       {
/* 242:    */       case 12: 
/* 243:263 */         VarVersionPair varpaar = new VarVersionPair((VarExprent)expr);
/* 244:264 */         if (!meth.varproc.getExternalVars().contains(varpaar))
/* 245:    */         {
/* 246:265 */           String varname = meth.varproc.getVarName(varpaar);
/* 247:267 */           if ((!varname.equals("this")) && (!varname.endsWith(".this"))) {
/* 248:268 */             return false;
/* 249:    */           }
/* 250:    */         }
/* 251:270 */         break;
/* 252:    */       case 5: 
/* 253:273 */         return false;
/* 254:    */       }
/* 255:    */     }
/* 256:277 */     return true;
/* 257:    */   }
/* 258:    */   
/* 259:    */   private static Statement findFirstData(Statement stat)
/* 260:    */   {
/* 261:283 */     if (stat.getExprents() != null) {
/* 262:284 */       return stat;
/* 263:    */     }
/* 264:287 */     if (stat.isLabeled()) {
/* 265:288 */       return null;
/* 266:    */     }
/* 267:291 */     switch (stat.type)
/* 268:    */     {
/* 269:    */     case 2: 
/* 270:    */     case 6: 
/* 271:    */     case 10: 
/* 272:    */     case 13: 
/* 273:    */     case 15: 
/* 274:297 */       return findFirstData(stat.getFirst());
/* 275:    */     }
/* 276:299 */     return null;
/* 277:    */   }
/* 278:    */   
/* 279:    */   private static boolean isInvocationInitConstructor(InvocationExprent inv, MethodWrapper meth, ClassWrapper wrapper, boolean withThis)
/* 280:    */   {
/* 281:306 */     if ((inv.getFunctype() == 2) && 
/* 282:307 */       (inv.getInstance().type == 12))
/* 283:    */     {
/* 284:308 */       VarExprent instvar = (VarExprent)inv.getInstance();
/* 285:309 */       VarVersionPair varpaar = new VarVersionPair(instvar);
/* 286:    */       
/* 287:311 */       String classname = (String)meth.varproc.getThisVars().get(varpaar);
/* 288:313 */       if ((classname != null) && (
/* 289:314 */         (withThis) || (!wrapper.getClassStruct().qualifiedName.equals(inv.getClassname())))) {
/* 290:315 */         return true;
/* 291:    */       }
/* 292:    */     }
/* 293:321 */     return false;
/* 294:    */   }
/* 295:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.InitializerProcessor
 * JD-Core Version:    0.7.0.1
 */