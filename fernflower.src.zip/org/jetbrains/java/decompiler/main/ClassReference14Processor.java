/*   1:    */ package org.jetbrains.java.decompiler.main;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*  12:    */ import org.jetbrains.java.decompiler.main.rels.MethodWrapper;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FieldExprent;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph.ExprentIterator;
/*  24:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  25:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement;
/*  26:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  27:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  28:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  29:    */ import org.jetbrains.java.decompiler.struct.StructField;
/*  30:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  31:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  32:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  33:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  34:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  35:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  36:    */ 
/*  37:    */ public class ClassReference14Processor
/*  38:    */ {
/*  39:    */   public final ExitExprent bodyexprent;
/*  40:    */   public final ExitExprent handlerexprent;
/*  41:    */   
/*  42:    */   public ClassReference14Processor()
/*  43:    */   {
/*  44: 48 */     InvocationExprent invfor = new InvocationExprent();
/*  45: 49 */     invfor.setName("forName");
/*  46: 50 */     invfor.setClassname("java/lang/Class");
/*  47: 51 */     invfor.setStringDescriptor("(Ljava/lang/String;)Ljava/lang/Class;");
/*  48: 52 */     invfor.setDescriptor(MethodDescriptor.parseDescriptor("(Ljava/lang/String;)Ljava/lang/Class;"));
/*  49: 53 */     invfor.setStatic(true);
/*  50: 54 */     invfor.setLstParameters(Arrays.asList(new Exprent[] { new VarExprent(0, VarType.VARTYPE_STRING, null) }));
/*  51:    */     
/*  52: 56 */     this.bodyexprent = new ExitExprent(0, invfor, VarType.VARTYPE_CLASS, null);
/*  53:    */     
/*  54:    */ 
/*  55:    */ 
/*  56: 60 */     InvocationExprent constr = new InvocationExprent();
/*  57: 61 */     constr.setName("<init>");
/*  58: 62 */     constr.setClassname("java/lang/NoClassDefFoundError");
/*  59: 63 */     constr.setStringDescriptor("()V");
/*  60: 64 */     constr.setFunctype(2);
/*  61: 65 */     constr.setDescriptor(MethodDescriptor.parseDescriptor("()V"));
/*  62:    */     
/*  63: 67 */     NewExprent newexpr = new NewExprent(new VarType(8, 0, "java/lang/NoClassDefFoundError"), new ArrayList(), null);
/*  64:    */     
/*  65: 69 */     newexpr.setConstructor(constr);
/*  66:    */     
/*  67: 71 */     InvocationExprent invcause = new InvocationExprent();
/*  68: 72 */     invcause.setName("initCause");
/*  69: 73 */     invcause.setClassname("java/lang/NoClassDefFoundError");
/*  70: 74 */     invcause.setStringDescriptor("(Ljava/lang/Throwable;)Ljava/lang/Throwable;");
/*  71: 75 */     invcause.setDescriptor(MethodDescriptor.parseDescriptor("(Ljava/lang/Throwable;)Ljava/lang/Throwable;"));
/*  72: 76 */     invcause.setInstance(newexpr);
/*  73: 77 */     invcause.setLstParameters(Arrays.asList(new Exprent[] { new VarExprent(2, new VarType(8, 0, "java/lang/ClassNotFoundException"), null) }));
/*  74:    */     
/*  75:    */ 
/*  76: 80 */     this.handlerexprent = new ExitExprent(1, invcause, null, null);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void processClassReferences(ClassesProcessor.ClassNode node)
/*  80:    */   {
/*  81: 88 */     ClassWrapper wrapper = node.getWrapper();
/*  82: 98 */     if (wrapper.getClassStruct().isVersionGE_1_5()) {
/*  83:100 */       return;
/*  84:    */     }
/*  85:104 */     HashMap<ClassWrapper, MethodWrapper> mapClassMeths = new HashMap();
/*  86:105 */     mapClassMethods(node, mapClassMeths);
/*  87:107 */     if (mapClassMeths.isEmpty()) {
/*  88:108 */       return;
/*  89:    */     }
/*  90:111 */     HashSet<ClassWrapper> setFound = new HashSet();
/*  91:112 */     processClassRec(node, mapClassMeths, setFound);
/*  92:114 */     if (!setFound.isEmpty()) {
/*  93:115 */       for (ClassWrapper wrp : setFound)
/*  94:    */       {
/*  95:116 */         StructMethod mt = ((MethodWrapper)mapClassMeths.get(wrp)).methodStruct;
/*  96:117 */         wrp.getHiddenMembers().add(InterpreterUtil.makeUniqueKey(mt.getName(), mt.getDescriptor()));
/*  97:    */       }
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static void processClassRec(ClassesProcessor.ClassNode node, HashMap<ClassWrapper, MethodWrapper> mapClassMeths, final HashSet<ClassWrapper> setFound)
/* 102:    */   {
/* 103:126 */     ClassWrapper wrapper = node.getWrapper();
/* 104:129 */     for (MethodWrapper meth : wrapper.getMethods())
/* 105:    */     {
/* 106:131 */       RootStatement root = meth.root;
/* 107:132 */       if (root != null)
/* 108:    */       {
/* 109:134 */         DirectGraph graph = meth.getOrBuildGraph();
/* 110:    */         
/* 111:136 */         graph.iterateExprents(new DirectGraph.ExprentIterator()
/* 112:    */         {
/* 113:    */           public int processExprent(Exprent exprent)
/* 114:    */           {
/* 115:138 */             for (Map.Entry<ClassWrapper, MethodWrapper> ent : this.val$mapClassMeths.entrySet()) {
/* 116:139 */               if (ClassReference14Processor.replaceInvocations(exprent, (ClassWrapper)ent.getKey(), (MethodWrapper)ent.getValue())) {
/* 117:140 */                 setFound.add(ent.getKey());
/* 118:    */               }
/* 119:    */             }
/* 120:143 */             return 0;
/* 121:    */           }
/* 122:    */         });
/* 123:    */       }
/* 124:    */     }
/* 125:150 */     for (int j = 0; j < 2; j++)
/* 126:    */     {
/* 127:151 */       VBStyleCollection<Exprent, String> initializers = j == 0 ? wrapper.getStaticFieldInitializers() : wrapper.getDynamicFieldInitializers();
/* 128:154 */       for (int i = 0; i < initializers.size(); i++) {
/* 129:155 */         for (Map.Entry<ClassWrapper, MethodWrapper> ent : mapClassMeths.entrySet())
/* 130:    */         {
/* 131:156 */           Exprent exprent = (Exprent)initializers.get(i);
/* 132:157 */           if (replaceInvocations(exprent, (ClassWrapper)ent.getKey(), (MethodWrapper)ent.getValue())) {
/* 133:158 */             setFound.add(ent.getKey());
/* 134:    */           }
/* 135:161 */           String cl = isClass14Invocation(exprent, (ClassWrapper)ent.getKey(), (MethodWrapper)ent.getValue());
/* 136:162 */           if (cl != null)
/* 137:    */           {
/* 138:163 */             initializers.set(i, new ConstExprent(VarType.VARTYPE_CLASS, cl.replace('.', '/'), exprent.bytecode));
/* 139:164 */             setFound.add(ent.getKey());
/* 140:    */           }
/* 141:    */         }
/* 142:    */       }
/* 143:    */     }
/* 144:171 */     for (ClassesProcessor.ClassNode nd : node.nested) {
/* 145:172 */       processClassRec(nd, mapClassMeths, setFound);
/* 146:    */     }
/* 147:    */   }
/* 148:    */   
/* 149:    */   private void mapClassMethods(ClassesProcessor.ClassNode node, Map<ClassWrapper, MethodWrapper> map)
/* 150:    */   {
/* 151:177 */     boolean noSynthFlag = DecompilerContext.getOption("nns");
/* 152:    */     
/* 153:179 */     ClassWrapper wrapper = node.getWrapper();
/* 154:181 */     for (MethodWrapper method : wrapper.getMethods())
/* 155:    */     {
/* 156:182 */       StructMethod mt = method.methodStruct;
/* 157:184 */       if (((noSynthFlag) || (mt.isSynthetic())) && (mt.getDescriptor().equals("(Ljava/lang/String;)Ljava/lang/Class;")) && (mt.hasModifier(8)))
/* 158:    */       {
/* 159:188 */         RootStatement root = method.root;
/* 160:189 */         if ((root != null) && (root.getFirst().type == 7))
/* 161:    */         {
/* 162:190 */           CatchStatement cst = (CatchStatement)root.getFirst();
/* 163:191 */           if ((cst.getStats().size() == 2) && (cst.getFirst().type == 8) && (((Statement)cst.getStats().get(1)).type == 8) && (((VarExprent)cst.getVars().get(0)).getVarType().equals(new VarType(8, 0, "java/lang/ClassNotFoundException"))))
/* 164:    */           {
/* 165:195 */             BasicBlockStatement body = (BasicBlockStatement)cst.getFirst();
/* 166:196 */             BasicBlockStatement handler = (BasicBlockStatement)cst.getStats().get(1);
/* 167:198 */             if ((body.getExprents().size() == 1) && (handler.getExprents().size() == 1) && 
/* 168:199 */               (this.bodyexprent.equals(body.getExprents().get(0))) && (this.handlerexprent.equals(handler.getExprents().get(0))))
/* 169:    */             {
/* 170:201 */               map.put(wrapper, method);
/* 171:202 */               break;
/* 172:    */             }
/* 173:    */           }
/* 174:    */         }
/* 175:    */       }
/* 176:    */     }
/* 177:211 */     for (ClassesProcessor.ClassNode nd : node.nested) {
/* 178:212 */       mapClassMethods(nd, map);
/* 179:    */     }
/* 180:    */   }
/* 181:    */   
/* 182:    */   private static boolean replaceInvocations(Exprent exprent, ClassWrapper wrapper, MethodWrapper meth)
/* 183:    */   {
/* 184:219 */     boolean res = false;
/* 185:    */     for (;;)
/* 186:    */     {
/* 187:223 */       boolean found = false;
/* 188:225 */       for (Exprent expr : exprent.getAllExprents())
/* 189:    */       {
/* 190:226 */         String cl = isClass14Invocation(expr, wrapper, meth);
/* 191:227 */         if (cl != null)
/* 192:    */         {
/* 193:228 */           exprent.replaceExprent(expr, new ConstExprent(VarType.VARTYPE_CLASS, cl.replace('.', '/'), expr.bytecode));
/* 194:229 */           found = true;
/* 195:230 */           res = true;
/* 196:231 */           break;
/* 197:    */         }
/* 198:234 */         res |= replaceInvocations(expr, wrapper, meth);
/* 199:    */       }
/* 200:237 */       if (!found) {
/* 201:    */         break;
/* 202:    */       }
/* 203:    */     }
/* 204:242 */     return res;
/* 205:    */   }
/* 206:    */   
/* 207:    */   private static String isClass14Invocation(Exprent exprent, ClassWrapper wrapper, MethodWrapper meth)
/* 208:    */   {
/* 209:248 */     if (exprent.type == 6)
/* 210:    */     {
/* 211:249 */       FunctionExprent fexpr = (FunctionExprent)exprent;
/* 212:250 */       if ((fexpr.getFuncType() == 36) && 
/* 213:251 */         (((Exprent)fexpr.getLstOperands().get(0)).type == 6))
/* 214:    */       {
/* 215:252 */         FunctionExprent headexpr = (FunctionExprent)fexpr.getLstOperands().get(0);
/* 216:253 */         if ((headexpr.getFuncType() == 42) && 
/* 217:254 */           (((Exprent)headexpr.getLstOperands().get(0)).type == 5) && (((Exprent)headexpr.getLstOperands().get(1)).type == 3) && (((ConstExprent)headexpr.getLstOperands().get(1)).getConstType().equals(VarType.VARTYPE_NULL)))
/* 218:    */         {
/* 219:258 */           FieldExprent field = (FieldExprent)headexpr.getLstOperands().get(0);
/* 220:259 */           ClassesProcessor.ClassNode fieldnode = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(field.getClassname());
/* 221:261 */           if ((fieldnode != null) && (fieldnode.classStruct.qualifiedName.equals(wrapper.getClassStruct().qualifiedName)))
/* 222:    */           {
/* 223:262 */             StructField fd = wrapper.getClassStruct().getField(field.getName(), field.getDescriptor().descriptorString);
/* 224:265 */             if ((fd != null) && (fd.hasModifier(8)) && ((fd.isSynthetic()) || (DecompilerContext.getOption("nns")))) {
/* 225:268 */               if ((((Exprent)fexpr.getLstOperands().get(1)).type == 2) && (((Exprent)fexpr.getLstOperands().get(2)).equals(field)))
/* 226:    */               {
/* 227:269 */                 AssignmentExprent asexpr = (AssignmentExprent)fexpr.getLstOperands().get(1);
/* 228:271 */                 if ((asexpr.getLeft().equals(field)) && (asexpr.getRight().type == 8))
/* 229:    */                 {
/* 230:272 */                   InvocationExprent invexpr = (InvocationExprent)asexpr.getRight();
/* 231:274 */                   if ((invexpr.getClassname().equals(wrapper.getClassStruct().qualifiedName)) && (invexpr.getName().equals(meth.methodStruct.getName())) && (invexpr.getStringDescriptor().equals(meth.methodStruct.getDescriptor()))) {
/* 232:278 */                     if (((Exprent)invexpr.getLstParameters().get(0)).type == 3)
/* 233:    */                     {
/* 234:279 */                       wrapper.getHiddenMembers().add(InterpreterUtil.makeUniqueKey(fd.getName(), fd.getDescriptor()));
/* 235:    */                       
/* 236:281 */                       return ((ConstExprent)invexpr.getLstParameters().get(0)).getValue().toString();
/* 237:    */                     }
/* 238:    */                   }
/* 239:    */                 }
/* 240:    */               }
/* 241:    */             }
/* 242:    */           }
/* 243:    */         }
/* 244:    */       }
/* 245:    */     }
/* 246:294 */     return null;
/* 247:    */   }
/* 248:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.ClassReference14Processor
 * JD-Core Version:    0.7.0.1
 */