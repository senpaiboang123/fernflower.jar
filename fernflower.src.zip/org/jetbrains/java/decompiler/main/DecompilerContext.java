/*   1:    */ package org.jetbrains.java.decompiler.main;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.Locale;
/*   5:    */ import java.util.Map;
/*   6:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeSourceMapper;
/*   7:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*   8:    */ import org.jetbrains.java.decompiler.main.collectors.ImportCollector;
/*   9:    */ import org.jetbrains.java.decompiler.main.collectors.VarNamesCollector;
/*  10:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*  11:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*  12:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerPreferences;
/*  13:    */ import org.jetbrains.java.decompiler.modules.renamer.PoolInterceptor;
/*  14:    */ import org.jetbrains.java.decompiler.struct.StructContext;
/*  15:    */ 
/*  16:    */ public class DecompilerContext
/*  17:    */ {
/*  18:    */   public static final String CURRENT_CLASS = "CURRENT_CLASS";
/*  19:    */   public static final String CURRENT_CLASS_WRAPPER = "CURRENT_CLASS_WRAPPER";
/*  20:    */   public static final String CURRENT_CLASS_NODE = "CURRENT_CLASS_NODE";
/*  21:    */   public static final String CURRENT_METHOD = "CURRENT_METHOD";
/*  22:    */   public static final String CURRENT_METHOD_DESCRIPTOR = "CURRENT_METHOD_DESCRIPTOR";
/*  23:    */   public static final String CURRENT_METHOD_WRAPPER = "CURRENT_METHOD_WRAPPER";
/*  24:    */   public static final String CURRENT_VAR_PROCESSOR = "CURRENT_VAR_PROCESSOR";
/*  25: 40 */   private static final ThreadLocal<DecompilerContext> currentContext = new ThreadLocal();
/*  26:    */   private final Map<String, Object> properties;
/*  27:    */   private StructContext structContext;
/*  28:    */   private ImportCollector importCollector;
/*  29:    */   private VarNamesCollector varNamescollector;
/*  30:    */   private CounterContainer counterContainer;
/*  31:    */   private ClassesProcessor classProcessor;
/*  32:    */   private PoolInterceptor poolInterceptor;
/*  33:    */   private IFernflowerLogger logger;
/*  34:    */   private BytecodeSourceMapper bytecodeSourceMapper;
/*  35:    */   
/*  36:    */   private DecompilerContext(Map<String, Object> properties)
/*  37:    */   {
/*  38: 53 */     this.properties = properties;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static void initContext(Map<String, Object> propertiesCustom)
/*  42:    */   {
/*  43: 57 */     Map<String, Object> properties = new HashMap(IFernflowerPreferences.DEFAULTS);
/*  44: 58 */     if (propertiesCustom != null) {
/*  45: 59 */       properties.putAll(propertiesCustom);
/*  46:    */     }
/*  47: 61 */     currentContext.set(new DecompilerContext(properties));
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static DecompilerContext getCurrentContext()
/*  51:    */   {
/*  52: 65 */     return (DecompilerContext)currentContext.get();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static void setCurrentContext(DecompilerContext context)
/*  56:    */   {
/*  57: 69 */     currentContext.set(context);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static Object getProperty(String key)
/*  61:    */   {
/*  62: 73 */     return getCurrentContext().properties.get(key);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static void setProperty(String key, Object value)
/*  66:    */   {
/*  67: 77 */     getCurrentContext().properties.put(key, value);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static boolean getOption(String key)
/*  71:    */   {
/*  72: 81 */     return "1".equals(getCurrentContext().properties.get(key));
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static ImportCollector getImportCollector()
/*  76:    */   {
/*  77: 85 */     return getCurrentContext().importCollector;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static void setImportCollector(ImportCollector importCollector)
/*  81:    */   {
/*  82: 89 */     getCurrentContext().importCollector = importCollector;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static VarNamesCollector getVarNamesCollector()
/*  86:    */   {
/*  87: 93 */     return getCurrentContext().varNamescollector;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static void setVarNamesCollector(VarNamesCollector varNamesCollector)
/*  91:    */   {
/*  92: 97 */     getCurrentContext().varNamescollector = varNamesCollector;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static StructContext getStructContext()
/*  96:    */   {
/*  97:101 */     return getCurrentContext().structContext;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static void setStructContext(StructContext structContext)
/* 101:    */   {
/* 102:105 */     getCurrentContext().structContext = structContext;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static CounterContainer getCounterContainer()
/* 106:    */   {
/* 107:109 */     return getCurrentContext().counterContainer;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static void setCounterContainer(CounterContainer counterContainer)
/* 111:    */   {
/* 112:113 */     getCurrentContext().counterContainer = counterContainer;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static ClassesProcessor getClassProcessor()
/* 116:    */   {
/* 117:117 */     return getCurrentContext().classProcessor;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static void setClassProcessor(ClassesProcessor classProcessor)
/* 121:    */   {
/* 122:121 */     getCurrentContext().classProcessor = classProcessor;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static PoolInterceptor getPoolInterceptor()
/* 126:    */   {
/* 127:125 */     return getCurrentContext().poolInterceptor;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static void setPoolInterceptor(PoolInterceptor poolinterceptor)
/* 131:    */   {
/* 132:129 */     getCurrentContext().poolInterceptor = poolinterceptor;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static BytecodeSourceMapper getBytecodeSourceMapper()
/* 136:    */   {
/* 137:133 */     return getCurrentContext().bytecodeSourceMapper;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static void setBytecodeSourceMapper(BytecodeSourceMapper bytecodeSourceMapper)
/* 141:    */   {
/* 142:137 */     getCurrentContext().bytecodeSourceMapper = bytecodeSourceMapper;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public static IFernflowerLogger getLogger()
/* 146:    */   {
/* 147:141 */     return getCurrentContext().logger;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public static void setLogger(IFernflowerLogger logger)
/* 151:    */   {
/* 152:145 */     if (logger != null)
/* 153:    */     {
/* 154:146 */       String level = (String)getProperty("log");
/* 155:147 */       if (level != null) {
/* 156:    */         try
/* 157:    */         {
/* 158:149 */           logger.setSeverity(IFernflowerLogger.Severity.valueOf(level.toUpperCase(Locale.US)));
/* 159:    */         }
/* 160:    */         catch (IllegalArgumentException ignore) {}
/* 161:    */       }
/* 162:    */     }
/* 163:154 */     getCurrentContext().logger = logger;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public static String getNewLineSeparator()
/* 167:    */   {
/* 168:158 */     return getOption("nls") ? "\n" : "\r\n";
/* 169:    */   }
/* 170:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.DecompilerContext
 * JD-Core Version:    0.7.0.1
 */