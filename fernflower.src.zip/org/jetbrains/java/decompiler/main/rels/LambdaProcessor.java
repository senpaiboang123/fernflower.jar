/*   1:    */ package org.jetbrains.java.decompiler.main.rels;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.util.BitSet;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*   9:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*  10:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor;
/*  11:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*  12:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode.LambdaInformation;
/*  13:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  14:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  15:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  16:    */ import org.jetbrains.java.decompiler.struct.attr.StructBootstrapMethodsAttribute;
/*  17:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  18:    */ import org.jetbrains.java.decompiler.struct.consts.LinkConstant;
/*  19:    */ import org.jetbrains.java.decompiler.struct.consts.PooledConstant;
/*  20:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  21:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  22:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  23:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  24:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  25:    */ 
/*  26:    */ public class LambdaProcessor
/*  27:    */ {
/*  28:    */   private static final String JAVAC_LAMBDA_CLASS = "java/lang/invoke/LambdaMetafactory";
/*  29:    */   private static final String JAVAC_LAMBDA_METHOD = "metafactory";
/*  30:    */   private static final String JAVAC_LAMBDA_ALT_METHOD = "altMetafactory";
/*  31:    */   
/*  32:    */   public void processClass(ClassesProcessor.ClassNode node)
/*  33:    */     throws IOException
/*  34:    */   {
/*  35: 43 */     for (ClassesProcessor.ClassNode child : node.nested) {
/*  36: 44 */       processClass(child);
/*  37:    */     }
/*  38: 47 */     hasLambda(node);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public boolean hasLambda(ClassesProcessor.ClassNode node)
/*  42:    */     throws IOException
/*  43:    */   {
/*  44: 51 */     ClassesProcessor clProcessor = DecompilerContext.getClassProcessor();
/*  45: 52 */     StructClass cl = node.classStruct;
/*  46: 54 */     if (cl.getBytecodeVersion() < 5) {
/*  47: 55 */       return false;
/*  48:    */     }
/*  49: 58 */     StructBootstrapMethodsAttribute bootstrap = (StructBootstrapMethodsAttribute)cl.getAttributes().getWithKey("BootstrapMethods");
/*  50: 60 */     if ((bootstrap == null) || (bootstrap.getMethodsNumber() == 0)) {
/*  51: 61 */       return false;
/*  52:    */     }
/*  53: 64 */     BitSet lambda_methods = new BitSet();
/*  54: 67 */     for (int i = 0; i < bootstrap.getMethodsNumber(); i++)
/*  55:    */     {
/*  56: 68 */       LinkConstant method_ref = bootstrap.getMethodReference(i);
/*  57: 71 */       if (("java/lang/invoke/LambdaMetafactory".equals(method_ref.classname)) && (("metafactory".equals(method_ref.elementname)) || ("altMetafactory".equals(method_ref.elementname)))) {
/*  58: 73 */         lambda_methods.set(i);
/*  59:    */       }
/*  60:    */     }
/*  61: 77 */     if (lambda_methods.isEmpty()) {
/*  62: 78 */       return false;
/*  63:    */     }
/*  64: 81 */     Map<String, String> mapMethodsLambda = new HashMap();
/*  65: 84 */     for (StructMethod mt : cl.getMethods())
/*  66:    */     {
/*  67: 85 */       mt.expandData();
/*  68:    */       
/*  69: 87 */       InstructionSequence seq = mt.getInstructionSequence();
/*  70: 88 */       if ((seq != null) && (seq.length() > 0))
/*  71:    */       {
/*  72: 89 */         int len = seq.length();
/*  73: 91 */         for (int i = 0; i < len; i++)
/*  74:    */         {
/*  75: 92 */           Instruction instr = seq.getInstr(i);
/*  76: 94 */           if (instr.opcode == 186)
/*  77:    */           {
/*  78: 95 */             LinkConstant invoke_dynamic = cl.getPool().getLinkConstant(instr.getOperand(0));
/*  79: 97 */             if (lambda_methods.get(invoke_dynamic.index1))
/*  80:    */             {
/*  81: 99 */               List<PooledConstant> bootstrap_arguments = bootstrap.getMethodArguments(invoke_dynamic.index1);
/*  82:100 */               MethodDescriptor md = MethodDescriptor.parseDescriptor(invoke_dynamic.descriptor);
/*  83:    */               
/*  84:102 */               String lambda_class_name = md.ret.value;
/*  85:103 */               String lambda_method_name = invoke_dynamic.elementname;
/*  86:104 */               String lambda_method_descriptor = ((PrimitiveConstant)bootstrap_arguments.get(2)).getString();
/*  87:    */               
/*  88:106 */               LinkConstant content_method_handle = (LinkConstant)bootstrap_arguments.get(1);
/*  89:    */               
/*  90:108 */               ClassesProcessor.ClassNode node_lambda = new ClassesProcessor.ClassNode(content_method_handle.classname, content_method_handle.elementname, content_method_handle.descriptor, content_method_handle.index1, lambda_class_name, lambda_method_name, lambda_method_descriptor, cl);
/*  91:    */               
/*  92:    */ 
/*  93:111 */               node_lambda.simpleName = (cl.qualifiedName + "##Lambda_" + invoke_dynamic.index1 + "_" + invoke_dynamic.index2);
/*  94:112 */               node_lambda.enclosingMethod = InterpreterUtil.makeUniqueKey(mt.getName(), mt.getDescriptor());
/*  95:    */               
/*  96:114 */               node.nested.add(node_lambda);
/*  97:115 */               node_lambda.parent = node;
/*  98:    */               
/*  99:117 */               clProcessor.getMapRootClasses().put(node_lambda.simpleName, node_lambda);
/* 100:118 */               mapMethodsLambda.put(node_lambda.lambdaInformation.content_method_key, node_lambda.simpleName);
/* 101:    */             }
/* 102:    */           }
/* 103:    */         }
/* 104:    */       }
/* 105:124 */       mt.releaseResources();
/* 106:    */     }
/* 107:128 */     for (ClassesProcessor.ClassNode nd : node.nested) {
/* 108:129 */       if (nd.type == 8)
/* 109:    */       {
/* 110:130 */         String parent_class_name = (String)mapMethodsLambda.get(nd.enclosingMethod);
/* 111:131 */         if (parent_class_name != null)
/* 112:    */         {
/* 113:132 */           ClassesProcessor.ClassNode parent_class = (ClassesProcessor.ClassNode)clProcessor.getMapRootClasses().get(parent_class_name);
/* 114:    */           
/* 115:134 */           parent_class.nested.add(nd);
/* 116:135 */           nd.parent = parent_class;
/* 117:    */         }
/* 118:    */       }
/* 119:    */     }
/* 120:142 */     return false;
/* 121:    */   }
/* 122:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.rels.LambdaProcessor
 * JD-Core Version:    0.7.0.1
 */