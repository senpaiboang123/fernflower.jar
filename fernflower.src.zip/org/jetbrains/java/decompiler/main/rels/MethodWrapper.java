/*  1:   */ package org.jetbrains.java.decompiler.main.rels;
/*  2:   */ 
/*  3:   */ import java.util.HashSet;
/*  4:   */ import java.util.List;
/*  5:   */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  6:   */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*  7:   */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.FlattenStatementsHelper;
/*  8:   */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  9:   */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/* 10:   */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/* 11:   */ import org.jetbrains.java.decompiler.struct.StructMethod;
/* 12:   */ 
/* 13:   */ public class MethodWrapper
/* 14:   */ {
/* 15:   */   public final RootStatement root;
/* 16:   */   public final VarProcessor varproc;
/* 17:   */   public final StructMethod methodStruct;
/* 18:   */   public final CounterContainer counter;
/* 19:   */   public DirectGraph graph;
/* 20:   */   public List<VarVersionPair> signatureFields;
/* 21:   */   public boolean decompiledWithErrors;
/* 22:46 */   public final HashSet<String> setOuterVarNames = new HashSet();
/* 23:   */   
/* 24:   */   public MethodWrapper(RootStatement root, VarProcessor varproc, StructMethod methodStruct, CounterContainer counter)
/* 25:   */   {
/* 26:49 */     this.root = root;
/* 27:50 */     this.varproc = varproc;
/* 28:51 */     this.methodStruct = methodStruct;
/* 29:52 */     this.counter = counter;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public DirectGraph getOrBuildGraph()
/* 33:   */   {
/* 34:56 */     if ((this.graph == null) && (this.root != null))
/* 35:   */     {
/* 36:57 */       FlattenStatementsHelper flatthelper = new FlattenStatementsHelper();
/* 37:58 */       this.graph = flatthelper.buildDirectGraph(this.root);
/* 38:   */     }
/* 39:60 */     return this.graph;
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.rels.MethodWrapper
 * JD-Core Version:    0.7.0.1
 */