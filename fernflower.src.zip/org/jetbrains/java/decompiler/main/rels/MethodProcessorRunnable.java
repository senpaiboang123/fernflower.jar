/*   1:    */ package org.jetbrains.java.decompiler.main.rels;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*   5:    */ import org.jetbrains.java.decompiler.code.cfg.ControlFlowGraph;
/*   6:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   7:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*   8:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*   9:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*  10:    */ import org.jetbrains.java.decompiler.modules.code.DeadCodeHelper;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.ClearStructHelper;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.DomHelper;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExitHelper;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.FinallyProcessor;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.IdeaNotNullHelper;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.IfHelper;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.InlineSingleBlockHelper;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.LabelHelper;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.LoopExtractHelper;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.MergeHelper;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.PPandMMHelper;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.SecondaryFunctionsHelper;
/*  24:    */ import org.jetbrains.java.decompiler.modules.decompiler.SequenceHelper;
/*  25:    */ import org.jetbrains.java.decompiler.modules.decompiler.StackVarsProcessor;
/*  26:    */ import org.jetbrains.java.decompiler.modules.decompiler.deobfuscator.ExceptionDeobfuscator;
/*  27:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  28:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  29:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  30:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  31:    */ 
/*  32:    */ public class MethodProcessorRunnable
/*  33:    */   implements Runnable
/*  34:    */ {
/*  35: 37 */   public final Object lock = new Object();
/*  36:    */   private final StructMethod method;
/*  37:    */   private final VarProcessor varProc;
/*  38:    */   private final DecompilerContext parentContext;
/*  39:    */   private volatile RootStatement root;
/*  40:    */   private volatile Throwable error;
/*  41: 45 */   private volatile boolean finished = false;
/*  42:    */   
/*  43:    */   public MethodProcessorRunnable(StructMethod method, VarProcessor varProc, DecompilerContext parentContext)
/*  44:    */   {
/*  45: 48 */     this.method = method;
/*  46: 49 */     this.varProc = varProc;
/*  47: 50 */     this.parentContext = parentContext;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void run()
/*  51:    */   {
/*  52: 55 */     DecompilerContext.setCurrentContext(this.parentContext);
/*  53:    */     
/*  54: 57 */     this.error = null;
/*  55: 58 */     this.root = null;
/*  56:    */     try
/*  57:    */     {
/*  58: 61 */       this.root = codeToJava(this.method, this.varProc);
/*  59:    */     }
/*  60:    */     catch (ThreadDeath ex)
/*  61:    */     {
/*  62: 64 */       throw ex;
/*  63:    */     }
/*  64:    */     catch (Throwable ex)
/*  65:    */     {
/*  66: 67 */       this.error = ex;
/*  67:    */     }
/*  68:    */     finally
/*  69:    */     {
/*  70: 70 */       DecompilerContext.setCurrentContext(null);
/*  71:    */     }
/*  72: 73 */     this.finished = true;
/*  73: 74 */     synchronized (this.lock)
/*  74:    */     {
/*  75: 75 */       this.lock.notifyAll();
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static RootStatement codeToJava(StructMethod mt, VarProcessor varProc)
/*  80:    */     throws IOException
/*  81:    */   {
/*  82: 80 */     StructClass cl = mt.getClassStruct();
/*  83:    */     
/*  84: 82 */     boolean isInitializer = "<clinit>".equals(mt.getName());
/*  85:    */     
/*  86: 84 */     mt.expandData();
/*  87: 85 */     InstructionSequence seq = mt.getInstructionSequence();
/*  88: 86 */     ControlFlowGraph graph = new ControlFlowGraph(seq);
/*  89:    */     
/*  90: 88 */     DeadCodeHelper.removeDeadBlocks(graph);
/*  91: 89 */     graph.inlineJsr(mt);
/*  92:    */     
/*  93:    */ 
/*  94: 92 */     DeadCodeHelper.connectDummyExitBlock(graph);
/*  95:    */     
/*  96: 94 */     DeadCodeHelper.removeGotos(graph);
/*  97:    */     
/*  98: 96 */     ExceptionDeobfuscator.removeCircularRanges(graph);
/*  99:    */     
/* 100: 98 */     ExceptionDeobfuscator.restorePopRanges(graph);
/* 101:100 */     if (DecompilerContext.getOption("rer")) {
/* 102:101 */       ExceptionDeobfuscator.removeEmptyRanges(graph);
/* 103:    */     }
/* 104:104 */     if (DecompilerContext.getOption("ner")) {
/* 105:106 */       DeadCodeHelper.incorporateValueReturns(graph);
/* 106:    */     }
/* 107:110 */     ExceptionDeobfuscator.insertEmptyExceptionHandlerBlocks(graph);
/* 108:    */     
/* 109:112 */     DeadCodeHelper.mergeBasicBlocks(graph);
/* 110:    */     
/* 111:114 */     DecompilerContext.getCounterContainer().setCounter(2, mt.getLocalVariables());
/* 112:116 */     if (ExceptionDeobfuscator.hasObfuscatedExceptions(graph)) {
/* 113:117 */       DecompilerContext.getLogger().writeMessage("Heavily obfuscated exception ranges found!", IFernflowerLogger.Severity.WARN);
/* 114:    */     }
/* 115:120 */     RootStatement root = DomHelper.parseGraph(graph);
/* 116:    */     
/* 117:122 */     FinallyProcessor fProc = new FinallyProcessor(varProc);
/* 118:123 */     while (fProc.iterateGraph(mt, root, graph)) {
/* 119:124 */       root = DomHelper.parseGraph(graph);
/* 120:    */     }
/* 121:129 */     DomHelper.removeSynchronizedHandler(root);
/* 122:    */     
/* 123:    */ 
/* 124:    */ 
/* 125:133 */     SequenceHelper.condenseSequences(root);
/* 126:    */     
/* 127:135 */     ClearStructHelper.clearStatements(root);
/* 128:    */     
/* 129:137 */     ExprProcessor proc = new ExprProcessor();
/* 130:138 */     proc.processStatement(root, cl);
/* 131:    */     
/* 132:140 */     SequenceHelper.condenseSequences(root);
/* 133:    */     for (;;)
/* 134:    */     {
/* 135:143 */       StackVarsProcessor stackProc = new StackVarsProcessor();
/* 136:144 */       stackProc.simplifyStackVars(root, mt, cl);
/* 137:    */       
/* 138:146 */       varProc.setVarVersions(root);
/* 139:148 */       if (!new PPandMMHelper().findPPandMM(root)) {
/* 140:    */         break;
/* 141:    */       }
/* 142:    */     }
/* 143:    */     for (;;)
/* 144:    */     {
/* 145:154 */       LabelHelper.cleanUpEdges(root);
/* 146:    */       for (;;)
/* 147:    */       {
/* 148:157 */         MergeHelper.enhanceLoops(root);
/* 149:159 */         if ((!LoopExtractHelper.extractLoops(root)) && 
/* 150:    */         
/* 151:    */ 
/* 152:    */ 
/* 153:163 */           (!IfHelper.mergeAllIfs(root))) {
/* 154:    */           break;
/* 155:    */         }
/* 156:    */       }
/* 157:168 */       if ((DecompilerContext.getOption("inn")) && 
/* 158:169 */         (IdeaNotNullHelper.removeHardcodedChecks(root, mt)))
/* 159:    */       {
/* 160:170 */         SequenceHelper.condenseSequences(root);
/* 161:    */         
/* 162:172 */         StackVarsProcessor stackProc = new StackVarsProcessor();
/* 163:173 */         stackProc.simplifyStackVars(root, mt, cl);
/* 164:    */         
/* 165:175 */         varProc.setVarVersions(root);
/* 166:    */       }
/* 167:179 */       LabelHelper.identifyLabels(root);
/* 168:181 */       if (!InlineSingleBlockHelper.inlineSingleBlocks(root)) {
/* 169:186 */         if (!isInitializer) {
/* 170:186 */           if (!ExitHelper.condenseExits(root)) {
/* 171:    */             break;
/* 172:    */           }
/* 173:    */         }
/* 174:    */       }
/* 175:    */     }
/* 176:196 */     ExitHelper.removeRedundantReturns(root);
/* 177:    */     
/* 178:198 */     SecondaryFunctionsHelper.identifySecondaryFunctions(root);
/* 179:    */     
/* 180:200 */     varProc.setVarDefinitions(root);
/* 181:    */     
/* 182:    */ 
/* 183:    */ 
/* 184:204 */     LabelHelper.replaceContinueWithBreak(root);
/* 185:    */     
/* 186:206 */     mt.releaseResources();
/* 187:    */     
/* 188:208 */     return root;
/* 189:    */   }
/* 190:    */   
/* 191:    */   public RootStatement getResult()
/* 192:    */     throws Throwable
/* 193:    */   {
/* 194:212 */     Throwable t = this.error;
/* 195:213 */     if (t != null) {
/* 196:213 */       throw t;
/* 197:    */     }
/* 198:214 */     return this.root;
/* 199:    */   }
/* 200:    */   
/* 201:    */   public boolean isFinished()
/* 202:    */   {
/* 203:218 */     return this.finished;
/* 204:    */   }
/* 205:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.rels.MethodProcessorRunnable
 * JD-Core Version:    0.7.0.1
 */