/*   1:    */ package org.jetbrains.java.decompiler.main.rels;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.LinkedList;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Set;
/*   9:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor;
/*  10:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*  11:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  12:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  13:    */ import org.jetbrains.java.decompiler.main.collectors.VarNamesCollector;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FieldExprent;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectNode;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  24:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  25:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  26:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  27:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  28:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  29:    */ 
/*  30:    */ public class NestedMemberAccess
/*  31:    */ {
/*  32:    */   private static final int METHOD_ACCESS_NORMAL = 1;
/*  33:    */   private static final int METHOD_ACCESS_FIELD_GET = 2;
/*  34:    */   private static final int METHOD_ACCESS_FIELD_SET = 3;
/*  35:    */   private static final int METHOD_ACCESS_METHOD = 4;
/*  36:    */   private boolean noSynthFlag;
/*  37: 45 */   private final Map<MethodWrapper, Integer> mapMethodType = new HashMap();
/*  38:    */   
/*  39:    */   public void propagateMemberAccess(ClassesProcessor.ClassNode root)
/*  40:    */   {
/*  41: 49 */     if (root.nested.isEmpty()) {
/*  42: 50 */       return;
/*  43:    */     }
/*  44: 53 */     this.noSynthFlag = DecompilerContext.getOption("nns");
/*  45:    */     
/*  46: 55 */     computeMethodTypes(root);
/*  47:    */     
/*  48: 57 */     eliminateStaticAccess(root);
/*  49:    */   }
/*  50:    */   
/*  51:    */   private void computeMethodTypes(ClassesProcessor.ClassNode node)
/*  52:    */   {
/*  53: 62 */     if (node.type == 8) {
/*  54: 63 */       return;
/*  55:    */     }
/*  56: 66 */     for (ClassesProcessor.ClassNode nd : node.nested) {
/*  57: 67 */       computeMethodTypes(nd);
/*  58:    */     }
/*  59: 70 */     for (MethodWrapper method : node.getWrapper().getMethods()) {
/*  60: 71 */       computeMethodType(node, method);
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   private void computeMethodType(ClassesProcessor.ClassNode node, MethodWrapper method)
/*  65:    */   {
/*  66: 76 */     int type = 1;
/*  67: 78 */     if (method.root != null)
/*  68:    */     {
/*  69: 79 */       DirectGraph graph = method.getOrBuildGraph();
/*  70:    */       
/*  71: 81 */       StructMethod mt = method.methodStruct;
/*  72: 82 */       if (((this.noSynthFlag) || (mt.isSynthetic())) && (mt.hasModifier(8)) && 
/*  73: 83 */         (graph.nodes.size() == 2)) {
/*  74: 84 */         if (graph.first.exprents.size() == 1)
/*  75:    */         {
/*  76: 85 */           Exprent exprent = (Exprent)graph.first.exprents.get(0);
/*  77:    */           
/*  78: 87 */           MethodDescriptor mtdesc = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/*  79: 88 */           int parcount = mtdesc.params.length;
/*  80:    */           
/*  81: 90 */           Exprent exprCore = exprent;
/*  82: 92 */           if (exprent.type == 4)
/*  83:    */           {
/*  84: 93 */             ExitExprent exexpr = (ExitExprent)exprent;
/*  85: 94 */             if ((exexpr.getExitType() == 0) && (exexpr.getValue() != null)) {
/*  86: 95 */               exprCore = exexpr.getValue();
/*  87:    */             }
/*  88:    */           }
/*  89: 99 */           switch (exprCore.type)
/*  90:    */           {
/*  91:    */           case 5: 
/*  92:101 */             FieldExprent fexpr = (FieldExprent)exprCore;
/*  93:102 */             if (((parcount == 1) && (!fexpr.isStatic())) || ((parcount == 0) && (fexpr.isStatic()))) {
/*  94:104 */               if ((fexpr.getClassname().equals(node.classStruct.qualifiedName)) && (
/*  95:105 */                 (fexpr.isStatic()) || ((fexpr.getInstance().type == 12) && (((VarExprent)fexpr.getInstance()).getIndex() == 0)))) {
/*  96:107 */                 type = 2;
/*  97:    */               }
/*  98:    */             }
/*  99:    */             break;
/* 100:    */           case 12: 
/* 101:113 */             if (parcount == 1) {
/* 102:115 */               if (((VarExprent)exprCore).getIndex() != 0) {
/* 103:116 */                 type = 2;
/* 104:    */               }
/* 105:    */             }
/* 106:    */             break;
/* 107:    */           case 8: 
/* 108:122 */             type = 4;
/* 109:123 */             break;
/* 110:    */           case 2: 
/* 111:125 */             AssignmentExprent asexpr = (AssignmentExprent)exprCore;
/* 112:126 */             if ((asexpr.getLeft().type == 5) && (asexpr.getRight().type == 12))
/* 113:    */             {
/* 114:127 */               FieldExprent fexpras = (FieldExprent)asexpr.getLeft();
/* 115:128 */               if (((parcount == 2) && (!fexpras.isStatic())) || ((parcount == 1) && (fexpras.isStatic()))) {
/* 116:130 */                 if ((fexpras.getClassname().equals(node.classStruct.qualifiedName)) && (
/* 117:131 */                   (fexpras.isStatic()) || ((fexpras.getInstance().type == 12) && (((VarExprent)fexpras.getInstance()).getIndex() == 0)))) {
/* 118:133 */                   if (((VarExprent)asexpr.getRight()).getIndex() == parcount - 1) {
/* 119:134 */                     type = 3;
/* 120:    */                   }
/* 121:    */                 }
/* 122:    */               }
/* 123:    */             }
/* 124:    */             break;
/* 125:    */           }
/* 126:143 */           if (type == 4)
/* 127:    */           {
/* 128:145 */             type = 1;
/* 129:    */             
/* 130:147 */             InvocationExprent invexpr = (InvocationExprent)exprCore;
/* 131:149 */             if (((invexpr.isStatic()) && (invexpr.getLstParameters().size() == parcount)) || ((!invexpr.isStatic()) && (invexpr.getInstance().type == 12) && (((VarExprent)invexpr.getInstance()).getIndex() == 0) && (invexpr.getLstParameters().size() == parcount - 1)))
/* 132:    */             {
/* 133:153 */               boolean equalpars = true;
/* 134:155 */               for (int i = 0; i < invexpr.getLstParameters().size(); i++)
/* 135:    */               {
/* 136:156 */                 Exprent parexpr = (Exprent)invexpr.getLstParameters().get(i);
/* 137:157 */                 if (parexpr.type == 12)
/* 138:    */                 {
/* 139:157 */                   if (((VarExprent)parexpr).getIndex() == i + (invexpr.isStatic() ? 0 : 1)) {}
/* 140:    */                 }
/* 141:    */                 else
/* 142:    */                 {
/* 143:159 */                   equalpars = false;
/* 144:160 */                   break;
/* 145:    */                 }
/* 146:    */               }
/* 147:164 */               if (equalpars) {
/* 148:165 */                 type = 4;
/* 149:    */               }
/* 150:    */             }
/* 151:    */           }
/* 152:    */         }
/* 153:170 */         else if (graph.first.exprents.size() == 2)
/* 154:    */         {
/* 155:171 */           Exprent exprentFirst = (Exprent)graph.first.exprents.get(0);
/* 156:172 */           Exprent exprentSecond = (Exprent)graph.first.exprents.get(1);
/* 157:174 */           if ((exprentFirst.type == 2) && (exprentSecond.type == 4))
/* 158:    */           {
/* 159:177 */             MethodDescriptor mtdesc = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/* 160:178 */             int parcount = mtdesc.params.length;
/* 161:    */             
/* 162:180 */             AssignmentExprent asexpr = (AssignmentExprent)exprentFirst;
/* 163:181 */             if ((asexpr.getLeft().type == 5) && (asexpr.getRight().type == 12))
/* 164:    */             {
/* 165:182 */               FieldExprent fexpras = (FieldExprent)asexpr.getLeft();
/* 166:183 */               if (((parcount == 2) && (!fexpras.isStatic())) || ((parcount == 1) && (fexpras.isStatic()))) {
/* 167:185 */                 if ((fexpras.getClassname().equals(node.classStruct.qualifiedName)) && (
/* 168:186 */                   (fexpras.isStatic()) || ((fexpras.getInstance().type == 12) && (((VarExprent)fexpras.getInstance()).getIndex() == 0)))) {
/* 169:188 */                   if (((VarExprent)asexpr.getRight()).getIndex() == parcount - 1)
/* 170:    */                   {
/* 171:190 */                     ExitExprent exexpr = (ExitExprent)exprentSecond;
/* 172:191 */                     if ((exexpr.getExitType() == 0) && (exexpr.getValue() != null) && 
/* 173:192 */                       (exexpr.getValue().type == 12) && (((VarExprent)asexpr.getRight()).getIndex() == parcount - 1)) {
/* 174:194 */                       type = 3;
/* 175:    */                     }
/* 176:    */                   }
/* 177:    */                 }
/* 178:    */               }
/* 179:    */             }
/* 180:    */           }
/* 181:    */         }
/* 182:    */       }
/* 183:    */     }
/* 184:208 */     if (type != 1) {
/* 185:209 */       this.mapMethodType.put(method, Integer.valueOf(type));
/* 186:    */     } else {
/* 187:212 */       this.mapMethodType.remove(method);
/* 188:    */     }
/* 189:    */   }
/* 190:    */   
/* 191:    */   private void eliminateStaticAccess(ClassesProcessor.ClassNode node)
/* 192:    */   {
/* 193:219 */     if (node.type == 8) {
/* 194:220 */       return;
/* 195:    */     }
/* 196:223 */     for (MethodWrapper meth : node.getWrapper().getMethods()) {
/* 197:225 */       if (meth.root != null)
/* 198:    */       {
/* 199:227 */         boolean replaced = false;
/* 200:    */         
/* 201:229 */         DirectGraph graph = meth.getOrBuildGraph();
/* 202:    */         
/* 203:231 */         HashSet<DirectNode> setVisited = new HashSet();
/* 204:232 */         LinkedList<DirectNode> stack = new LinkedList();
/* 205:233 */         stack.add(graph.first);
/* 206:235 */         while (!stack.isEmpty())
/* 207:    */         {
/* 208:237 */           DirectNode nd = (DirectNode)stack.removeFirst();
/* 209:239 */           if (!setVisited.contains(nd))
/* 210:    */           {
/* 211:242 */             setVisited.add(nd);
/* 212:244 */             for (int i = 0; i < nd.exprents.size(); i++)
/* 213:    */             {
/* 214:245 */               Exprent exprent = (Exprent)nd.exprents.get(i);
/* 215:    */               
/* 216:247 */               replaced |= replaceInvocations(node, meth, exprent);
/* 217:249 */               if (exprent.type == 8)
/* 218:    */               {
/* 219:250 */                 Exprent ret = replaceAccessExprent(node, meth, (InvocationExprent)exprent);
/* 220:252 */                 if (ret != null)
/* 221:    */                 {
/* 222:253 */                   nd.exprents.set(i, ret);
/* 223:254 */                   replaced = true;
/* 224:    */                 }
/* 225:    */               }
/* 226:    */             }
/* 227:259 */             for (DirectNode ndx : nd.succs) {
/* 228:260 */               stack.add(ndx);
/* 229:    */             }
/* 230:    */           }
/* 231:    */         }
/* 232:264 */         if (replaced) {
/* 233:265 */           computeMethodType(node, meth);
/* 234:    */         }
/* 235:    */       }
/* 236:    */     }
/* 237:270 */     for (ClassesProcessor.ClassNode child : node.nested) {
/* 238:271 */       eliminateStaticAccess(child);
/* 239:    */     }
/* 240:    */   }
/* 241:    */   
/* 242:    */   private boolean replaceInvocations(ClassesProcessor.ClassNode caller, MethodWrapper meth, Exprent exprent)
/* 243:    */   {
/* 244:278 */     boolean res = false;
/* 245:280 */     for (Exprent expr : exprent.getAllExprents()) {
/* 246:281 */       res |= replaceInvocations(caller, meth, expr);
/* 247:    */     }
/* 248:    */     for (;;)
/* 249:    */     {
/* 250:286 */       boolean found = false;
/* 251:288 */       for (Exprent expr : exprent.getAllExprents()) {
/* 252:289 */         if (expr.type == 8)
/* 253:    */         {
/* 254:290 */           Exprent newexpr = replaceAccessExprent(caller, meth, (InvocationExprent)expr);
/* 255:291 */           if (newexpr != null)
/* 256:    */           {
/* 257:292 */             exprent.replaceExprent(expr, newexpr);
/* 258:293 */             found = true;
/* 259:294 */             res = true;
/* 260:295 */             break;
/* 261:    */           }
/* 262:    */         }
/* 263:    */       }
/* 264:300 */       if (!found) {
/* 265:    */         break;
/* 266:    */       }
/* 267:    */     }
/* 268:305 */     return res;
/* 269:    */   }
/* 270:    */   
/* 271:    */   private static boolean sameTree(ClassesProcessor.ClassNode caller, ClassesProcessor.ClassNode callee)
/* 272:    */   {
/* 273:310 */     if (caller.classStruct.qualifiedName.equals(callee.classStruct.qualifiedName)) {
/* 274:311 */       return false;
/* 275:    */     }
/* 276:314 */     while (caller.parent != null) {
/* 277:315 */       caller = caller.parent;
/* 278:    */     }
/* 279:318 */     while (callee.parent != null) {
/* 280:319 */       callee = callee.parent;
/* 281:    */     }
/* 282:322 */     return caller == callee;
/* 283:    */   }
/* 284:    */   
/* 285:    */   private Exprent replaceAccessExprent(ClassesProcessor.ClassNode caller, MethodWrapper methdest, InvocationExprent invexpr)
/* 286:    */   {
/* 287:327 */     ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(invexpr.getClassname());
/* 288:    */     
/* 289:329 */     MethodWrapper methsource = null;
/* 290:330 */     if ((node != null) && (node.getWrapper() != null)) {
/* 291:331 */       methsource = node.getWrapper().getMethodWrapper(invexpr.getName(), invexpr.getStringDescriptor());
/* 292:    */     }
/* 293:334 */     if ((methsource == null) || (!this.mapMethodType.containsKey(methsource))) {
/* 294:335 */       return null;
/* 295:    */     }
/* 296:339 */     if ((node.classStruct.qualifiedName.equals(caller.classStruct.qualifiedName)) && (methsource.methodStruct.getName().equals(methdest.methodStruct.getName())) && (methsource.methodStruct.getDescriptor().equals(methdest.methodStruct.getDescriptor()))) {
/* 297:343 */       return null;
/* 298:    */     }
/* 299:346 */     int type = ((Integer)this.mapMethodType.get(methsource)).intValue();
/* 300:353 */     if (!sameTree(caller, node)) {
/* 301:354 */       return null;
/* 302:    */     }
/* 303:357 */     DirectGraph graph = methsource.getOrBuildGraph();
/* 304:358 */     Exprent source = (Exprent)graph.first.exprents.get(0);
/* 305:    */     
/* 306:360 */     Exprent retexprent = null;
/* 307:362 */     switch (type)
/* 308:    */     {
/* 309:    */     case 2: 
/* 310:364 */       ExitExprent exsource = (ExitExprent)source;
/* 311:365 */       if (exsource.getValue().type == 12)
/* 312:    */       {
/* 313:366 */         VarExprent var = (VarExprent)exsource.getValue();
/* 314:367 */         String varname = methsource.varproc.getVarName(new VarVersionPair(var));
/* 315:369 */         if (!methdest.setOuterVarNames.contains(varname))
/* 316:    */         {
/* 317:370 */           VarNamesCollector vnc = new VarNamesCollector();
/* 318:371 */           vnc.addName(varname);
/* 319:    */           
/* 320:373 */           methdest.varproc.refreshVarNames(vnc);
/* 321:374 */           methdest.setOuterVarNames.add(varname);
/* 322:    */         }
/* 323:377 */         int index = methdest.counter.getCounterAndIncrement(2);
/* 324:378 */         VarExprent ret = new VarExprent(index, var.getVarType(), methdest.varproc);
/* 325:379 */         methdest.varproc.setVarName(new VarVersionPair(index, 0), varname);
/* 326:    */         
/* 327:381 */         retexprent = ret;
/* 328:    */       }
/* 329:    */       else
/* 330:    */       {
/* 331:384 */         FieldExprent ret = (FieldExprent)exsource.getValue().copy();
/* 332:385 */         if (!ret.isStatic()) {
/* 333:386 */           ret.replaceExprent(ret.getInstance(), (Exprent)invexpr.getLstParameters().get(0));
/* 334:    */         }
/* 335:388 */         retexprent = ret;
/* 336:    */       }
/* 337:390 */       break;
/* 338:    */     case 3: 
/* 339:    */       AssignmentExprent ret;
/* 340:    */       AssignmentExprent ret;
/* 341:393 */       if (source.type == 4)
/* 342:    */       {
/* 343:394 */         ExitExprent extex = (ExitExprent)source;
/* 344:395 */         ret = (AssignmentExprent)extex.getValue().copy();
/* 345:    */       }
/* 346:    */       else
/* 347:    */       {
/* 348:398 */         ret = (AssignmentExprent)source.copy();
/* 349:    */       }
/* 350:400 */       FieldExprent fexpr = (FieldExprent)ret.getLeft();
/* 351:402 */       if (fexpr.isStatic())
/* 352:    */       {
/* 353:403 */         ret.replaceExprent(ret.getRight(), (Exprent)invexpr.getLstParameters().get(0));
/* 354:    */       }
/* 355:    */       else
/* 356:    */       {
/* 357:406 */         ret.replaceExprent(ret.getRight(), (Exprent)invexpr.getLstParameters().get(1));
/* 358:407 */         fexpr.replaceExprent(fexpr.getInstance(), (Exprent)invexpr.getLstParameters().get(0));
/* 359:    */       }
/* 360:409 */       retexprent = ret;
/* 361:410 */       break;
/* 362:    */     case 4: 
/* 363:412 */       if (source.type == 4) {
/* 364:413 */         source = ((ExitExprent)source).getValue();
/* 365:    */       }
/* 366:416 */       InvocationExprent invret = (InvocationExprent)source.copy();
/* 367:    */       
/* 368:418 */       int index = 0;
/* 369:419 */       if (!invret.isStatic())
/* 370:    */       {
/* 371:420 */         invret.replaceExprent(invret.getInstance(), (Exprent)invexpr.getLstParameters().get(0));
/* 372:421 */         index = 1;
/* 373:    */       }
/* 374:424 */       for (int i = 0; i < invret.getLstParameters().size(); i++) {
/* 375:425 */         invret.replaceExprent((Exprent)invret.getLstParameters().get(i), (Exprent)invexpr.getLstParameters().get(i + index));
/* 376:    */       }
/* 377:428 */       retexprent = invret;
/* 378:    */     }
/* 379:432 */     if (retexprent != null)
/* 380:    */     {
/* 381:434 */       boolean hide = true;
/* 382:436 */       if ((node.type == 0) || ((node.access & 0x8) != 0))
/* 383:    */       {
/* 384:437 */         StructMethod mt = methsource.methodStruct;
/* 385:438 */         if (!mt.isSynthetic()) {
/* 386:439 */           hide = false;
/* 387:    */         }
/* 388:    */       }
/* 389:442 */       if (hide) {
/* 390:443 */         node.getWrapper().getHiddenMembers().add(InterpreterUtil.makeUniqueKey(invexpr.getName(), invexpr.getStringDescriptor()));
/* 391:    */       }
/* 392:    */     }
/* 393:447 */     return retexprent;
/* 394:    */   }
/* 395:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.rels.NestedMemberAccess
 * JD-Core Version:    0.7.0.1
 */