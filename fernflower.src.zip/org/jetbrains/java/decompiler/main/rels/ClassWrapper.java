/*   1:    */ package org.jetbrains.java.decompiler.main.rels;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*   9:    */ import org.jetbrains.java.decompiler.main.collectors.VarNamesCollector;
/*  10:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*  11:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  16:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  17:    */ import org.jetbrains.java.decompiler.struct.StructField;
/*  18:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  19:    */ import org.jetbrains.java.decompiler.struct.attr.StructLocalVariableTableAttribute;
/*  20:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  21:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  22:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  23:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  24:    */ 
/*  25:    */ public class ClassWrapper
/*  26:    */ {
/*  27:    */   private final StructClass classStruct;
/*  28: 44 */   private final Set<String> hiddenMembers = new HashSet();
/*  29: 45 */   private final VBStyleCollection<Exprent, String> staticFieldInitializers = new VBStyleCollection();
/*  30: 46 */   private final VBStyleCollection<Exprent, String> dynamicFieldInitializers = new VBStyleCollection();
/*  31: 47 */   private final VBStyleCollection<MethodWrapper, String> methods = new VBStyleCollection();
/*  32:    */   
/*  33:    */   public ClassWrapper(StructClass classStruct)
/*  34:    */   {
/*  35: 50 */     this.classStruct = classStruct;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void init()
/*  39:    */     throws IOException
/*  40:    */   {
/*  41: 54 */     DecompilerContext.setProperty("CURRENT_CLASS", this.classStruct);
/*  42: 55 */     DecompilerContext.setProperty("CURRENT_CLASS_WRAPPER", this);
/*  43: 56 */     DecompilerContext.getLogger().startClass(this.classStruct.qualifiedName);
/*  44:    */     
/*  45:    */ 
/*  46: 59 */     Set<String> setFieldNames = new HashSet();
/*  47: 60 */     for (StructField fd : this.classStruct.getFields()) {
/*  48: 61 */       setFieldNames.add(fd.getName());
/*  49:    */     }
/*  50: 64 */     int maxSec = Integer.parseInt(DecompilerContext.getProperty("mpm").toString());
/*  51: 65 */     boolean testMode = DecompilerContext.getOption("__unit_test_mode__");
/*  52: 67 */     for (StructMethod mt : this.classStruct.getMethods())
/*  53:    */     {
/*  54: 68 */       DecompilerContext.getLogger().startMethod(mt.getName() + " " + mt.getDescriptor());
/*  55:    */       
/*  56: 70 */       VarNamesCollector vc = new VarNamesCollector();
/*  57: 71 */       DecompilerContext.setVarNamesCollector(vc);
/*  58:    */       
/*  59: 73 */       CounterContainer counter = new CounterContainer();
/*  60: 74 */       DecompilerContext.setCounterContainer(counter);
/*  61:    */       
/*  62: 76 */       DecompilerContext.setProperty("CURRENT_METHOD", mt);
/*  63: 77 */       DecompilerContext.setProperty("CURRENT_METHOD_DESCRIPTOR", MethodDescriptor.parseDescriptor(mt.getDescriptor()));
/*  64:    */       
/*  65: 79 */       VarProcessor varProc = new VarProcessor();
/*  66: 80 */       DecompilerContext.setProperty("CURRENT_VAR_PROCESSOR", varProc);
/*  67:    */       
/*  68: 82 */       RootStatement root = null;
/*  69:    */       
/*  70: 84 */       boolean isError = false;
/*  71:    */       try
/*  72:    */       {
/*  73: 87 */         if (mt.containsCode())
/*  74:    */         {
/*  75: 88 */           if ((maxSec == 0) || (testMode))
/*  76:    */           {
/*  77: 89 */             root = MethodProcessorRunnable.codeToJava(mt, varProc);
/*  78:    */           }
/*  79:    */           else
/*  80:    */           {
/*  81: 92 */             MethodProcessorRunnable mtProc = new MethodProcessorRunnable(mt, varProc, DecompilerContext.getCurrentContext());
/*  82:    */             
/*  83: 94 */             Thread mtThread = new Thread(mtProc, "Java decompiler");
/*  84: 95 */             long stopAt = System.currentTimeMillis() + maxSec * 1000;
/*  85:    */             
/*  86: 97 */             mtThread.start();
/*  87: 99 */             while (!mtProc.isFinished())
/*  88:    */             {
/*  89:    */               try
/*  90:    */               {
/*  91:101 */                 synchronized (mtProc.lock)
/*  92:    */                 {
/*  93:102 */                   mtProc.lock.wait(200L);
/*  94:    */                 }
/*  95:    */               }
/*  96:    */               catch (InterruptedException e)
/*  97:    */               {
/*  98:106 */                 killThread(mtThread);
/*  99:107 */                 throw e;
/* 100:    */               }
/* 101:110 */               if (System.currentTimeMillis() >= stopAt)
/* 102:    */               {
/* 103:111 */                 String message = "Processing time limit exceeded for method " + mt.getName() + ", execution interrupted.";
/* 104:112 */                 DecompilerContext.getLogger().writeMessage(message, IFernflowerLogger.Severity.ERROR);
/* 105:113 */                 killThread(mtThread);
/* 106:114 */                 isError = true;
/* 107:    */               }
/* 108:    */             }
/* 109:119 */             if (!isError) {
/* 110:120 */               root = mtProc.getResult();
/* 111:    */             }
/* 112:    */           }
/* 113:    */         }
/* 114:    */         else
/* 115:    */         {
/* 116:125 */           boolean thisVar = !mt.hasModifier(8);
/* 117:126 */           MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/* 118:    */           
/* 119:128 */           int paramCount = 0;
/* 120:129 */           if (thisVar)
/* 121:    */           {
/* 122:130 */             varProc.getThisVars().put(new VarVersionPair(0, 0), this.classStruct.qualifiedName);
/* 123:131 */             paramCount = 1;
/* 124:    */           }
/* 125:133 */           paramCount += md.params.length;
/* 126:    */           
/* 127:135 */           int varIndex = 0;
/* 128:136 */           for (int i = 0; i < paramCount; i++)
/* 129:    */           {
/* 130:137 */             varProc.setVarName(new VarVersionPair(varIndex, 0), vc.getFreeName(varIndex));
/* 131:139 */             if (thisVar)
/* 132:    */             {
/* 133:140 */               if (i == 0) {
/* 134:141 */                 varIndex++;
/* 135:    */               } else {
/* 136:144 */                 varIndex += md.params[(i - 1)].stackSize;
/* 137:    */               }
/* 138:    */             }
/* 139:    */             else {
/* 140:148 */               varIndex += md.params[i].stackSize;
/* 141:    */             }
/* 142:    */           }
/* 143:    */         }
/* 144:    */       }
/* 145:    */       catch (Throwable ex)
/* 146:    */       {
/* 147:154 */         DecompilerContext.getLogger().writeMessage("Method " + mt.getName() + " " + mt.getDescriptor() + " couldn't be decompiled.", ex);
/* 148:155 */         isError = true;
/* 149:    */       }
/* 150:158 */       MethodWrapper methodWrapper = new MethodWrapper(root, varProc, mt, counter);
/* 151:159 */       methodWrapper.decompiledWithErrors = isError;
/* 152:    */       
/* 153:161 */       this.methods.addWithKey(methodWrapper, InterpreterUtil.makeUniqueKey(mt.getName(), mt.getDescriptor()));
/* 154:    */       
/* 155:    */ 
/* 156:164 */       varProc.refreshVarNames(new VarNamesCollector(setFieldNames));
/* 157:167 */       if (DecompilerContext.getOption("udv"))
/* 158:    */       {
/* 159:168 */         StructLocalVariableTableAttribute attr = (StructLocalVariableTableAttribute)mt.getAttributes().getWithKey("LocalVariableTable");
/* 160:171 */         if (attr != null) {
/* 161:172 */           varProc.setDebugVarNames(attr.getMapVarNames());
/* 162:    */         }
/* 163:    */       }
/* 164:176 */       DecompilerContext.getLogger().endMethod();
/* 165:    */     }
/* 166:179 */     DecompilerContext.getLogger().endClass();
/* 167:    */   }
/* 168:    */   
/* 169:    */   private static void killThread(Thread thread)
/* 170:    */   {
/* 171:184 */     thread.stop();
/* 172:    */   }
/* 173:    */   
/* 174:    */   public MethodWrapper getMethodWrapper(String name, String descriptor)
/* 175:    */   {
/* 176:188 */     return (MethodWrapper)this.methods.getWithKey(InterpreterUtil.makeUniqueKey(name, descriptor));
/* 177:    */   }
/* 178:    */   
/* 179:    */   public StructClass getClassStruct()
/* 180:    */   {
/* 181:192 */     return this.classStruct;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public VBStyleCollection<MethodWrapper, String> getMethods()
/* 185:    */   {
/* 186:196 */     return this.methods;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public Set<String> getHiddenMembers()
/* 190:    */   {
/* 191:200 */     return this.hiddenMembers;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public VBStyleCollection<Exprent, String> getStaticFieldInitializers()
/* 195:    */   {
/* 196:204 */     return this.staticFieldInitializers;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public VBStyleCollection<Exprent, String> getDynamicFieldInitializers()
/* 200:    */   {
/* 201:208 */     return this.dynamicFieldInitializers;
/* 202:    */   }
/* 203:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.rels.ClassWrapper
 * JD-Core Version:    0.7.0.1
 */