/*   1:    */ package org.jetbrains.java.decompiler.main.rels;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.LinkedList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor;
/*  12:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*  13:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode.LambdaInformation;
/*  14:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  15:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  16:    */ import org.jetbrains.java.decompiler.main.collectors.VarNamesCollector;
/*  17:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*  18:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FieldExprent;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*  24:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*  25:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  26:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*  27:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph.ExprentIterator;
/*  28:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectNode;
/*  29:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*  30:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  31:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  32:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  33:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  34:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  35:    */ import org.jetbrains.java.decompiler.struct.StructField;
/*  36:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  37:    */ import org.jetbrains.java.decompiler.struct.attr.StructEnclosingMethodAttribute;
/*  38:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  39:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  40:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  41:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  42:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  43:    */ 
/*  44:    */ public class NestedClassProcessor
/*  45:    */ {
/*  46:    */   public void processClass(ClassesProcessor.ClassNode root, ClassesProcessor.ClassNode node)
/*  47:    */   {
/*  48: 48 */     if ((node.type == 8) && (!node.lambdaInformation.is_method_reference))
/*  49:    */     {
/*  50: 49 */       ClassesProcessor.ClassNode node_content = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(node.classStruct.qualifiedName);
/*  51: 50 */       if ((node_content != null) && (node_content.getWrapper() != null)) {
/*  52: 51 */         node_content.getWrapper().getHiddenMembers().add(node.lambdaInformation.content_method_key);
/*  53:    */       }
/*  54:    */     }
/*  55: 55 */     if (node.nested.isEmpty()) {
/*  56: 56 */       return;
/*  57:    */     }
/*  58: 59 */     if (node.type != 8)
/*  59:    */     {
/*  60: 60 */       computeLocalVarsAndDefinitions(node);
/*  61:    */       
/*  62:    */ 
/*  63: 63 */       checkNotFoundClasses(root, node);
/*  64:    */     }
/*  65: 66 */     int nameless = 0;int synthetics = 0;
/*  66: 67 */     for (ClassesProcessor.ClassNode child : node.nested)
/*  67:    */     {
/*  68: 68 */       StructClass cl = child.classStruct;
/*  69: 70 */       if (((child.type == 4) || (child.type == 1)) && (child.simpleName == null))
/*  70:    */       {
/*  71: 71 */         if (((child.access & 0x1000) != 0) || (cl.isSynthetic()))
/*  72:    */         {
/*  73: 72 */           child.simpleName = ("SyntheticClass_" + ++synthetics);
/*  74:    */         }
/*  75:    */         else
/*  76:    */         {
/*  77: 75 */           String message = "Nameless local or member class " + cl.qualifiedName + "!";
/*  78: 76 */           DecompilerContext.getLogger().writeMessage(message, IFernflowerLogger.Severity.WARN);
/*  79: 77 */           child.simpleName = ("NamelessClass_" + ++nameless);
/*  80:    */         }
/*  81: 79 */         child.namelessConstructorStub = ((!cl.hasModifier(8)) && (cl.getMethods().size() + cl.getFields().size() == 0));
/*  82:    */       }
/*  83: 81 */       else if (((child.type == 2) && ((child.access & 0x1000) != 0)) || (cl.isSynthetic()))
/*  84:    */       {
/*  85: 82 */         child.namelessConstructorStub = ((!cl.hasModifier(8)) && (cl.getMethods().size() + cl.getFields().size() == 0));
/*  86:    */       }
/*  87:    */     }
/*  88: 86 */     for (ClassesProcessor.ClassNode child : node.nested) {
/*  89: 87 */       if (child.type == 8)
/*  90:    */       {
/*  91: 88 */         setLambdaVars(node, child);
/*  92:    */       }
/*  93: 90 */       else if ((child.type != 1) || ((child.access & 0x8) == 0))
/*  94:    */       {
/*  95: 91 */         insertLocalVars(node, child);
/*  96: 93 */         if (child.type == 4) {
/*  97: 94 */           setLocalClassDefinition((MethodWrapper)node.getWrapper().getMethods().getWithKey(child.enclosingMethod), child);
/*  98:    */         }
/*  99:    */       }
/* 100:    */     }
/* 101: 99 */     for (ClassesProcessor.ClassNode child : node.nested) {
/* 102:100 */       processClass(root, child);
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   private static void setLambdaVars(ClassesProcessor.ClassNode parent, ClassesProcessor.ClassNode child)
/* 107:    */   {
/* 108:105 */     if (child.lambdaInformation.is_method_reference) {
/* 109:106 */       return;
/* 110:    */     }
/* 111:109 */     MethodWrapper method = (MethodWrapper)parent.getWrapper().getMethods().getWithKey(child.lambdaInformation.content_method_key);
/* 112:110 */     final MethodWrapper enclosingMethod = (MethodWrapper)parent.getWrapper().getMethods().getWithKey(child.enclosingMethod);
/* 113:    */     
/* 114:112 */     MethodDescriptor md_lambda = MethodDescriptor.parseDescriptor(child.lambdaInformation.method_descriptor);
/* 115:113 */     final MethodDescriptor md_content = MethodDescriptor.parseDescriptor(child.lambdaInformation.content_method_descriptor);
/* 116:    */     
/* 117:115 */     final int vars_count = md_content.params.length - md_lambda.params.length;
/* 118:    */     
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:120 */     final boolean is_static_lambda_content = child.lambdaInformation.is_content_method_static;
/* 123:    */     
/* 124:122 */     String parent_class_name = parent.getWrapper().getClassStruct().qualifiedName;
/* 125:123 */     String lambda_class_name = child.simpleName;
/* 126:    */     
/* 127:125 */     VarType lambda_class_type = new VarType(lambda_class_name, true);
/* 128:128 */     if ((!is_static_lambda_content) && (DecompilerContext.getOption("lac")))
/* 129:    */     {
/* 130:129 */       method.varproc.getThisVars().put(new VarVersionPair(0, 0), parent_class_name);
/* 131:130 */       method.varproc.setVarName(new VarVersionPair(0, 0), parent.simpleName + ".this");
/* 132:    */     }
/* 133:133 */     final Map<VarVersionPair, String> mapNewNames = new HashMap();
/* 134:    */     
/* 135:135 */     enclosingMethod.getOrBuildGraph().iterateExprents(new DirectGraph.ExprentIterator()
/* 136:    */     {
/* 137:    */       public int processExprent(Exprent exprent)
/* 138:    */       {
/* 139:138 */         List<Exprent> lst = exprent.getAllExprents(true);
/* 140:139 */         lst.add(exprent);
/* 141:141 */         for (Exprent expr : lst) {
/* 142:142 */           if (expr.type == 10)
/* 143:    */           {
/* 144:143 */             NewExprent new_expr = (NewExprent)expr;
/* 145:145 */             if ((new_expr.isLambda()) && (this.val$lambda_class_type.equals(new_expr.getNewType())))
/* 146:    */             {
/* 147:146 */               InvocationExprent inv_dynamic = new_expr.getConstructor();
/* 148:    */               
/* 149:148 */               int param_index = is_static_lambda_content ? 0 : 1;
/* 150:149 */               int varIndex = is_static_lambda_content ? 0 : 1;
/* 151:151 */               for (int i = 0; i < vars_count; i++)
/* 152:    */               {
/* 153:152 */                 Exprent param = (Exprent)inv_dynamic.getLstParameters().get(param_index + i);
/* 154:154 */                 if (param.type == 12)
/* 155:    */                 {
/* 156:155 */                   VarVersionPair pair = new VarVersionPair((VarExprent)param);
/* 157:156 */                   String name = enclosingMethod.varproc.getVarName(pair);
/* 158:157 */                   mapNewNames.put(new VarVersionPair(varIndex, 0), name);
/* 159:    */                 }
/* 160:160 */                 varIndex += md_content.params[i].stackSize;
/* 161:    */               }
/* 162:    */             }
/* 163:    */           }
/* 164:    */         }
/* 165:166 */         return 0;
/* 166:    */       }
/* 167:170 */     });
/* 168:171 */     Set<String> setNewOuterNames = new HashSet(mapNewNames.values());
/* 169:172 */     setNewOuterNames.removeAll(method.setOuterVarNames);
/* 170:    */     
/* 171:174 */     method.varproc.refreshVarNames(new VarNamesCollector(setNewOuterNames));
/* 172:175 */     method.setOuterVarNames.addAll(setNewOuterNames);
/* 173:177 */     for (Map.Entry<VarVersionPair, String> entry : mapNewNames.entrySet()) {
/* 174:178 */       method.varproc.setVarName((VarVersionPair)entry.getKey(), (String)entry.getValue());
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   private static void checkNotFoundClasses(ClassesProcessor.ClassNode root, ClassesProcessor.ClassNode node)
/* 179:    */   {
/* 180:183 */     List<ClassesProcessor.ClassNode> copy = new ArrayList(node.nested);
/* 181:185 */     for (ClassesProcessor.ClassNode child : copy) {
/* 182:186 */       if (!child.classStruct.hasModifier(4096)) {
/* 183:190 */         if (((child.type == 4) || (child.type == 2)) && (child.enclosingMethod == null))
/* 184:    */         {
/* 185:191 */           Set<String> setEnclosing = child.enclosingClasses;
/* 186:193 */           if (!setEnclosing.isEmpty())
/* 187:    */           {
/* 188:194 */             StructEnclosingMethodAttribute attr = (StructEnclosingMethodAttribute)child.classStruct.getAttributes().getWithKey("EnclosingMethod");
/* 189:196 */             if ((attr != null) && (attr.getMethodName() != null) && (node.classStruct.qualifiedName.equals(attr.getClassName())) && (node.classStruct.getMethod(attr.getMethodName(), attr.getMethodDescriptor()) != null))
/* 190:    */             {
/* 191:200 */               child.enclosingMethod = InterpreterUtil.makeUniqueKey(attr.getMethodName(), attr.getMethodDescriptor());
/* 192:201 */               continue;
/* 193:    */             }
/* 194:    */           }
/* 195:205 */           node.nested.remove(child);
/* 196:206 */           child.parent = null;
/* 197:207 */           setEnclosing.remove(node.classStruct.qualifiedName);
/* 198:    */           
/* 199:209 */           boolean hasEnclosing = (!setEnclosing.isEmpty()) && (insertNestedClass(root, child));
/* 200:211 */           if (!hasEnclosing) {
/* 201:212 */             if (child.type == 2)
/* 202:    */             {
/* 203:213 */               String message = "Unreferenced anonymous class " + child.classStruct.qualifiedName + "!";
/* 204:214 */               DecompilerContext.getLogger().writeMessage(message, IFernflowerLogger.Severity.WARN);
/* 205:    */             }
/* 206:216 */             else if (child.type == 4)
/* 207:    */             {
/* 208:217 */               String message = "Unreferenced local class " + child.classStruct.qualifiedName + "!";
/* 209:218 */               DecompilerContext.getLogger().writeMessage(message, IFernflowerLogger.Severity.WARN);
/* 210:    */             }
/* 211:    */           }
/* 212:    */         }
/* 213:    */       }
/* 214:    */     }
/* 215:    */   }
/* 216:    */   
/* 217:    */   private static boolean insertNestedClass(ClassesProcessor.ClassNode root, ClassesProcessor.ClassNode child)
/* 218:    */   {
/* 219:226 */     Set<String> setEnclosing = child.enclosingClasses;
/* 220:    */     
/* 221:228 */     LinkedList<ClassesProcessor.ClassNode> stack = new LinkedList();
/* 222:229 */     stack.add(root);
/* 223:231 */     while (!stack.isEmpty())
/* 224:    */     {
/* 225:232 */       ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)stack.removeFirst();
/* 226:234 */       if (setEnclosing.contains(node.classStruct.qualifiedName))
/* 227:    */       {
/* 228:235 */         node.nested.add(child);
/* 229:236 */         child.parent = node;
/* 230:    */         
/* 231:238 */         return true;
/* 232:    */       }
/* 233:242 */       stack.addAll(node.nested);
/* 234:    */     }
/* 235:245 */     return false;
/* 236:    */   }
/* 237:    */   
/* 238:    */   private static void computeLocalVarsAndDefinitions(final ClassesProcessor.ClassNode node)
/* 239:    */   {
/* 240:251 */     Map<String, Map<String, List<VarFieldPair>>> mapVarMasks = new HashMap();
/* 241:    */     
/* 242:253 */     int clTypes = 0;
/* 243:255 */     for (ClassesProcessor.ClassNode nd : node.nested) {
/* 244:256 */       if (!nd.classStruct.hasModifier(4096)) {
/* 245:260 */         if ((nd.type != 8) && ((nd.access & 0x8) == 0) && ((nd.access & 0x200) == 0))
/* 246:    */         {
/* 247:263 */           clTypes |= nd.type;
/* 248:    */           
/* 249:265 */           Map<String, List<VarFieldPair>> mask = getMaskLocalVars(nd.getWrapper());
/* 250:266 */           if (mask.isEmpty())
/* 251:    */           {
/* 252:267 */             String message = "Nested class " + nd.classStruct.qualifiedName + " has no constructor!";
/* 253:268 */             DecompilerContext.getLogger().writeMessage(message, IFernflowerLogger.Severity.WARN);
/* 254:    */           }
/* 255:    */           else
/* 256:    */           {
/* 257:271 */             mapVarMasks.put(nd.classStruct.qualifiedName, mask);
/* 258:    */           }
/* 259:    */         }
/* 260:    */       }
/* 261:    */     }
/* 262:277 */     final Map<String, Map<String, List<VarFieldPair>>> mapVarFieldPairs = new HashMap();
/* 263:279 */     if (clTypes != 1) {
/* 264:281 */       for (final MethodWrapper method : node.getWrapper().getMethods()) {
/* 265:282 */         if (method.root != null) {
/* 266:283 */           method.getOrBuildGraph().iterateExprents(new DirectGraph.ExprentIterator()
/* 267:    */           {
/* 268:    */             public int processExprent(Exprent exprent)
/* 269:    */             {
/* 270:286 */               List<Exprent> lst = exprent.getAllExprents(true);
/* 271:287 */               lst.add(exprent);
/* 272:289 */               for (Exprent expr : lst) {
/* 273:290 */                 if (expr.type == 10)
/* 274:    */                 {
/* 275:291 */                   InvocationExprent constructor = ((NewExprent)expr).getConstructor();
/* 276:293 */                   if ((constructor != null) && (this.val$mapVarMasks.containsKey(constructor.getClassname())))
/* 277:    */                   {
/* 278:294 */                     String refClassName = constructor.getClassname();
/* 279:295 */                     ClassesProcessor.ClassNode nestedClassNode = node.getClassNode(refClassName);
/* 280:297 */                     if (nestedClassNode.type != 1)
/* 281:    */                     {
/* 282:298 */                       List<NestedClassProcessor.VarFieldPair> mask = (List)((Map)this.val$mapVarMasks.get(refClassName)).get(constructor.getStringDescriptor());
/* 283:300 */                       if (!mapVarFieldPairs.containsKey(refClassName)) {
/* 284:301 */                         mapVarFieldPairs.put(refClassName, new HashMap());
/* 285:    */                       }
/* 286:304 */                       List<NestedClassProcessor.VarFieldPair> lstTemp = new ArrayList();
/* 287:306 */                       for (int i = 0; i < mask.size(); i++)
/* 288:    */                       {
/* 289:307 */                         Exprent param = (Exprent)constructor.getLstParameters().get(i);
/* 290:308 */                         NestedClassProcessor.VarFieldPair pair = null;
/* 291:310 */                         if ((param.type == 12) && (mask.get(i) != null))
/* 292:    */                         {
/* 293:311 */                           VarVersionPair varPair = new VarVersionPair((VarExprent)param);
/* 294:    */                           
/* 295:    */ 
/* 296:    */ 
/* 297:315 */                           pair = new NestedClassProcessor.VarFieldPair(((NestedClassProcessor.VarFieldPair)mask.get(i)).fieldKey, varPair);
/* 298:    */                         }
/* 299:319 */                         lstTemp.add(pair);
/* 300:    */                       }
/* 301:322 */                       List<NestedClassProcessor.VarFieldPair> pairMask = (List)((Map)mapVarFieldPairs.get(refClassName)).get(constructor.getStringDescriptor());
/* 302:323 */                       if (pairMask == null) {
/* 303:324 */                         pairMask = lstTemp;
/* 304:    */                       } else {
/* 305:327 */                         for (int i = 0; i < pairMask.size(); i++) {
/* 306:328 */                           if (!InterpreterUtil.equalObjects(pairMask.get(i), lstTemp.get(i))) {
/* 307:329 */                             pairMask.set(i, null);
/* 308:    */                           }
/* 309:    */                         }
/* 310:    */                       }
/* 311:334 */                       ((Map)mapVarFieldPairs.get(refClassName)).put(constructor.getStringDescriptor(), pairMask);
/* 312:335 */                       nestedClassNode.enclosingMethod = InterpreterUtil.makeUniqueKey(method.methodStruct.getName(), method.methodStruct.getDescriptor());
/* 313:    */                     }
/* 314:    */                   }
/* 315:    */                 }
/* 316:    */               }
/* 317:342 */               return 0;
/* 318:    */             }
/* 319:    */           });
/* 320:    */         }
/* 321:    */       }
/* 322:    */     }
/* 323:350 */     for (Map.Entry<String, Map<String, List<VarFieldPair>>> enclosing : mapVarMasks.entrySet())
/* 324:    */     {
/* 325:351 */       nestedNode = node.getClassNode((String)enclosing.getKey());
/* 326:    */       
/* 327:    */ 
/* 328:354 */       interPairMask = null;
/* 329:356 */       if (mapVarFieldPairs.containsKey(enclosing.getKey())) {
/* 330:357 */         for (List<VarFieldPair> mask : ((Map)mapVarFieldPairs.get(enclosing.getKey())).values()) {
/* 331:358 */           if (interPairMask == null) {
/* 332:359 */             interPairMask = new ArrayList(mask);
/* 333:    */           } else {
/* 334:362 */             mergeListSignatures(interPairMask, mask, false);
/* 335:    */           }
/* 336:    */         }
/* 337:    */       }
/* 338:367 */       List<VarFieldPair> interMask = null;
/* 339:369 */       for (List<VarFieldPair> mask : ((Map)enclosing.getValue()).values()) {
/* 340:370 */         if (interMask == null) {
/* 341:371 */           interMask = new ArrayList(mask);
/* 342:    */         } else {
/* 343:374 */           mergeListSignatures(interMask, mask, false);
/* 344:    */         }
/* 345:    */       }
/* 346:378 */       if (interPairMask == null)
/* 347:    */       {
/* 348:379 */         interPairMask = interMask != null ? new ArrayList(interMask) : new ArrayList();
/* 349:    */         
/* 350:381 */         boolean found = false;
/* 351:383 */         for (int i = 0; i < interPairMask.size(); i++) {
/* 352:384 */           if (interPairMask.get(i) != null)
/* 353:    */           {
/* 354:385 */             if (found) {
/* 355:386 */               interPairMask.set(i, null);
/* 356:    */             }
/* 357:388 */             found = true;
/* 358:    */           }
/* 359:    */         }
/* 360:    */       }
/* 361:393 */       mergeListSignatures(interPairMask, interMask, true);
/* 362:395 */       for (VarFieldPair pair : interPairMask) {
/* 363:396 */         if ((pair != null) && (pair.fieldKey.length() > 0)) {
/* 364:397 */           nestedNode.mapFieldsToVars.put(pair.fieldKey, pair.varPair);
/* 365:    */         }
/* 366:    */       }
/* 367:402 */       for (Map.Entry<String, List<VarFieldPair>> entry : ((Map)enclosing.getValue()).entrySet())
/* 368:    */       {
/* 369:403 */         mergeListSignatures((List)entry.getValue(), interPairMask, false);
/* 370:    */         
/* 371:405 */         method = nestedNode.getWrapper().getMethodWrapper("<init>", (String)entry.getKey());
/* 372:406 */         method.signatureFields = new ArrayList();
/* 373:408 */         for (VarFieldPair pair : (List)entry.getValue()) {
/* 374:409 */           method.signatureFields.add(pair == null ? null : pair.varPair);
/* 375:    */         }
/* 376:    */       }
/* 377:    */     }
/* 378:    */     ClassesProcessor.ClassNode nestedNode;
/* 379:    */     List<VarFieldPair> interPairMask;
/* 380:    */     MethodWrapper method;
/* 381:    */   }
/* 382:    */   
/* 383:    */   private static void insertLocalVars(ClassesProcessor.ClassNode parent, ClassesProcessor.ClassNode child)
/* 384:    */   {
/* 385:417 */     MethodWrapper enclosingMethod = (MethodWrapper)parent.getWrapper().getMethods().getWithKey(child.enclosingMethod);
/* 386:420 */     for (final MethodWrapper method : child.getWrapper().getMethods()) {
/* 387:421 */       if (method.root != null)
/* 388:    */       {
/* 389:422 */         Map<VarVersionPair, String> mapNewNames = new HashMap();
/* 390:423 */         Map<VarVersionPair, VarType> mapNewTypes = new HashMap();
/* 391:    */         
/* 392:425 */         final Map<Integer, VarVersionPair> mapParamsToNewVars = new HashMap();
/* 393:    */         int index;
/* 394:    */         int varIndex;
/* 395:    */         MethodDescriptor md;
/* 396:426 */         if (method.signatureFields != null)
/* 397:    */         {
/* 398:427 */           index = 0;varIndex = 1;
/* 399:428 */           md = MethodDescriptor.parseDescriptor(method.methodStruct.getDescriptor());
/* 400:430 */           for (VarVersionPair pair : method.signatureFields)
/* 401:    */           {
/* 402:431 */             if (pair != null)
/* 403:    */             {
/* 404:432 */               VarVersionPair newVar = new VarVersionPair(method.counter.getCounterAndIncrement(2), 0);
/* 405:    */               
/* 406:434 */               mapParamsToNewVars.put(Integer.valueOf(varIndex), newVar);
/* 407:    */               
/* 408:436 */               String varName = null;
/* 409:437 */               VarType varType = null;
/* 410:439 */               if (child.type != 1)
/* 411:    */               {
/* 412:440 */                 varName = enclosingMethod.varproc.getVarName(pair);
/* 413:441 */                 varType = enclosingMethod.varproc.getVarType(pair);
/* 414:    */                 
/* 415:443 */                 enclosingMethod.varproc.setVarFinal(pair, 2);
/* 416:    */               }
/* 417:446 */               if ((pair.var == -1) || ("this".equals(varName)))
/* 418:    */               {
/* 419:447 */                 if (parent.simpleName == null) {
/* 420:449 */                   varName = "<VAR_NAMELESS_ENCLOSURE>";
/* 421:    */                 } else {
/* 422:452 */                   varName = parent.simpleName + ".this";
/* 423:    */                 }
/* 424:454 */                 method.varproc.getThisVars().put(newVar, parent.classStruct.qualifiedName);
/* 425:    */               }
/* 426:457 */               mapNewNames.put(newVar, varName);
/* 427:458 */               mapNewTypes.put(newVar, varType);
/* 428:    */             }
/* 429:461 */             varIndex += md.params[(index++)].stackSize;
/* 430:    */           }
/* 431:    */         }
/* 432:465 */         final Map<String, VarVersionPair> mapFieldsToNewVars = new HashMap();
/* 433:466 */         for (ClassesProcessor.ClassNode classNode = child; classNode != null; classNode = classNode.parent) {
/* 434:467 */           for (Map.Entry<String, VarVersionPair> entry : classNode.mapFieldsToVars.entrySet())
/* 435:    */           {
/* 436:468 */             VarVersionPair newVar = new VarVersionPair(method.counter.getCounterAndIncrement(2), 0);
/* 437:    */             
/* 438:470 */             mapFieldsToNewVars.put(InterpreterUtil.makeUniqueKey(classNode.classStruct.qualifiedName, (String)entry.getKey()), newVar);
/* 439:    */             
/* 440:472 */             String varName = null;
/* 441:473 */             VarType varType = null;
/* 442:475 */             if (classNode.type != 1)
/* 443:    */             {
/* 444:476 */               MethodWrapper enclosing_method = (MethodWrapper)classNode.parent.getWrapper().getMethods().getWithKey(classNode.enclosingMethod);
/* 445:    */               
/* 446:478 */               varName = enclosing_method.varproc.getVarName((VarVersionPair)entry.getValue());
/* 447:479 */               varType = enclosing_method.varproc.getVarType((VarVersionPair)entry.getValue());
/* 448:    */               
/* 449:481 */               enclosing_method.varproc.setVarFinal((VarVersionPair)entry.getValue(), 2);
/* 450:    */             }
/* 451:484 */             if ((((VarVersionPair)entry.getValue()).var == -1) || ("this".equals(varName)))
/* 452:    */             {
/* 453:485 */               if (classNode.parent.simpleName == null) {
/* 454:487 */                 varName = "<VAR_NAMELESS_ENCLOSURE>";
/* 455:    */               } else {
/* 456:490 */                 varName = classNode.parent.simpleName + ".this";
/* 457:    */               }
/* 458:492 */               method.varproc.getThisVars().put(newVar, classNode.parent.classStruct.qualifiedName);
/* 459:    */             }
/* 460:495 */             mapNewNames.put(newVar, varName);
/* 461:496 */             mapNewTypes.put(newVar, varType);
/* 462:499 */             if (classNode == child)
/* 463:    */             {
/* 464:500 */               StructField fd = (StructField)child.classStruct.getFields().getWithKey(entry.getKey());
/* 465:501 */               child.getWrapper().getHiddenMembers().add(InterpreterUtil.makeUniqueKey(fd.getName(), fd.getDescriptor()));
/* 466:    */             }
/* 467:    */           }
/* 468:    */         }
/* 469:506 */         Set<String> setNewOuterNames = new HashSet(mapNewNames.values());
/* 470:507 */         setNewOuterNames.removeAll(method.setOuterVarNames);
/* 471:    */         
/* 472:509 */         method.varproc.refreshVarNames(new VarNamesCollector(setNewOuterNames));
/* 473:510 */         method.setOuterVarNames.addAll(setNewOuterNames);
/* 474:512 */         for (Map.Entry<VarVersionPair, String> entry : mapNewNames.entrySet())
/* 475:    */         {
/* 476:513 */           VarVersionPair pair = (VarVersionPair)entry.getKey();
/* 477:514 */           VarType type = (VarType)mapNewTypes.get(pair);
/* 478:    */           
/* 479:516 */           method.varproc.setVarName(pair, (String)entry.getValue());
/* 480:517 */           if (type != null) {
/* 481:518 */             method.varproc.setVarType(pair, type);
/* 482:    */           }
/* 483:    */         }
/* 484:522 */         method.getOrBuildGraph().iterateExprents(new DirectGraph.ExprentIterator()
/* 485:    */         {
/* 486:    */           public int processExprent(Exprent exprent)
/* 487:    */           {
/* 488:525 */             if (exprent.type == 2)
/* 489:    */             {
/* 490:526 */               AssignmentExprent assignExpr = (AssignmentExprent)exprent;
/* 491:527 */               if (assignExpr.getLeft().type == 5)
/* 492:    */               {
/* 493:528 */                 FieldExprent fExpr = (FieldExprent)assignExpr.getLeft();
/* 494:529 */                 String qName = this.val$child.classStruct.qualifiedName;
/* 495:530 */                 if ((fExpr.getClassname().equals(qName)) && (mapFieldsToNewVars.containsKey(InterpreterUtil.makeUniqueKey(qName, fExpr.getName(), fExpr.getDescriptor().descriptorString)))) {
/* 496:532 */                   return 2;
/* 497:    */                 }
/* 498:    */               }
/* 499:    */             }
/* 500:537 */             if ((this.val$child.type == 2) && ("<init>".equals(method.methodStruct.getName())) && (exprent.type == 8))
/* 501:    */             {
/* 502:540 */               InvocationExprent invokeExpr = (InvocationExprent)exprent;
/* 503:541 */               if (invokeExpr.getFunctype() == 2)
/* 504:    */               {
/* 505:543 */                 this.val$child.superInvocation = invokeExpr;
/* 506:544 */                 return 2;
/* 507:    */               }
/* 508:    */             }
/* 509:548 */             replaceExprent(exprent);
/* 510:    */             
/* 511:550 */             return 0;
/* 512:    */           }
/* 513:    */           
/* 514:    */           private Exprent replaceExprent(Exprent exprent)
/* 515:    */           {
/* 516:554 */             if (exprent.type == 12)
/* 517:    */             {
/* 518:555 */               int varIndex = ((VarExprent)exprent).getIndex();
/* 519:556 */               if (mapParamsToNewVars.containsKey(Integer.valueOf(varIndex)))
/* 520:    */               {
/* 521:557 */                 VarVersionPair newVar = (VarVersionPair)mapParamsToNewVars.get(Integer.valueOf(varIndex));
/* 522:558 */                 method.varproc.getExternalVars().add(newVar);
/* 523:559 */                 return new VarExprent(newVar.var, method.varproc.getVarType(newVar), method.varproc);
/* 524:    */               }
/* 525:    */             }
/* 526:562 */             else if (exprent.type == 5)
/* 527:    */             {
/* 528:563 */               FieldExprent fExpr = (FieldExprent)exprent;
/* 529:564 */               String key = InterpreterUtil.makeUniqueKey(fExpr.getClassname(), fExpr.getName(), fExpr.getDescriptor().descriptorString);
/* 530:565 */               if (mapFieldsToNewVars.containsKey(key))
/* 531:    */               {
/* 532:568 */                 VarVersionPair newVar = (VarVersionPair)mapFieldsToNewVars.get(key);
/* 533:569 */                 method.varproc.getExternalVars().add(newVar);
/* 534:570 */                 return new VarExprent(newVar.var, method.varproc.getVarType(newVar), method.varproc);
/* 535:    */               }
/* 536:    */             }
/* 537:574 */             boolean replaced = true;
/* 538:575 */             while (replaced)
/* 539:    */             {
/* 540:576 */               replaced = false;
/* 541:578 */               for (Exprent expr : exprent.getAllExprents())
/* 542:    */               {
/* 543:579 */                 Exprent retExpr = replaceExprent(expr);
/* 544:580 */                 if (retExpr != null)
/* 545:    */                 {
/* 546:581 */                   exprent.replaceExprent(expr, retExpr);
/* 547:582 */                   replaced = true;
/* 548:583 */                   break;
/* 549:    */                 }
/* 550:    */               }
/* 551:    */             }
/* 552:588 */             return null;
/* 553:    */           }
/* 554:    */         });
/* 555:    */       }
/* 556:    */     }
/* 557:    */   }
/* 558:    */   
/* 559:    */   private static Map<String, List<VarFieldPair>> getMaskLocalVars(ClassWrapper wrapper)
/* 560:    */   {
/* 561:596 */     Map<String, List<VarFieldPair>> mapMasks = new HashMap();
/* 562:    */     
/* 563:598 */     StructClass cl = wrapper.getClassStruct();
/* 564:601 */     for (StructMethod mt : cl.getMethods()) {
/* 565:602 */       if ("<init>".equals(mt.getName()))
/* 566:    */       {
/* 567:603 */         MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/* 568:604 */         MethodWrapper method = wrapper.getMethodWrapper("<init>", mt.getDescriptor());
/* 569:605 */         DirectGraph graph = method.getOrBuildGraph();
/* 570:607 */         if (graph != null)
/* 571:    */         {
/* 572:608 */           List<VarFieldPair> fields = new ArrayList();
/* 573:    */           
/* 574:610 */           int varIndex = 1;
/* 575:611 */           for (int i = 0; i < md.params.length; i++)
/* 576:    */           {
/* 577:612 */             String keyField = getEnclosingVarField(cl, method, graph, varIndex);
/* 578:613 */             fields.add(keyField == null ? null : new VarFieldPair(keyField, new VarVersionPair(-1, 0)));
/* 579:614 */             varIndex += md.params[i].stackSize;
/* 580:    */           }
/* 581:617 */           mapMasks.put(mt.getDescriptor(), fields);
/* 582:    */         }
/* 583:    */       }
/* 584:    */     }
/* 585:622 */     return mapMasks;
/* 586:    */   }
/* 587:    */   
/* 588:    */   private static String getEnclosingVarField(StructClass cl, MethodWrapper method, DirectGraph graph, int index)
/* 589:    */   {
/* 590:626 */     String field = "";
/* 591:629 */     if (method.varproc.getVarFinal(new VarVersionPair(index, 0)) == 1) {
/* 592:630 */       return null;
/* 593:    */     }
/* 594:633 */     boolean noSynthFlag = DecompilerContext.getOption("nns");
/* 595:    */     
/* 596:    */ 
/* 597:636 */     DirectNode firstNode = graph.first;
/* 598:637 */     if (firstNode.preds.isEmpty()) {
/* 599:639 */       for (Exprent exprent : firstNode.exprents) {
/* 600:640 */         if (exprent.type == 2)
/* 601:    */         {
/* 602:641 */           AssignmentExprent assignExpr = (AssignmentExprent)exprent;
/* 603:642 */           if ((assignExpr.getRight().type == 12) && (((VarExprent)assignExpr.getRight()).getIndex() == index) && (assignExpr.getLeft().type == 5))
/* 604:    */           {
/* 605:645 */             FieldExprent left = (FieldExprent)assignExpr.getLeft();
/* 606:646 */             StructField fd = cl.getField(left.getName(), left.getDescriptor().descriptorString);
/* 607:648 */             if ((fd != null) && (cl.qualifiedName.equals(left.getClassname())) && (fd.hasModifier(16)) && ((fd.isSynthetic()) || ((noSynthFlag) && (fd.hasModifier(2)))))
/* 608:    */             {
/* 609:652 */               field = InterpreterUtil.makeUniqueKey(left.getName(), left.getDescriptor().descriptorString);
/* 610:653 */               break;
/* 611:    */             }
/* 612:    */           }
/* 613:    */         }
/* 614:    */       }
/* 615:    */     }
/* 616:660 */     return field;
/* 617:    */   }
/* 618:    */   
/* 619:    */   private static void mergeListSignatures(List<VarFieldPair> first, List<VarFieldPair> second, boolean both)
/* 620:    */   {
/* 621:664 */     int i = 1;
/* 622:667 */     while ((first.size() > i) && (second.size() > i))
/* 623:    */     {
/* 624:671 */       VarFieldPair fObj = (VarFieldPair)first.get(first.size() - i);
/* 625:672 */       VarFieldPair sObj = (VarFieldPair)second.get(second.size() - i);
/* 626:674 */       if (!isEqual(both, fObj, sObj))
/* 627:    */       {
/* 628:675 */         first.set(first.size() - i, null);
/* 629:676 */         if (both) {
/* 630:677 */           second.set(second.size() - i, null);
/* 631:    */         }
/* 632:    */       }
/* 633:680 */       else if (fObj != null)
/* 634:    */       {
/* 635:681 */         if (fObj.varPair.var == -1) {
/* 636:682 */           fObj.varPair = sObj.varPair;
/* 637:    */         } else {
/* 638:685 */           sObj.varPair = fObj.varPair;
/* 639:    */         }
/* 640:    */       }
/* 641:689 */       i++;
/* 642:    */     }
/* 643:692 */     for (int j = 1; j <= first.size() - i; j++) {
/* 644:693 */       first.set(j, null);
/* 645:    */     }
/* 646:696 */     if (both) {
/* 647:697 */       for (int j = 1; j <= second.size() - i; j++) {
/* 648:698 */         second.set(j, null);
/* 649:    */       }
/* 650:    */     }
/* 651:703 */     if (first.isEmpty())
/* 652:    */     {
/* 653:704 */       if ((!second.isEmpty()) && (both)) {
/* 654:705 */         second.set(0, null);
/* 655:    */       }
/* 656:    */     }
/* 657:708 */     else if (second.isEmpty())
/* 658:    */     {
/* 659:709 */       first.set(0, null);
/* 660:    */     }
/* 661:    */     else
/* 662:    */     {
/* 663:712 */       VarFieldPair fObj = (VarFieldPair)first.get(0);
/* 664:713 */       VarFieldPair sObj = (VarFieldPair)second.get(0);
/* 665:715 */       if (!isEqual(both, fObj, sObj))
/* 666:    */       {
/* 667:716 */         first.set(0, null);
/* 668:717 */         if (both) {
/* 669:718 */           second.set(0, null);
/* 670:    */         }
/* 671:    */       }
/* 672:721 */       else if (fObj != null)
/* 673:    */       {
/* 674:722 */         if (fObj.varPair.var == -1) {
/* 675:723 */           fObj.varPair = sObj.varPair;
/* 676:    */         } else {
/* 677:726 */           sObj.varPair = fObj.varPair;
/* 678:    */         }
/* 679:    */       }
/* 680:    */     }
/* 681:    */   }
/* 682:    */   
/* 683:    */   private static boolean isEqual(boolean both, VarFieldPair fObj, VarFieldPair sObj)
/* 684:    */   {
/* 685:    */     boolean eq;
/* 686:    */     boolean eq;
/* 687:734 */     if ((fObj == null) || (sObj == null))
/* 688:    */     {
/* 689:735 */       eq = fObj == sObj;
/* 690:    */     }
/* 691:    */     else
/* 692:    */     {
/* 693:738 */       eq = true;
/* 694:739 */       if (fObj.fieldKey.length() == 0) {
/* 695:740 */         fObj.fieldKey = sObj.fieldKey;
/* 696:742 */       } else if (sObj.fieldKey.length() == 0)
/* 697:    */       {
/* 698:743 */         if (both) {
/* 699:744 */           sObj.fieldKey = fObj.fieldKey;
/* 700:    */         }
/* 701:    */       }
/* 702:    */       else {
/* 703:748 */         eq = fObj.fieldKey.equals(sObj.fieldKey);
/* 704:    */       }
/* 705:    */     }
/* 706:751 */     return eq;
/* 707:    */   }
/* 708:    */   
/* 709:    */   private static void setLocalClassDefinition(MethodWrapper method, ClassesProcessor.ClassNode node)
/* 710:    */   {
/* 711:755 */     RootStatement root = method.root;
/* 712:    */     
/* 713:757 */     Set<Statement> setStats = new HashSet();
/* 714:758 */     VarType classType = new VarType(node.classStruct.qualifiedName, true);
/* 715:    */     
/* 716:760 */     Statement statement = getDefStatement(root, classType, setStats);
/* 717:761 */     if (statement == null) {
/* 718:763 */       statement = root.getFirst();
/* 719:    */     }
/* 720:766 */     Statement first = findFirstBlock(statement, setStats);
/* 721:    */     List<Exprent> lst;
/* 722:    */     List<Exprent> lst;
/* 723:770 */     if (first == null)
/* 724:    */     {
/* 725:771 */       lst = statement.getVarDefinitions();
/* 726:    */     }
/* 727:    */     else
/* 728:    */     {
/* 729:    */       List<Exprent> lst;
/* 730:773 */       if (first.getExprents() == null) {
/* 731:774 */         lst = first.getVarDefinitions();
/* 732:    */       } else {
/* 733:777 */         lst = first.getExprents();
/* 734:    */       }
/* 735:    */     }
/* 736:780 */     int addIndex = 0;
/* 737:781 */     for (Exprent expr : lst)
/* 738:    */     {
/* 739:782 */       if (searchForClass(expr, classType)) {
/* 740:    */         break;
/* 741:    */       }
/* 742:785 */       addIndex++;
/* 743:    */     }
/* 744:788 */     VarExprent var = new VarExprent(method.counter.getCounterAndIncrement(2), classType, method.varproc);
/* 745:789 */     var.setDefinition(true);
/* 746:790 */     var.setClassDef(true);
/* 747:    */     
/* 748:792 */     lst.add(addIndex, var);
/* 749:    */   }
/* 750:    */   
/* 751:    */   private static Statement findFirstBlock(Statement stat, Set<Statement> setStats)
/* 752:    */   {
/* 753:796 */     LinkedList<Statement> stack = new LinkedList();
/* 754:797 */     stack.add(stat);
/* 755:799 */     while (!stack.isEmpty())
/* 756:    */     {
/* 757:800 */       Statement st = (Statement)stack.remove(0);
/* 758:802 */       if ((stack.isEmpty()) || (setStats.contains(st)))
/* 759:    */       {
/* 760:803 */         if (((st.isLabeled()) && (!stack.isEmpty())) || (st.getExprents() != null)) {
/* 761:804 */           return st;
/* 762:    */         }
/* 763:807 */         stack.clear();
/* 764:810 */         switch (st.type)
/* 765:    */         {
/* 766:    */         case 15: 
/* 767:812 */           stack.addAll(0, st.getStats());
/* 768:813 */           break;
/* 769:    */         case 2: 
/* 770:    */         case 6: 
/* 771:    */         case 10: 
/* 772:    */         case 13: 
/* 773:818 */           stack.add(st.getFirst());
/* 774:819 */           break;
/* 775:    */         case 3: 
/* 776:    */         case 4: 
/* 777:    */         case 5: 
/* 778:    */         case 7: 
/* 779:    */         case 8: 
/* 780:    */         case 9: 
/* 781:    */         case 11: 
/* 782:    */         case 12: 
/* 783:    */         case 14: 
/* 784:    */         default: 
/* 785:821 */           return st;
/* 786:    */         }
/* 787:    */       }
/* 788:    */     }
/* 789:826 */     return null;
/* 790:    */   }
/* 791:    */   
/* 792:    */   private static Statement getDefStatement(Statement stat, VarType classType, Set<Statement> setStats)
/* 793:    */   {
/* 794:830 */     List<Exprent> lst = new ArrayList();
/* 795:831 */     Statement retStat = null;
/* 796:    */     int counter;
/* 797:833 */     if (stat.getExprents() == null)
/* 798:    */     {
/* 799:834 */       counter = 0;
/* 800:836 */       for (Object obj : stat.getSequentialObjects()) {
/* 801:837 */         if ((obj instanceof Statement))
/* 802:    */         {
/* 803:838 */           Statement st = (Statement)obj;
/* 804:    */           
/* 805:840 */           Statement stTemp = getDefStatement(st, classType, setStats);
/* 806:842 */           if (stTemp != null)
/* 807:    */           {
/* 808:843 */             if (counter == 1)
/* 809:    */             {
/* 810:844 */               retStat = stat;
/* 811:845 */               break;
/* 812:    */             }
/* 813:847 */             retStat = stTemp;
/* 814:848 */             counter++;
/* 815:    */           }
/* 816:851 */           if (st.type == 5)
/* 817:    */           {
/* 818:852 */             DoStatement dost = (DoStatement)st;
/* 819:    */             
/* 820:854 */             lst.addAll(dost.getInitExprentList());
/* 821:855 */             lst.addAll(dost.getConditionExprentList());
/* 822:    */           }
/* 823:    */         }
/* 824:858 */         else if ((obj instanceof Exprent))
/* 825:    */         {
/* 826:859 */           lst.add((Exprent)obj);
/* 827:    */         }
/* 828:    */       }
/* 829:    */     }
/* 830:    */     else
/* 831:    */     {
/* 832:864 */       lst = stat.getExprents();
/* 833:    */     }
/* 834:867 */     if (retStat != stat) {
/* 835:868 */       for (Exprent exprent : lst) {
/* 836:869 */         if ((exprent != null) && (searchForClass(exprent, classType)))
/* 837:    */         {
/* 838:870 */           retStat = stat;
/* 839:871 */           break;
/* 840:    */         }
/* 841:    */       }
/* 842:    */     }
/* 843:876 */     if (retStat != null) {
/* 844:877 */       setStats.add(stat);
/* 845:    */     }
/* 846:880 */     return retStat;
/* 847:    */   }
/* 848:    */   
/* 849:    */   private static boolean searchForClass(Exprent exprent, VarType classType)
/* 850:    */   {
/* 851:884 */     List<Exprent> lst = exprent.getAllExprents(true);
/* 852:885 */     lst.add(exprent);
/* 853:    */     
/* 854:887 */     String classname = classType.value;
/* 855:889 */     for (Exprent expr : lst)
/* 856:    */     {
/* 857:890 */       boolean res = false;
/* 858:892 */       switch (expr.type)
/* 859:    */       {
/* 860:    */       case 3: 
/* 861:894 */         ConstExprent constExpr = (ConstExprent)expr;
/* 862:895 */         res = ((VarType.VARTYPE_CLASS.equals(constExpr.getConstType())) && (classname.equals(constExpr.getValue()))) || (classType.equals(constExpr.getConstType()));
/* 863:    */         
/* 864:897 */         break;
/* 865:    */       case 5: 
/* 866:899 */         res = classname.equals(((FieldExprent)expr).getClassname());
/* 867:900 */         break;
/* 868:    */       case 8: 
/* 869:902 */         res = classname.equals(((InvocationExprent)expr).getClassname());
/* 870:903 */         break;
/* 871:    */       case 10: 
/* 872:905 */         VarType newType = expr.getExprType();
/* 873:906 */         res = (newType.type == 8) && (classname.equals(newType.value));
/* 874:907 */         break;
/* 875:    */       case 12: 
/* 876:909 */         VarExprent varExpr = (VarExprent)expr;
/* 877:910 */         if (varExpr.isDefinition())
/* 878:    */         {
/* 879:911 */           VarType varType = varExpr.getVarType();
/* 880:912 */           if ((classType.equals(varType)) || ((varType.arrayDim > 0) && (classType.value.equals(varType.value)))) {
/* 881:913 */             res = true;
/* 882:    */           }
/* 883:    */         }
/* 884:    */         break;
/* 885:    */       }
/* 886:918 */       if (res) {
/* 887:919 */         return true;
/* 888:    */       }
/* 889:    */     }
/* 890:923 */     return false;
/* 891:    */   }
/* 892:    */   
/* 893:    */   private static class VarFieldPair
/* 894:    */   {
/* 895:927 */     public String fieldKey = "";
/* 896:    */     public VarVersionPair varPair;
/* 897:    */     
/* 898:    */     public VarFieldPair(String field, VarVersionPair varPair)
/* 899:    */     {
/* 900:931 */       this.fieldKey = field;
/* 901:932 */       this.varPair = varPair;
/* 902:    */     }
/* 903:    */     
/* 904:    */     public boolean equals(Object o)
/* 905:    */     {
/* 906:937 */       if (o == this) {
/* 907:937 */         return true;
/* 908:    */       }
/* 909:938 */       if ((o == null) || (!(o instanceof VarFieldPair))) {
/* 910:938 */         return false;
/* 911:    */       }
/* 912:940 */       VarFieldPair pair = (VarFieldPair)o;
/* 913:941 */       return (this.fieldKey.equals(pair.fieldKey)) && (this.varPair.equals(pair.varPair));
/* 914:    */     }
/* 915:    */     
/* 916:    */     public int hashCode()
/* 917:    */     {
/* 918:946 */       return this.fieldKey.hashCode() + this.varPair.hashCode();
/* 919:    */     }
/* 920:    */   }
/* 921:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.rels.NestedClassProcessor
 * JD-Core Version:    0.7.0.1
 */