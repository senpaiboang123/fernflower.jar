/*    1:     */ package org.jetbrains.java.decompiler.main;
/*    2:     */ 
/*    3:     */ import java.util.Iterator;
/*    4:     */ import java.util.LinkedHashMap;
/*    5:     */ import java.util.List;
/*    6:     */ import java.util.Map;
/*    7:     */ import java.util.Set;
/*    8:     */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*    9:     */ import org.jetbrains.java.decompiler.main.collectors.BytecodeSourceMapper;
/*   10:     */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*   11:     */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*   12:     */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*   13:     */ import org.jetbrains.java.decompiler.main.rels.MethodWrapper;
/*   14:     */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*   15:     */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AnnotationExprent;
/*   16:     */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*   17:     */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*   18:     */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*   19:     */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DummyExitStatement;
/*   20:     */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*   21:     */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*   22:     */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*   23:     */ import org.jetbrains.java.decompiler.modules.renamer.PoolInterceptor;
/*   24:     */ import org.jetbrains.java.decompiler.struct.StructClass;
/*   25:     */ import org.jetbrains.java.decompiler.struct.StructField;
/*   26:     */ import org.jetbrains.java.decompiler.struct.StructMember;
/*   27:     */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*   28:     */ import org.jetbrains.java.decompiler.struct.attr.StructAnnDefaultAttribute;
/*   29:     */ import org.jetbrains.java.decompiler.struct.attr.StructAnnotationAttribute;
/*   30:     */ import org.jetbrains.java.decompiler.struct.attr.StructAnnotationParameterAttribute;
/*   31:     */ import org.jetbrains.java.decompiler.struct.attr.StructConstantValueAttribute;
/*   32:     */ import org.jetbrains.java.decompiler.struct.attr.StructExceptionsAttribute;
/*   33:     */ import org.jetbrains.java.decompiler.struct.attr.StructGenericSignatureAttribute;
/*   34:     */ import org.jetbrains.java.decompiler.struct.attr.StructLineNumberTableAttribute;
/*   35:     */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*   36:     */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*   37:     */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*   38:     */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*   39:     */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*   40:     */ import org.jetbrains.java.decompiler.struct.gen.generics.GenericClassDescriptor;
/*   41:     */ import org.jetbrains.java.decompiler.struct.gen.generics.GenericFieldDescriptor;
/*   42:     */ import org.jetbrains.java.decompiler.struct.gen.generics.GenericMain;
/*   43:     */ import org.jetbrains.java.decompiler.struct.gen.generics.GenericMethodDescriptor;
/*   44:     */ import org.jetbrains.java.decompiler.struct.gen.generics.GenericType;
/*   45:     */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*   46:     */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*   47:     */ 
/*   48:     */ public class ClassWriter
/*   49:     */ {
/*   50:     */   private final ClassReference14Processor ref14processor;
/*   51:     */   private final PoolInterceptor interceptor;
/*   52:     */   
/*   53:     */   public ClassWriter()
/*   54:     */   {
/*   55:  53 */     this.ref14processor = new ClassReference14Processor();
/*   56:  54 */     this.interceptor = DecompilerContext.getPoolInterceptor();
/*   57:     */   }
/*   58:     */   
/*   59:     */   private void invokeProcessors(ClassesProcessor.ClassNode node)
/*   60:     */   {
/*   61:  58 */     ClassWrapper wrapper = node.getWrapper();
/*   62:  59 */     StructClass cl = wrapper.getClassStruct();
/*   63:     */     
/*   64:  61 */     InitializerProcessor.extractInitializers(wrapper);
/*   65:  63 */     if ((node.type == 0) && (DecompilerContext.getOption("dc4"))) {
/*   66:  64 */       this.ref14processor.processClassReferences(node);
/*   67:     */     }
/*   68:  67 */     if ((cl.hasModifier(16384)) && (DecompilerContext.getOption("den"))) {
/*   69:  68 */       EnumProcessor.clearEnum(wrapper);
/*   70:     */     }
/*   71:  71 */     if (DecompilerContext.getOption("das")) {
/*   72:  72 */       AssertProcessor.buildAssertions(node);
/*   73:     */     }
/*   74:     */   }
/*   75:     */   
/*   76:     */   public void classLambdaToJava(ClassesProcessor.ClassNode node, TextBuffer buffer, Exprent method_object, int indent, BytecodeMappingTracer origTracer)
/*   77:     */   {
/*   78:  77 */     ClassWrapper wrapper = node.getWrapper();
/*   79:  78 */     if (wrapper == null) {
/*   80:  79 */       return;
/*   81:     */     }
/*   82:  82 */     boolean lambdaToAnonymous = DecompilerContext.getOption("lac");
/*   83:     */     
/*   84:  84 */     ClassesProcessor.ClassNode outerNode = (ClassesProcessor.ClassNode)DecompilerContext.getProperty("CURRENT_CLASS_NODE");
/*   85:  85 */     DecompilerContext.setProperty("CURRENT_CLASS_NODE", node);
/*   86:     */     
/*   87:  87 */     BytecodeMappingTracer tracer = new BytecodeMappingTracer(origTracer.getCurrentSourceLine());
/*   88:     */     try
/*   89:     */     {
/*   90:  90 */       StructClass cl = wrapper.getClassStruct();
/*   91:     */       
/*   92:  92 */       DecompilerContext.getLogger().startWriteClass(node.simpleName);
/*   93:  94 */       if (node.lambdaInformation.is_method_reference)
/*   94:     */       {
/*   95:  95 */         if ((!node.lambdaInformation.is_content_method_static) && (method_object != null)) {
/*   96:  97 */           buffer.append(method_object.toJava(indent, tracer));
/*   97:     */         } else {
/*   98: 101 */           buffer.append(ExprProcessor.getCastTypeName(new VarType(node.lambdaInformation.content_class_name, false)));
/*   99:     */         }
/*  100: 104 */         buffer.append("::");
/*  101: 105 */         buffer.append(node.lambdaInformation.content_method_name);
/*  102:     */       }
/*  103:     */       else
/*  104:     */       {
/*  105: 109 */         StructMethod mt = cl.getMethod(node.lambdaInformation.content_method_key);
/*  106: 110 */         MethodWrapper methodWrapper = wrapper.getMethodWrapper(mt.getName(), mt.getDescriptor());
/*  107: 111 */         MethodDescriptor md_content = MethodDescriptor.parseDescriptor(node.lambdaInformation.content_method_descriptor);
/*  108: 112 */         MethodDescriptor md_lambda = MethodDescriptor.parseDescriptor(node.lambdaInformation.method_descriptor);
/*  109: 114 */         if (!lambdaToAnonymous)
/*  110:     */         {
/*  111: 115 */           buffer.append('(');
/*  112:     */           
/*  113: 117 */           boolean firstParameter = true;
/*  114: 118 */           int index = node.lambdaInformation.is_content_method_static ? 0 : 1;
/*  115: 119 */           int start_index = md_content.params.length - md_lambda.params.length;
/*  116: 121 */           for (int i = 0; i < md_content.params.length; i++)
/*  117:     */           {
/*  118: 122 */             if (i >= start_index)
/*  119:     */             {
/*  120: 123 */               if (!firstParameter) {
/*  121: 124 */                 buffer.append(", ");
/*  122:     */               }
/*  123: 127 */               String parameterName = methodWrapper.varproc.getVarName(new VarVersionPair(index, 0));
/*  124: 128 */               buffer.append(parameterName == null ? "param" + index : parameterName);
/*  125:     */               
/*  126: 130 */               firstParameter = false;
/*  127:     */             }
/*  128: 133 */             index += md_content.params[i].stackSize;
/*  129:     */           }
/*  130: 136 */           buffer.append(") ->");
/*  131:     */         }
/*  132: 139 */         buffer.append(" {").appendLineSeparator();
/*  133: 140 */         tracer.incrementCurrentSourceLine();
/*  134:     */         
/*  135: 142 */         methodLambdaToJava(node, wrapper, mt, buffer, indent + 1, !lambdaToAnonymous, tracer);
/*  136:     */         
/*  137: 144 */         buffer.appendIndent(indent).append("}");
/*  138:     */         
/*  139: 146 */         addTracer(cl, mt, tracer);
/*  140:     */       }
/*  141:     */     }
/*  142:     */     finally
/*  143:     */     {
/*  144: 150 */       DecompilerContext.setProperty("CURRENT_CLASS_NODE", outerNode);
/*  145:     */     }
/*  146: 153 */     DecompilerContext.getLogger().endWriteClass();
/*  147:     */   }
/*  148:     */   
/*  149:     */   public void classToJava(ClassesProcessor.ClassNode node, TextBuffer buffer, int indent, BytecodeMappingTracer tracer)
/*  150:     */   {
/*  151: 157 */     ClassesProcessor.ClassNode outerNode = (ClassesProcessor.ClassNode)DecompilerContext.getProperty("CURRENT_CLASS_NODE");
/*  152: 158 */     DecompilerContext.setProperty("CURRENT_CLASS_NODE", node);
/*  153:     */     
/*  154: 160 */     int startLine = tracer != null ? tracer.getCurrentSourceLine() : 0;
/*  155: 161 */     BytecodeMappingTracer dummy_tracer = new BytecodeMappingTracer(startLine);
/*  156:     */     try
/*  157:     */     {
/*  158: 165 */       invokeProcessors(node);
/*  159:     */       
/*  160: 167 */       ClassWrapper wrapper = node.getWrapper();
/*  161: 168 */       StructClass cl = wrapper.getClassStruct();
/*  162:     */       
/*  163: 170 */       DecompilerContext.getLogger().startWriteClass(cl.qualifiedName);
/*  164:     */       
/*  165:     */ 
/*  166: 173 */       int start_class_def = buffer.length();
/*  167: 174 */       writeClassDefinition(node, buffer, indent);
/*  168:     */       
/*  169: 176 */       boolean hasContent = false;
/*  170: 177 */       boolean enumFields = false;
/*  171:     */       
/*  172: 179 */       dummy_tracer.incrementCurrentSourceLine(buffer.countLines(start_class_def));
/*  173: 181 */       for (StructField fd : cl.getFields())
/*  174:     */       {
/*  175: 182 */         boolean hide = ((fd.isSynthetic()) && (DecompilerContext.getOption("rsy"))) || (wrapper.getHiddenMembers().contains(InterpreterUtil.makeUniqueKey(fd.getName(), fd.getDescriptor())));
/*  176: 184 */         if (!hide)
/*  177:     */         {
/*  178: 186 */           boolean isEnum = (fd.hasModifier(16384)) && (DecompilerContext.getOption("den"));
/*  179: 187 */           if (isEnum)
/*  180:     */           {
/*  181: 188 */             if (enumFields)
/*  182:     */             {
/*  183: 189 */               buffer.append(',').appendLineSeparator();
/*  184: 190 */               dummy_tracer.incrementCurrentSourceLine();
/*  185:     */             }
/*  186: 192 */             enumFields = true;
/*  187:     */           }
/*  188: 194 */           else if (enumFields)
/*  189:     */           {
/*  190: 195 */             buffer.append(';');
/*  191: 196 */             buffer.appendLineSeparator();
/*  192: 197 */             buffer.appendLineSeparator();
/*  193: 198 */             dummy_tracer.incrementCurrentSourceLine(2);
/*  194: 199 */             enumFields = false;
/*  195:     */           }
/*  196: 202 */           fieldToJava(wrapper, cl, fd, buffer, indent + 1, dummy_tracer);
/*  197:     */           
/*  198: 204 */           hasContent = true;
/*  199:     */         }
/*  200:     */       }
/*  201: 207 */       if (enumFields)
/*  202:     */       {
/*  203: 208 */         buffer.append(';').appendLineSeparator();
/*  204: 209 */         dummy_tracer.incrementCurrentSourceLine();
/*  205:     */       }
/*  206: 213 */       startLine += buffer.countLines(start_class_def);
/*  207: 216 */       for (StructMethod mt : cl.getMethods())
/*  208:     */       {
/*  209: 217 */         boolean hide = ((mt.isSynthetic()) && (DecompilerContext.getOption("rsy"))) || ((mt.hasModifier(64)) && (DecompilerContext.getOption("rbr"))) || (wrapper.getHiddenMembers().contains(InterpreterUtil.makeUniqueKey(mt.getName(), mt.getDescriptor())));
/*  210: 220 */         if (!hide)
/*  211:     */         {
/*  212: 222 */           int position = buffer.length();
/*  213: 223 */           int storedLine = startLine;
/*  214: 224 */           if (hasContent)
/*  215:     */           {
/*  216: 225 */             buffer.appendLineSeparator();
/*  217: 226 */             startLine++;
/*  218:     */           }
/*  219: 228 */           BytecodeMappingTracer method_tracer = new BytecodeMappingTracer(startLine);
/*  220: 229 */           boolean methodSkipped = !methodToJava(node, mt, buffer, indent + 1, method_tracer);
/*  221: 230 */           if (!methodSkipped)
/*  222:     */           {
/*  223: 231 */             hasContent = true;
/*  224: 232 */             addTracer(cl, mt, method_tracer);
/*  225: 233 */             startLine = method_tracer.getCurrentSourceLine();
/*  226:     */           }
/*  227:     */           else
/*  228:     */           {
/*  229: 236 */             buffer.setLength(position);
/*  230: 237 */             startLine = storedLine;
/*  231:     */           }
/*  232:     */         }
/*  233:     */       }
/*  234: 242 */       for (ClassesProcessor.ClassNode inner : node.nested) {
/*  235: 243 */         if (inner.type == 1)
/*  236:     */         {
/*  237: 244 */           StructClass innerCl = inner.classStruct;
/*  238: 245 */           boolean isSynthetic = ((inner.access & 0x1000) != 0) || (innerCl.isSynthetic()) || (inner.namelessConstructorStub);
/*  239: 246 */           boolean hide = ((isSynthetic) && (DecompilerContext.getOption("rsy"))) || (wrapper.getHiddenMembers().contains(innerCl.qualifiedName));
/*  240: 248 */           if (!hide)
/*  241:     */           {
/*  242: 250 */             if (hasContent)
/*  243:     */             {
/*  244: 251 */               buffer.appendLineSeparator();
/*  245: 252 */               startLine++;
/*  246:     */             }
/*  247: 254 */             BytecodeMappingTracer class_tracer = new BytecodeMappingTracer(startLine);
/*  248: 255 */             classToJava(inner, buffer, indent + 1, class_tracer);
/*  249: 256 */             startLine = buffer.countLines();
/*  250:     */             
/*  251: 258 */             hasContent = true;
/*  252:     */           }
/*  253:     */         }
/*  254:     */       }
/*  255: 262 */       buffer.appendIndent(indent).append('}');
/*  256: 264 */       if (node.type != 2) {
/*  257: 265 */         buffer.appendLineSeparator();
/*  258:     */       }
/*  259:     */     }
/*  260:     */     finally
/*  261:     */     {
/*  262: 269 */       DecompilerContext.setProperty("CURRENT_CLASS_NODE", outerNode);
/*  263:     */     }
/*  264: 272 */     DecompilerContext.getLogger().endWriteClass();
/*  265:     */   }
/*  266:     */   
/*  267:     */   private static void addTracer(StructClass cls, StructMethod method, BytecodeMappingTracer tracer)
/*  268:     */   {
/*  269: 276 */     StructLineNumberTableAttribute table = (StructLineNumberTableAttribute)method.getAttributes().getWithKey("LineNumberTable");
/*  270: 277 */     tracer.setLineNumberTable(table);
/*  271: 278 */     String key = InterpreterUtil.makeUniqueKey(method.getName(), method.getDescriptor());
/*  272: 279 */     DecompilerContext.getBytecodeSourceMapper().addTracer(cls.qualifiedName, key, tracer);
/*  273:     */   }
/*  274:     */   
/*  275:     */   private void writeClassDefinition(ClassesProcessor.ClassNode node, TextBuffer buffer, int indent)
/*  276:     */   {
/*  277: 283 */     if (node.type == 2)
/*  278:     */     {
/*  279: 284 */       buffer.append(" {").appendLineSeparator();
/*  280: 285 */       return;
/*  281:     */     }
/*  282: 288 */     ClassWrapper wrapper = node.getWrapper();
/*  283: 289 */     StructClass cl = wrapper.getClassStruct();
/*  284:     */     
/*  285: 291 */     int flags = node.type == 0 ? cl.getAccessFlags() : node.access;
/*  286: 292 */     boolean isDeprecated = cl.getAttributes().containsKey("Deprecated");
/*  287: 293 */     boolean isSynthetic = ((flags & 0x1000) != 0) || (cl.getAttributes().containsKey("Synthetic"));
/*  288: 294 */     boolean isEnum = (DecompilerContext.getOption("den")) && ((flags & 0x4000) != 0);
/*  289: 295 */     boolean isInterface = (flags & 0x200) != 0;
/*  290: 296 */     boolean isAnnotation = (flags & 0x2000) != 0;
/*  291: 298 */     if (isDeprecated) {
/*  292: 299 */       appendDeprecation(buffer, indent);
/*  293:     */     }
/*  294: 302 */     if (this.interceptor != null)
/*  295:     */     {
/*  296: 303 */       String oldName = this.interceptor.getOldName(cl.qualifiedName);
/*  297: 304 */       appendRenameComment(buffer, oldName, MType.CLASS, indent);
/*  298:     */     }
/*  299: 307 */     if (isSynthetic) {
/*  300: 308 */       appendComment(buffer, "synthetic class", indent);
/*  301:     */     }
/*  302: 311 */     appendAnnotations(buffer, cl, indent);
/*  303:     */     
/*  304: 313 */     buffer.appendIndent(indent);
/*  305: 315 */     if (isEnum)
/*  306:     */     {
/*  307: 317 */       flags &= 0xFFFFFBFF;
/*  308: 318 */       flags &= 0xFFFFFFEF;
/*  309:     */     }
/*  310: 321 */     appendModifiers(buffer, flags, 3103, isInterface, 1032);
/*  311: 323 */     if (isEnum)
/*  312:     */     {
/*  313: 324 */       buffer.append("enum ");
/*  314:     */     }
/*  315: 326 */     else if (isInterface)
/*  316:     */     {
/*  317: 327 */       if (isAnnotation) {
/*  318: 328 */         buffer.append('@');
/*  319:     */       }
/*  320: 330 */       buffer.append("interface ");
/*  321:     */     }
/*  322:     */     else
/*  323:     */     {
/*  324: 333 */       buffer.append("class ");
/*  325:     */     }
/*  326: 336 */     GenericClassDescriptor descriptor = null;
/*  327: 337 */     if (DecompilerContext.getOption("dgs"))
/*  328:     */     {
/*  329: 338 */       StructGenericSignatureAttribute attr = (StructGenericSignatureAttribute)cl.getAttributes().getWithKey("Signature");
/*  330: 339 */       if (attr != null) {
/*  331: 340 */         descriptor = GenericMain.parseClassSignature(attr.getSignature());
/*  332:     */       }
/*  333:     */     }
/*  334: 344 */     buffer.append(node.simpleName);
/*  335: 346 */     if ((descriptor != null) && (!descriptor.fparameters.isEmpty())) {
/*  336: 347 */       appendTypeParameters(buffer, descriptor.fparameters, descriptor.fbounds);
/*  337:     */     }
/*  338: 350 */     buffer.append(' ');
/*  339: 352 */     if ((!isEnum) && (!isInterface) && (cl.superClass != null))
/*  340:     */     {
/*  341: 353 */       VarType supertype = new VarType(cl.superClass.getString(), true);
/*  342: 354 */       if (!VarType.VARTYPE_OBJECT.equals(supertype))
/*  343:     */       {
/*  344: 355 */         buffer.append("extends ");
/*  345: 356 */         if (descriptor != null) {
/*  346: 357 */           buffer.append(GenericMain.getGenericCastTypeName(descriptor.superclass));
/*  347:     */         } else {
/*  348: 360 */           buffer.append(ExprProcessor.getCastTypeName(supertype));
/*  349:     */         }
/*  350: 362 */         buffer.append(' ');
/*  351:     */       }
/*  352:     */     }
/*  353: 366 */     if (!isAnnotation)
/*  354:     */     {
/*  355: 367 */       int[] interfaces = cl.getInterfaces();
/*  356: 368 */       if (interfaces.length > 0)
/*  357:     */       {
/*  358: 369 */         buffer.append(isInterface ? "extends " : "implements ");
/*  359: 370 */         for (int i = 0; i < interfaces.length; i++)
/*  360:     */         {
/*  361: 371 */           if (i > 0) {
/*  362: 372 */             buffer.append(", ");
/*  363:     */           }
/*  364: 374 */           if (descriptor != null) {
/*  365: 375 */             buffer.append(GenericMain.getGenericCastTypeName((GenericType)descriptor.superinterfaces.get(i)));
/*  366:     */           } else {
/*  367: 378 */             buffer.append(ExprProcessor.getCastTypeName(new VarType(cl.getInterface(i), true)));
/*  368:     */           }
/*  369:     */         }
/*  370: 381 */         buffer.append(' ');
/*  371:     */       }
/*  372:     */     }
/*  373: 385 */     buffer.append('{').appendLineSeparator();
/*  374:     */   }
/*  375:     */   
/*  376:     */   private void fieldToJava(ClassWrapper wrapper, StructClass cl, StructField fd, TextBuffer buffer, int indent, BytecodeMappingTracer tracer)
/*  377:     */   {
/*  378: 389 */     int start = buffer.length();
/*  379: 390 */     boolean isInterface = cl.hasModifier(512);
/*  380: 391 */     boolean isDeprecated = fd.getAttributes().containsKey("Deprecated");
/*  381: 392 */     boolean isEnum = (fd.hasModifier(16384)) && (DecompilerContext.getOption("den"));
/*  382: 394 */     if (isDeprecated) {
/*  383: 395 */       appendDeprecation(buffer, indent);
/*  384:     */     }
/*  385: 398 */     if (this.interceptor != null)
/*  386:     */     {
/*  387: 399 */       String oldName = this.interceptor.getOldName(cl.qualifiedName + " " + fd.getName() + " " + fd.getDescriptor());
/*  388: 400 */       appendRenameComment(buffer, oldName, MType.FIELD, indent);
/*  389:     */     }
/*  390: 403 */     if (fd.isSynthetic()) {
/*  391: 404 */       appendComment(buffer, "synthetic field", indent);
/*  392:     */     }
/*  393: 407 */     appendAnnotations(buffer, fd, indent);
/*  394:     */     
/*  395: 409 */     buffer.appendIndent(indent);
/*  396: 411 */     if (!isEnum) {
/*  397: 412 */       appendModifiers(buffer, fd.getAccessFlags(), 223, isInterface, 25);
/*  398:     */     }
/*  399: 415 */     VarType fieldType = new VarType(fd.getDescriptor(), false);
/*  400:     */     
/*  401: 417 */     GenericFieldDescriptor descriptor = null;
/*  402: 418 */     if (DecompilerContext.getOption("dgs"))
/*  403:     */     {
/*  404: 419 */       StructGenericSignatureAttribute attr = (StructGenericSignatureAttribute)fd.getAttributes().getWithKey("Signature");
/*  405: 420 */       if (attr != null) {
/*  406: 421 */         descriptor = GenericMain.parseFieldSignature(attr.getSignature());
/*  407:     */       }
/*  408:     */     }
/*  409: 425 */     if (!isEnum)
/*  410:     */     {
/*  411: 426 */       if (descriptor != null) {
/*  412: 427 */         buffer.append(GenericMain.getGenericCastTypeName(descriptor.type));
/*  413:     */       } else {
/*  414: 430 */         buffer.append(ExprProcessor.getCastTypeName(fieldType));
/*  415:     */       }
/*  416: 432 */       buffer.append(' ');
/*  417:     */     }
/*  418: 435 */     buffer.append(fd.getName());
/*  419:     */     
/*  420: 437 */     tracer.incrementCurrentSourceLine(buffer.countLines(start));
/*  421:     */     Exprent initializer;
/*  422:     */     Exprent initializer;
/*  423: 440 */     if (fd.hasModifier(8)) {
/*  424: 441 */       initializer = (Exprent)wrapper.getStaticFieldInitializers().getWithKey(InterpreterUtil.makeUniqueKey(fd.getName(), fd.getDescriptor()));
/*  425:     */     } else {
/*  426: 444 */       initializer = (Exprent)wrapper.getDynamicFieldInitializers().getWithKey(InterpreterUtil.makeUniqueKey(fd.getName(), fd.getDescriptor()));
/*  427:     */     }
/*  428: 446 */     if (initializer != null)
/*  429:     */     {
/*  430: 447 */       if ((isEnum) && (initializer.type == 10))
/*  431:     */       {
/*  432: 448 */         NewExprent nexpr = (NewExprent)initializer;
/*  433: 449 */         nexpr.setEnumConst(true);
/*  434: 450 */         buffer.append(nexpr.toJava(indent, tracer));
/*  435:     */       }
/*  436:     */       else
/*  437:     */       {
/*  438: 453 */         buffer.append(" = ");
/*  439:     */         
/*  440: 455 */         buffer.append(initializer.toJava(indent, tracer));
/*  441:     */       }
/*  442:     */     }
/*  443: 458 */     else if ((fd.hasModifier(16)) && (fd.hasModifier(8)))
/*  444:     */     {
/*  445: 459 */       StructConstantValueAttribute attr = (StructConstantValueAttribute)fd.getAttributes().getWithKey("ConstantValue");
/*  446: 461 */       if (attr != null)
/*  447:     */       {
/*  448: 462 */         PrimitiveConstant constant = cl.getPool().getPrimitiveConstant(attr.getIndex());
/*  449: 463 */         buffer.append(" = ");
/*  450: 464 */         buffer.append(new ConstExprent(fieldType, constant.value, null).toJava(indent, tracer));
/*  451:     */       }
/*  452:     */     }
/*  453: 468 */     if (!isEnum)
/*  454:     */     {
/*  455: 469 */       buffer.append(";").appendLineSeparator();
/*  456: 470 */       tracer.incrementCurrentSourceLine();
/*  457:     */     }
/*  458:     */   }
/*  459:     */   
/*  460:     */   private static void methodLambdaToJava(ClassesProcessor.ClassNode lambdaNode, ClassWrapper classWrapper, StructMethod mt, TextBuffer buffer, int indent, boolean codeOnly, BytecodeMappingTracer tracer)
/*  461:     */   {
/*  462: 480 */     MethodWrapper methodWrapper = classWrapper.getMethodWrapper(mt.getName(), mt.getDescriptor());
/*  463:     */     
/*  464: 482 */     MethodWrapper outerWrapper = (MethodWrapper)DecompilerContext.getProperty("CURRENT_METHOD_WRAPPER");
/*  465: 483 */     DecompilerContext.setProperty("CURRENT_METHOD_WRAPPER", methodWrapper);
/*  466:     */     try
/*  467:     */     {
/*  468: 486 */       String method_name = lambdaNode.lambdaInformation.method_name;
/*  469: 487 */       MethodDescriptor md_content = MethodDescriptor.parseDescriptor(lambdaNode.lambdaInformation.content_method_descriptor);
/*  470: 488 */       MethodDescriptor md_lambda = MethodDescriptor.parseDescriptor(lambdaNode.lambdaInformation.method_descriptor);
/*  471: 490 */       if (!codeOnly)
/*  472:     */       {
/*  473: 491 */         buffer.appendIndent(indent);
/*  474: 492 */         buffer.append("public ");
/*  475: 493 */         buffer.append(method_name);
/*  476: 494 */         buffer.append("(");
/*  477:     */         
/*  478: 496 */         boolean firstParameter = true;
/*  479: 497 */         int index = lambdaNode.lambdaInformation.is_content_method_static ? 0 : 1;
/*  480: 498 */         int start_index = md_content.params.length - md_lambda.params.length;
/*  481: 500 */         for (int i = 0; i < md_content.params.length; i++)
/*  482:     */         {
/*  483: 501 */           if (i >= start_index)
/*  484:     */           {
/*  485: 502 */             if (!firstParameter) {
/*  486: 503 */               buffer.append(", ");
/*  487:     */             }
/*  488: 506 */             String typeName = ExprProcessor.getCastTypeName(md_content.params[i].copy());
/*  489: 507 */             if (("<undefinedtype>".equals(typeName)) && (DecompilerContext.getOption("uto"))) {
/*  490: 509 */               typeName = ExprProcessor.getCastTypeName(VarType.VARTYPE_OBJECT);
/*  491:     */             }
/*  492: 512 */             buffer.append(typeName);
/*  493: 513 */             buffer.append(" ");
/*  494:     */             
/*  495: 515 */             String parameterName = methodWrapper.varproc.getVarName(new VarVersionPair(index, 0));
/*  496: 516 */             buffer.append(parameterName == null ? "param" + index : parameterName);
/*  497:     */             
/*  498: 518 */             firstParameter = false;
/*  499:     */           }
/*  500: 521 */           index += md_content.params[i].stackSize;
/*  501:     */         }
/*  502: 524 */         buffer.append(") {").appendLineSeparator();
/*  503:     */         
/*  504: 526 */         indent++;
/*  505:     */       }
/*  506: 529 */       RootStatement root = classWrapper.getMethodWrapper(mt.getName(), mt.getDescriptor()).root;
/*  507: 530 */       if ((!methodWrapper.decompiledWithErrors) && 
/*  508: 531 */         (root != null)) {
/*  509:     */         try
/*  510:     */         {
/*  511: 533 */           buffer.append(root.toJava(indent, tracer));
/*  512:     */         }
/*  513:     */         catch (Throwable ex)
/*  514:     */         {
/*  515: 536 */           DecompilerContext.getLogger().writeMessage("Method " + mt.getName() + " " + mt.getDescriptor() + " couldn't be written.", ex);
/*  516: 537 */           methodWrapper.decompiledWithErrors = true;
/*  517:     */         }
/*  518:     */       }
/*  519: 542 */       if (methodWrapper.decompiledWithErrors)
/*  520:     */       {
/*  521: 543 */         buffer.appendIndent(indent);
/*  522: 544 */         buffer.append("// $FF: Couldn't be decompiled");
/*  523: 545 */         buffer.appendLineSeparator();
/*  524:     */       }
/*  525: 548 */       if (root != null) {
/*  526: 549 */         tracer.addMapping(root.getDummyExit().bytecode);
/*  527:     */       }
/*  528: 552 */       if (!codeOnly)
/*  529:     */       {
/*  530: 553 */         indent--;
/*  531: 554 */         buffer.appendIndent(indent).append('}').appendLineSeparator();
/*  532:     */       }
/*  533:     */     }
/*  534:     */     finally
/*  535:     */     {
/*  536: 558 */       DecompilerContext.setProperty("CURRENT_METHOD_WRAPPER", outerWrapper);
/*  537:     */     }
/*  538:     */   }
/*  539:     */   
/*  540:     */   private static String toValidJavaIdentifier(String name)
/*  541:     */   {
/*  542: 563 */     if ((name == null) || (name.isEmpty())) {
/*  543: 563 */       return name;
/*  544:     */     }
/*  545: 565 */     boolean changed = false;
/*  546: 566 */     StringBuilder res = new StringBuilder(name.length());
/*  547: 567 */     for (int i = 0; i < name.length(); i++)
/*  548:     */     {
/*  549: 568 */       char c = name.charAt(i);
/*  550: 569 */       if (((i == 0) && (!Character.isJavaIdentifierStart(c))) || ((i > 0) && (!Character.isJavaIdentifierPart(c))))
/*  551:     */       {
/*  552: 571 */         changed = true;
/*  553: 572 */         res.append("_");
/*  554:     */       }
/*  555:     */       else
/*  556:     */       {
/*  557: 574 */         res.append(c);
/*  558:     */       }
/*  559:     */     }
/*  560: 576 */     if (!changed) {
/*  561: 577 */       return name;
/*  562:     */     }
/*  563: 579 */     return "/* $FF was: " + name + "*/";
/*  564:     */   }
/*  565:     */   
/*  566:     */   private boolean methodToJava(ClassesProcessor.ClassNode node, StructMethod mt, TextBuffer buffer, int indent, BytecodeMappingTracer tracer)
/*  567:     */   {
/*  568: 583 */     ClassWrapper wrapper = node.getWrapper();
/*  569: 584 */     StructClass cl = wrapper.getClassStruct();
/*  570: 585 */     MethodWrapper methodWrapper = wrapper.getMethodWrapper(mt.getName(), mt.getDescriptor());
/*  571:     */     
/*  572: 587 */     boolean hideMethod = false;
/*  573: 588 */     int start_index_method = buffer.length();
/*  574:     */     
/*  575: 590 */     MethodWrapper outerWrapper = (MethodWrapper)DecompilerContext.getProperty("CURRENT_METHOD_WRAPPER");
/*  576: 591 */     DecompilerContext.setProperty("CURRENT_METHOD_WRAPPER", methodWrapper);
/*  577:     */     try
/*  578:     */     {
/*  579: 594 */       boolean isInterface = cl.hasModifier(512);
/*  580: 595 */       boolean isAnnotation = cl.hasModifier(8192);
/*  581: 596 */       boolean isEnum = (cl.hasModifier(16384)) && (DecompilerContext.getOption("den"));
/*  582: 597 */       boolean isDeprecated = mt.getAttributes().containsKey("Deprecated");
/*  583: 598 */       boolean clinit = false;boolean init = false;boolean dinit = false;
/*  584:     */       
/*  585: 600 */       MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/*  586:     */       
/*  587: 602 */       int flags = mt.getAccessFlags();
/*  588: 603 */       if ((flags & 0x100) != 0) {
/*  589: 604 */         flags &= 0xFFFFF7FF;
/*  590:     */       }
/*  591: 606 */       if ("<clinit>".equals(mt.getName())) {
/*  592: 607 */         flags &= 0x8;
/*  593:     */       }
/*  594: 610 */       if (isDeprecated) {
/*  595: 611 */         appendDeprecation(buffer, indent);
/*  596:     */       }
/*  597: 614 */       if (this.interceptor != null)
/*  598:     */       {
/*  599: 615 */         String oldName = this.interceptor.getOldName(cl.qualifiedName + " " + mt.getName() + " " + mt.getDescriptor());
/*  600: 616 */         appendRenameComment(buffer, oldName, MType.METHOD, indent);
/*  601:     */       }
/*  602: 619 */       boolean isSynthetic = ((flags & 0x1000) != 0) || (mt.getAttributes().containsKey("Synthetic"));
/*  603: 620 */       boolean isBridge = (flags & 0x40) != 0;
/*  604: 621 */       if (isSynthetic) {
/*  605: 622 */         appendComment(buffer, "synthetic method", indent);
/*  606:     */       }
/*  607: 624 */       if (isBridge) {
/*  608: 625 */         appendComment(buffer, "bridge method", indent);
/*  609:     */       }
/*  610: 628 */       appendAnnotations(buffer, mt, indent);
/*  611:     */       
/*  612: 630 */       buffer.appendIndent(indent);
/*  613:     */       
/*  614: 632 */       appendModifiers(buffer, flags, 3391, isInterface, 1025);
/*  615: 634 */       if ((isInterface) && (mt.containsCode())) {
/*  616: 636 */         buffer.append("default ");
/*  617:     */       }
/*  618: 639 */       String name = mt.getName();
/*  619: 640 */       if ("<init>".equals(name))
/*  620:     */       {
/*  621: 641 */         if (node.type == 2)
/*  622:     */         {
/*  623: 642 */           name = "";
/*  624: 643 */           dinit = true;
/*  625:     */         }
/*  626:     */         else
/*  627:     */         {
/*  628: 646 */           name = node.simpleName;
/*  629: 647 */           init = true;
/*  630:     */         }
/*  631:     */       }
/*  632: 650 */       else if ("<clinit>".equals(name))
/*  633:     */       {
/*  634: 651 */         name = "";
/*  635: 652 */         clinit = true;
/*  636:     */       }
/*  637: 655 */       GenericMethodDescriptor descriptor = null;
/*  638: 656 */       if (DecompilerContext.getOption("dgs"))
/*  639:     */       {
/*  640: 657 */         StructGenericSignatureAttribute attr = (StructGenericSignatureAttribute)mt.getAttributes().getWithKey("Signature");
/*  641: 658 */         if (attr != null)
/*  642:     */         {
/*  643: 659 */           descriptor = GenericMain.parseMethodSignature(attr.getSignature());
/*  644: 660 */           if (descriptor != null)
/*  645:     */           {
/*  646: 661 */             int actualParams = md.params.length;
/*  647: 662 */             List<VarVersionPair> sigFields = methodWrapper.signatureFields;
/*  648: 663 */             if (sigFields != null)
/*  649:     */             {
/*  650: 664 */               actualParams = 0;
/*  651: 665 */               for (VarVersionPair field : methodWrapper.signatureFields) {
/*  652: 666 */                 if (field == null) {
/*  653: 667 */                   actualParams++;
/*  654:     */                 }
/*  655:     */               }
/*  656:     */             }
/*  657: 671 */             else if ((isEnum) && (init))
/*  658:     */             {
/*  659: 671 */               actualParams -= 2;
/*  660:     */             }
/*  661: 672 */             if (actualParams != descriptor.params.size())
/*  662:     */             {
/*  663: 673 */               String message = "Inconsistent generic signature in method " + mt.getName() + " " + mt.getDescriptor() + " in " + cl.qualifiedName;
/*  664: 674 */               DecompilerContext.getLogger().writeMessage(message, IFernflowerLogger.Severity.WARN);
/*  665: 675 */               descriptor = null;
/*  666:     */             }
/*  667:     */           }
/*  668:     */         }
/*  669:     */       }
/*  670: 681 */       boolean throwsExceptions = false;
/*  671: 682 */       int paramCount = 0;
/*  672: 684 */       if ((!clinit) && (!dinit))
/*  673:     */       {
/*  674: 685 */         boolean thisVar = !mt.hasModifier(8);
/*  675: 687 */         if ((descriptor != null) && (!descriptor.fparameters.isEmpty()))
/*  676:     */         {
/*  677: 688 */           appendTypeParameters(buffer, descriptor.fparameters, descriptor.fbounds);
/*  678: 689 */           buffer.append(' ');
/*  679:     */         }
/*  680: 692 */         if (!init)
/*  681:     */         {
/*  682: 693 */           if (descriptor != null) {
/*  683: 694 */             buffer.append(GenericMain.getGenericCastTypeName(descriptor.ret));
/*  684:     */           } else {
/*  685: 697 */             buffer.append(ExprProcessor.getCastTypeName(md.ret));
/*  686:     */           }
/*  687: 699 */           buffer.append(' ');
/*  688:     */         }
/*  689: 702 */         buffer.append(toValidJavaIdentifier(name));
/*  690: 703 */         buffer.append('(');
/*  691:     */         
/*  692:     */ 
/*  693: 706 */         List<VarVersionPair> signFields = methodWrapper.signatureFields;
/*  694:     */         
/*  695: 708 */         int lastVisibleParameterIndex = -1;
/*  696: 709 */         for (int i = 0; i < md.params.length; i++) {
/*  697: 710 */           if ((signFields == null) || (signFields.get(i) == null)) {
/*  698: 711 */             lastVisibleParameterIndex = i;
/*  699:     */           }
/*  700:     */         }
/*  701: 715 */         boolean firstParameter = true;
/*  702: 716 */         int index = thisVar ? 1 : (isEnum) && (init) ? 3 : 0;
/*  703: 717 */         boolean hasDescriptor = descriptor != null;
/*  704: 718 */         int start = (isEnum) && (init) && (!hasDescriptor) ? 2 : 0;
/*  705: 719 */         int params = hasDescriptor ? descriptor.params.size() : md.params.length;
/*  706: 720 */         for (int i = start; i < params; i++)
/*  707:     */         {
/*  708: 721 */           if ((hasDescriptor) || (signFields == null) || (signFields.get(i) == null))
/*  709:     */           {
/*  710: 722 */             if (!firstParameter) {
/*  711: 723 */               buffer.append(", ");
/*  712:     */             }
/*  713: 726 */             appendParameterAnnotations(buffer, mt, paramCount);
/*  714: 728 */             if (methodWrapper.varproc.getVarFinal(new VarVersionPair(index, 0)) == 2) {
/*  715: 729 */               buffer.append("final ");
/*  716:     */             }
/*  717: 732 */             if (descriptor != null)
/*  718:     */             {
/*  719: 733 */               GenericType parameterType = (GenericType)descriptor.params.get(i);
/*  720:     */               
/*  721: 735 */               boolean isVarArg = (i == lastVisibleParameterIndex) && (mt.hasModifier(128)) && (parameterType.arrayDim > 0);
/*  722: 736 */               if (isVarArg) {
/*  723: 737 */                 parameterType = parameterType.decreaseArrayDim();
/*  724:     */               }
/*  725: 740 */               String typeName = GenericMain.getGenericCastTypeName(parameterType);
/*  726: 741 */               if (("<undefinedtype>".equals(typeName)) && (DecompilerContext.getOption("uto"))) {
/*  727: 743 */                 typeName = ExprProcessor.getCastTypeName(VarType.VARTYPE_OBJECT);
/*  728:     */               }
/*  729: 746 */               buffer.append(typeName);
/*  730: 748 */               if (isVarArg) {
/*  731: 749 */                 buffer.append("...");
/*  732:     */               }
/*  733:     */             }
/*  734:     */             else
/*  735:     */             {
/*  736: 753 */               VarType parameterType = md.params[i];
/*  737:     */               
/*  738: 755 */               boolean isVarArg = (i == lastVisibleParameterIndex) && (mt.hasModifier(128)) && (parameterType.arrayDim > 0);
/*  739: 756 */               if (isVarArg) {
/*  740: 757 */                 parameterType = parameterType.decreaseArrayDim();
/*  741:     */               }
/*  742: 760 */               String typeName = ExprProcessor.getCastTypeName(parameterType);
/*  743: 761 */               if (("<undefinedtype>".equals(typeName)) && (DecompilerContext.getOption("uto"))) {
/*  744: 763 */                 typeName = ExprProcessor.getCastTypeName(VarType.VARTYPE_OBJECT);
/*  745:     */               }
/*  746: 766 */               buffer.append(typeName);
/*  747: 768 */               if (isVarArg) {
/*  748: 769 */                 buffer.append("...");
/*  749:     */               }
/*  750:     */             }
/*  751: 773 */             buffer.append(' ');
/*  752: 774 */             String parameterName = methodWrapper.varproc.getVarName(new VarVersionPair(index, 0));
/*  753: 775 */             buffer.append(parameterName == null ? "param" + index : parameterName);
/*  754:     */             
/*  755: 777 */             firstParameter = false;
/*  756: 778 */             paramCount++;
/*  757:     */           }
/*  758: 781 */           index += md.params[i].stackSize;
/*  759:     */         }
/*  760: 784 */         buffer.append(')');
/*  761:     */         
/*  762: 786 */         StructExceptionsAttribute attr = (StructExceptionsAttribute)mt.getAttributes().getWithKey("Exceptions");
/*  763: 787 */         if (((descriptor != null) && (!descriptor.exceptions.isEmpty())) || (attr != null))
/*  764:     */         {
/*  765: 788 */           throwsExceptions = true;
/*  766: 789 */           buffer.append(" throws ");
/*  767: 791 */           for (int i = 0; i < attr.getThrowsExceptions().size(); i++)
/*  768:     */           {
/*  769: 792 */             if (i > 0) {
/*  770: 793 */               buffer.append(", ");
/*  771:     */             }
/*  772: 795 */             if ((descriptor != null) && (!descriptor.exceptions.isEmpty()))
/*  773:     */             {
/*  774: 796 */               GenericType type = (GenericType)descriptor.exceptions.get(i);
/*  775: 797 */               buffer.append(GenericMain.getGenericCastTypeName(type));
/*  776:     */             }
/*  777:     */             else
/*  778:     */             {
/*  779: 800 */               VarType type = new VarType(attr.getExcClassname(i, cl.getPool()), true);
/*  780: 801 */               buffer.append(ExprProcessor.getCastTypeName(type));
/*  781:     */             }
/*  782:     */           }
/*  783:     */         }
/*  784:     */       }
/*  785: 807 */       tracer.incrementCurrentSourceLine(buffer.countLines(start_index_method));
/*  786: 809 */       if ((flags & 0x500) != 0)
/*  787:     */       {
/*  788: 810 */         if (isAnnotation)
/*  789:     */         {
/*  790: 811 */           StructAnnDefaultAttribute attr = (StructAnnDefaultAttribute)mt.getAttributes().getWithKey("AnnotationDefault");
/*  791: 812 */           if (attr != null)
/*  792:     */           {
/*  793: 813 */             buffer.append(" default ");
/*  794: 814 */             buffer.append(attr.getDefaultValue().toJava(indent + 1, new BytecodeMappingTracer()));
/*  795:     */           }
/*  796:     */         }
/*  797: 818 */         buffer.append(';');
/*  798: 819 */         buffer.appendLineSeparator();
/*  799: 820 */         tracer.incrementCurrentSourceLine();
/*  800:     */       }
/*  801:     */       else
/*  802:     */       {
/*  803: 823 */         if ((!clinit) && (!dinit)) {
/*  804: 824 */           buffer.append(' ');
/*  805:     */         }
/*  806: 828 */         buffer.append('{').appendLineSeparator();
/*  807: 829 */         tracer.incrementCurrentSourceLine();
/*  808:     */         
/*  809: 831 */         RootStatement root = wrapper.getMethodWrapper(mt.getName(), mt.getDescriptor()).root;
/*  810: 833 */         if ((root != null) && (!methodWrapper.decompiledWithErrors)) {
/*  811:     */           try
/*  812:     */           {
/*  813: 835 */             TextBuffer code = root.toJava(indent + 1, tracer);
/*  814:     */             
/*  815: 837 */             hideMethod = ((clinit) || (dinit) || (hideConstructor(wrapper, init, throwsExceptions, paramCount))) && (code.length() == 0);
/*  816:     */             
/*  817: 839 */             buffer.append(code);
/*  818:     */           }
/*  819:     */           catch (Throwable ex)
/*  820:     */           {
/*  821: 842 */             DecompilerContext.getLogger().writeMessage("Method " + mt.getName() + " " + mt.getDescriptor() + " couldn't be written.", ex);
/*  822: 843 */             methodWrapper.decompiledWithErrors = true;
/*  823:     */           }
/*  824:     */         }
/*  825: 847 */         if (methodWrapper.decompiledWithErrors)
/*  826:     */         {
/*  827: 848 */           buffer.appendIndent(indent + 1);
/*  828: 849 */           buffer.append("// $FF: Couldn't be decompiled");
/*  829: 850 */           buffer.appendLineSeparator();
/*  830: 851 */           tracer.incrementCurrentSourceLine();
/*  831:     */         }
/*  832: 854 */         if (root != null) {
/*  833: 855 */           tracer.addMapping(root.getDummyExit().bytecode);
/*  834:     */         }
/*  835: 857 */         buffer.appendIndent(indent).append('}').appendLineSeparator();
/*  836: 858 */         tracer.incrementCurrentSourceLine();
/*  837:     */       }
/*  838:     */     }
/*  839:     */     finally
/*  840:     */     {
/*  841: 862 */       DecompilerContext.setProperty("CURRENT_METHOD_WRAPPER", outerWrapper);
/*  842:     */     }
/*  843: 869 */     return !hideMethod;
/*  844:     */   }
/*  845:     */   
/*  846:     */   private static boolean hideConstructor(ClassWrapper wrapper, boolean init, boolean throwsExceptions, int paramCount)
/*  847:     */   {
/*  848: 873 */     if ((!init) || (throwsExceptions) || (paramCount > 0) || (!DecompilerContext.getOption("hdc"))) {
/*  849: 874 */       return false;
/*  850:     */     }
/*  851: 877 */     int count = 0;
/*  852: 878 */     for (StructMethod mt : wrapper.getClassStruct().getMethods()) {
/*  853: 879 */       if ("<init>".equals(mt.getName()))
/*  854:     */       {
/*  855: 880 */         count++;
/*  856: 880 */         if (count > 1) {
/*  857: 881 */           return false;
/*  858:     */         }
/*  859:     */       }
/*  860:     */     }
/*  861: 886 */     return true;
/*  862:     */   }
/*  863:     */   
/*  864:     */   private static void appendDeprecation(TextBuffer buffer, int indent)
/*  865:     */   {
/*  866: 890 */     buffer.appendIndent(indent).append("/** @deprecated */").appendLineSeparator();
/*  867:     */   }
/*  868:     */   
/*  869:     */   private static enum MType
/*  870:     */   {
/*  871: 893 */     CLASS,  FIELD,  METHOD;
/*  872:     */     
/*  873:     */     private MType() {}
/*  874:     */   }
/*  875:     */   
/*  876:     */   private static void appendRenameComment(TextBuffer buffer, String oldName, MType type, int indent)
/*  877:     */   {
/*  878: 896 */     if (oldName == null) {
/*  879: 896 */       return;
/*  880:     */     }
/*  881: 898 */     buffer.appendIndent(indent);
/*  882: 899 */     buffer.append("// $FF: renamed from: ");
/*  883: 901 */     switch (2.$SwitchMap$org$jetbrains$java$decompiler$main$ClassWriter$MType[type.ordinal()])
/*  884:     */     {
/*  885:     */     case 1: 
/*  886: 903 */       buffer.append(ExprProcessor.buildJavaClassName(oldName));
/*  887: 904 */       break;
/*  888:     */     case 2: 
/*  889: 907 */       String[] fParts = oldName.split(" ");
/*  890: 908 */       FieldDescriptor fd = FieldDescriptor.parseDescriptor(fParts[2]);
/*  891: 909 */       buffer.append(fParts[1]);
/*  892: 910 */       buffer.append(' ');
/*  893: 911 */       buffer.append(getTypePrintOut(fd.type));
/*  894: 912 */       break;
/*  895:     */     default: 
/*  896: 915 */       String[] mParts = oldName.split(" ");
/*  897: 916 */       MethodDescriptor md = MethodDescriptor.parseDescriptor(mParts[2]);
/*  898: 917 */       buffer.append(mParts[1]);
/*  899: 918 */       buffer.append(" (");
/*  900: 919 */       boolean first = true;
/*  901: 920 */       for (VarType paramType : md.params)
/*  902:     */       {
/*  903: 921 */         if (!first) {
/*  904: 922 */           buffer.append(", ");
/*  905:     */         }
/*  906: 924 */         first = false;
/*  907: 925 */         buffer.append(getTypePrintOut(paramType));
/*  908:     */       }
/*  909: 927 */       buffer.append(") ");
/*  910: 928 */       buffer.append(getTypePrintOut(md.ret));
/*  911:     */     }
/*  912: 931 */     buffer.appendLineSeparator();
/*  913:     */   }
/*  914:     */   
/*  915:     */   private static String getTypePrintOut(VarType type)
/*  916:     */   {
/*  917: 935 */     String typeText = ExprProcessor.getCastTypeName(type, false);
/*  918: 936 */     if (("<undefinedtype>".equals(typeText)) && (DecompilerContext.getOption("uto"))) {
/*  919: 938 */       typeText = ExprProcessor.getCastTypeName(VarType.VARTYPE_OBJECT, false);
/*  920:     */     }
/*  921: 940 */     return typeText;
/*  922:     */   }
/*  923:     */   
/*  924:     */   private static void appendComment(TextBuffer buffer, String comment, int indent)
/*  925:     */   {
/*  926: 944 */     buffer.appendIndent(indent).append("// $FF: ").append(comment).appendLineSeparator();
/*  927:     */   }
/*  928:     */   
/*  929: 947 */   private static final String[] ANNOTATION_ATTRIBUTES = { "RuntimeVisibleAnnotations", "RuntimeInvisibleAnnotations" };
/*  930:     */   
/*  931:     */   private static void appendAnnotations(TextBuffer buffer, StructMember mb, int indent)
/*  932:     */   {
/*  933: 951 */     BytecodeMappingTracer tracer_dummy = new BytecodeMappingTracer();
/*  934: 953 */     for (String name : ANNOTATION_ATTRIBUTES)
/*  935:     */     {
/*  936: 954 */       StructAnnotationAttribute attribute = (StructAnnotationAttribute)mb.getAttributes().getWithKey(name);
/*  937: 955 */       if (attribute != null) {
/*  938: 956 */         for (AnnotationExprent annotation : attribute.getAnnotations()) {
/*  939: 957 */           buffer.append(annotation.toJava(indent, tracer_dummy)).appendLineSeparator();
/*  940:     */         }
/*  941:     */       }
/*  942:     */     }
/*  943:     */   }
/*  944:     */   
/*  945: 963 */   private static final String[] PARAMETER_ANNOTATION_ATTRIBUTES = { "RuntimeVisibleParameterAnnotations", "RuntimeInvisibleParameterAnnotations" };
/*  946:     */   
/*  947:     */   private static void appendParameterAnnotations(TextBuffer buffer, StructMethod mt, int param)
/*  948:     */   {
/*  949: 968 */     BytecodeMappingTracer tracer_dummy = new BytecodeMappingTracer();
/*  950: 970 */     for (String name : PARAMETER_ANNOTATION_ATTRIBUTES)
/*  951:     */     {
/*  952: 971 */       StructAnnotationParameterAttribute attribute = (StructAnnotationParameterAttribute)mt.getAttributes().getWithKey(name);
/*  953: 972 */       if (attribute != null)
/*  954:     */       {
/*  955: 973 */         List<List<AnnotationExprent>> annotations = attribute.getParamAnnotations();
/*  956: 974 */         if (param < annotations.size()) {
/*  957: 975 */           for (AnnotationExprent annotation : (List)annotations.get(param)) {
/*  958: 976 */             buffer.append(annotation.toJava(0, tracer_dummy)).append(' ');
/*  959:     */           }
/*  960:     */         }
/*  961:     */       }
/*  962:     */     }
/*  963:     */   }
/*  964:     */   
/*  965: 983 */   private static final Map<Integer, String> MODIFIERS = new LinkedHashMap() {};
/*  966:     */   private static final int CLASS_ALLOWED = 3103;
/*  967:     */   private static final int FIELD_ALLOWED = 223;
/*  968:     */   private static final int METHOD_ALLOWED = 3391;
/*  969:     */   private static final int CLASS_EXCLUDED = 1032;
/*  970:     */   private static final int FIELD_EXCLUDED = 25;
/*  971:     */   private static final int METHOD_EXCLUDED = 1025;
/*  972:     */   
/*  973:     */   private static void appendModifiers(TextBuffer buffer, int flags, int allowed, boolean isInterface, int excluded)
/*  974:     */   {
/*  975:1012 */     flags &= allowed;
/*  976:1013 */     if (!isInterface) {
/*  977:1013 */       excluded = 0;
/*  978:     */     }
/*  979:1014 */     for (Iterator i$ = MODIFIERS.keySet().iterator(); i$.hasNext();)
/*  980:     */     {
/*  981:1014 */       int modifier = ((Integer)i$.next()).intValue();
/*  982:1015 */       if (((flags & modifier) == modifier) && ((modifier & excluded) == 0)) {
/*  983:1016 */         buffer.append((String)MODIFIERS.get(Integer.valueOf(modifier))).append(' ');
/*  984:     */       }
/*  985:     */     }
/*  986:     */   }
/*  987:     */   
/*  988:     */   private static void appendTypeParameters(TextBuffer buffer, List<String> parameters, List<List<GenericType>> bounds)
/*  989:     */   {
/*  990:1022 */     buffer.append('<');
/*  991:1024 */     for (int i = 0; i < parameters.size(); i++)
/*  992:     */     {
/*  993:1025 */       if (i > 0) {
/*  994:1026 */         buffer.append(", ");
/*  995:     */       }
/*  996:1029 */       buffer.append((String)parameters.get(i));
/*  997:     */       
/*  998:1031 */       List<GenericType> parameterBounds = (List)bounds.get(i);
/*  999:1032 */       if ((parameterBounds.size() > 1) || (!"java/lang/Object".equals(((GenericType)parameterBounds.get(0)).value)))
/* 1000:     */       {
/* 1001:1033 */         buffer.append(" extends ");
/* 1002:1034 */         buffer.append(GenericMain.getGenericCastTypeName((GenericType)parameterBounds.get(0)));
/* 1003:1035 */         for (int j = 1; j < parameterBounds.size(); j++)
/* 1004:     */         {
/* 1005:1036 */           buffer.append(" & ");
/* 1006:1037 */           buffer.append(GenericMain.getGenericCastTypeName((GenericType)parameterBounds.get(j)));
/* 1007:     */         }
/* 1008:     */       }
/* 1009:     */     }
/* 1010:1042 */     buffer.append('>');
/* 1011:     */   }
/* 1012:     */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.ClassWriter
 * JD-Core Version:    0.7.0.1
 */