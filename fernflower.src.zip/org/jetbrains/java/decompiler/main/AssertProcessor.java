/*   1:    */ package org.jetbrains.java.decompiler.main;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*   8:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*   9:    */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*  10:    */ import org.jetbrains.java.decompiler.main.rels.MethodWrapper;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.SecondaryFunctionsHelper;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssertExprent;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FieldExprent;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.IfExprent;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  24:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  25:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement;
/*  26:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  27:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  28:    */ import org.jetbrains.java.decompiler.struct.StructField;
/*  29:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  30:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  31:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  32:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  33:    */ 
/*  34:    */ public class AssertProcessor
/*  35:    */ {
/*  36: 40 */   private static final VarType CLASS_ASSERTION_ERROR = new VarType(8, 0, "java/lang/AssertionError");
/*  37:    */   
/*  38:    */   public static void buildAssertions(ClassesProcessor.ClassNode node)
/*  39:    */   {
/*  40: 44 */     ClassWrapper wrapper = node.getWrapper();
/*  41:    */     
/*  42: 46 */     StructField field = findAssertionField(node);
/*  43: 48 */     if (field != null)
/*  44:    */     {
/*  45: 50 */       String key = InterpreterUtil.makeUniqueKey(field.getName(), field.getDescriptor());
/*  46:    */       
/*  47: 52 */       boolean res = false;
/*  48: 54 */       for (MethodWrapper meth : wrapper.getMethods())
/*  49:    */       {
/*  50: 55 */         RootStatement root = meth.root;
/*  51: 56 */         if (root != null) {
/*  52: 57 */           res |= replaceAssertions(root, wrapper.getClassStruct().qualifiedName, key);
/*  53:    */         }
/*  54:    */       }
/*  55: 61 */       if (res) {
/*  56: 63 */         wrapper.getHiddenMembers().add(key);
/*  57:    */       }
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   private static StructField findAssertionField(ClassesProcessor.ClassNode node)
/*  62:    */   {
/*  63: 70 */     ClassWrapper wrapper = node.getWrapper();
/*  64:    */     
/*  65: 72 */     boolean noSynthFlag = DecompilerContext.getOption("nns");
/*  66: 74 */     for (StructField fd : wrapper.getClassStruct().getFields())
/*  67:    */     {
/*  68: 76 */       String keyField = InterpreterUtil.makeUniqueKey(fd.getName(), fd.getDescriptor());
/*  69: 79 */       if (wrapper.getStaticFieldInitializers().containsKey(keyField)) {
/*  70: 82 */         if ((fd.hasModifier(8)) && (fd.hasModifier(16)) && ((noSynthFlag) || (fd.isSynthetic())))
/*  71:    */         {
/*  72: 85 */           FieldDescriptor fdescr = FieldDescriptor.parseDescriptor(fd.getDescriptor());
/*  73: 86 */           if (VarType.VARTYPE_BOOLEAN.equals(fdescr.type))
/*  74:    */           {
/*  75: 88 */             Exprent initializer = (Exprent)wrapper.getStaticFieldInitializers().getWithKey(keyField);
/*  76: 89 */             if (initializer.type == 6)
/*  77:    */             {
/*  78: 90 */               FunctionExprent fexpr = (FunctionExprent)initializer;
/*  79: 92 */               if ((fexpr.getFuncType() == 12) && (((Exprent)fexpr.getLstOperands().get(0)).type == 8))
/*  80:    */               {
/*  81: 95 */                 InvocationExprent invexpr = (InvocationExprent)fexpr.getLstOperands().get(0);
/*  82: 97 */                 if ((invexpr.getInstance() != null) && (invexpr.getInstance().type == 3) && ("desiredAssertionStatus".equals(invexpr.getName())) && ("java/lang/Class".equals(invexpr.getClassname())) && (invexpr.getLstParameters().isEmpty()))
/*  83:    */                 {
/*  84:103 */                   ConstExprent cexpr = (ConstExprent)invexpr.getInstance();
/*  85:104 */                   if (VarType.VARTYPE_CLASS.equals(cexpr.getConstType()))
/*  86:    */                   {
/*  87:106 */                     ClassesProcessor.ClassNode nd = node;
/*  88:107 */                     while ((nd != null) && 
/*  89:108 */                       (!nd.getWrapper().getClassStruct().qualifiedName.equals(cexpr.getValue()))) {
/*  90:111 */                       nd = nd.parent;
/*  91:    */                     }
/*  92:114 */                     if (nd != null) {
/*  93:115 */                       return fd;
/*  94:    */                     }
/*  95:    */                   }
/*  96:    */                 }
/*  97:    */               }
/*  98:    */             }
/*  99:    */           }
/* 100:    */         }
/* 101:    */       }
/* 102:    */     }
/* 103:127 */     return null;
/* 104:    */   }
/* 105:    */   
/* 106:    */   private static boolean replaceAssertions(Statement statement, String classname, String key)
/* 107:    */   {
/* 108:133 */     boolean res = false;
/* 109:135 */     for (Statement st : statement.getStats()) {
/* 110:136 */       res |= replaceAssertions(st, classname, key);
/* 111:    */     }
/* 112:139 */     boolean replaced = true;
/* 113:140 */     while (replaced)
/* 114:    */     {
/* 115:141 */       replaced = false;
/* 116:143 */       for (Statement st : statement.getStats()) {
/* 117:144 */         if ((st.type == 2) && 
/* 118:145 */           (replaceAssertion(statement, (IfStatement)st, classname, key)))
/* 119:    */         {
/* 120:146 */           replaced = true;
/* 121:147 */           break;
/* 122:    */         }
/* 123:    */       }
/* 124:152 */       res |= replaced;
/* 125:    */     }
/* 126:155 */     return res;
/* 127:    */   }
/* 128:    */   
/* 129:    */   private static boolean replaceAssertion(Statement parent, IfStatement stat, String classname, String key)
/* 130:    */   {
/* 131:160 */     Statement ifstat = stat.getIfstat();
/* 132:161 */     InvocationExprent throwError = isAssertionError(ifstat);
/* 133:163 */     if (throwError == null) {
/* 134:164 */       return false;
/* 135:    */     }
/* 136:167 */     Object[] exprres = getAssertionExprent(stat.getHeadexprent().getCondition().copy(), classname, key);
/* 137:168 */     if (!((Boolean)exprres[1]).booleanValue()) {
/* 138:169 */       return false;
/* 139:    */     }
/* 140:172 */     List<Exprent> lstParams = new ArrayList();
/* 141:    */     
/* 142:174 */     Exprent ascond = null;Exprent retcond = null;
/* 143:175 */     if (exprres[0] != null)
/* 144:    */     {
/* 145:176 */       ascond = new FunctionExprent(12, (Exprent)exprres[0], throwError.bytecode);
/* 146:177 */       retcond = SecondaryFunctionsHelper.propagateBoolNot(ascond);
/* 147:    */     }
/* 148:180 */     lstParams.add(retcond == null ? ascond : retcond);
/* 149:181 */     if (!throwError.getLstParameters().isEmpty()) {
/* 150:182 */       lstParams.add(throwError.getLstParameters().get(0));
/* 151:    */     }
/* 152:185 */     AssertExprent asexpr = new AssertExprent(lstParams);
/* 153:    */     
/* 154:187 */     Statement newstat = new BasicBlockStatement(new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0)));
/* 155:    */     
/* 156:189 */     newstat.setExprents(Arrays.asList(new Exprent[] { asexpr }));
/* 157:    */     
/* 158:191 */     Statement first = stat.getFirst();
/* 159:193 */     if ((stat.iftype == 1) || ((first.getExprents() != null) && (!first.getExprents().isEmpty())))
/* 160:    */     {
/* 161:196 */       first.removeSuccessor(stat.getIfEdge());
/* 162:197 */       first.removeSuccessor(stat.getElseEdge());
/* 163:    */       
/* 164:199 */       List<Statement> lstStatements = new ArrayList();
/* 165:200 */       if ((first.getExprents() != null) && (!first.getExprents().isEmpty())) {
/* 166:201 */         lstStatements.add(first);
/* 167:    */       }
/* 168:203 */       lstStatements.add(newstat);
/* 169:204 */       if (stat.iftype == 1) {
/* 170:205 */         lstStatements.add(stat.getElsestat());
/* 171:    */       }
/* 172:208 */       SequenceStatement sequence = new SequenceStatement(lstStatements);
/* 173:209 */       sequence.setAllParent();
/* 174:211 */       for (int i = 0; i < sequence.getStats().size() - 1; i++) {
/* 175:212 */         ((Statement)sequence.getStats().get(i)).addSuccessor(new StatEdge(1, (Statement)sequence.getStats().get(i), (Statement)sequence.getStats().get(i + 1)));
/* 176:    */       }
/* 177:216 */       if (stat.iftype == 1)
/* 178:    */       {
/* 179:217 */         Statement ifelse = stat.getElsestat();
/* 180:    */         
/* 181:219 */         List<StatEdge> lstSuccs = ifelse.getAllSuccessorEdges();
/* 182:220 */         if (!lstSuccs.isEmpty())
/* 183:    */         {
/* 184:221 */           StatEdge endedge = (StatEdge)lstSuccs.get(0);
/* 185:222 */           if (endedge.closure == stat) {
/* 186:223 */             sequence.addLabeledEdge(endedge);
/* 187:    */           }
/* 188:    */         }
/* 189:    */       }
/* 190:228 */       newstat = sequence;
/* 191:    */     }
/* 192:231 */     newstat.getVarDefinitions().addAll(stat.getVarDefinitions());
/* 193:232 */     parent.replaceStatement(stat, newstat);
/* 194:    */     
/* 195:234 */     return true;
/* 196:    */   }
/* 197:    */   
/* 198:    */   private static InvocationExprent isAssertionError(Statement stat)
/* 199:    */   {
/* 200:239 */     if ((stat == null) || (stat.getExprents() == null) || (stat.getExprents().size() != 1)) {
/* 201:240 */       return null;
/* 202:    */     }
/* 203:243 */     Exprent expr = (Exprent)stat.getExprents().get(0);
/* 204:245 */     if (expr.type == 4)
/* 205:    */     {
/* 206:246 */       ExitExprent exexpr = (ExitExprent)expr;
/* 207:247 */       if ((exexpr.getExitType() == 1) && (exexpr.getValue().type == 10))
/* 208:    */       {
/* 209:248 */         NewExprent nexpr = (NewExprent)exexpr.getValue();
/* 210:249 */         if ((CLASS_ASSERTION_ERROR.equals(nexpr.getNewType())) && (nexpr.getConstructor() != null)) {
/* 211:250 */           return nexpr.getConstructor();
/* 212:    */         }
/* 213:    */       }
/* 214:    */     }
/* 215:255 */     return null;
/* 216:    */   }
/* 217:    */   
/* 218:    */   private static Object[] getAssertionExprent(Exprent exprent, String classname, String key)
/* 219:    */   {
/* 220:260 */     if (exprent.type == 6)
/* 221:    */     {
/* 222:261 */       FunctionExprent fexpr = (FunctionExprent)exprent;
/* 223:262 */       if (fexpr.getFuncType() == 48)
/* 224:    */       {
/* 225:264 */         for (int i = 0; i < 2; i++)
/* 226:    */         {
/* 227:265 */           Exprent param = (Exprent)fexpr.getLstOperands().get(i);
/* 228:267 */           if (isAssertionField(param, classname, key)) {
/* 229:268 */             return new Object[] { fexpr.getLstOperands().get(1 - i), Boolean.valueOf(true) };
/* 230:    */           }
/* 231:    */         }
/* 232:272 */         for (int i = 0; i < 2; i++)
/* 233:    */         {
/* 234:273 */           Exprent param = (Exprent)fexpr.getLstOperands().get(i);
/* 235:    */           
/* 236:275 */           Object[] res = getAssertionExprent(param, classname, key);
/* 237:276 */           if (((Boolean)res[1]).booleanValue())
/* 238:    */           {
/* 239:277 */             if (param != res[0]) {
/* 240:278 */               fexpr.getLstOperands().set(i, (Exprent)res[0]);
/* 241:    */             }
/* 242:280 */             return new Object[] { fexpr, Boolean.valueOf(true) };
/* 243:    */           }
/* 244:    */         }
/* 245:    */       }
/* 246:284 */       else if (isAssertionField(fexpr, classname, key))
/* 247:    */       {
/* 248:286 */         return new Object[] { null, Boolean.valueOf(true) };
/* 249:    */       }
/* 250:    */     }
/* 251:290 */     return new Object[] { exprent, Boolean.valueOf(false) };
/* 252:    */   }
/* 253:    */   
/* 254:    */   private static boolean isAssertionField(Exprent exprent, String classname, String key)
/* 255:    */   {
/* 256:295 */     if (exprent.type == 6)
/* 257:    */     {
/* 258:296 */       FunctionExprent fparam = (FunctionExprent)exprent;
/* 259:297 */       if ((fparam.getFuncType() == 12) && (((Exprent)fparam.getLstOperands().get(0)).type == 5))
/* 260:    */       {
/* 261:299 */         FieldExprent fdparam = (FieldExprent)fparam.getLstOperands().get(0);
/* 262:300 */         if ((classname.equals(fdparam.getClassname())) && (key.equals(InterpreterUtil.makeUniqueKey(fdparam.getName(), fdparam.getDescriptor().descriptorString)))) {
/* 263:302 */           return true;
/* 264:    */         }
/* 265:    */       }
/* 266:    */     }
/* 267:307 */     return false;
/* 268:    */   }
/* 269:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.AssertProcessor
 * JD-Core Version:    0.7.0.1
 */