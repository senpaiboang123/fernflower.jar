/*  1:   */ package org.jetbrains.java.decompiler.main.collectors;
/*  2:   */ 
/*  3:   */ import java.util.HashSet;
/*  4:   */ import java.util.Set;
/*  5:   */ 
/*  6:   */ public class VarNamesCollector
/*  7:   */ {
/*  8:23 */   private final Set<String> usedNames = new HashSet();
/*  9:   */   
/* 10:   */   public VarNamesCollector() {}
/* 11:   */   
/* 12:   */   public VarNamesCollector(Set<String> setNames)
/* 13:   */   {
/* 14:28 */     this.usedNames.addAll(setNames);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void addName(String value)
/* 18:   */   {
/* 19:32 */     this.usedNames.add(value);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getFreeName(int index)
/* 23:   */   {
/* 24:36 */     return getFreeName("var" + index);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getFreeName(String proposition)
/* 28:   */   {
/* 29:40 */     while (this.usedNames.contains(proposition)) {
/* 30:41 */       proposition = proposition + "x";
/* 31:   */     }
/* 32:43 */     this.usedNames.add(proposition);
/* 33:44 */     return proposition;
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.collectors.VarNamesCollector
 * JD-Core Version:    0.7.0.1
 */