/*   1:    */ package org.jetbrains.java.decompiler.main.collectors;
/*   2:    */ 
/*   3:    */ import java.util.Collections;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import java.util.Set;
/*   9:    */ import org.jetbrains.java.decompiler.struct.attr.StructLineNumberTableAttribute;
/*  10:    */ 
/*  11:    */ public class BytecodeMappingTracer
/*  12:    */ {
/*  13:    */   private int currentSourceLine;
/*  14: 25 */   private StructLineNumberTableAttribute lineNumberTable = null;
/*  15: 26 */   private final Map<Integer, Integer> mapping = new HashMap();
/*  16:    */   
/*  17:    */   public BytecodeMappingTracer() {}
/*  18:    */   
/*  19:    */   public BytecodeMappingTracer(int initial_source_line)
/*  20:    */   {
/*  21: 31 */     this.currentSourceLine = initial_source_line;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public void incrementCurrentSourceLine()
/*  25:    */   {
/*  26: 35 */     this.currentSourceLine += 1;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void incrementCurrentSourceLine(int number_lines)
/*  30:    */   {
/*  31: 39 */     this.currentSourceLine += number_lines;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void addMapping(int bytecode_offset)
/*  35:    */   {
/*  36: 43 */     if (!this.mapping.containsKey(Integer.valueOf(bytecode_offset))) {
/*  37: 44 */       this.mapping.put(Integer.valueOf(bytecode_offset), Integer.valueOf(this.currentSourceLine));
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void addMapping(Set<Integer> bytecode_offsets)
/*  42:    */   {
/*  43: 49 */     if (bytecode_offsets != null) {
/*  44: 50 */       for (Integer bytecode_offset : bytecode_offsets) {
/*  45: 51 */         addMapping(bytecode_offset.intValue());
/*  46:    */       }
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void addTracer(BytecodeMappingTracer tracer)
/*  51:    */   {
/*  52: 57 */     if (tracer != null) {
/*  53: 58 */       for (Map.Entry<Integer, Integer> entry : tracer.mapping.entrySet()) {
/*  54: 59 */         if (!this.mapping.containsKey(entry.getKey())) {
/*  55: 60 */           this.mapping.put(entry.getKey(), entry.getValue());
/*  56:    */         }
/*  57:    */       }
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   public Map<Integer, Integer> getMapping()
/*  62:    */   {
/*  63: 67 */     return this.mapping;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public int getCurrentSourceLine()
/*  67:    */   {
/*  68: 71 */     return this.currentSourceLine;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setCurrentSourceLine(int currentSourceLine)
/*  72:    */   {
/*  73: 75 */     this.currentSourceLine = currentSourceLine;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void setLineNumberTable(StructLineNumberTableAttribute lineNumberTable)
/*  77:    */   {
/*  78: 79 */     this.lineNumberTable = lineNumberTable;
/*  79:    */   }
/*  80:    */   
/*  81: 82 */   private final Set<Integer> unmappedLines = new HashSet();
/*  82:    */   
/*  83:    */   public Set<Integer> getUnmappedLines()
/*  84:    */   {
/*  85: 85 */     return this.unmappedLines;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Map<Integer, Integer> getOriginalLinesMapping()
/*  89:    */   {
/*  90: 89 */     if (this.lineNumberTable == null) {
/*  91: 90 */       return Collections.emptyMap();
/*  92:    */     }
/*  93: 93 */     Map<Integer, Integer> res = new HashMap();
/*  94:    */     
/*  95:    */ 
/*  96: 96 */     int[] data = this.lineNumberTable.getRawData();
/*  97: 97 */     for (int i = 0; i < data.length; i += 2)
/*  98:    */     {
/*  99: 98 */       int originalOffset = data[i];
/* 100: 99 */       int originalLine = data[(i + 1)];
/* 101:100 */       Integer newLine = (Integer)this.mapping.get(Integer.valueOf(originalOffset));
/* 102:101 */       if (newLine != null) {
/* 103:102 */         res.put(Integer.valueOf(originalLine), newLine);
/* 104:    */       } else {
/* 105:105 */         this.unmappedLines.add(Integer.valueOf(originalLine));
/* 106:    */       }
/* 107:    */     }
/* 108:110 */     for (Map.Entry<Integer, Integer> entry : this.mapping.entrySet())
/* 109:    */     {
/* 110:111 */       int originalLine = this.lineNumberTable.findLineNumber(((Integer)entry.getKey()).intValue());
/* 111:112 */       if ((originalLine > -1) && (!res.containsKey(Integer.valueOf(originalLine))))
/* 112:    */       {
/* 113:113 */         res.put(Integer.valueOf(originalLine), entry.getValue());
/* 114:114 */         this.unmappedLines.remove(Integer.valueOf(originalLine));
/* 115:    */       }
/* 116:    */     }
/* 117:117 */     return res;
/* 118:    */   }
/* 119:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer
 * JD-Core Version:    0.7.0.1
 */