/*   1:    */ package org.jetbrains.java.decompiler.main.collectors;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.LinkedHashMap;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ import java.util.TreeMap;
/*  12:    */ import java.util.TreeSet;
/*  13:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  14:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  15:    */ 
/*  16:    */ public class BytecodeSourceMapper
/*  17:    */ {
/*  18:    */   private int offset_total;
/*  19: 29 */   private final Map<String, Map<String, Map<Integer, Integer>>> mapping = new LinkedHashMap();
/*  20: 32 */   private final Map<Integer, Integer> linesMapping = new HashMap();
/*  21: 33 */   private final Set<Integer> unmappedLines = new TreeSet();
/*  22:    */   
/*  23:    */   public void addMapping(String className, String methodName, int bytecodeOffset, int sourceLine)
/*  24:    */   {
/*  25: 36 */     Map<String, Map<Integer, Integer>> class_mapping = (Map)this.mapping.get(className);
/*  26: 37 */     if (class_mapping == null) {
/*  27: 38 */       this.mapping.put(className, class_mapping = new LinkedHashMap());
/*  28:    */     }
/*  29: 41 */     Map<Integer, Integer> method_mapping = (Map)class_mapping.get(methodName);
/*  30: 42 */     if (method_mapping == null) {
/*  31: 43 */       class_mapping.put(methodName, method_mapping = new HashMap());
/*  32:    */     }
/*  33: 47 */     if (!method_mapping.containsKey(Integer.valueOf(bytecodeOffset))) {
/*  34: 48 */       method_mapping.put(Integer.valueOf(bytecodeOffset), Integer.valueOf(sourceLine));
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void addTracer(String className, String methodName, BytecodeMappingTracer tracer)
/*  39:    */   {
/*  40: 53 */     for (Map.Entry<Integer, Integer> entry : tracer.getMapping().entrySet()) {
/*  41: 54 */       addMapping(className, methodName, ((Integer)entry.getKey()).intValue(), ((Integer)entry.getValue()).intValue());
/*  42:    */     }
/*  43: 56 */     this.linesMapping.putAll(tracer.getOriginalLinesMapping());
/*  44: 57 */     this.unmappedLines.addAll(tracer.getUnmappedLines());
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void dumpMapping(TextBuffer buffer, boolean offsetsToHex)
/*  48:    */   {
/*  49: 61 */     if ((this.mapping.isEmpty()) && (this.linesMapping.isEmpty())) {
/*  50: 62 */       return;
/*  51:    */     }
/*  52: 65 */     String lineSeparator = DecompilerContext.getNewLineSeparator();
/*  53: 67 */     for (Map.Entry<String, Map<String, Map<Integer, Integer>>> class_entry : this.mapping.entrySet())
/*  54:    */     {
/*  55: 68 */       Map<String, Map<Integer, Integer>> class_mapping = (Map)class_entry.getValue();
/*  56: 69 */       buffer.append("class '" + (String)class_entry.getKey() + "' {" + lineSeparator);
/*  57:    */       
/*  58: 71 */       boolean is_first_method = true;
/*  59: 72 */       for (Map.Entry<String, Map<Integer, Integer>> method_entry : class_mapping.entrySet())
/*  60:    */       {
/*  61: 73 */         Map<Integer, Integer> method_mapping = (Map)method_entry.getValue();
/*  62: 75 */         if (!is_first_method) {
/*  63: 76 */           buffer.appendLineSeparator();
/*  64:    */         }
/*  65: 79 */         buffer.appendIndent(1).append("method '" + (String)method_entry.getKey() + "' {" + lineSeparator);
/*  66:    */         
/*  67: 81 */         List<Integer> lstBytecodeOffsets = new ArrayList(method_mapping.keySet());
/*  68: 82 */         Collections.sort(lstBytecodeOffsets);
/*  69: 84 */         for (Integer offset : lstBytecodeOffsets)
/*  70:    */         {
/*  71: 85 */           Integer line = (Integer)method_mapping.get(offset);
/*  72:    */           
/*  73: 87 */           String strOffset = offsetsToHex ? Integer.toHexString(offset.intValue()) : line.toString();
/*  74: 88 */           buffer.appendIndent(2).append(strOffset).appendIndent(2).append(line.intValue() + this.offset_total + lineSeparator);
/*  75:    */         }
/*  76: 90 */         buffer.appendIndent(1).append("}").appendLineSeparator();
/*  77:    */         
/*  78: 92 */         is_first_method = false;
/*  79:    */       }
/*  80: 95 */       buffer.append("}").appendLineSeparator().appendLineSeparator();
/*  81:    */     }
/*  82: 99 */     buffer.append("Lines mapping:").appendLineSeparator();
/*  83:100 */     Map<Integer, Integer> sorted = new TreeMap(this.linesMapping);
/*  84:101 */     for (Map.Entry<Integer, Integer> entry : sorted.entrySet()) {
/*  85:102 */       buffer.append(((Integer)entry.getKey()).intValue()).append(" <-> ").append(((Integer)entry.getValue()).intValue() + this.offset_total + 1).appendLineSeparator();
/*  86:    */     }
/*  87:105 */     if (!this.unmappedLines.isEmpty())
/*  88:    */     {
/*  89:106 */       buffer.append("Not mapped:").appendLineSeparator();
/*  90:107 */       for (Integer line : this.unmappedLines) {
/*  91:108 */         if (!this.linesMapping.containsKey(line)) {
/*  92:109 */           buffer.append(line.intValue()).appendLineSeparator();
/*  93:    */         }
/*  94:    */       }
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   public int getTotalOffset()
/*  99:    */   {
/* 100:116 */     return this.offset_total;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void setTotalOffset(int offset_total)
/* 104:    */   {
/* 105:120 */     this.offset_total = offset_total;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void addTotalOffset(int offset_total)
/* 109:    */   {
/* 110:124 */     this.offset_total += offset_total;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public int[] getOriginalLinesMapping()
/* 114:    */   {
/* 115:131 */     int[] res = new int[this.linesMapping.size() * 2];
/* 116:132 */     int i = 0;
/* 117:133 */     for (Map.Entry<Integer, Integer> entry : this.linesMapping.entrySet())
/* 118:    */     {
/* 119:134 */       res[i] = ((Integer)entry.getKey()).intValue();
/* 120:135 */       this.unmappedLines.remove(entry.getKey());
/* 121:136 */       res[(i + 1)] = (((Integer)entry.getValue()).intValue() + this.offset_total + 1);
/* 122:137 */       i += 2;
/* 123:    */     }
/* 124:139 */     return res;
/* 125:    */   }
/* 126:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.collectors.BytecodeSourceMapper
 * JD-Core Version:    0.7.0.1
 */