/*   1:    */ package org.jetbrains.java.decompiler.main.collectors;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor;
/*  13:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*  14:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  15:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  16:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  17:    */ import org.jetbrains.java.decompiler.struct.StructContext;
/*  18:    */ 
/*  19:    */ public class ImportCollector
/*  20:    */ {
/*  21:    */   private static final String JAVA_LANG_PACKAGE = "java.lang";
/*  22: 32 */   private final Map<String, String> mapSimpleNames = new HashMap();
/*  23: 33 */   private final Set<String> setNotImportedNames = new HashSet();
/*  24: 34 */   private String currentPackageSlash = "";
/*  25: 35 */   private String currentPackagePoint = "";
/*  26:    */   
/*  27:    */   public ImportCollector(ClassesProcessor.ClassNode root)
/*  28:    */   {
/*  29: 39 */     String clname = root.classStruct.qualifiedName;
/*  30: 40 */     int index = clname.lastIndexOf("/");
/*  31: 41 */     if (index >= 0)
/*  32:    */     {
/*  33: 42 */       this.currentPackageSlash = clname.substring(0, index);
/*  34: 43 */       this.currentPackagePoint = this.currentPackageSlash.replace('/', '.');
/*  35: 44 */       this.currentPackageSlash += "/";
/*  36:    */     }
/*  37:    */   }
/*  38:    */   
/*  39:    */   public String getShortName(String fullname)
/*  40:    */   {
/*  41: 49 */     return getShortName(fullname, true);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public String getShortName(String fullname, boolean imported)
/*  45:    */   {
/*  46: 54 */     ClassesProcessor clproc = DecompilerContext.getClassProcessor();
/*  47: 55 */     ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)clproc.getMapRootClasses().get(fullname.replace('.', '/'));
/*  48:    */     
/*  49: 57 */     String retname = null;
/*  50: 59 */     if ((node != null) && (node.classStruct.isOwn()))
/*  51:    */     {
/*  52: 61 */       retname = node.simpleName;
/*  53: 63 */       while ((node.parent != null) && (node.type == 1))
/*  54:    */       {
/*  55: 64 */         retname = node.parent.simpleName + "." + retname;
/*  56: 65 */         node = node.parent;
/*  57:    */       }
/*  58: 68 */       if (node.type == 0)
/*  59:    */       {
/*  60: 69 */         fullname = node.classStruct.qualifiedName;
/*  61: 70 */         fullname = fullname.replace('/', '.');
/*  62:    */       }
/*  63:    */       else
/*  64:    */       {
/*  65: 73 */         return retname;
/*  66:    */       }
/*  67:    */     }
/*  68:    */     else
/*  69:    */     {
/*  70: 77 */       fullname = fullname.replace('$', '.');
/*  71:    */     }
/*  72: 80 */     String nshort = fullname;
/*  73: 81 */     String npackage = "";
/*  74:    */     
/*  75: 83 */     int lastpoint = fullname.lastIndexOf(".");
/*  76: 85 */     if (lastpoint >= 0)
/*  77:    */     {
/*  78: 86 */       nshort = fullname.substring(lastpoint + 1);
/*  79: 87 */       npackage = fullname.substring(0, lastpoint);
/*  80:    */     }
/*  81: 90 */     StructContext context = DecompilerContext.getStructContext();
/*  82:    */     
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86: 95 */     boolean existsDefaultClass = ((context.getClass(this.currentPackageSlash + nshort) != null) && (!npackage.equals(this.currentPackagePoint))) || ((context.getClass(nshort) != null) && (!this.currentPackagePoint.isEmpty()));
/*  87:100 */     if ((existsDefaultClass) || ((this.mapSimpleNames.containsKey(nshort)) && (!npackage.equals(this.mapSimpleNames.get(nshort))))) {
/*  88:103 */       return npackage + "." + retname;
/*  89:    */     }
/*  90:105 */     if (!this.mapSimpleNames.containsKey(nshort))
/*  91:    */     {
/*  92:106 */       this.mapSimpleNames.put(nshort, npackage);
/*  93:108 */       if (!imported) {
/*  94:109 */         this.setNotImportedNames.add(nshort);
/*  95:    */       }
/*  96:    */     }
/*  97:113 */     return retname == null ? nshort : retname;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public int writeImports(TextBuffer buffer)
/* 101:    */   {
/* 102:117 */     int importlines_written = 0;
/* 103:    */     
/* 104:119 */     List<String> imports = packImports();
/* 105:121 */     for (String s : imports)
/* 106:    */     {
/* 107:122 */       buffer.append("import ");
/* 108:123 */       buffer.append(s);
/* 109:124 */       buffer.append(";");
/* 110:125 */       buffer.appendLineSeparator();
/* 111:    */       
/* 112:127 */       importlines_written++;
/* 113:    */     }
/* 114:130 */     return importlines_written;
/* 115:    */   }
/* 116:    */   
/* 117:    */   private List<String> packImports()
/* 118:    */   {
/* 119:134 */     List<Map.Entry<String, String>> lst = new ArrayList(this.mapSimpleNames.entrySet());
/* 120:    */     
/* 121:136 */     Collections.sort(lst, new Comparator()
/* 122:    */     {
/* 123:    */       public int compare(Map.Entry<String, String> par0, Map.Entry<String, String> par1)
/* 124:    */       {
/* 125:138 */         int res = ((String)par0.getValue()).compareTo((String)par1.getValue());
/* 126:139 */         if (res == 0) {
/* 127:140 */           res = ((String)par0.getKey()).compareTo((String)par1.getKey());
/* 128:    */         }
/* 129:142 */         return res;
/* 130:    */       }
/* 131:145 */     });
/* 132:146 */     List<String> res = new ArrayList();
/* 133:147 */     for (Map.Entry<String, String> ent : lst) {
/* 134:149 */       if ((!this.setNotImportedNames.contains(ent.getKey())) && (!"java.lang".equals(ent.getValue())) && (!((String)ent.getValue()).isEmpty())) {
/* 135:152 */         res.add((String)ent.getValue() + "." + (String)ent.getKey());
/* 136:    */       }
/* 137:    */     }
/* 138:156 */     return res;
/* 139:    */   }
/* 140:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.collectors.ImportCollector
 * JD-Core Version:    0.7.0.1
 */