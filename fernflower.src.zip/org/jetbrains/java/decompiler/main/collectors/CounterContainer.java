/*  1:   */ package org.jetbrains.java.decompiler.main.collectors;
/*  2:   */ 
/*  3:   */ public class CounterContainer
/*  4:   */ {
/*  5:   */   public static final int STATEMENT_COUNTER = 0;
/*  6:   */   public static final int EXPRENT_COUNTER = 1;
/*  7:   */   public static final int VAR_COUNTER = 2;
/*  8:24 */   private final int[] values = { 1, 1, 1 };
/*  9:   */   
/* 10:   */   public void setCounter(int counter, int value)
/* 11:   */   {
/* 12:27 */     this.values[counter] = value;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public int getCounter(int counter)
/* 16:   */   {
/* 17:31 */     return this.values[counter];
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int getCounterAndIncrement(int counter)
/* 21:   */   {
/* 22:35 */     int tmp5_4 = counter; int[] tmp5_1 = this.values; int tmp7_6 = tmp5_1[tmp5_4];tmp5_1[tmp5_4] = (tmp7_6 + 1);return tmp7_6;
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.collectors.CounterContainer
 * JD-Core Version:    0.7.0.1
 */