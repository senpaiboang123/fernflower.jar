/*  1:   */ package org.jetbrains.java.decompiler.main.extern;
/*  2:   */ 
/*  3:   */ public abstract interface IIdentifierRenamer
/*  4:   */ {
/*  5:   */   public abstract boolean toBeRenamed(Type paramType, String paramString1, String paramString2, String paramString3);
/*  6:   */   
/*  7:   */   public abstract String getNextClassName(String paramString1, String paramString2);
/*  8:   */   
/*  9:   */   public abstract String getNextFieldName(String paramString1, String paramString2, String paramString3);
/* 10:   */   
/* 11:   */   public abstract String getNextMethodName(String paramString1, String paramString2, String paramString3);
/* 12:   */   
/* 13:   */   public static enum Type
/* 14:   */   {
/* 15:20 */     ELEMENT_CLASS,  ELEMENT_FIELD,  ELEMENT_METHOD;
/* 16:   */     
/* 17:   */     private Type() {}
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.extern.IIdentifierRenamer
 * JD-Core Version:    0.7.0.1
 */