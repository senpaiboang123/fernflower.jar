package org.jetbrains.java.decompiler.main.extern;

import java.util.jar.Manifest;

public abstract interface IResultSaver
{
  public abstract void saveFolder(String paramString);
  
  public abstract void copyFile(String paramString1, String paramString2, String paramString3);
  
  public abstract void saveClassFile(String paramString1, String paramString2, String paramString3, String paramString4, int[] paramArrayOfInt);
  
  public abstract void createArchive(String paramString1, String paramString2, Manifest paramManifest);
  
  public abstract void saveDirEntry(String paramString1, String paramString2, String paramString3);
  
  public abstract void copyEntry(String paramString1, String paramString2, String paramString3, String paramString4);
  
  public abstract void saveClassEntry(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);
  
  public abstract void closeArchive(String paramString1, String paramString2);
}


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.extern.IResultSaver
 * JD-Core Version:    0.7.0.1
 */