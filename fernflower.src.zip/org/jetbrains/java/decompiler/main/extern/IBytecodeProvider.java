package org.jetbrains.java.decompiler.main.extern;

import java.io.IOException;

public abstract interface IBytecodeProvider
{
  public abstract byte[] getBytecode(String paramString1, String paramString2)
    throws IOException;
}


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.extern.IBytecodeProvider
 * JD-Core Version:    0.7.0.1
 */