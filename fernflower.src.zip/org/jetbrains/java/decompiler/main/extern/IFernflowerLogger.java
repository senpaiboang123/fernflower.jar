/*  1:   */ package org.jetbrains.java.decompiler.main.extern;
/*  2:   */ 
/*  3:   */ public abstract class IFernflowerLogger
/*  4:   */ {
/*  5:   */   public static enum Severity
/*  6:   */   {
/*  7:21 */     TRACE("TRACE: "),  INFO("INFO:  "),  WARN("WARN:  "),  ERROR("ERROR: ");
/*  8:   */     
/*  9:   */     public final String prefix;
/* 10:   */     
/* 11:   */     private Severity(String prefix)
/* 12:   */     {
/* 13:26 */       this.prefix = prefix;
/* 14:   */     }
/* 15:   */   }
/* 16:   */   
/* 17:30 */   private Severity severity = Severity.INFO;
/* 18:   */   
/* 19:   */   public boolean accepts(Severity severity)
/* 20:   */   {
/* 21:33 */     return severity.ordinal() >= this.severity.ordinal();
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setSeverity(Severity severity)
/* 25:   */   {
/* 26:37 */     this.severity = severity;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public abstract void writeMessage(String paramString, Severity paramSeverity);
/* 30:   */   
/* 31:   */   public abstract void writeMessage(String paramString, Throwable paramThrowable);
/* 32:   */   
/* 33:   */   public void startReadingClass(String className) {}
/* 34:   */   
/* 35:   */   public void endReadingClass() {}
/* 36:   */   
/* 37:   */   public void startClass(String className) {}
/* 38:   */   
/* 39:   */   public void endClass() {}
/* 40:   */   
/* 41:   */   public void startMethod(String methodName) {}
/* 42:   */   
/* 43:   */   public void endMethod() {}
/* 44:   */   
/* 45:   */   public void startWriteClass(String className) {}
/* 46:   */   
/* 47:   */   public void endWriteClass() {}
/* 48:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.extern.IFernflowerLogger
 * JD-Core Version:    0.7.0.1
 */