/*  1:   */ package org.jetbrains.java.decompiler.main.extern;
/*  2:   */ 
/*  3:   */ import java.util.Collections;
/*  4:   */ import java.util.HashMap;
/*  5:   */ import java.util.Map;
/*  6:   */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  7:   */ 
/*  8:   */ public abstract interface IFernflowerPreferences
/*  9:   */ {
/* 10:   */   public static final String REMOVE_BRIDGE = "rbr";
/* 11:   */   public static final String REMOVE_SYNTHETIC = "rsy";
/* 12:   */   public static final String DECOMPILE_INNER = "din";
/* 13:   */   public static final String DECOMPILE_CLASS_1_4 = "dc4";
/* 14:   */   public static final String DECOMPILE_ASSERTIONS = "das";
/* 15:   */   public static final String HIDE_EMPTY_SUPER = "hes";
/* 16:   */   public static final String HIDE_DEFAULT_CONSTRUCTOR = "hdc";
/* 17:   */   public static final String DECOMPILE_GENERIC_SIGNATURES = "dgs";
/* 18:   */   public static final String NO_EXCEPTIONS_RETURN = "ner";
/* 19:   */   public static final String DECOMPILE_ENUM = "den";
/* 20:   */   public static final String REMOVE_GET_CLASS_NEW = "rgn";
/* 21:   */   public static final String LITERALS_AS_IS = "lit";
/* 22:   */   public static final String BOOLEAN_TRUE_ONE = "bto";
/* 23:   */   public static final String ASCII_STRING_CHARACTERS = "asc";
/* 24:   */   public static final String SYNTHETIC_NOT_SET = "nns";
/* 25:   */   public static final String UNDEFINED_PARAM_TYPE_OBJECT = "uto";
/* 26:   */   public static final String USE_DEBUG_VAR_NAMES = "udv";
/* 27:   */   public static final String REMOVE_EMPTY_RANGES = "rer";
/* 28:   */   public static final String FINALLY_DEINLINE = "fdi";
/* 29:   */   public static final String IDEA_NOT_NULL_ANNOTATION = "inn";
/* 30:   */   public static final String LAMBDA_TO_ANONYMOUS_CLASS = "lac";
/* 31:   */   public static final String BYTECODE_SOURCE_MAPPING = "bsm";
/* 32:   */   public static final String LOG_LEVEL = "log";
/* 33:   */   public static final String MAX_PROCESSING_METHOD = "mpm";
/* 34:   */   public static final String RENAME_ENTITIES = "ren";
/* 35:   */   public static final String USER_RENAMER_CLASS = "urc";
/* 36:   */   public static final String NEW_LINE_SEPARATOR = "nls";
/* 37:   */   public static final String INDENT_STRING = "ind";
/* 38:   */   public static final String BANNER = "ban";
/* 39:   */   public static final String DUMP_ORIGINAL_LINES = "__dump_original_lines__";
/* 40:   */   public static final String UNIT_TEST_MODE = "__unit_test_mode__";
/* 41:   */   public static final String LINE_SEPARATOR_WIN = "\r\n";
/* 42:   */   public static final String LINE_SEPARATOR_UNX = "\n";
/* 43:62 */   public static final Map<String, Object> DEFAULTS = Collections.unmodifiableMap(new HashMap() {});
/* 44:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.main.extern.IFernflowerPreferences
 * JD-Core Version:    0.7.0.1
 */