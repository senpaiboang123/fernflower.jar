/*   1:    */ package org.jetbrains.java.decompiler.modules.code;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.LinkedList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Set;
/*   9:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*  10:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*  11:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*  12:    */ import org.jetbrains.java.decompiler.code.cfg.ControlFlowGraph;
/*  13:    */ import org.jetbrains.java.decompiler.code.cfg.ExceptionRangeCFG;
/*  14:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  15:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  16:    */ 
/*  17:    */ public class DeadCodeHelper
/*  18:    */ {
/*  19:    */   public static void removeDeadBlocks(ControlFlowGraph graph)
/*  20:    */   {
/*  21: 33 */     LinkedList<BasicBlock> stack = new LinkedList();
/*  22: 34 */     HashSet<BasicBlock> setStacked = new HashSet();
/*  23:    */     
/*  24: 36 */     stack.add(graph.getFirst());
/*  25: 37 */     setStacked.add(graph.getFirst());
/*  26: 39 */     while (!stack.isEmpty())
/*  27:    */     {
/*  28: 40 */       BasicBlock block = (BasicBlock)stack.removeFirst();
/*  29:    */       
/*  30: 42 */       List<BasicBlock> lstSuccs = new ArrayList(block.getSuccs());
/*  31: 43 */       lstSuccs.addAll(block.getSuccExceptions());
/*  32: 45 */       for (BasicBlock succ : lstSuccs) {
/*  33: 46 */         if (!setStacked.contains(succ))
/*  34:    */         {
/*  35: 47 */           stack.add(succ);
/*  36: 48 */           setStacked.add(succ);
/*  37:    */         }
/*  38:    */       }
/*  39:    */     }
/*  40: 53 */     HashSet<BasicBlock> setAllBlocks = new HashSet(graph.getBlocks());
/*  41: 54 */     setAllBlocks.removeAll(setStacked);
/*  42: 56 */     for (BasicBlock block : setAllBlocks) {
/*  43: 57 */       graph.removeBlock(block);
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static void removeEmptyBlocks(ControlFlowGraph graph)
/*  48:    */   {
/*  49: 63 */     List<BasicBlock> blocks = graph.getBlocks();
/*  50:    */     boolean cont;
/*  51:    */     do
/*  52:    */     {
/*  53: 67 */       cont = false;
/*  54: 69 */       for (int i = blocks.size() - 1; i >= 0; i--)
/*  55:    */       {
/*  56: 70 */         BasicBlock block = (BasicBlock)blocks.get(i);
/*  57: 72 */         if (removeEmptyBlock(graph, block, false))
/*  58:    */         {
/*  59: 73 */           cont = true;
/*  60: 74 */           break;
/*  61:    */         }
/*  62:    */       }
/*  63: 78 */     } while (cont);
/*  64:    */   }
/*  65:    */   
/*  66:    */   private static boolean removeEmptyBlock(ControlFlowGraph graph, BasicBlock block, boolean merging)
/*  67:    */   {
/*  68: 83 */     boolean deletedRanges = false;
/*  69: 85 */     if (block.getSeq().isEmpty())
/*  70:    */     {
/*  71: 87 */       if (block.getSuccs().size() > 1)
/*  72:    */       {
/*  73: 88 */         if (block.getPreds().size() > 1) {
/*  74: 90 */           throw new RuntimeException("ERROR: empty block with multiple predecessors and successors found");
/*  75:    */         }
/*  76: 92 */         if (!merging) {
/*  77: 93 */           throw new RuntimeException("ERROR: empty block with multiple successors found");
/*  78:    */         }
/*  79:    */       }
/*  80: 97 */       HashSet<BasicBlock> setExits = new HashSet(graph.getLast().getPreds());
/*  81: 99 */       if ((block.getPredExceptions().isEmpty()) && ((!setExits.contains(block)) || (block.getPreds().size() == 1)))
/*  82:    */       {
/*  83:102 */         if (setExits.contains(block))
/*  84:    */         {
/*  85:103 */           BasicBlock pred = (BasicBlock)block.getPreds().get(0);
/*  86:106 */           if ((pred.getSuccs().size() != 1) || ((!pred.getSeq().isEmpty()) && (pred.getSeq().getLastInstr().group == 3))) {
/*  87:108 */             return false;
/*  88:    */           }
/*  89:    */         }
/*  90:112 */         HashSet<BasicBlock> setPreds = new HashSet(block.getPreds());
/*  91:113 */         HashSet<BasicBlock> setSuccs = new HashSet(block.getSuccs());
/*  92:    */         
/*  93:    */ 
/*  94:116 */         HashSet<BasicBlock> setCommonExceptionHandlers = null;
/*  95:117 */         for (int i = 0; i < 2; i++) {
/*  96:118 */           for (BasicBlock pred : i == 0 ? setPreds : setSuccs) {
/*  97:119 */             if (setCommonExceptionHandlers == null) {
/*  98:120 */               setCommonExceptionHandlers = new HashSet(pred.getSuccExceptions());
/*  99:    */             } else {
/* 100:123 */               setCommonExceptionHandlers.retainAll(pred.getSuccExceptions());
/* 101:    */             }
/* 102:    */           }
/* 103:    */         }
/* 104:129 */         if ((setCommonExceptionHandlers != null) && (!setCommonExceptionHandlers.isEmpty())) {
/* 105:130 */           for (BasicBlock handler : setCommonExceptionHandlers) {
/* 106:131 */             if (!block.getSuccExceptions().contains(handler)) {
/* 107:132 */               return false;
/* 108:    */             }
/* 109:    */           }
/* 110:    */         }
/* 111:138 */         List<ExceptionRangeCFG> lstRanges = graph.getExceptions();
/* 112:139 */         for (int i = lstRanges.size() - 1; i >= 0; i--)
/* 113:    */         {
/* 114:140 */           ExceptionRangeCFG range = (ExceptionRangeCFG)lstRanges.get(i);
/* 115:141 */           List<BasicBlock> lst = range.getProtectedRange();
/* 116:143 */           if ((lst.size() == 1) && (lst.get(0) == block)) {
/* 117:144 */             if (DecompilerContext.getOption("rer"))
/* 118:    */             {
/* 119:145 */               block.removeSuccessorException(range.getHandler());
/* 120:146 */               lstRanges.remove(i);
/* 121:    */               
/* 122:148 */               deletedRanges = true;
/* 123:    */             }
/* 124:    */             else
/* 125:    */             {
/* 126:151 */               return false;
/* 127:    */             }
/* 128:    */           }
/* 129:    */         }
/* 130:    */         BasicBlock pred;
/* 131:    */         Iterator i$;
/* 132:158 */         if (merging)
/* 133:    */         {
/* 134:159 */           pred = (BasicBlock)block.getPreds().get(0);
/* 135:160 */           pred.removeSuccessor(block);
/* 136:    */           
/* 137:162 */           List<BasicBlock> lstSuccs = new ArrayList(block.getSuccs());
/* 138:163 */           for (BasicBlock succ : lstSuccs)
/* 139:    */           {
/* 140:164 */             block.removeSuccessor(succ);
/* 141:165 */             pred.addSuccessor(succ);
/* 142:    */           }
/* 143:    */         }
/* 144:    */         else
/* 145:    */         {
/* 146:169 */           for (i$ = setPreds.iterator(); i$.hasNext();)
/* 147:    */           {
/* 148:169 */             pred = (BasicBlock)i$.next();
/* 149:170 */             for (BasicBlock succ : setSuccs) {
/* 150:171 */               pred.replaceSuccessor(block, succ);
/* 151:    */             }
/* 152:    */           }
/* 153:    */         }
/* 154:    */         BasicBlock pred;
/* 155:177 */         Set<BasicBlock> setFinallyExits = graph.getFinallyExits();
/* 156:178 */         if (setFinallyExits.contains(block))
/* 157:    */         {
/* 158:179 */           setFinallyExits.remove(block);
/* 159:180 */           setFinallyExits.add(setPreds.iterator().next());
/* 160:    */         }
/* 161:184 */         if (graph.getFirst() == block)
/* 162:    */         {
/* 163:185 */           if (setSuccs.size() != 1) {
/* 164:186 */             throw new RuntimeException("multiple or no entry blocks!");
/* 165:    */           }
/* 166:189 */           graph.setFirst((BasicBlock)setSuccs.iterator().next());
/* 167:    */         }
/* 168:194 */         graph.removeBlock(block);
/* 169:196 */         if (deletedRanges) {
/* 170:197 */           removeDeadBlocks(graph);
/* 171:    */         }
/* 172:    */       }
/* 173:    */     }
/* 174:202 */     return deletedRanges;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public static boolean isDominator(ControlFlowGraph graph, BasicBlock block, BasicBlock dom)
/* 178:    */   {
/* 179:208 */     HashSet<BasicBlock> marked = new HashSet();
/* 180:210 */     if (block == dom) {
/* 181:211 */       return true;
/* 182:    */     }
/* 183:214 */     LinkedList<BasicBlock> lstNodes = new LinkedList();
/* 184:215 */     lstNodes.add(block);
/* 185:217 */     while (!lstNodes.isEmpty())
/* 186:    */     {
/* 187:219 */       BasicBlock node = (BasicBlock)lstNodes.remove(0);
/* 188:220 */       if (!marked.contains(node))
/* 189:    */       {
/* 190:224 */         marked.add(node);
/* 191:227 */         if (node == graph.getFirst()) {
/* 192:228 */           return false;
/* 193:    */         }
/* 194:231 */         for (int i = 0; i < node.getPreds().size(); i++)
/* 195:    */         {
/* 196:232 */           BasicBlock pred = (BasicBlock)node.getPreds().get(i);
/* 197:233 */           if ((!marked.contains(pred)) && (pred != dom)) {
/* 198:234 */             lstNodes.add(pred);
/* 199:    */           }
/* 200:    */         }
/* 201:238 */         for (int i = 0; i < node.getPredExceptions().size(); i++)
/* 202:    */         {
/* 203:239 */           BasicBlock pred = (BasicBlock)node.getPredExceptions().get(i);
/* 204:240 */           if ((!marked.contains(pred)) && (pred != dom)) {
/* 205:241 */             lstNodes.add(pred);
/* 206:    */           }
/* 207:    */         }
/* 208:    */       }
/* 209:    */     }
/* 210:246 */     return true;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public static void removeGotos(ControlFlowGraph graph)
/* 214:    */   {
/* 215:251 */     for (BasicBlock block : graph.getBlocks())
/* 216:    */     {
/* 217:252 */       Instruction instr = block.getLastInstruction();
/* 218:254 */       if ((instr != null) && (instr.opcode == 167)) {
/* 219:255 */         block.getSeq().removeLast();
/* 220:    */       }
/* 221:    */     }
/* 222:259 */     removeEmptyBlocks(graph);
/* 223:    */   }
/* 224:    */   
/* 225:    */   public static void connectDummyExitBlock(ControlFlowGraph graph)
/* 226:    */   {
/* 227:264 */     BasicBlock exit = graph.getLast();
/* 228:265 */     for (BasicBlock block : new HashSet(exit.getPreds()))
/* 229:    */     {
/* 230:266 */       exit.removePredecessor(block);
/* 231:267 */       block.addSuccessor(exit);
/* 232:    */     }
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static void incorporateValueReturns(ControlFlowGraph graph)
/* 236:    */   {
/* 237:273 */     for (Iterator i$ = graph.getBlocks().iterator(); i$.hasNext();)
/* 238:    */     {
/* 239:273 */       block = (BasicBlock)i$.next();
/* 240:274 */       InstructionSequence seq = block.getSeq();
/* 241:    */       
/* 242:276 */       int len = seq.length();
/* 243:277 */       if ((len > 0) && (len < 3))
/* 244:    */       {
/* 245:279 */         boolean ok = false;
/* 246:281 */         if ((seq.getLastInstr().opcode >= 172) && (seq.getLastInstr().opcode <= 177)) {
/* 247:282 */           if (len == 1) {
/* 248:283 */             ok = true;
/* 249:285 */           } else if (seq.getLastInstr().opcode != 177) {
/* 250:286 */             switch (seq.getInstr(0).opcode)
/* 251:    */             {
/* 252:    */             case 1: 
/* 253:    */             case 9: 
/* 254:    */             case 10: 
/* 255:    */             case 11: 
/* 256:    */             case 12: 
/* 257:    */             case 13: 
/* 258:    */             case 14: 
/* 259:    */             case 15: 
/* 260:    */             case 16: 
/* 261:    */             case 17: 
/* 262:    */             case 18: 
/* 263:    */             case 19: 
/* 264:    */             case 20: 
/* 265:    */             case 21: 
/* 266:    */             case 22: 
/* 267:    */             case 23: 
/* 268:    */             case 24: 
/* 269:    */             case 25: 
/* 270:305 */               ok = true;
/* 271:    */             }
/* 272:    */           }
/* 273:    */         }
/* 274:310 */         if (ok)
/* 275:    */         {
/* 276:312 */           if (!block.getPreds().isEmpty())
/* 277:    */           {
/* 278:314 */             HashSet<BasicBlock> setPredHandlersUnion = new HashSet();
/* 279:315 */             HashSet<BasicBlock> setPredHandlersIntersection = new HashSet();
/* 280:    */             
/* 281:317 */             boolean firstpred = true;
/* 282:318 */             for (BasicBlock pred : block.getPreds())
/* 283:    */             {
/* 284:319 */               if (firstpred)
/* 285:    */               {
/* 286:320 */                 setPredHandlersIntersection.addAll(pred.getSuccExceptions());
/* 287:321 */                 firstpred = false;
/* 288:    */               }
/* 289:    */               else
/* 290:    */               {
/* 291:324 */                 setPredHandlersIntersection.retainAll(pred.getSuccExceptions());
/* 292:    */               }
/* 293:327 */               setPredHandlersUnion.addAll(pred.getSuccExceptions());
/* 294:    */             }
/* 295:331 */             setPredHandlersIntersection.removeAll(block.getSuccExceptions());
/* 296:332 */             BasicBlock predecessor = (BasicBlock)block.getPreds().get(0);
/* 297:334 */             for (BasicBlock handler : setPredHandlersIntersection)
/* 298:    */             {
/* 299:335 */               ExceptionRangeCFG range = graph.getExceptionRange(handler, predecessor);
/* 300:    */               
/* 301:337 */               range.getProtectedRange().add(block);
/* 302:338 */               block.addSuccessorException(handler);
/* 303:    */             }
/* 304:342 */             HashSet<BasicBlock> setRangesToBeRemoved = new HashSet(block.getSuccExceptions());
/* 305:343 */             setRangesToBeRemoved.removeAll(setPredHandlersUnion);
/* 306:345 */             for (BasicBlock handler : setRangesToBeRemoved)
/* 307:    */             {
/* 308:346 */               ExceptionRangeCFG range = graph.getExceptionRange(handler, block);
/* 309:348 */               if (range.getProtectedRange().size() > 1)
/* 310:    */               {
/* 311:349 */                 range.getProtectedRange().remove(block);
/* 312:350 */                 block.removeSuccessorException(handler);
/* 313:    */               }
/* 314:    */             }
/* 315:    */           }
/* 316:356 */           if ((block.getPreds().size() == 1) && (block.getPredExceptions().isEmpty()))
/* 317:    */           {
/* 318:358 */             bpred = (BasicBlock)block.getPreds().get(0);
/* 319:359 */             if (bpred.getSuccs().size() == 1)
/* 320:    */             {
/* 321:362 */               for (BasicBlock succ : bpred.getSuccExceptions()) {
/* 322:363 */                 if (!block.getSuccExceptions().contains(succ))
/* 323:    */                 {
/* 324:364 */                   ExceptionRangeCFG range = graph.getExceptionRange(succ, bpred);
/* 325:    */                   
/* 326:366 */                   range.getProtectedRange().add(block);
/* 327:367 */                   block.addSuccessorException(succ);
/* 328:    */                 }
/* 329:    */               }
/* 330:372 */               for (BasicBlock succ : new HashSet(block.getSuccExceptions())) {
/* 331:373 */                 if (!bpred.getSuccExceptions().contains(succ))
/* 332:    */                 {
/* 333:374 */                   ExceptionRangeCFG range = graph.getExceptionRange(succ, block);
/* 334:376 */                   if (range.getProtectedRange().size() > 1)
/* 335:    */                   {
/* 336:377 */                     range.getProtectedRange().remove(block);
/* 337:378 */                     block.removeSuccessorException(succ);
/* 338:    */                   }
/* 339:    */                 }
/* 340:    */               }
/* 341:    */             }
/* 342:    */           }
/* 343:    */         }
/* 344:    */       }
/* 345:    */     }
/* 346:    */     BasicBlock block;
/* 347:    */     BasicBlock bpred;
/* 348:    */   }
/* 349:    */   
/* 350:    */   public static void mergeBasicBlocks(ControlFlowGraph graph)
/* 351:    */   {
/* 352:    */     for (;;)
/* 353:    */     {
/* 354:394 */       boolean merged = false;
/* 355:396 */       for (BasicBlock block : graph.getBlocks())
/* 356:    */       {
/* 357:398 */         InstructionSequence seq = block.getSeq();
/* 358:400 */         if (block.getSuccs().size() == 1)
/* 359:    */         {
/* 360:401 */           BasicBlock next = (BasicBlock)block.getSuccs().get(0);
/* 361:403 */           if ((next != graph.getLast()) && ((seq.isEmpty()) || (seq.getLastInstr().group != 3))) {
/* 362:405 */             if ((next.getPreds().size() == 1) && (next.getPredExceptions().isEmpty()) && (next != graph.getFirst()))
/* 363:    */             {
/* 364:408 */               boolean sameRanges = true;
/* 365:409 */               for (ExceptionRangeCFG range : graph.getExceptions()) {
/* 366:410 */                 if ((range.getProtectedRange().contains(block) ^ range.getProtectedRange().contains(next)))
/* 367:    */                 {
/* 368:412 */                   sameRanges = false;
/* 369:413 */                   break;
/* 370:    */                 }
/* 371:    */               }
/* 372:417 */               if (sameRanges)
/* 373:    */               {
/* 374:418 */                 seq.addSequence(next.getSeq());
/* 375:419 */                 block.getInstrOldOffsets().addAll(next.getInstrOldOffsets());
/* 376:420 */                 next.getSeq().clear();
/* 377:    */                 
/* 378:422 */                 removeEmptyBlock(graph, next, true);
/* 379:    */                 
/* 380:424 */                 merged = true;
/* 381:425 */                 break;
/* 382:    */               }
/* 383:    */             }
/* 384:    */           }
/* 385:    */         }
/* 386:    */       }
/* 387:432 */       if (!merged) {
/* 388:    */         break;
/* 389:    */       }
/* 390:    */     }
/* 391:    */   }
/* 392:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.code.DeadCodeHelper
 * JD-Core Version:    0.7.0.1
 */