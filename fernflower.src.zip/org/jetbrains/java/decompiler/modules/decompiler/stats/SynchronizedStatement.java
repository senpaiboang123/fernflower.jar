/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*   6:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*   7:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*   8:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   9:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.SequenceHelper;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  14:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  15:    */ 
/*  16:    */ public class SynchronizedStatement
/*  17:    */   extends Statement
/*  18:    */ {
/*  19:    */   private Statement body;
/*  20: 35 */   private final List<Exprent> headexprent = new ArrayList();
/*  21:    */   
/*  22:    */   public SynchronizedStatement()
/*  23:    */   {
/*  24: 42 */     this.type = 10;
/*  25:    */     
/*  26: 44 */     this.headexprent.add(null);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public SynchronizedStatement(Statement head, Statement body, Statement exc)
/*  30:    */   {
/*  31: 49 */     this();
/*  32:    */     
/*  33: 51 */     this.first = head;
/*  34: 52 */     this.stats.addWithKey(head, head.id);
/*  35:    */     
/*  36: 54 */     this.body = body;
/*  37: 55 */     this.stats.addWithKey(body, body.id);
/*  38:    */     
/*  39: 57 */     this.stats.addWithKey(exc, exc.id);
/*  40:    */     
/*  41: 59 */     List<StatEdge> lstSuccs = body.getSuccessorEdges(1073741824);
/*  42: 60 */     if (!lstSuccs.isEmpty())
/*  43:    */     {
/*  44: 61 */       StatEdge edge = (StatEdge)lstSuccs.get(0);
/*  45: 62 */       if (edge.getType() == 1) {
/*  46: 63 */         this.post = edge.getDestination();
/*  47:    */       }
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  52:    */   {
/*  53: 74 */     TextBuffer buf = new TextBuffer();
/*  54: 75 */     buf.append(ExprProcessor.listToJava(this.varDefinitions, indent, tracer));
/*  55: 76 */     buf.append(this.first.toJava(indent, tracer));
/*  56: 78 */     if (isLabeled())
/*  57:    */     {
/*  58: 79 */       buf.appendIndent(indent).append("label").append(this.id.toString()).append(":").appendLineSeparator();
/*  59: 80 */       tracer.incrementCurrentSourceLine();
/*  60:    */     }
/*  61: 83 */     buf.appendIndent(indent).append(((Exprent)this.headexprent.get(0)).toJava(indent, tracer)).append(" {").appendLineSeparator();
/*  62: 84 */     tracer.incrementCurrentSourceLine();
/*  63:    */     
/*  64: 86 */     buf.append(ExprProcessor.jmpWrapper(this.body, indent + 1, true, tracer));
/*  65:    */     
/*  66: 88 */     buf.appendIndent(indent).append("}").appendLineSeparator();
/*  67: 89 */     mapMonitorExitInstr(tracer);
/*  68: 90 */     tracer.incrementCurrentSourceLine();
/*  69:    */     
/*  70: 92 */     return buf;
/*  71:    */   }
/*  72:    */   
/*  73:    */   private void mapMonitorExitInstr(BytecodeMappingTracer tracer)
/*  74:    */   {
/*  75: 96 */     BasicBlock block = this.body.getBasichead().getBlock();
/*  76: 97 */     if ((!block.getSeq().isEmpty()) && (block.getLastInstruction().opcode == 195))
/*  77:    */     {
/*  78: 98 */       Integer offset = block.getOldOffset(block.size() - 1);
/*  79: 99 */       if (offset.intValue() > -1) {
/*  80: 99 */         tracer.addMapping(offset.intValue());
/*  81:    */       }
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void initExprents()
/*  86:    */   {
/*  87:104 */     this.headexprent.set(0, this.first.getExprents().remove(this.first.getExprents().size() - 1));
/*  88:    */   }
/*  89:    */   
/*  90:    */   public List<Object> getSequentialObjects()
/*  91:    */   {
/*  92:109 */     List<Object> lst = new ArrayList(this.stats);
/*  93:110 */     lst.add(1, this.headexprent.get(0));
/*  94:    */     
/*  95:112 */     return lst;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void replaceExprent(Exprent oldexpr, Exprent newexpr)
/*  99:    */   {
/* 100:116 */     if (this.headexprent.get(0) == oldexpr) {
/* 101:117 */       this.headexprent.set(0, newexpr);
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void replaceStatement(Statement oldstat, Statement newstat)
/* 106:    */   {
/* 107:123 */     if (this.body == oldstat) {
/* 108:124 */       this.body = newstat;
/* 109:    */     }
/* 110:127 */     super.replaceStatement(oldstat, newstat);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void removeExc()
/* 114:    */   {
/* 115:131 */     Statement exc = (Statement)this.stats.get(2);
/* 116:132 */     SequenceHelper.destroyStatementContent(exc, true);
/* 117:    */     
/* 118:134 */     this.stats.removeWithKey(exc.id);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public Statement getSimpleCopy()
/* 122:    */   {
/* 123:138 */     return new SynchronizedStatement();
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void initSimpleCopy()
/* 127:    */   {
/* 128:142 */     this.first = ((Statement)this.stats.get(0));
/* 129:143 */     this.body = ((Statement)this.stats.get(1));
/* 130:    */   }
/* 131:    */   
/* 132:    */   public Statement getBody()
/* 133:    */   {
/* 134:151 */     return this.body;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void setBody(Statement body)
/* 138:    */   {
/* 139:155 */     this.body = body;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public List<Exprent> getHeadexprentList()
/* 143:    */   {
/* 144:159 */     return this.headexprent;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public Exprent getHeadexprent()
/* 148:    */   {
/* 149:163 */     return (Exprent)this.headexprent.get(0);
/* 150:    */   }
/* 151:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.SynchronizedStatement
 * JD-Core Version:    0.7.0.1
 */