/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.List;
/*   6:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*   7:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*   8:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*   9:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  10:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  11:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  12:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.DecHelper;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  18:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  19:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  20:    */ 
/*  21:    */ public class CatchStatement
/*  22:    */   extends Statement
/*  23:    */ {
/*  24: 37 */   private final List<List<String>> exctstrings = new ArrayList();
/*  25: 39 */   private final List<VarExprent> vars = new ArrayList();
/*  26:    */   
/*  27:    */   private CatchStatement()
/*  28:    */   {
/*  29: 46 */     this.type = 7;
/*  30:    */   }
/*  31:    */   
/*  32:    */   private CatchStatement(Statement head, Statement next, HashSet<Statement> setHandlers)
/*  33:    */   {
/*  34: 51 */     this();
/*  35:    */     
/*  36: 53 */     this.first = head;
/*  37: 54 */     this.stats.addWithKey(this.first, this.first.id);
/*  38: 56 */     for (StatEdge edge : head.getSuccessorEdges(2))
/*  39:    */     {
/*  40: 57 */       Statement stat = edge.getDestination();
/*  41: 59 */       if (setHandlers.contains(stat))
/*  42:    */       {
/*  43: 60 */         this.stats.addWithKey(stat, stat.id);
/*  44: 61 */         this.exctstrings.add(new ArrayList(edge.getExceptions()));
/*  45:    */         
/*  46: 63 */         this.vars.add(new VarExprent(DecompilerContext.getCounterContainer().getCounterAndIncrement(2), new VarType(8, 0, (String)edge.getExceptions().get(0)), (VarProcessor)DecompilerContext.getProperty("CURRENT_VAR_PROCESSOR")));
/*  47:    */       }
/*  48:    */     }
/*  49: 70 */     if (next != null) {
/*  50: 71 */       this.post = next;
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static Statement isHead(Statement head)
/*  55:    */   {
/*  56: 81 */     if (head.getLastBasicType() != 2) {
/*  57: 82 */       return null;
/*  58:    */     }
/*  59: 85 */     HashSet<Statement> setHandlers = DecHelper.getUniquePredExceptions(head);
/*  60: 87 */     if (!setHandlers.isEmpty())
/*  61:    */     {
/*  62: 89 */       int hnextcount = 0;
/*  63:    */       
/*  64: 91 */       Statement next = null;
/*  65: 92 */       List<StatEdge> lstHeadSuccs = head.getSuccessorEdges(1073741824);
/*  66: 93 */       if ((!lstHeadSuccs.isEmpty()) && (((StatEdge)lstHeadSuccs.get(0)).getType() == 1))
/*  67:    */       {
/*  68: 94 */         next = ((StatEdge)lstHeadSuccs.get(0)).getDestination();
/*  69: 95 */         hnextcount = 2;
/*  70:    */       }
/*  71: 98 */       for (StatEdge edge : head.getSuccessorEdges(2))
/*  72:    */       {
/*  73: 99 */         Statement stat = edge.getDestination();
/*  74:    */         
/*  75:101 */         boolean handlerok = true;
/*  76:103 */         if ((edge.getExceptions() != null) && (setHandlers.contains(stat)))
/*  77:    */         {
/*  78:104 */           if (stat.getLastBasicType() != 2)
/*  79:    */           {
/*  80:105 */             handlerok = false;
/*  81:    */           }
/*  82:    */           else
/*  83:    */           {
/*  84:108 */             List<StatEdge> lstStatSuccs = stat.getSuccessorEdges(1073741824);
/*  85:109 */             if ((!lstStatSuccs.isEmpty()) && (((StatEdge)lstStatSuccs.get(0)).getType() == 1))
/*  86:    */             {
/*  87:111 */               Statement statn = ((StatEdge)lstStatSuccs.get(0)).getDestination();
/*  88:113 */               if (next == null) {
/*  89:114 */                 next = statn;
/*  90:116 */               } else if (next != statn) {
/*  91:117 */                 handlerok = false;
/*  92:    */               }
/*  93:120 */               if (handlerok) {
/*  94:121 */                 hnextcount++;
/*  95:    */               }
/*  96:    */             }
/*  97:    */           }
/*  98:    */         }
/*  99:    */         else {
/* 100:127 */           handlerok = false;
/* 101:    */         }
/* 102:130 */         if (!handlerok) {
/* 103:131 */           setHandlers.remove(stat);
/* 104:    */         }
/* 105:    */       }
/* 106:135 */       if ((hnextcount != 1) && (!setHandlers.isEmpty()))
/* 107:    */       {
/* 108:136 */         List<Statement> lst = new ArrayList();
/* 109:137 */         lst.add(head);
/* 110:138 */         lst.addAll(setHandlers);
/* 111:140 */         for (Statement st : lst) {
/* 112:141 */           if (st.isMonitorEnter()) {
/* 113:142 */             return null;
/* 114:    */           }
/* 115:    */         }
/* 116:146 */         if (DecHelper.checkStatementExceptions(lst)) {
/* 117:147 */           return new CatchStatement(head, next, setHandlers);
/* 118:    */         }
/* 119:    */       }
/* 120:    */     }
/* 121:151 */     return null;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 125:    */   {
/* 126:155 */     TextBuffer buf = new TextBuffer();
/* 127:    */     
/* 128:157 */     buf.append(ExprProcessor.listToJava(this.varDefinitions, indent, tracer));
/* 129:159 */     if (isLabeled())
/* 130:    */     {
/* 131:160 */       buf.appendIndent(indent).append("label").append(this.id.toString()).append(":").appendLineSeparator();
/* 132:161 */       tracer.incrementCurrentSourceLine();
/* 133:    */     }
/* 134:164 */     buf.appendIndent(indent).append("try {").appendLineSeparator();
/* 135:165 */     tracer.incrementCurrentSourceLine();
/* 136:    */     
/* 137:167 */     buf.append(ExprProcessor.jmpWrapper(this.first, indent + 1, true, tracer));
/* 138:168 */     buf.appendIndent(indent).append("}");
/* 139:170 */     for (int i = 1; i < this.stats.size(); i++)
/* 140:    */     {
/* 141:171 */       Statement stat = (Statement)this.stats.get(i);
/* 142:    */       
/* 143:173 */       BasicBlock block = stat.getBasichead().getBlock();
/* 144:174 */       if ((!block.getSeq().isEmpty()) && (block.getInstruction(0).opcode == 58))
/* 145:    */       {
/* 146:175 */         Integer offset = block.getOldOffset(0);
/* 147:176 */         if (offset.intValue() > -1) {
/* 148:176 */           tracer.addMapping(offset.intValue());
/* 149:    */         }
/* 150:    */       }
/* 151:179 */       buf.append(" catch (");
/* 152:    */       
/* 153:181 */       List<String> exception_types = (List)this.exctstrings.get(i - 1);
/* 154:182 */       if (exception_types.size() > 1) {
/* 155:183 */         for (int exc_index = 1; exc_index < exception_types.size(); exc_index++)
/* 156:    */         {
/* 157:184 */           VarType exc_type = new VarType(8, 0, (String)exception_types.get(exc_index));
/* 158:185 */           String exc_type_name = ExprProcessor.getCastTypeName(exc_type);
/* 159:    */           
/* 160:187 */           buf.append(exc_type_name).append(" | ");
/* 161:    */         }
/* 162:    */       }
/* 163:190 */       buf.append(((VarExprent)this.vars.get(i - 1)).toJava(indent, tracer));
/* 164:191 */       buf.append(") {").appendLineSeparator();
/* 165:192 */       tracer.incrementCurrentSourceLine();
/* 166:193 */       buf.append(ExprProcessor.jmpWrapper(stat, indent + 1, true, tracer)).appendIndent(indent).append("}");
/* 167:    */     }
/* 168:196 */     buf.appendLineSeparator();
/* 169:    */     
/* 170:198 */     tracer.incrementCurrentSourceLine();
/* 171:199 */     return buf;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public Statement getSimpleCopy()
/* 175:    */   {
/* 176:204 */     CatchStatement cs = new CatchStatement();
/* 177:206 */     for (List<String> exc : this.exctstrings)
/* 178:    */     {
/* 179:207 */       cs.exctstrings.add(new ArrayList(exc));
/* 180:208 */       cs.vars.add(new VarExprent(DecompilerContext.getCounterContainer().getCounterAndIncrement(2), new VarType(8, 0, (String)exc.get(0)), (VarProcessor)DecompilerContext.getProperty("CURRENT_VAR_PROCESSOR")));
/* 181:    */     }
/* 182:213 */     return cs;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public List<VarExprent> getVars()
/* 186:    */   {
/* 187:221 */     return this.vars;
/* 188:    */   }
/* 189:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement
 * JD-Core Version:    0.7.0.1
 */