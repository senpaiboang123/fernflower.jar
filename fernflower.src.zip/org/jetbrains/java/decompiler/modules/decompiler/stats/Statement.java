/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.LinkedList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*  13:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*  14:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*  15:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  16:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  17:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  18:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.StrongConnectivityHelper;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  22:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable;
/*  23:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable.MatchProperties;
/*  24:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  25:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode;
/*  26:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode.RuleValue;
/*  27:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  28:    */ 
/*  29:    */ public class Statement
/*  30:    */   implements IMatchable
/*  31:    */ {
/*  32:    */   public static final int STATEDGE_ALL = -2147483648;
/*  33:    */   public static final int STATEDGE_DIRECT_ALL = 1073741824;
/*  34:    */   public static final int DIRECTION_BACKWARD = 0;
/*  35:    */   public static final int DIRECTION_FORWARD = 1;
/*  36:    */   public static final int TYPE_GENERAL = 0;
/*  37:    */   public static final int TYPE_IF = 2;
/*  38:    */   public static final int TYPE_DO = 5;
/*  39:    */   public static final int TYPE_SWITCH = 6;
/*  40:    */   public static final int TYPE_TRYCATCH = 7;
/*  41:    */   public static final int TYPE_BASICBLOCK = 8;
/*  42:    */   public static final int TYPE_FINALLY = 9;
/*  43:    */   public static final int TYPE_SYNCRONIZED = 10;
/*  44:    */   public static final int TYPE_PLACEHOLDER = 11;
/*  45:    */   public static final int TYPE_CATCHALL = 12;
/*  46:    */   public static final int TYPE_ROOT = 13;
/*  47:    */   public static final int TYPE_DUMMYEXIT = 14;
/*  48:    */   public static final int TYPE_SEQUENCE = 15;
/*  49:    */   public static final int LASTBASICTYPE_IF = 0;
/*  50:    */   public static final int LASTBASICTYPE_SWITCH = 1;
/*  51:    */   public static final int LASTBASICTYPE_GENERAL = 2;
/*  52:    */   public int type;
/*  53:    */   public Integer id;
/*  54:    */   private final Map<Integer, List<StatEdge>> mapSuccEdges;
/*  55:    */   private final Map<Integer, List<StatEdge>> mapPredEdges;
/*  56:    */   private final Map<Integer, List<Statement>> mapSuccStates;
/*  57:    */   private final Map<Integer, List<Statement>> mapPredStates;
/*  58:    */   protected final VBStyleCollection<Statement, Integer> stats;
/*  59:    */   protected Statement parent;
/*  60:    */   protected Statement first;
/*  61:    */   protected List<Exprent> exprents;
/*  62:    */   protected final HashSet<StatEdge> labelEdges;
/*  63:    */   protected final List<Exprent> varDefinitions;
/*  64:    */   private boolean copied;
/*  65:    */   protected Statement post;
/*  66:    */   protected int lastBasicType;
/*  67:    */   protected boolean isMonitorEnter;
/*  68:    */   protected boolean containsMonitorExit;
/*  69:    */   protected HashSet<Statement> continueSet;
/*  70:    */   
/*  71:    */   public Statement()
/*  72:    */   {
/*  73: 76 */     this.mapSuccEdges = new HashMap();
/*  74: 77 */     this.mapPredEdges = new HashMap();
/*  75:    */     
/*  76: 79 */     this.mapSuccStates = new HashMap();
/*  77: 80 */     this.mapPredStates = new HashMap();
/*  78:    */     
/*  79:    */ 
/*  80: 83 */     this.stats = new VBStyleCollection();
/*  81:    */     
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88: 91 */     this.labelEdges = new HashSet();
/*  89:    */     
/*  90: 93 */     this.varDefinitions = new ArrayList();
/*  91:    */     
/*  92:    */ 
/*  93: 96 */     this.copied = false;
/*  94:    */     
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:103 */     this.lastBasicType = 2;
/* 101:    */     
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:109 */     this.continueSet = new HashSet();
/* 107:    */     
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:117 */     this.id = Integer.valueOf(DecompilerContext.getCounterContainer().getCounterAndIncrement(0));
/* 115:    */   }
/* 116:    */   
/* 117:    */   public void clearTempInformation()
/* 118:    */   {
/* 119:126 */     this.post = null;
/* 120:127 */     this.continueSet = null;
/* 121:    */     
/* 122:129 */     this.copied = false;
/* 123:    */     
/* 124:    */ 
/* 125:132 */     this.isMonitorEnter = false;
/* 126:133 */     this.containsMonitorExit = false;
/* 127:    */     
/* 128:135 */     processMap(this.mapSuccEdges);
/* 129:136 */     processMap(this.mapPredEdges);
/* 130:137 */     processMap(this.mapSuccStates);
/* 131:138 */     processMap(this.mapPredStates);
/* 132:    */   }
/* 133:    */   
/* 134:    */   private static <T> void processMap(Map<Integer, List<T>> map)
/* 135:    */   {
/* 136:142 */     map.remove(Integer.valueOf(2));
/* 137:    */     
/* 138:144 */     List<T> lst = (List)map.get(Integer.valueOf(1073741824));
/* 139:145 */     if (lst != null) {
/* 140:146 */       map.put(Integer.valueOf(-2147483648), new ArrayList(lst));
/* 141:    */     } else {
/* 142:149 */       map.remove(Integer.valueOf(-2147483648));
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   public void collapseNodesToStatement(Statement stat)
/* 147:    */   {
/* 148:155 */     Statement head = stat.getFirst();
/* 149:156 */     Statement post = stat.getPost();
/* 150:    */     
/* 151:158 */     VBStyleCollection<Statement, Integer> setNodes = stat.getStats();
/* 152:161 */     if (post != null) {
/* 153:162 */       for (StatEdge edge : post.getEdges(1073741824, 0)) {
/* 154:163 */         if (stat.containsStatementStrict(edge.getSource()))
/* 155:    */         {
/* 156:164 */           edge.getSource().changeEdgeType(1, edge, 4);
/* 157:165 */           stat.addLabeledEdge(edge);
/* 158:    */         }
/* 159:    */       }
/* 160:    */     }
/* 161:171 */     for (StatEdge prededge : head.getAllPredecessorEdges())
/* 162:    */     {
/* 163:173 */       if ((prededge.getType() != 2) && (stat.containsStatementStrict(prededge.getSource())))
/* 164:    */       {
/* 165:175 */         prededge.getSource().changeEdgeType(1, prededge, 8);
/* 166:176 */         stat.addLabeledEdge(prededge);
/* 167:    */       }
/* 168:179 */       head.removePredecessor(prededge);
/* 169:180 */       prededge.getSource().changeEdgeNode(1, prededge, stat);
/* 170:181 */       stat.addPredecessor(prededge);
/* 171:    */     }
/* 172:184 */     if (setNodes.containsKey(this.first.id)) {
/* 173:185 */       this.first = stat;
/* 174:    */     }
/* 175:189 */     Set<Statement> setHandlers = new HashSet(head.getNeighbours(2, 1));
/* 176:190 */     for (Statement node : setNodes) {
/* 177:191 */       setHandlers.retainAll(node.getNeighbours(2, 1));
/* 178:    */     }
/* 179:    */     Iterator i$;
/* 180:194 */     if (!setHandlers.isEmpty())
/* 181:    */     {
/* 182:196 */       for (StatEdge edge : head.getEdges(2, 1))
/* 183:    */       {
/* 184:197 */         Statement handler = edge.getDestination();
/* 185:199 */         if ((setHandlers.contains(handler)) && 
/* 186:200 */           (!setNodes.containsKey(handler.id))) {
/* 187:201 */           stat.addSuccessor(new StatEdge(stat, handler, edge.getExceptions()));
/* 188:    */         }
/* 189:    */       }
/* 190:206 */       for (i$ = setNodes.iterator(); i$.hasNext();)
/* 191:    */       {
/* 192:206 */         node = (Statement)i$.next();
/* 193:207 */         for (StatEdge edge : node.getEdges(2, 1)) {
/* 194:208 */           if (setHandlers.contains(edge.getDestination())) {
/* 195:209 */             node.removeSuccessor(edge);
/* 196:    */           }
/* 197:    */         }
/* 198:    */       }
/* 199:    */     }
/* 200:    */     Statement node;
/* 201:215 */     if ((post != null) && (!stat.getNeighbours(2, 1).contains(post))) {
/* 202:217 */       stat.addSuccessor(new StatEdge(1, stat, post));
/* 203:    */     }
/* 204:222 */     for (Statement st : setNodes) {
/* 205:223 */       this.stats.removeWithKey(st.id);
/* 206:    */     }
/* 207:226 */     this.stats.addWithKey(stat, stat.id);
/* 208:    */     
/* 209:228 */     stat.setAllParent();
/* 210:229 */     stat.setParent(this);
/* 211:    */     
/* 212:231 */     stat.buildContinueSet();
/* 213:    */     
/* 214:233 */     stat.buildMonitorFlags();
/* 215:235 */     if (stat.type == 6) {
/* 216:237 */       ((SwitchStatement)stat).sortEdgesAndNodes();
/* 217:    */     }
/* 218:    */   }
/* 219:    */   
/* 220:    */   public void setAllParent()
/* 221:    */   {
/* 222:242 */     for (Statement st : this.stats) {
/* 223:243 */       st.setParent(this);
/* 224:    */     }
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void addLabeledEdge(StatEdge edge)
/* 228:    */   {
/* 229:249 */     if (edge.closure != null) {
/* 230:250 */       edge.closure.getLabelEdges().remove(edge);
/* 231:    */     }
/* 232:252 */     edge.closure = this;
/* 233:253 */     getLabelEdges().add(edge);
/* 234:    */   }
/* 235:    */   
/* 236:    */   private void addEdgeDirectInternal(int direction, StatEdge edge, int edgetype)
/* 237:    */   {
/* 238:258 */     Map<Integer, List<StatEdge>> mapEdges = direction == 0 ? this.mapPredEdges : this.mapSuccEdges;
/* 239:259 */     Map<Integer, List<Statement>> mapStates = direction == 0 ? this.mapPredStates : this.mapSuccStates;
/* 240:    */     
/* 241:261 */     List<StatEdge> lst = (List)mapEdges.get(Integer.valueOf(edgetype));
/* 242:262 */     if (lst == null) {
/* 243:263 */       mapEdges.put(Integer.valueOf(edgetype), lst = new ArrayList());
/* 244:    */     }
/* 245:265 */     lst.add(edge);
/* 246:    */     
/* 247:267 */     List<Statement> lstStates = (List)mapStates.get(Integer.valueOf(edgetype));
/* 248:268 */     if (lstStates == null) {
/* 249:269 */       mapStates.put(Integer.valueOf(edgetype), lstStates = new ArrayList());
/* 250:    */     }
/* 251:271 */     lstStates.add(direction == 0 ? edge.getSource() : edge.getDestination());
/* 252:    */   }
/* 253:    */   
/* 254:    */   private void addEdgeInternal(int direction, StatEdge edge)
/* 255:    */   {
/* 256:276 */     int type = edge.getType();
/* 257:    */     int[] arrtypes;
/* 258:    */     int[] arrtypes;
/* 259:279 */     if (type == 2) {
/* 260:280 */       arrtypes = new int[] { -2147483648, 2 };
/* 261:    */     } else {
/* 262:283 */       arrtypes = new int[] { -2147483648, 1073741824, type };
/* 263:    */     }
/* 264:286 */     for (int edgetype : arrtypes) {
/* 265:287 */       addEdgeDirectInternal(direction, edge, edgetype);
/* 266:    */     }
/* 267:    */   }
/* 268:    */   
/* 269:    */   private void removeEdgeDirectInternal(int direction, StatEdge edge, int edgetype)
/* 270:    */   {
/* 271:293 */     Map<Integer, List<StatEdge>> mapEdges = direction == 0 ? this.mapPredEdges : this.mapSuccEdges;
/* 272:294 */     Map<Integer, List<Statement>> mapStates = direction == 0 ? this.mapPredStates : this.mapSuccStates;
/* 273:    */     
/* 274:296 */     List<StatEdge> lst = (List)mapEdges.get(Integer.valueOf(edgetype));
/* 275:297 */     if (lst != null)
/* 276:    */     {
/* 277:298 */       int index = lst.indexOf(edge);
/* 278:299 */       if (index >= 0)
/* 279:    */       {
/* 280:300 */         lst.remove(index);
/* 281:301 */         ((List)mapStates.get(Integer.valueOf(edgetype))).remove(index);
/* 282:    */       }
/* 283:    */     }
/* 284:    */   }
/* 285:    */   
/* 286:    */   private void removeEdgeInternal(int direction, StatEdge edge)
/* 287:    */   {
/* 288:308 */     int type = edge.getType();
/* 289:    */     int[] arrtypes;
/* 290:    */     int[] arrtypes;
/* 291:311 */     if (type == 2) {
/* 292:312 */       arrtypes = new int[] { -2147483648, 2 };
/* 293:    */     } else {
/* 294:315 */       arrtypes = new int[] { -2147483648, 1073741824, type };
/* 295:    */     }
/* 296:318 */     for (int edgetype : arrtypes) {
/* 297:319 */       removeEdgeDirectInternal(direction, edge, edgetype);
/* 298:    */     }
/* 299:    */   }
/* 300:    */   
/* 301:    */   public void addPredecessor(StatEdge edge)
/* 302:    */   {
/* 303:324 */     addEdgeInternal(0, edge);
/* 304:    */   }
/* 305:    */   
/* 306:    */   public void removePredecessor(StatEdge edge)
/* 307:    */   {
/* 308:329 */     if (edge == null) {
/* 309:330 */       return;
/* 310:    */     }
/* 311:333 */     removeEdgeInternal(0, edge);
/* 312:    */   }
/* 313:    */   
/* 314:    */   public void addSuccessor(StatEdge edge)
/* 315:    */   {
/* 316:337 */     addEdgeInternal(1, edge);
/* 317:339 */     if (edge.closure != null) {
/* 318:340 */       edge.closure.getLabelEdges().add(edge);
/* 319:    */     }
/* 320:343 */     edge.getDestination().addPredecessor(edge);
/* 321:    */   }
/* 322:    */   
/* 323:    */   public void removeSuccessor(StatEdge edge)
/* 324:    */   {
/* 325:348 */     if (edge == null) {
/* 326:349 */       return;
/* 327:    */     }
/* 328:352 */     removeEdgeInternal(1, edge);
/* 329:354 */     if (edge.closure != null) {
/* 330:355 */       edge.closure.getLabelEdges().remove(edge);
/* 331:    */     }
/* 332:358 */     if (edge.getDestination() != null) {
/* 333:359 */       edge.getDestination().removePredecessor(edge);
/* 334:    */     }
/* 335:    */   }
/* 336:    */   
/* 337:    */   public void removeAllSuccessors(Statement stat)
/* 338:    */   {
/* 339:366 */     if (stat == null) {
/* 340:367 */       return;
/* 341:    */     }
/* 342:370 */     for (StatEdge edge : getAllSuccessorEdges()) {
/* 343:371 */       if (edge.getDestination() == stat) {
/* 344:372 */         removeSuccessor(edge);
/* 345:    */       }
/* 346:    */     }
/* 347:    */   }
/* 348:    */   
/* 349:    */   public HashSet<Statement> buildContinueSet()
/* 350:    */   {
/* 351:378 */     this.continueSet.clear();
/* 352:380 */     for (Statement st : this.stats)
/* 353:    */     {
/* 354:381 */       this.continueSet.addAll(st.buildContinueSet());
/* 355:382 */       if (st != this.first) {
/* 356:383 */         this.continueSet.remove(st.getBasichead());
/* 357:    */       }
/* 358:    */     }
/* 359:387 */     for (StatEdge edge : getEdges(8, 1)) {
/* 360:388 */       this.continueSet.add(edge.getDestination().getBasichead());
/* 361:    */     }
/* 362:391 */     if (this.type == 5) {
/* 363:392 */       this.continueSet.remove(this.first.getBasichead());
/* 364:    */     }
/* 365:395 */     return this.continueSet;
/* 366:    */   }
/* 367:    */   
/* 368:    */   public void buildMonitorFlags()
/* 369:    */   {
/* 370:400 */     for (Statement st : this.stats) {
/* 371:401 */       st.buildMonitorFlags();
/* 372:    */     }
/* 373:404 */     switch (this.type)
/* 374:    */     {
/* 375:    */     case 8: 
/* 376:406 */       BasicBlockStatement bblock = (BasicBlockStatement)this;
/* 377:407 */       InstructionSequence seq = bblock.getBlock().getSeq();
/* 378:409 */       if ((seq != null) && (seq.length() > 0))
/* 379:    */       {
/* 380:410 */         for (int i = 0; i < seq.length(); i++) {
/* 381:411 */           if (seq.getInstr(i).opcode == 195)
/* 382:    */           {
/* 383:412 */             this.containsMonitorExit = true;
/* 384:413 */             break;
/* 385:    */           }
/* 386:    */         }
/* 387:416 */         this.isMonitorEnter = (seq.getLastInstr().opcode == 194);
/* 388:    */       }
/* 389:    */       break;
/* 390:    */     case 2: 
/* 391:    */     case 15: 
/* 392:421 */       this.containsMonitorExit = false;
/* 393:422 */       for (Statement st : this.stats) {
/* 394:423 */         this.containsMonitorExit |= st.isContainsMonitorExit();
/* 395:    */       }
/* 396:426 */       break;
/* 397:    */     case 0: 
/* 398:    */     case 10: 
/* 399:    */     case 13: 
/* 400:    */       break;
/* 401:    */     case 1: 
/* 402:    */     case 3: 
/* 403:    */     case 4: 
/* 404:    */     case 5: 
/* 405:    */     case 6: 
/* 406:    */     case 7: 
/* 407:    */     case 9: 
/* 408:    */     case 11: 
/* 409:    */     case 12: 
/* 410:    */     case 14: 
/* 411:    */     default: 
/* 412:432 */       this.containsMonitorExit = false;
/* 413:433 */       for (Statement st : this.stats) {
/* 414:434 */         this.containsMonitorExit |= st.isContainsMonitorExit();
/* 415:    */       }
/* 416:    */     }
/* 417:    */   }
/* 418:    */   
/* 419:    */   public List<Statement> getReversePostOrderList()
/* 420:    */   {
/* 421:441 */     return getReversePostOrderList(this.first);
/* 422:    */   }
/* 423:    */   
/* 424:    */   public List<Statement> getReversePostOrderList(Statement stat)
/* 425:    */   {
/* 426:445 */     List<Statement> res = new ArrayList();
/* 427:    */     
/* 428:447 */     addToReversePostOrderListIterative(stat, res);
/* 429:    */     
/* 430:449 */     return res;
/* 431:    */   }
/* 432:    */   
/* 433:    */   public List<Statement> getPostReversePostOrderList()
/* 434:    */   {
/* 435:453 */     return getPostReversePostOrderList(null);
/* 436:    */   }
/* 437:    */   
/* 438:    */   public List<Statement> getPostReversePostOrderList(List<Statement> lstexits)
/* 439:    */   {
/* 440:458 */     List<Statement> res = new ArrayList();
/* 441:460 */     if (lstexits == null)
/* 442:    */     {
/* 443:461 */       StrongConnectivityHelper schelper = new StrongConnectivityHelper(this);
/* 444:462 */       lstexits = StrongConnectivityHelper.getExitReps(schelper.getComponents());
/* 445:    */     }
/* 446:465 */     HashSet<Statement> setVisited = new HashSet();
/* 447:467 */     for (Statement exit : lstexits) {
/* 448:468 */       addToPostReversePostOrderList(exit, res, setVisited);
/* 449:    */     }
/* 450:471 */     if (res.size() != this.stats.size()) {
/* 451:472 */       throw new RuntimeException("computing post reverse post order failed!");
/* 452:    */     }
/* 453:475 */     return res;
/* 454:    */   }
/* 455:    */   
/* 456:    */   public boolean containsStatement(Statement stat)
/* 457:    */   {
/* 458:479 */     return (this == stat) || (containsStatementStrict(stat));
/* 459:    */   }
/* 460:    */   
/* 461:    */   public boolean containsStatementStrict(Statement stat)
/* 462:    */   {
/* 463:484 */     if (this.stats.contains(stat)) {
/* 464:485 */       return true;
/* 465:    */     }
/* 466:488 */     for (int i = 0; i < this.stats.size(); i++) {
/* 467:489 */       if (((Statement)this.stats.get(i)).containsStatementStrict(stat)) {
/* 468:490 */         return true;
/* 469:    */       }
/* 470:    */     }
/* 471:494 */     return false;
/* 472:    */   }
/* 473:    */   
/* 474:    */   public TextBuffer toJava()
/* 475:    */   {
/* 476:499 */     return toJava(0, new BytecodeMappingTracer());
/* 477:    */   }
/* 478:    */   
/* 479:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 480:    */   {
/* 481:503 */     throw new RuntimeException("not implemented");
/* 482:    */   }
/* 483:    */   
/* 484:    */   public List<Object> getSequentialObjects()
/* 485:    */   {
/* 486:508 */     return new ArrayList(this.stats);
/* 487:    */   }
/* 488:    */   
/* 489:    */   public void initExprents() {}
/* 490:    */   
/* 491:    */   public void replaceExprent(Exprent oldexpr, Exprent newexpr) {}
/* 492:    */   
/* 493:    */   public Statement getSimpleCopy()
/* 494:    */   {
/* 495:520 */     throw new RuntimeException("not implemented");
/* 496:    */   }
/* 497:    */   
/* 498:    */   public void initSimpleCopy()
/* 499:    */   {
/* 500:524 */     if (!this.stats.isEmpty()) {
/* 501:525 */       this.first = ((Statement)this.stats.get(0));
/* 502:    */     }
/* 503:    */   }
/* 504:    */   
/* 505:    */   public void replaceStatement(Statement oldstat, Statement newstat)
/* 506:    */   {
/* 507:531 */     for (StatEdge edge : oldstat.getAllPredecessorEdges())
/* 508:    */     {
/* 509:532 */       oldstat.removePredecessor(edge);
/* 510:533 */       edge.getSource().changeEdgeNode(1, edge, newstat);
/* 511:534 */       newstat.addPredecessor(edge);
/* 512:    */     }
/* 513:537 */     for (StatEdge edge : oldstat.getAllSuccessorEdges())
/* 514:    */     {
/* 515:538 */       oldstat.removeSuccessor(edge);
/* 516:539 */       edge.setSource(newstat);
/* 517:540 */       newstat.addSuccessor(edge);
/* 518:    */     }
/* 519:543 */     int statindex = this.stats.getIndexByKey(oldstat.id);
/* 520:544 */     this.stats.removeWithKey(oldstat.id);
/* 521:545 */     this.stats.addWithKeyAndIndex(statindex, newstat, newstat.id);
/* 522:    */     
/* 523:547 */     newstat.setParent(this);
/* 524:548 */     newstat.post = oldstat.post;
/* 525:550 */     if (this.first == oldstat) {
/* 526:551 */       this.first = newstat;
/* 527:    */     }
/* 528:554 */     List<StatEdge> lst = new ArrayList(oldstat.getLabelEdges());
/* 529:556 */     for (int i = lst.size() - 1; i >= 0; i--)
/* 530:    */     {
/* 531:557 */       StatEdge edge = (StatEdge)lst.get(i);
/* 532:558 */       if (edge.getSource() != newstat) {
/* 533:559 */         newstat.addLabeledEdge(edge);
/* 534:562 */       } else if ((this == edge.getDestination()) || (containsStatementStrict(edge.getDestination()))) {
/* 535:563 */         edge.closure = null;
/* 536:    */       } else {
/* 537:566 */         addLabeledEdge(edge);
/* 538:    */       }
/* 539:    */     }
/* 540:571 */     oldstat.getLabelEdges().clear();
/* 541:    */   }
/* 542:    */   
/* 543:    */   private static void addToReversePostOrderListIterative(Statement root, List<Statement> lst)
/* 544:    */   {
/* 545:581 */     LinkedList<Statement> stackNode = new LinkedList();
/* 546:582 */     LinkedList<Integer> stackIndex = new LinkedList();
/* 547:583 */     HashSet<Statement> setVisited = new HashSet();
/* 548:    */     
/* 549:585 */     stackNode.add(root);
/* 550:586 */     stackIndex.add(Integer.valueOf(0));
/* 551:588 */     while (!stackNode.isEmpty())
/* 552:    */     {
/* 553:590 */       Statement node = (Statement)stackNode.getLast();
/* 554:591 */       int index = ((Integer)stackIndex.removeLast()).intValue();
/* 555:    */       
/* 556:593 */       setVisited.add(node);
/* 557:    */       
/* 558:595 */       List<StatEdge> lstEdges = node.getAllSuccessorEdges();
/* 559:597 */       for (; index < lstEdges.size(); index++)
/* 560:    */       {
/* 561:598 */         StatEdge edge = (StatEdge)lstEdges.get(index);
/* 562:599 */         Statement succ = edge.getDestination();
/* 563:601 */         if ((!setVisited.contains(succ)) && ((edge.getType() == 1) || (edge.getType() == 2)))
/* 564:    */         {
/* 565:604 */           stackIndex.add(Integer.valueOf(index + 1));
/* 566:    */           
/* 567:606 */           stackNode.add(succ);
/* 568:607 */           stackIndex.add(Integer.valueOf(0));
/* 569:    */           
/* 570:609 */           break;
/* 571:    */         }
/* 572:    */       }
/* 573:613 */       if (index == lstEdges.size())
/* 574:    */       {
/* 575:614 */         lst.add(0, node);
/* 576:    */         
/* 577:616 */         stackNode.removeLast();
/* 578:    */       }
/* 579:    */     }
/* 580:    */   }
/* 581:    */   
/* 582:    */   private static void addToPostReversePostOrderList(Statement stat, List<Statement> lst, HashSet<Statement> setVisited)
/* 583:    */   {
/* 584:624 */     if (setVisited.contains(stat)) {
/* 585:625 */       return;
/* 586:    */     }
/* 587:627 */     setVisited.add(stat);
/* 588:629 */     for (StatEdge prededge : stat.getEdges(3, 0))
/* 589:    */     {
/* 590:630 */       Statement pred = prededge.getSource();
/* 591:631 */       if (!setVisited.contains(pred)) {
/* 592:632 */         addToPostReversePostOrderList(pred, lst, setVisited);
/* 593:    */       }
/* 594:    */     }
/* 595:636 */     lst.add(0, stat);
/* 596:    */   }
/* 597:    */   
/* 598:    */   public void changeEdgeNode(int direction, StatEdge edge, Statement value)
/* 599:    */   {
/* 600:645 */     Map<Integer, List<StatEdge>> mapEdges = direction == 0 ? this.mapPredEdges : this.mapSuccEdges;
/* 601:646 */     Map<Integer, List<Statement>> mapStates = direction == 0 ? this.mapPredStates : this.mapSuccStates;
/* 602:    */     
/* 603:648 */     int type = edge.getType();
/* 604:    */     int[] arrtypes;
/* 605:    */     int[] arrtypes;
/* 606:651 */     if (type == 2) {
/* 607:652 */       arrtypes = new int[] { -2147483648, 2 };
/* 608:    */     } else {
/* 609:655 */       arrtypes = new int[] { -2147483648, 1073741824, type };
/* 610:    */     }
/* 611:658 */     for (int edgetype : arrtypes)
/* 612:    */     {
/* 613:659 */       List<StatEdge> lst = (List)mapEdges.get(Integer.valueOf(edgetype));
/* 614:660 */       if (lst != null)
/* 615:    */       {
/* 616:661 */         int index = lst.indexOf(edge);
/* 617:662 */         if (index >= 0) {
/* 618:663 */           ((List)mapStates.get(Integer.valueOf(edgetype))).set(index, value);
/* 619:    */         }
/* 620:    */       }
/* 621:    */     }
/* 622:668 */     if (direction == 0) {
/* 623:669 */       edge.setSource(value);
/* 624:    */     } else {
/* 625:672 */       edge.setDestination(value);
/* 626:    */     }
/* 627:    */   }
/* 628:    */   
/* 629:    */   public void changeEdgeType(int direction, StatEdge edge, int newtype)
/* 630:    */   {
/* 631:678 */     int oldtype = edge.getType();
/* 632:679 */     if (oldtype == newtype) {
/* 633:680 */       return;
/* 634:    */     }
/* 635:683 */     if ((oldtype == 2) || (newtype == 2)) {
/* 636:684 */       throw new RuntimeException("Invalid edge type!");
/* 637:    */     }
/* 638:687 */     removeEdgeDirectInternal(direction, edge, oldtype);
/* 639:688 */     addEdgeDirectInternal(direction, edge, newtype);
/* 640:690 */     if (direction == 1) {
/* 641:691 */       edge.getDestination().changeEdgeType(0, edge, newtype);
/* 642:    */     }
/* 643:694 */     edge.setType(newtype);
/* 644:    */   }
/* 645:    */   
/* 646:    */   private List<StatEdge> getEdges(int type, int direction)
/* 647:    */   {
/* 648:700 */     Map<Integer, List<StatEdge>> map = direction == 0 ? this.mapPredEdges : this.mapSuccEdges;
/* 649:    */     List<StatEdge> res;
/* 650:703 */     if ((type & type - 1) == 0)
/* 651:    */     {
/* 652:704 */       List<StatEdge> res = (List)map.get(Integer.valueOf(type));
/* 653:705 */       res = res == null ? new ArrayList() : new ArrayList(res);
/* 654:    */     }
/* 655:    */     else
/* 656:    */     {
/* 657:708 */       res = new ArrayList();
/* 658:709 */       for (int edgetype : StatEdge.TYPES) {
/* 659:710 */         if ((type & edgetype) != 0)
/* 660:    */         {
/* 661:711 */           List<StatEdge> lst = (List)map.get(Integer.valueOf(edgetype));
/* 662:712 */           if (lst != null) {
/* 663:713 */             res.addAll(lst);
/* 664:    */           }
/* 665:    */         }
/* 666:    */       }
/* 667:    */     }
/* 668:719 */     return res;
/* 669:    */   }
/* 670:    */   
/* 671:    */   public List<Statement> getNeighbours(int type, int direction)
/* 672:    */   {
/* 673:724 */     Map<Integer, List<Statement>> map = direction == 0 ? this.mapPredStates : this.mapSuccStates;
/* 674:    */     List<Statement> res;
/* 675:727 */     if ((type & type - 1) == 0)
/* 676:    */     {
/* 677:728 */       List<Statement> res = (List)map.get(Integer.valueOf(type));
/* 678:729 */       res = res == null ? new ArrayList() : new ArrayList(res);
/* 679:    */     }
/* 680:    */     else
/* 681:    */     {
/* 682:732 */       res = new ArrayList();
/* 683:733 */       for (int edgetype : StatEdge.TYPES) {
/* 684:734 */         if ((type & edgetype) != 0)
/* 685:    */         {
/* 686:735 */           List<Statement> lst = (List)map.get(Integer.valueOf(edgetype));
/* 687:736 */           if (lst != null) {
/* 688:737 */             res.addAll(lst);
/* 689:    */           }
/* 690:    */         }
/* 691:    */       }
/* 692:    */     }
/* 693:743 */     return res;
/* 694:    */   }
/* 695:    */   
/* 696:    */   public Set<Statement> getNeighboursSet(int type, int direction)
/* 697:    */   {
/* 698:747 */     return new HashSet(getNeighbours(type, direction));
/* 699:    */   }
/* 700:    */   
/* 701:    */   public List<StatEdge> getSuccessorEdges(int type)
/* 702:    */   {
/* 703:751 */     return getEdges(type, 1);
/* 704:    */   }
/* 705:    */   
/* 706:    */   public List<StatEdge> getPredecessorEdges(int type)
/* 707:    */   {
/* 708:755 */     return getEdges(type, 0);
/* 709:    */   }
/* 710:    */   
/* 711:    */   public List<StatEdge> getAllSuccessorEdges()
/* 712:    */   {
/* 713:759 */     return getEdges(-2147483648, 1);
/* 714:    */   }
/* 715:    */   
/* 716:    */   public List<StatEdge> getAllPredecessorEdges()
/* 717:    */   {
/* 718:763 */     return getEdges(-2147483648, 0);
/* 719:    */   }
/* 720:    */   
/* 721:    */   public Statement getFirst()
/* 722:    */   {
/* 723:767 */     return this.first;
/* 724:    */   }
/* 725:    */   
/* 726:    */   public void setFirst(Statement first)
/* 727:    */   {
/* 728:771 */     this.first = first;
/* 729:    */   }
/* 730:    */   
/* 731:    */   public Statement getPost()
/* 732:    */   {
/* 733:775 */     return this.post;
/* 734:    */   }
/* 735:    */   
/* 736:    */   public void setPost(Statement post)
/* 737:    */   {
/* 738:779 */     this.post = post;
/* 739:    */   }
/* 740:    */   
/* 741:    */   public VBStyleCollection<Statement, Integer> getStats()
/* 742:    */   {
/* 743:783 */     return this.stats;
/* 744:    */   }
/* 745:    */   
/* 746:    */   public int getLastBasicType()
/* 747:    */   {
/* 748:787 */     return this.lastBasicType;
/* 749:    */   }
/* 750:    */   
/* 751:    */   public HashSet<Statement> getContinueSet()
/* 752:    */   {
/* 753:791 */     return this.continueSet;
/* 754:    */   }
/* 755:    */   
/* 756:    */   public boolean isContainsMonitorExit()
/* 757:    */   {
/* 758:795 */     return this.containsMonitorExit;
/* 759:    */   }
/* 760:    */   
/* 761:    */   public boolean isMonitorEnter()
/* 762:    */   {
/* 763:799 */     return this.isMonitorEnter;
/* 764:    */   }
/* 765:    */   
/* 766:    */   public BasicBlockStatement getBasichead()
/* 767:    */   {
/* 768:803 */     if (this.type == 8) {
/* 769:804 */       return (BasicBlockStatement)this;
/* 770:    */     }
/* 771:807 */     return this.first.getBasichead();
/* 772:    */   }
/* 773:    */   
/* 774:    */   public boolean isLabeled()
/* 775:    */   {
/* 776:813 */     for (StatEdge edge : this.labelEdges) {
/* 777:814 */       if ((edge.labeled) && (edge.explicit)) {
/* 778:815 */         return true;
/* 779:    */       }
/* 780:    */     }
/* 781:818 */     return false;
/* 782:    */   }
/* 783:    */   
/* 784:    */   public boolean hasBasicSuccEdge()
/* 785:    */   {
/* 786:825 */     return (this.type == 8) || ((this.type == 2) && (((IfStatement)this).iftype == 0)) || ((this.type == 5) && (((DoStatement)this).getLooptype() != 0));
/* 787:    */   }
/* 788:    */   
/* 789:    */   public Statement getParent()
/* 790:    */   {
/* 791:832 */     return this.parent;
/* 792:    */   }
/* 793:    */   
/* 794:    */   public void setParent(Statement parent)
/* 795:    */   {
/* 796:836 */     this.parent = parent;
/* 797:    */   }
/* 798:    */   
/* 799:    */   public HashSet<StatEdge> getLabelEdges()
/* 800:    */   {
/* 801:840 */     return this.labelEdges;
/* 802:    */   }
/* 803:    */   
/* 804:    */   public List<Exprent> getVarDefinitions()
/* 805:    */   {
/* 806:844 */     return this.varDefinitions;
/* 807:    */   }
/* 808:    */   
/* 809:    */   public List<Exprent> getExprents()
/* 810:    */   {
/* 811:848 */     return this.exprents;
/* 812:    */   }
/* 813:    */   
/* 814:    */   public void setExprents(List<Exprent> exprents)
/* 815:    */   {
/* 816:852 */     this.exprents = exprents;
/* 817:    */   }
/* 818:    */   
/* 819:    */   public boolean isCopied()
/* 820:    */   {
/* 821:856 */     return this.copied;
/* 822:    */   }
/* 823:    */   
/* 824:    */   public void setCopied(boolean copied)
/* 825:    */   {
/* 826:860 */     this.copied = copied;
/* 827:    */   }
/* 828:    */   
/* 829:    */   public String toString()
/* 830:    */   {
/* 831:865 */     return this.id.toString();
/* 832:    */   }
/* 833:    */   
/* 834:    */   public IMatchable findObject(MatchNode matchNode, int index)
/* 835:    */   {
/* 836:874 */     int node_type = matchNode.getType();
/* 837:876 */     if ((node_type == 0) && (!this.stats.isEmpty()))
/* 838:    */     {
/* 839:877 */       String position = (String)matchNode.getRuleValue(IMatchable.MatchProperties.STATEMENT_POSITION);
/* 840:878 */       if (position != null)
/* 841:    */       {
/* 842:879 */         if (position.matches("-?\\d+")) {
/* 843:880 */           return (IMatchable)this.stats.get((this.stats.size() + Integer.parseInt(position)) % this.stats.size());
/* 844:    */         }
/* 845:    */       }
/* 846:882 */       else if (index < this.stats.size()) {
/* 847:883 */         return (IMatchable)this.stats.get(index);
/* 848:    */       }
/* 849:    */     }
/* 850:885 */     else if ((node_type == 1) && (this.exprents != null) && (!this.exprents.isEmpty()))
/* 851:    */     {
/* 852:886 */       String position = (String)matchNode.getRuleValue(IMatchable.MatchProperties.EXPRENT_POSITION);
/* 853:887 */       if (position != null)
/* 854:    */       {
/* 855:888 */         if (position.matches("-?\\d+")) {
/* 856:889 */           return (IMatchable)this.exprents.get((this.exprents.size() + Integer.parseInt(position)) % this.exprents.size());
/* 857:    */         }
/* 858:    */       }
/* 859:891 */       else if (index < this.exprents.size()) {
/* 860:892 */         return (IMatchable)this.exprents.get(index);
/* 861:    */       }
/* 862:    */     }
/* 863:896 */     return null;
/* 864:    */   }
/* 865:    */   
/* 866:    */   public boolean match(MatchNode matchNode, MatchEngine engine)
/* 867:    */   {
/* 868:901 */     if (matchNode.getType() != 0) {
/* 869:902 */       return false;
/* 870:    */     }
/* 871:905 */     for (Map.Entry<IMatchable.MatchProperties, MatchNode.RuleValue> rule : matchNode.getRules().entrySet()) {
/* 872:906 */       switch (1.$SwitchMap$org$jetbrains$java$decompiler$struct$match$IMatchable$MatchProperties[((IMatchable.MatchProperties)rule.getKey()).ordinal()])
/* 873:    */       {
/* 874:    */       case 1: 
/* 875:908 */         if (this.type != ((Integer)((MatchNode.RuleValue)rule.getValue()).value).intValue()) {
/* 876:909 */           return false;
/* 877:    */         }
/* 878:    */         break;
/* 879:    */       case 2: 
/* 880:913 */         if (this.stats.size() != ((Integer)((MatchNode.RuleValue)rule.getValue()).value).intValue()) {
/* 881:914 */           return false;
/* 882:    */         }
/* 883:    */         break;
/* 884:    */       case 3: 
/* 885:918 */         int exprsize = ((Integer)((MatchNode.RuleValue)rule.getValue()).value).intValue();
/* 886:919 */         if (exprsize == -1)
/* 887:    */         {
/* 888:920 */           if (this.exprents != null) {
/* 889:921 */             return false;
/* 890:    */           }
/* 891:    */         }
/* 892:924 */         else if ((this.exprents == null) || (this.exprents.size() != exprsize)) {
/* 893:925 */           return false;
/* 894:    */         }
/* 895:    */         break;
/* 896:    */       case 4: 
/* 897:930 */         if (!engine.checkAndSetVariableValue((String)((MatchNode.RuleValue)rule.getValue()).value, this)) {
/* 898:931 */           return false;
/* 899:    */         }
/* 900:    */         break;
/* 901:    */       }
/* 902:    */     }
/* 903:938 */     return true;
/* 904:    */   }
/* 905:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.Statement
 * JD-Core Version:    0.7.0.1
 */