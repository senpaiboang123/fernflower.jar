/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*  2:   */ 
/*  3:   */ import org.jetbrains.java.decompiler.code.Instruction;
/*  4:   */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*  5:   */ import org.jetbrains.java.decompiler.code.SimpleInstructionSequence;
/*  6:   */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*  7:   */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  8:   */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  9:   */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/* 10:   */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/* 11:   */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/* 12:   */ 
/* 13:   */ public class BasicBlockStatement
/* 14:   */   extends Statement
/* 15:   */ {
/* 16:   */   private final BasicBlock block;
/* 17:   */   
/* 18:   */   public BasicBlockStatement(BasicBlock block)
/* 19:   */   {
/* 20:42 */     this.type = 8;
/* 21:   */     
/* 22:44 */     this.block = block;
/* 23:   */     
/* 24:46 */     this.id = Integer.valueOf(block.id);
/* 25:47 */     CounterContainer coun = DecompilerContext.getCounterContainer();
/* 26:48 */     if (this.id.intValue() >= coun.getCounter(0)) {
/* 27:49 */       coun.setCounter(0, this.id.intValue() + 1);
/* 28:   */     }
/* 29:52 */     Instruction instr = block.getLastInstruction();
/* 30:53 */     if (instr != null) {
/* 31:54 */       if ((instr.group == 2) && (instr.opcode != 167)) {
/* 32:55 */         this.lastBasicType = 0;
/* 33:57 */       } else if (instr.group == 3) {
/* 34:58 */         this.lastBasicType = 1;
/* 35:   */       }
/* 36:   */     }
/* 37:63 */     buildMonitorFlags();
/* 38:   */   }
/* 39:   */   
/* 40:   */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 41:   */   {
/* 42:71 */     return ExprProcessor.listToJava(this.varDefinitions, indent, tracer).append(ExprProcessor.listToJava(this.exprents, indent, tracer));
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Statement getSimpleCopy()
/* 46:   */   {
/* 47:76 */     BasicBlock newblock = new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0));
/* 48:   */     
/* 49:   */ 
/* 50:79 */     SimpleInstructionSequence seq = new SimpleInstructionSequence();
/* 51:80 */     for (int i = 0; i < this.block.getSeq().length(); i++) {
/* 52:81 */       seq.addInstruction(this.block.getSeq().getInstr(i).clone(), -1);
/* 53:   */     }
/* 54:84 */     newblock.setSeq(seq);
/* 55:   */     
/* 56:86 */     return new BasicBlockStatement(newblock);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public BasicBlock getBlock()
/* 60:   */   {
/* 61:95 */     return this.block;
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement
 * JD-Core Version:    0.7.0.1
 */