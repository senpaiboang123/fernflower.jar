/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Set;
/*  10:    */ import org.jetbrains.java.decompiler.code.SwitchInstruction;
/*  11:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*  12:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  13:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  14:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  15:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.DecHelper;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.SwitchExprent;
/*  22:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  23:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  24:    */ 
/*  25:    */ public class SwitchStatement
/*  26:    */   extends Statement
/*  27:    */ {
/*  28: 40 */   private List<Statement> caseStatements = new ArrayList();
/*  29: 42 */   private List<List<StatEdge>> caseEdges = new ArrayList();
/*  30: 44 */   private List<List<ConstExprent>> caseValues = new ArrayList();
/*  31:    */   private StatEdge default_edge;
/*  32: 48 */   private final List<Exprent> headexprent = new ArrayList();
/*  33:    */   
/*  34:    */   private SwitchStatement()
/*  35:    */   {
/*  36: 55 */     this.type = 6;
/*  37:    */     
/*  38: 57 */     this.headexprent.add(null);
/*  39:    */   }
/*  40:    */   
/*  41:    */   private SwitchStatement(Statement head, Statement poststat)
/*  42:    */   {
/*  43: 62 */     this();
/*  44:    */     
/*  45: 64 */     this.first = head;
/*  46: 65 */     this.stats.addWithKey(head, head.id);
/*  47:    */     
/*  48:    */ 
/*  49: 68 */     Set<Statement> lstNodes = new HashSet(head.getNeighbours(1, 1));
/*  50: 71 */     if (poststat != null)
/*  51:    */     {
/*  52: 72 */       this.post = poststat;
/*  53: 73 */       lstNodes.remove(this.post);
/*  54:    */     }
/*  55: 76 */     this.default_edge = ((StatEdge)head.getSuccessorEdges(1073741824).get(0));
/*  56: 78 */     for (Statement st : lstNodes) {
/*  57: 79 */       this.stats.addWithKey(st, st.id);
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static Statement isHead(Statement head)
/*  62:    */   {
/*  63: 89 */     if ((head.type == 8) && (head.getLastBasicType() == 1))
/*  64:    */     {
/*  65: 91 */       List<Statement> lst = new ArrayList();
/*  66: 92 */       if (DecHelper.isChoiceStatement(head, lst))
/*  67:    */       {
/*  68: 93 */         Statement post = (Statement)lst.remove(0);
/*  69: 95 */         for (Statement st : lst) {
/*  70: 96 */           if (st.isMonitorEnter()) {
/*  71: 97 */             return null;
/*  72:    */           }
/*  73:    */         }
/*  74:101 */         if (DecHelper.checkStatementExceptions(lst)) {
/*  75:102 */           return new SwitchStatement(head, post);
/*  76:    */         }
/*  77:    */       }
/*  78:    */     }
/*  79:107 */     return null;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  83:    */   {
/*  84:111 */     TextBuffer buf = new TextBuffer();
/*  85:112 */     buf.append(ExprProcessor.listToJava(this.varDefinitions, indent, tracer));
/*  86:113 */     buf.append(this.first.toJava(indent, tracer));
/*  87:115 */     if (isLabeled())
/*  88:    */     {
/*  89:116 */       buf.appendIndent(indent).append("label").append(this.id.toString()).append(":").appendLineSeparator();
/*  90:117 */       tracer.incrementCurrentSourceLine();
/*  91:    */     }
/*  92:120 */     buf.appendIndent(indent).append(((Exprent)this.headexprent.get(0)).toJava(indent, tracer)).append(" {").appendLineSeparator();
/*  93:121 */     tracer.incrementCurrentSourceLine();
/*  94:    */     
/*  95:123 */     VarType switch_type = ((Exprent)this.headexprent.get(0)).getExprType();
/*  96:125 */     for (int i = 0; i < this.caseStatements.size(); i++)
/*  97:    */     {
/*  98:127 */       Statement stat = (Statement)this.caseStatements.get(i);
/*  99:128 */       List<StatEdge> edges = (List)this.caseEdges.get(i);
/* 100:129 */       List<ConstExprent> values = (List)this.caseValues.get(i);
/* 101:131 */       for (int j = 0; j < edges.size(); j++) {
/* 102:132 */         if (edges.get(j) == this.default_edge)
/* 103:    */         {
/* 104:133 */           buf.appendIndent(indent).append("default:").appendLineSeparator();
/* 105:134 */           tracer.incrementCurrentSourceLine();
/* 106:    */         }
/* 107:    */         else
/* 108:    */         {
/* 109:137 */           ConstExprent value = (ConstExprent)((ConstExprent)values.get(j)).copy();
/* 110:138 */           value.setConstType(switch_type);
/* 111:    */           
/* 112:140 */           buf.appendIndent(indent).append("case ").append(value.toJava(indent, tracer)).append(":").appendLineSeparator();
/* 113:141 */           tracer.incrementCurrentSourceLine();
/* 114:    */         }
/* 115:    */       }
/* 116:145 */       buf.append(ExprProcessor.jmpWrapper(stat, indent + 1, false, tracer));
/* 117:    */     }
/* 118:148 */     buf.appendIndent(indent).append("}").appendLineSeparator();
/* 119:149 */     tracer.incrementCurrentSourceLine();
/* 120:    */     
/* 121:151 */     return buf;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void initExprents()
/* 125:    */   {
/* 126:155 */     SwitchExprent swexpr = (SwitchExprent)this.first.getExprents().remove(this.first.getExprents().size() - 1);
/* 127:156 */     swexpr.setCaseValues(this.caseValues);
/* 128:    */     
/* 129:158 */     this.headexprent.set(0, swexpr);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public List<Object> getSequentialObjects()
/* 133:    */   {
/* 134:163 */     List<Object> lst = new ArrayList(this.stats);
/* 135:164 */     lst.add(1, this.headexprent.get(0));
/* 136:    */     
/* 137:166 */     return lst;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void replaceExprent(Exprent oldexpr, Exprent newexpr)
/* 141:    */   {
/* 142:170 */     if (this.headexprent.get(0) == oldexpr) {
/* 143:171 */       this.headexprent.set(0, newexpr);
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void replaceStatement(Statement oldstat, Statement newstat)
/* 148:    */   {
/* 149:177 */     for (int i = 0; i < this.caseStatements.size(); i++) {
/* 150:178 */       if (this.caseStatements.get(i) == oldstat) {
/* 151:179 */         this.caseStatements.set(i, newstat);
/* 152:    */       }
/* 153:    */     }
/* 154:183 */     super.replaceStatement(oldstat, newstat);
/* 155:    */   }
/* 156:    */   
/* 157:    */   public Statement getSimpleCopy()
/* 158:    */   {
/* 159:187 */     return new SwitchStatement();
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void initSimpleCopy()
/* 163:    */   {
/* 164:191 */     this.first = ((Statement)this.stats.get(0));
/* 165:192 */     this.default_edge = ((StatEdge)this.first.getSuccessorEdges(1073741824).get(0));
/* 166:    */     
/* 167:194 */     sortEdgesAndNodes();
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void sortEdgesAndNodes()
/* 171:    */   {
/* 172:203 */     HashMap<StatEdge, Integer> mapEdgeIndex = new HashMap();
/* 173:    */     
/* 174:205 */     List<StatEdge> lstFirstSuccs = this.first.getSuccessorEdges(1073741824);
/* 175:206 */     for (int i = 0; i < lstFirstSuccs.size(); i++) {
/* 176:207 */       mapEdgeIndex.put(lstFirstSuccs.get(i), Integer.valueOf(i == 0 ? lstFirstSuccs.size() : i));
/* 177:    */     }
/* 178:211 */     BasicBlockStatement bbstat = (BasicBlockStatement)this.first;
/* 179:212 */     int[] values = ((SwitchInstruction)bbstat.getBlock().getLastInstruction()).getValues();
/* 180:    */     
/* 181:214 */     List<Statement> nodes = new ArrayList();
/* 182:215 */     List<List<Integer>> edges = new ArrayList();
/* 183:218 */     for (int i = 1; i < this.stats.size(); i++)
/* 184:    */     {
/* 185:220 */       Statement stat = (Statement)this.stats.get(i);
/* 186:    */       
/* 187:222 */       List<Integer> lst = new ArrayList();
/* 188:223 */       for (StatEdge edge : stat.getPredecessorEdges(1)) {
/* 189:224 */         if (edge.getSource() == this.first) {
/* 190:225 */           lst.add(mapEdgeIndex.get(edge));
/* 191:    */         }
/* 192:    */       }
/* 193:228 */       Collections.sort(lst);
/* 194:    */       
/* 195:230 */       nodes.add(stat);
/* 196:231 */       edges.add(lst);
/* 197:    */     }
/* 198:235 */     List<StatEdge> lstExitEdges = this.first.getSuccessorEdges(12);
/* 199:236 */     while (!lstExitEdges.isEmpty())
/* 200:    */     {
/* 201:237 */       StatEdge edge = (StatEdge)lstExitEdges.get(0);
/* 202:    */       
/* 203:239 */       List<Integer> lst = new ArrayList();
/* 204:240 */       for (int i = lstExitEdges.size() - 1; i >= 0; i--)
/* 205:    */       {
/* 206:241 */         StatEdge edgeTemp = (StatEdge)lstExitEdges.get(i);
/* 207:242 */         if ((edgeTemp.getDestination() == edge.getDestination()) && (edgeTemp.getType() == edge.getType()))
/* 208:    */         {
/* 209:243 */           lst.add(mapEdgeIndex.get(edgeTemp));
/* 210:244 */           lstExitEdges.remove(i);
/* 211:    */         }
/* 212:    */       }
/* 213:247 */       Collections.sort(lst);
/* 214:    */       
/* 215:249 */       nodes.add(null);
/* 216:250 */       edges.add(lst);
/* 217:    */     }
/* 218:254 */     for (int i = 0; i < edges.size() - 1; i++) {
/* 219:255 */       for (int j = edges.size() - 1; j > i; j--) {
/* 220:256 */         if (((Integer)((List)edges.get(j - 1)).get(0)).intValue() > ((Integer)((List)edges.get(j)).get(0)).intValue())
/* 221:    */         {
/* 222:257 */           edges.set(j, edges.set(j - 1, edges.get(j)));
/* 223:258 */           nodes.set(j, nodes.set(j - 1, nodes.get(j)));
/* 224:    */         }
/* 225:    */       }
/* 226:    */     }
/* 227:264 */     for (int index = 0; index < nodes.size(); index++)
/* 228:    */     {
/* 229:265 */       Statement stat = (Statement)nodes.get(index);
/* 230:267 */       if (stat != null)
/* 231:    */       {
/* 232:268 */         HashSet<Statement> setPreds = new HashSet(stat.getNeighbours(1, 0));
/* 233:269 */         setPreds.remove(this.first);
/* 234:271 */         if (!setPreds.isEmpty())
/* 235:    */         {
/* 236:272 */           Statement pred = (Statement)setPreds.iterator().next();
/* 237:274 */           for (int j = 0; j < nodes.size(); j++) {
/* 238:275 */             if ((j != index - 1) && (nodes.get(j) == pred))
/* 239:    */             {
/* 240:276 */               nodes.add(j + 1, stat);
/* 241:277 */               edges.add(j + 1, edges.get(index));
/* 242:279 */               if (j > index)
/* 243:    */               {
/* 244:280 */                 nodes.remove(index);
/* 245:281 */                 edges.remove(index);
/* 246:282 */                 index--; break;
/* 247:    */               }
/* 248:285 */               nodes.remove(index + 1);
/* 249:286 */               edges.remove(index + 1);
/* 250:    */               
/* 251:288 */               break;
/* 252:    */             }
/* 253:    */           }
/* 254:    */         }
/* 255:    */       }
/* 256:    */     }
/* 257:296 */     List<List<StatEdge>> lstEdges = new ArrayList();
/* 258:297 */     List<List<ConstExprent>> lstValues = new ArrayList();
/* 259:299 */     for (List<Integer> lst : edges)
/* 260:    */     {
/* 261:300 */       List<StatEdge> lste = new ArrayList();
/* 262:301 */       List<ConstExprent> lstv = new ArrayList();
/* 263:    */       
/* 264:303 */       List<StatEdge> lstSuccs = this.first.getSuccessorEdges(1073741824);
/* 265:304 */       for (Integer in : lst)
/* 266:    */       {
/* 267:305 */         int index = in.intValue() == lstSuccs.size() ? 0 : in.intValue();
/* 268:    */         
/* 269:307 */         lste.add(lstSuccs.get(index));
/* 270:308 */         lstv.add(index == 0 ? null : new ConstExprent(values[(index - 1)], false, null));
/* 271:    */       }
/* 272:310 */       lstEdges.add(lste);
/* 273:311 */       lstValues.add(lstv);
/* 274:    */     }
/* 275:315 */     for (int i = 0; i < nodes.size(); i++) {
/* 276:316 */       if (nodes.get(i) == null)
/* 277:    */       {
/* 278:317 */         BasicBlockStatement bstat = new BasicBlockStatement(new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0)));
/* 279:    */         
/* 280:    */ 
/* 281:320 */         StatEdge sample_edge = (StatEdge)((List)lstEdges.get(i)).get(0);
/* 282:    */         
/* 283:322 */         bstat.addSuccessor(new StatEdge(sample_edge.getType(), bstat, sample_edge.getDestination(), sample_edge.closure));
/* 284:324 */         for (StatEdge edge : (List)lstEdges.get(i))
/* 285:    */         {
/* 286:326 */           edge.getSource().changeEdgeType(1, edge, 1);
/* 287:327 */           edge.closure.getLabelEdges().remove(edge);
/* 288:    */           
/* 289:329 */           edge.getDestination().removePredecessor(edge);
/* 290:330 */           edge.getSource().changeEdgeNode(1, edge, bstat);
/* 291:331 */           bstat.addPredecessor(edge);
/* 292:    */         }
/* 293:334 */         nodes.set(i, bstat);
/* 294:335 */         this.stats.addWithKey(bstat, bstat.id);
/* 295:336 */         bstat.setParent(this);
/* 296:    */       }
/* 297:    */     }
/* 298:340 */     this.caseStatements = nodes;
/* 299:341 */     this.caseEdges = lstEdges;
/* 300:342 */     this.caseValues = lstValues;
/* 301:    */   }
/* 302:    */   
/* 303:    */   public List<Exprent> getHeadexprentList()
/* 304:    */   {
/* 305:346 */     return this.headexprent;
/* 306:    */   }
/* 307:    */   
/* 308:    */   public Exprent getHeadexprent()
/* 309:    */   {
/* 310:350 */     return (Exprent)this.headexprent.get(0);
/* 311:    */   }
/* 312:    */   
/* 313:    */   public List<List<StatEdge>> getCaseEdges()
/* 314:    */   {
/* 315:354 */     return this.caseEdges;
/* 316:    */   }
/* 317:    */   
/* 318:    */   public List<Statement> getCaseStatements()
/* 319:    */   {
/* 320:358 */     return this.caseStatements;
/* 321:    */   }
/* 322:    */   
/* 323:    */   public StatEdge getDefault_edge()
/* 324:    */   {
/* 325:362 */     return this.default_edge;
/* 326:    */   }
/* 327:    */   
/* 328:    */   public List<List<ConstExprent>> getCaseValues()
/* 329:    */   {
/* 330:366 */     return this.caseValues;
/* 331:    */   }
/* 332:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.SwitchStatement
 * JD-Core Version:    0.7.0.1
 */