/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import java.util.HashSet;
/*  5:   */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  6:   */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  7:   */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  8:   */ 
/*  9:   */ public class GeneralStatement
/* 10:   */   extends Statement
/* 11:   */ {
/* 12:   */   private GeneralStatement()
/* 13:   */   {
/* 14:32 */     this.type = 0;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public GeneralStatement(Statement head, Collection<Statement> statements, Statement post)
/* 18:   */   {
/* 19:37 */     this();
/* 20:   */     
/* 21:39 */     this.first = head;
/* 22:40 */     this.stats.addWithKey(head, head.id);
/* 23:   */     
/* 24:42 */     HashSet<Statement> set = new HashSet(statements);
/* 25:43 */     set.remove(head);
/* 26:45 */     for (Statement st : set) {
/* 27:46 */       this.stats.addWithKey(st, st.id);
/* 28:   */     }
/* 29:49 */     this.post = post;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 33:   */   {
/* 34:57 */     TextBuffer buf = new TextBuffer();
/* 35:59 */     if (isLabeled()) {
/* 36:60 */       buf.appendIndent(indent).append("label").append(this.id.toString()).append(":").appendLineSeparator();
/* 37:   */     }
/* 38:63 */     buf.appendIndent(indent).append("abstract statement {").appendLineSeparator();
/* 39:64 */     for (Statement stat : this.stats) {
/* 40:65 */       buf.append(stat.toJava(indent + 1, tracer));
/* 41:   */     }
/* 42:67 */     buf.appendIndent(indent).append("}");
/* 43:   */     
/* 44:69 */     return buf;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.GeneralStatement
 * JD-Core Version:    0.7.0.1
 */