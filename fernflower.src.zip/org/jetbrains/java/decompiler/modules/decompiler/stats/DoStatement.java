/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.List;
/*   6:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   7:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  11:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  12:    */ 
/*  13:    */ public class DoStatement
/*  14:    */   extends Statement
/*  15:    */ {
/*  16:    */   public static final int LOOP_DO = 0;
/*  17:    */   public static final int LOOP_DOWHILE = 1;
/*  18:    */   public static final int LOOP_WHILE = 2;
/*  19:    */   public static final int LOOP_FOR = 3;
/*  20:    */   private int looptype;
/*  21: 37 */   private final List<Exprent> initExprent = new ArrayList();
/*  22: 38 */   private final List<Exprent> conditionExprent = new ArrayList();
/*  23: 39 */   private final List<Exprent> incExprent = new ArrayList();
/*  24:    */   
/*  25:    */   private DoStatement()
/*  26:    */   {
/*  27: 46 */     this.type = 5;
/*  28: 47 */     this.looptype = 0;
/*  29:    */     
/*  30: 49 */     this.initExprent.add(null);
/*  31: 50 */     this.conditionExprent.add(null);
/*  32: 51 */     this.incExprent.add(null);
/*  33:    */   }
/*  34:    */   
/*  35:    */   private DoStatement(Statement head)
/*  36:    */   {
/*  37: 56 */     this();
/*  38:    */     
/*  39: 58 */     this.first = head;
/*  40: 59 */     this.stats.addWithKey(this.first, this.first.id);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static Statement isHead(Statement head)
/*  44:    */   {
/*  45: 70 */     if ((head.getLastBasicType() == 2) && (!head.isMonitorEnter()))
/*  46:    */     {
/*  47: 73 */       StatEdge edge = null;
/*  48: 74 */       List<StatEdge> lstSuccs = head.getSuccessorEdges(1073741824);
/*  49: 75 */       if (!lstSuccs.isEmpty()) {
/*  50: 76 */         edge = (StatEdge)lstSuccs.get(0);
/*  51:    */       }
/*  52: 80 */       if ((edge != null) && (edge.getType() == 1) && (edge.getDestination() == head)) {
/*  53: 81 */         return new DoStatement(head);
/*  54:    */       }
/*  55: 85 */       if ((head.type != 5) && ((edge == null) || (edge.getType() != 1)) && (head.getContinueSet().contains(head.getBasichead()))) {
/*  56: 87 */         return new DoStatement(head);
/*  57:    */       }
/*  58:    */     }
/*  59: 91 */     return null;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  63:    */   {
/*  64: 95 */     TextBuffer buf = new TextBuffer();
/*  65:    */     
/*  66: 97 */     buf.append(ExprProcessor.listToJava(this.varDefinitions, indent, tracer));
/*  67: 99 */     if (isLabeled())
/*  68:    */     {
/*  69:100 */       buf.appendIndent(indent).append("label").append(this.id.toString()).append(":").appendLineSeparator();
/*  70:101 */       tracer.incrementCurrentSourceLine();
/*  71:    */     }
/*  72:104 */     switch (this.looptype)
/*  73:    */     {
/*  74:    */     case 0: 
/*  75:106 */       buf.appendIndent(indent).append("while(true) {").appendLineSeparator();
/*  76:107 */       tracer.incrementCurrentSourceLine();
/*  77:108 */       buf.append(ExprProcessor.jmpWrapper(this.first, indent + 1, true, tracer));
/*  78:109 */       buf.appendIndent(indent).append("}").appendLineSeparator();
/*  79:110 */       tracer.incrementCurrentSourceLine();
/*  80:111 */       break;
/*  81:    */     case 1: 
/*  82:113 */       buf.appendIndent(indent).append("do {").appendLineSeparator();
/*  83:114 */       tracer.incrementCurrentSourceLine();
/*  84:115 */       buf.append(ExprProcessor.jmpWrapper(this.first, indent + 1, true, tracer));
/*  85:116 */       buf.appendIndent(indent).append("} while(").append(((Exprent)this.conditionExprent.get(0)).toJava(indent, tracer)).append(");").appendLineSeparator();
/*  86:117 */       tracer.incrementCurrentSourceLine();
/*  87:118 */       break;
/*  88:    */     case 2: 
/*  89:120 */       buf.appendIndent(indent).append("while(").append(((Exprent)this.conditionExprent.get(0)).toJava(indent, tracer)).append(") {").appendLineSeparator();
/*  90:121 */       tracer.incrementCurrentSourceLine();
/*  91:122 */       buf.append(ExprProcessor.jmpWrapper(this.first, indent + 1, true, tracer));
/*  92:123 */       buf.appendIndent(indent).append("}").appendLineSeparator();
/*  93:124 */       tracer.incrementCurrentSourceLine();
/*  94:125 */       break;
/*  95:    */     case 3: 
/*  96:127 */       buf.appendIndent(indent).append("for(");
/*  97:128 */       if (this.initExprent.get(0) != null) {
/*  98:129 */         buf.append(((Exprent)this.initExprent.get(0)).toJava(indent, tracer));
/*  99:    */       }
/* 100:131 */       buf.append("; ").append(((Exprent)this.conditionExprent.get(0)).toJava(indent, tracer)).append("; ").append(((Exprent)this.incExprent.get(0)).toJava(indent, tracer)).append(") {").appendLineSeparator();
/* 101:    */       
/* 102:    */ 
/* 103:134 */       tracer.incrementCurrentSourceLine();
/* 104:135 */       buf.append(ExprProcessor.jmpWrapper(this.first, indent + 1, true, tracer));
/* 105:136 */       buf.appendIndent(indent).append("}").appendLineSeparator();
/* 106:137 */       tracer.incrementCurrentSourceLine();
/* 107:    */     }
/* 108:140 */     return buf;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public List<Object> getSequentialObjects()
/* 112:    */   {
/* 113:145 */     List<Object> lst = new ArrayList();
/* 114:147 */     switch (this.looptype)
/* 115:    */     {
/* 116:    */     case 3: 
/* 117:149 */       if (getInitExprent() != null) {
/* 118:150 */         lst.add(getInitExprent());
/* 119:    */       }
/* 120:    */     case 2: 
/* 121:153 */       lst.add(getConditionExprent());
/* 122:    */     }
/* 123:156 */     lst.add(this.first);
/* 124:158 */     switch (this.looptype)
/* 125:    */     {
/* 126:    */     case 1: 
/* 127:160 */       lst.add(getConditionExprent());
/* 128:161 */       break;
/* 129:    */     case 3: 
/* 130:163 */       lst.add(getIncExprent());
/* 131:    */     }
/* 132:166 */     return lst;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void replaceExprent(Exprent oldexpr, Exprent newexpr)
/* 136:    */   {
/* 137:170 */     if (this.initExprent.get(0) == oldexpr) {
/* 138:171 */       this.initExprent.set(0, newexpr);
/* 139:    */     }
/* 140:173 */     if (this.conditionExprent.get(0) == oldexpr) {
/* 141:174 */       this.conditionExprent.set(0, newexpr);
/* 142:    */     }
/* 143:176 */     if (this.incExprent.get(0) == oldexpr) {
/* 144:177 */       this.incExprent.set(0, newexpr);
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   public Statement getSimpleCopy()
/* 149:    */   {
/* 150:182 */     return new DoStatement();
/* 151:    */   }
/* 152:    */   
/* 153:    */   public List<Exprent> getInitExprentList()
/* 154:    */   {
/* 155:190 */     return this.initExprent;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public List<Exprent> getConditionExprentList()
/* 159:    */   {
/* 160:194 */     return this.conditionExprent;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public List<Exprent> getIncExprentList()
/* 164:    */   {
/* 165:198 */     return this.incExprent;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public Exprent getConditionExprent()
/* 169:    */   {
/* 170:202 */     return (Exprent)this.conditionExprent.get(0);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public void setConditionExprent(Exprent conditionExprent)
/* 174:    */   {
/* 175:206 */     this.conditionExprent.set(0, conditionExprent);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public Exprent getIncExprent()
/* 179:    */   {
/* 180:210 */     return (Exprent)this.incExprent.get(0);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public void setIncExprent(Exprent incExprent)
/* 184:    */   {
/* 185:214 */     this.incExprent.set(0, incExprent);
/* 186:    */   }
/* 187:    */   
/* 188:    */   public Exprent getInitExprent()
/* 189:    */   {
/* 190:218 */     return (Exprent)this.initExprent.get(0);
/* 191:    */   }
/* 192:    */   
/* 193:    */   public void setInitExprent(Exprent initExprent)
/* 194:    */   {
/* 195:222 */     this.initExprent.set(0, initExprent);
/* 196:    */   }
/* 197:    */   
/* 198:    */   public int getLooptype()
/* 199:    */   {
/* 200:226 */     return this.looptype;
/* 201:    */   }
/* 202:    */   
/* 203:    */   public void setLooptype(int looptype)
/* 204:    */   {
/* 205:230 */     this.looptype = looptype;
/* 206:    */   }
/* 207:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement
 * JD-Core Version:    0.7.0.1
 */