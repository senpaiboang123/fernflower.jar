/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   6:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.DecHelper;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.IfExprent;
/*  12:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable;
/*  13:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable.MatchProperties;
/*  14:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  15:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode;
/*  16:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  17:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  18:    */ 
/*  19:    */ public class IfStatement
/*  20:    */   extends Statement
/*  21:    */ {
/*  22:    */   public static final int IFTYPE_IF = 0;
/*  23:    */   public static final int IFTYPE_IFELSE = 1;
/*  24:    */   public int iftype;
/*  25:    */   private Statement ifstat;
/*  26:    */   private Statement elsestat;
/*  27:    */   private StatEdge ifedge;
/*  28:    */   private StatEdge elseedge;
/*  29: 52 */   private boolean negated = false;
/*  30:    */   private boolean iffflag;
/*  31: 56 */   private final List<Exprent> headexprent = new ArrayList();
/*  32:    */   
/*  33:    */   private IfStatement()
/*  34:    */   {
/*  35: 63 */     this.type = 2;
/*  36:    */     
/*  37: 65 */     this.headexprent.add(null);
/*  38:    */   }
/*  39:    */   
/*  40:    */   private IfStatement(Statement head, int regedges, Statement postst)
/*  41:    */   {
/*  42: 70 */     this();
/*  43:    */     
/*  44: 72 */     this.first = head;
/*  45: 73 */     this.stats.addWithKey(head, head.id);
/*  46:    */     
/*  47: 75 */     List<StatEdge> lstHeadSuccs = head.getSuccessorEdges(1073741824);
/*  48: 77 */     switch (regedges)
/*  49:    */     {
/*  50:    */     case 0: 
/*  51: 79 */       this.ifstat = null;
/*  52: 80 */       this.elsestat = null;
/*  53:    */       
/*  54: 82 */       break;
/*  55:    */     case 1: 
/*  56: 84 */       this.ifstat = null;
/*  57: 85 */       this.elsestat = null;
/*  58:    */       
/*  59: 87 */       StatEdge edgeif = (StatEdge)lstHeadSuccs.get(1);
/*  60: 88 */       if (edgeif.getType() != 1)
/*  61:    */       {
/*  62: 89 */         this.post = ((StatEdge)lstHeadSuccs.get(0)).getDestination();
/*  63:    */       }
/*  64:    */       else
/*  65:    */       {
/*  66: 92 */         this.post = edgeif.getDestination();
/*  67: 93 */         this.negated = true;
/*  68:    */       }
/*  69: 95 */       break;
/*  70:    */     case 2: 
/*  71: 97 */       this.elsestat = ((StatEdge)lstHeadSuccs.get(0)).getDestination();
/*  72: 98 */       this.ifstat = ((StatEdge)lstHeadSuccs.get(1)).getDestination();
/*  73:    */       
/*  74:100 */       List<StatEdge> lstSucc = this.ifstat.getSuccessorEdges(1);
/*  75:101 */       List<StatEdge> lstSucc1 = this.elsestat.getSuccessorEdges(1);
/*  76:103 */       if ((this.ifstat.getPredecessorEdges(1).size() > 1) || (lstSucc.size() > 1)) {
/*  77:104 */         this.post = this.ifstat;
/*  78:106 */       } else if ((this.elsestat.getPredecessorEdges(1).size() > 1) || (lstSucc1.size() > 1)) {
/*  79:107 */         this.post = this.elsestat;
/*  80:110 */       } else if (lstSucc.size() == 0) {
/*  81:111 */         this.post = this.elsestat;
/*  82:113 */       } else if (lstSucc1.size() == 0) {
/*  83:114 */         this.post = this.ifstat;
/*  84:    */       }
/*  85:118 */       if (this.ifstat == this.post)
/*  86:    */       {
/*  87:119 */         if (this.elsestat != this.post)
/*  88:    */         {
/*  89:120 */           this.ifstat = this.elsestat;
/*  90:121 */           this.negated = true;
/*  91:    */         }
/*  92:    */         else
/*  93:    */         {
/*  94:124 */           this.ifstat = null;
/*  95:    */         }
/*  96:126 */         this.elsestat = null;
/*  97:    */       }
/*  98:128 */       else if (this.elsestat == this.post)
/*  99:    */       {
/* 100:129 */         this.elsestat = null;
/* 101:    */       }
/* 102:    */       else
/* 103:    */       {
/* 104:132 */         this.post = postst;
/* 105:    */       }
/* 106:135 */       if (this.elsestat == null) {
/* 107:136 */         regedges = 1;
/* 108:    */       }
/* 109:    */       break;
/* 110:    */     }
/* 111:140 */     this.ifedge = ((StatEdge)lstHeadSuccs.get(this.negated ? 0 : 1));
/* 112:141 */     this.elseedge = (regedges == 2 ? (StatEdge)lstHeadSuccs.get(this.negated ? 1 : 0) : null);
/* 113:    */     
/* 114:143 */     this.iftype = (regedges == 2 ? 1 : 0);
/* 115:145 */     if (this.iftype == 0) {
/* 116:146 */       if (regedges == 0)
/* 117:    */       {
/* 118:147 */         StatEdge edge = (StatEdge)lstHeadSuccs.get(0);
/* 119:148 */         head.removeSuccessor(edge);
/* 120:149 */         edge.setSource(this);
/* 121:150 */         addSuccessor(edge);
/* 122:    */       }
/* 123:152 */       else if (regedges == 1)
/* 124:    */       {
/* 125:153 */         StatEdge edge = (StatEdge)lstHeadSuccs.get(this.negated ? 1 : 0);
/* 126:154 */         head.removeSuccessor(edge);
/* 127:    */       }
/* 128:    */     }
/* 129:158 */     if (this.ifstat != null) {
/* 130:159 */       this.stats.addWithKey(this.ifstat, this.ifstat.id);
/* 131:    */     }
/* 132:162 */     if (this.elsestat != null) {
/* 133:163 */       this.stats.addWithKey(this.elsestat, this.elsestat.id);
/* 134:    */     }
/* 135:166 */     if (this.post == head) {
/* 136:167 */       this.post = this;
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static Statement isHead(Statement head)
/* 141:    */   {
/* 142:178 */     if ((head.type == 8) && (head.getLastBasicType() == 0))
/* 143:    */     {
/* 144:179 */       int regsize = head.getSuccessorEdges(1).size();
/* 145:    */       
/* 146:181 */       Statement p = null;
/* 147:    */       
/* 148:183 */       boolean ok = regsize < 2;
/* 149:184 */       if (!ok)
/* 150:    */       {
/* 151:185 */         List<Statement> lst = new ArrayList();
/* 152:186 */         if (DecHelper.isChoiceStatement(head, lst))
/* 153:    */         {
/* 154:187 */           p = (Statement)lst.remove(0);
/* 155:189 */           for (Statement st : lst) {
/* 156:190 */             if (st.isMonitorEnter()) {
/* 157:191 */               return null;
/* 158:    */             }
/* 159:    */           }
/* 160:195 */           ok = DecHelper.checkStatementExceptions(lst);
/* 161:    */         }
/* 162:    */       }
/* 163:199 */       if (ok) {
/* 164:200 */         return new IfStatement(head, regsize, p);
/* 165:    */       }
/* 166:    */     }
/* 167:204 */     return null;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 171:    */   {
/* 172:208 */     String indstr = InterpreterUtil.getIndentString(indent);
/* 173:209 */     TextBuffer buf = new TextBuffer();
/* 174:    */     
/* 175:211 */     buf.append(ExprProcessor.listToJava(this.varDefinitions, indent, tracer));
/* 176:212 */     buf.append(this.first.toJava(indent, tracer));
/* 177:214 */     if (isLabeled())
/* 178:    */     {
/* 179:215 */       buf.appendIndent(indent).append("label").append(this.id.toString()).append(":").appendLineSeparator();
/* 180:216 */       tracer.incrementCurrentSourceLine();
/* 181:    */     }
/* 182:219 */     buf.appendIndent(indent).append(((Exprent)this.headexprent.get(0)).toJava(indent, tracer)).append(" {").appendLineSeparator();
/* 183:220 */     tracer.incrementCurrentSourceLine();
/* 184:222 */     if (this.ifstat == null)
/* 185:    */     {
/* 186:223 */       buf.appendIndent(indent + 1);
/* 187:225 */       if (this.ifedge.explicit)
/* 188:    */       {
/* 189:226 */         if (this.ifedge.getType() == 4) {
/* 190:228 */           buf.append("break");
/* 191:    */         } else {
/* 192:232 */           buf.append("continue");
/* 193:    */         }
/* 194:235 */         if (this.ifedge.labeled) {
/* 195:236 */           buf.append(" label").append(this.ifedge.closure.id.toString());
/* 196:    */         }
/* 197:    */       }
/* 198:239 */       buf.append(";").appendLineSeparator();
/* 199:240 */       tracer.incrementCurrentSourceLine();
/* 200:    */     }
/* 201:    */     else
/* 202:    */     {
/* 203:243 */       buf.append(ExprProcessor.jmpWrapper(this.ifstat, indent + 1, true, tracer));
/* 204:    */     }
/* 205:246 */     boolean elseif = false;
/* 206:248 */     if (this.elsestat != null) {
/* 207:249 */       if ((this.elsestat.type == 2) && (this.elsestat.varDefinitions.isEmpty()) && (this.elsestat.getFirst().getExprents().isEmpty()) && (!this.elsestat.isLabeled()) && ((this.elsestat.getSuccessorEdges(1073741824).isEmpty()) || (!((StatEdge)this.elsestat.getSuccessorEdges(1073741824).get(0)).explicit)))
/* 208:    */       {
/* 209:254 */         TextBuffer content = ExprProcessor.jmpWrapper(this.elsestat, indent, false, tracer);
/* 210:255 */         content.setStart(indstr.length());
/* 211:    */         
/* 212:257 */         buf.appendIndent(indent).append("} else ");
/* 213:258 */         buf.append(content);
/* 214:    */         
/* 215:260 */         elseif = true;
/* 216:    */       }
/* 217:    */       else
/* 218:    */       {
/* 219:263 */         BytecodeMappingTracer else_tracer = new BytecodeMappingTracer(tracer.getCurrentSourceLine() + 1);
/* 220:264 */         TextBuffer content = ExprProcessor.jmpWrapper(this.elsestat, indent + 1, false, else_tracer);
/* 221:266 */         if (content.length() > 0)
/* 222:    */         {
/* 223:267 */           buf.appendIndent(indent).append("} else {").appendLineSeparator();
/* 224:    */           
/* 225:269 */           tracer.setCurrentSourceLine(else_tracer.getCurrentSourceLine());
/* 226:270 */           tracer.addTracer(else_tracer);
/* 227:    */           
/* 228:272 */           buf.append(content);
/* 229:    */         }
/* 230:    */       }
/* 231:    */     }
/* 232:277 */     if (!elseif)
/* 233:    */     {
/* 234:278 */       buf.appendIndent(indent).append("}").appendLineSeparator();
/* 235:279 */       tracer.incrementCurrentSourceLine();
/* 236:    */     }
/* 237:282 */     return buf;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public void initExprents()
/* 241:    */   {
/* 242:287 */     IfExprent ifexpr = (IfExprent)this.first.getExprents().remove(this.first.getExprents().size() - 1);
/* 243:289 */     if (this.negated)
/* 244:    */     {
/* 245:290 */       ifexpr = (IfExprent)ifexpr.copy();
/* 246:291 */       ifexpr.negateIf();
/* 247:    */     }
/* 248:294 */     this.headexprent.set(0, ifexpr);
/* 249:    */   }
/* 250:    */   
/* 251:    */   public List<Object> getSequentialObjects()
/* 252:    */   {
/* 253:299 */     List<Object> lst = new ArrayList(this.stats);
/* 254:300 */     lst.add(1, this.headexprent.get(0));
/* 255:    */     
/* 256:302 */     return lst;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public void replaceExprent(Exprent oldexpr, Exprent newexpr)
/* 260:    */   {
/* 261:306 */     if (this.headexprent.get(0) == oldexpr) {
/* 262:307 */       this.headexprent.set(0, newexpr);
/* 263:    */     }
/* 264:    */   }
/* 265:    */   
/* 266:    */   public void replaceStatement(Statement oldstat, Statement newstat)
/* 267:    */   {
/* 268:313 */     super.replaceStatement(oldstat, newstat);
/* 269:315 */     if (this.ifstat == oldstat) {
/* 270:316 */       this.ifstat = newstat;
/* 271:    */     }
/* 272:319 */     if (this.elsestat == oldstat) {
/* 273:320 */       this.elsestat = newstat;
/* 274:    */     }
/* 275:323 */     List<StatEdge> lstSuccs = this.first.getSuccessorEdges(1073741824);
/* 276:325 */     if (this.iftype == 0)
/* 277:    */     {
/* 278:326 */       this.ifedge = ((StatEdge)lstSuccs.get(0));
/* 279:327 */       this.elseedge = null;
/* 280:    */     }
/* 281:    */     else
/* 282:    */     {
/* 283:330 */       StatEdge edge0 = (StatEdge)lstSuccs.get(0);
/* 284:331 */       StatEdge edge1 = (StatEdge)lstSuccs.get(1);
/* 285:332 */       if (edge0.getDestination() == this.ifstat)
/* 286:    */       {
/* 287:333 */         this.ifedge = edge0;
/* 288:334 */         this.elseedge = edge1;
/* 289:    */       }
/* 290:    */       else
/* 291:    */       {
/* 292:337 */         this.ifedge = edge1;
/* 293:338 */         this.elseedge = edge0;
/* 294:    */       }
/* 295:    */     }
/* 296:    */   }
/* 297:    */   
/* 298:    */   public Statement getSimpleCopy()
/* 299:    */   {
/* 300:345 */     IfStatement is = new IfStatement();
/* 301:346 */     is.iftype = this.iftype;
/* 302:347 */     is.negated = this.negated;
/* 303:348 */     is.iffflag = this.iffflag;
/* 304:    */     
/* 305:350 */     return is;
/* 306:    */   }
/* 307:    */   
/* 308:    */   public void initSimpleCopy()
/* 309:    */   {
/* 310:355 */     this.first = ((Statement)this.stats.get(0));
/* 311:    */     
/* 312:357 */     List<StatEdge> lstSuccs = this.first.getSuccessorEdges(1073741824);
/* 313:358 */     this.ifedge = ((StatEdge)lstSuccs.get((this.iftype == 0) || (this.negated) ? 0 : 1));
/* 314:359 */     if (this.stats.size() > 1) {
/* 315:360 */       this.ifstat = ((Statement)this.stats.get(1));
/* 316:    */     }
/* 317:363 */     if (this.iftype == 1)
/* 318:    */     {
/* 319:364 */       this.elseedge = ((StatEdge)lstSuccs.get(this.negated ? 1 : 0));
/* 320:365 */       this.elsestat = ((Statement)this.stats.get(2));
/* 321:    */     }
/* 322:    */   }
/* 323:    */   
/* 324:    */   public Statement getElsestat()
/* 325:    */   {
/* 326:374 */     return this.elsestat;
/* 327:    */   }
/* 328:    */   
/* 329:    */   public void setElsestat(Statement elsestat)
/* 330:    */   {
/* 331:378 */     this.elsestat = elsestat;
/* 332:    */   }
/* 333:    */   
/* 334:    */   public Statement getIfstat()
/* 335:    */   {
/* 336:382 */     return this.ifstat;
/* 337:    */   }
/* 338:    */   
/* 339:    */   public void setIfstat(Statement ifstat)
/* 340:    */   {
/* 341:386 */     this.ifstat = ifstat;
/* 342:    */   }
/* 343:    */   
/* 344:    */   public boolean isNegated()
/* 345:    */   {
/* 346:390 */     return this.negated;
/* 347:    */   }
/* 348:    */   
/* 349:    */   public void setNegated(boolean negated)
/* 350:    */   {
/* 351:394 */     this.negated = negated;
/* 352:    */   }
/* 353:    */   
/* 354:    */   public List<Exprent> getHeadexprentList()
/* 355:    */   {
/* 356:398 */     return this.headexprent;
/* 357:    */   }
/* 358:    */   
/* 359:    */   public IfExprent getHeadexprent()
/* 360:    */   {
/* 361:402 */     return (IfExprent)this.headexprent.get(0);
/* 362:    */   }
/* 363:    */   
/* 364:    */   public boolean isIffflag()
/* 365:    */   {
/* 366:406 */     return this.iffflag;
/* 367:    */   }
/* 368:    */   
/* 369:    */   public void setIffflag(boolean iffflag)
/* 370:    */   {
/* 371:410 */     this.iffflag = iffflag;
/* 372:    */   }
/* 373:    */   
/* 374:    */   public void setElseEdge(StatEdge elseedge)
/* 375:    */   {
/* 376:414 */     this.elseedge = elseedge;
/* 377:    */   }
/* 378:    */   
/* 379:    */   public void setIfEdge(StatEdge ifedge)
/* 380:    */   {
/* 381:418 */     this.ifedge = ifedge;
/* 382:    */   }
/* 383:    */   
/* 384:    */   public StatEdge getIfEdge()
/* 385:    */   {
/* 386:422 */     return this.ifedge;
/* 387:    */   }
/* 388:    */   
/* 389:    */   public StatEdge getElseEdge()
/* 390:    */   {
/* 391:426 */     return this.elseedge;
/* 392:    */   }
/* 393:    */   
/* 394:    */   public IMatchable findObject(MatchNode matchNode, int index)
/* 395:    */   {
/* 396:435 */     IMatchable object = super.findObject(matchNode, index);
/* 397:436 */     if (object != null) {
/* 398:437 */       return object;
/* 399:    */     }
/* 400:440 */     if (matchNode.getType() == 1)
/* 401:    */     {
/* 402:441 */       String position = (String)matchNode.getRuleValue(IMatchable.MatchProperties.EXPRENT_POSITION);
/* 403:442 */       if ("head".equals(position)) {
/* 404:443 */         return getHeadexprent();
/* 405:    */       }
/* 406:    */     }
/* 407:447 */     return null;
/* 408:    */   }
/* 409:    */   
/* 410:    */   public boolean match(MatchNode matchNode, MatchEngine engine)
/* 411:    */   {
/* 412:452 */     if (!super.match(matchNode, engine)) {
/* 413:453 */       return false;
/* 414:    */     }
/* 415:456 */     Integer type = (Integer)matchNode.getRuleValue(IMatchable.MatchProperties.STATEMENT_IFTYPE);
/* 416:457 */     if ((type != null) && 
/* 417:458 */       (this.iftype != type.intValue())) {
/* 418:459 */       return false;
/* 419:    */     }
/* 420:463 */     return true;
/* 421:    */   }
/* 422:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement
 * JD-Core Version:    0.7.0.1
 */