/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*  2:   */ 
/*  3:   */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  4:   */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  5:   */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  6:   */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  7:   */ 
/*  8:   */ public class RootStatement
/*  9:   */   extends Statement
/* 10:   */ {
/* 11:   */   private DummyExitStatement dummyExit;
/* 12:   */   
/* 13:   */   public RootStatement(Statement head, DummyExitStatement dummyExit)
/* 14:   */   {
/* 15:29 */     this.type = 13;
/* 16:   */     
/* 17:31 */     this.first = head;
/* 18:32 */     this.dummyExit = dummyExit;
/* 19:   */     
/* 20:34 */     this.stats.addWithKey(this.first, this.first.id);
/* 21:35 */     this.first.setParent(this);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 25:   */   {
/* 26:39 */     return ExprProcessor.listToJava(this.varDefinitions, indent, tracer).append(this.first.toJava(indent, tracer));
/* 27:   */   }
/* 28:   */   
/* 29:   */   public DummyExitStatement getDummyExit()
/* 30:   */   {
/* 31:43 */     return this.dummyExit;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setDummyExit(DummyExitStatement dummyExit)
/* 35:   */   {
/* 36:47 */     this.dummyExit = dummyExit;
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement
 * JD-Core Version:    0.7.0.1
 */