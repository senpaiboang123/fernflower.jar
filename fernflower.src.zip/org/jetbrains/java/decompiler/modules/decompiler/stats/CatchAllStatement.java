/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.List;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   9:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  10:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.DecHelper;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  16:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  17:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  18:    */ 
/*  19:    */ public class CatchAllStatement
/*  20:    */   extends Statement
/*  21:    */ {
/*  22:    */   private Statement handler;
/*  23:    */   private boolean isFinally;
/*  24:    */   private VarExprent monitor;
/*  25: 43 */   private final List<VarExprent> vars = new ArrayList();
/*  26:    */   
/*  27:    */   private CatchAllStatement()
/*  28:    */   {
/*  29: 50 */     this.type = 12;
/*  30:    */   }
/*  31:    */   
/*  32:    */   private CatchAllStatement(Statement head, Statement handler)
/*  33:    */   {
/*  34: 55 */     this();
/*  35:    */     
/*  36: 57 */     this.first = head;
/*  37: 58 */     this.stats.addWithKey(head, head.id);
/*  38:    */     
/*  39: 60 */     this.handler = handler;
/*  40: 61 */     this.stats.addWithKey(handler, handler.id);
/*  41:    */     
/*  42: 63 */     List<StatEdge> lstSuccs = head.getSuccessorEdges(1073741824);
/*  43: 64 */     if (!lstSuccs.isEmpty())
/*  44:    */     {
/*  45: 65 */       StatEdge edge = (StatEdge)lstSuccs.get(0);
/*  46: 66 */       if (edge.getType() == 1) {
/*  47: 67 */         this.post = edge.getDestination();
/*  48:    */       }
/*  49:    */     }
/*  50: 71 */     this.vars.add(new VarExprent(DecompilerContext.getCounterContainer().getCounterAndIncrement(2), new VarType(8, 0, "java/lang/Throwable"), (VarProcessor)DecompilerContext.getProperty("CURRENT_VAR_PROCESSOR")));
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static Statement isHead(Statement head)
/*  54:    */   {
/*  55: 83 */     if (head.getLastBasicType() != 2) {
/*  56: 84 */       return null;
/*  57:    */     }
/*  58: 87 */     HashSet<Statement> setHandlers = DecHelper.getUniquePredExceptions(head);
/*  59: 89 */     if (setHandlers.size() != 1) {
/*  60: 90 */       return null;
/*  61:    */     }
/*  62: 93 */     for (StatEdge edge : head.getSuccessorEdges(2))
/*  63:    */     {
/*  64: 94 */       Statement exc = edge.getDestination();
/*  65: 96 */       if ((edge.getExceptions() == null) && (setHandlers.contains(exc)) && (exc.getLastBasicType() == 2))
/*  66:    */       {
/*  67: 97 */         List<StatEdge> lstSuccs = exc.getSuccessorEdges(1073741824);
/*  68: 98 */         if ((lstSuccs.isEmpty()) || (((StatEdge)lstSuccs.get(0)).getType() != 1))
/*  69:    */         {
/*  70:100 */           if ((head.isMonitorEnter()) || (exc.isMonitorEnter())) {
/*  71:101 */             return null;
/*  72:    */           }
/*  73:104 */           if (DecHelper.checkStatementExceptions(Arrays.asList(new Statement[] { head, exc }))) {
/*  74:105 */             return new CatchAllStatement(head, exc);
/*  75:    */           }
/*  76:    */         }
/*  77:    */       }
/*  78:    */     }
/*  79:111 */     return null;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  83:    */   {
/*  84:115 */     String new_line_separator = DecompilerContext.getNewLineSeparator();
/*  85:    */     
/*  86:117 */     TextBuffer buf = new TextBuffer();
/*  87:    */     
/*  88:119 */     buf.append(ExprProcessor.listToJava(this.varDefinitions, indent, tracer));
/*  89:    */     
/*  90:121 */     boolean labeled = isLabeled();
/*  91:122 */     if (labeled)
/*  92:    */     {
/*  93:123 */       buf.appendIndent(indent).append("label").append(this.id.toString()).append(":").appendLineSeparator();
/*  94:124 */       tracer.incrementCurrentSourceLine();
/*  95:    */     }
/*  96:127 */     List<StatEdge> lstSuccs = this.first.getSuccessorEdges(1073741824);
/*  97:128 */     if ((this.first.type == 7) && (this.first.varDefinitions.isEmpty()) && (this.isFinally) && (!labeled) && (!this.first.isLabeled()) && ((lstSuccs.isEmpty()) || (!((StatEdge)lstSuccs.get(0)).explicit)))
/*  98:    */     {
/*  99:130 */       TextBuffer content = ExprProcessor.jmpWrapper(this.first, indent, true, tracer);
/* 100:131 */       content.setLength(content.length() - new_line_separator.length());
/* 101:132 */       tracer.incrementCurrentSourceLine(-1);
/* 102:133 */       buf.append(content);
/* 103:    */     }
/* 104:    */     else
/* 105:    */     {
/* 106:136 */       buf.appendIndent(indent).append("try {").appendLineSeparator();
/* 107:137 */       tracer.incrementCurrentSourceLine();
/* 108:138 */       buf.append(ExprProcessor.jmpWrapper(this.first, indent + 1, true, tracer));
/* 109:139 */       buf.appendIndent(indent).append("}");
/* 110:    */     }
/* 111:142 */     buf.append(" catch (" + ((VarExprent)this.vars.get(0)).toJava(indent, tracer) + ")").append(" {").appendLineSeparator();
/* 112:    */     
/* 113:144 */     tracer.incrementCurrentSourceLine();
/* 114:146 */     if (this.monitor != null)
/* 115:    */     {
/* 116:147 */       buf.appendIndent(indent + 1).append("if(").append(this.monitor.toJava(indent, tracer)).append(") {").appendLineSeparator();
/* 117:148 */       tracer.incrementCurrentSourceLine();
/* 118:    */     }
/* 119:151 */     buf.append(ExprProcessor.jmpWrapper(this.handler, indent + 1 + (this.monitor != null ? 1 : 0), true, tracer));
/* 120:153 */     if (this.monitor != null)
/* 121:    */     {
/* 122:154 */       buf.appendIndent(indent + 1).append("}").appendLineSeparator();
/* 123:155 */       tracer.incrementCurrentSourceLine();
/* 124:    */     }
/* 125:158 */     buf.appendIndent(indent).append("}").appendLineSeparator();
/* 126:159 */     tracer.incrementCurrentSourceLine();
/* 127:    */     
/* 128:161 */     return buf;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void replaceStatement(Statement oldstat, Statement newstat)
/* 132:    */   {
/* 133:166 */     if (this.handler == oldstat) {
/* 134:167 */       this.handler = newstat;
/* 135:    */     }
/* 136:170 */     super.replaceStatement(oldstat, newstat);
/* 137:    */   }
/* 138:    */   
/* 139:    */   public Statement getSimpleCopy()
/* 140:    */   {
/* 141:175 */     CatchAllStatement cas = new CatchAllStatement();
/* 142:    */     
/* 143:177 */     cas.isFinally = this.isFinally;
/* 144:179 */     if (this.monitor != null) {
/* 145:180 */       cas.monitor = new VarExprent(DecompilerContext.getCounterContainer().getCounterAndIncrement(2), VarType.VARTYPE_INT, (VarProcessor)DecompilerContext.getProperty("CURRENT_VAR_PROCESSOR"));
/* 146:    */     }
/* 147:185 */     if (!this.vars.isEmpty()) {
/* 148:187 */       this.vars.add(new VarExprent(DecompilerContext.getCounterContainer().getCounterAndIncrement(2), new VarType(8, 0, "java/lang/Throwable"), (VarProcessor)DecompilerContext.getProperty("CURRENT_VAR_PROCESSOR")));
/* 149:    */     }
/* 150:192 */     return cas;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void initSimpleCopy()
/* 154:    */   {
/* 155:196 */     this.first = ((Statement)this.stats.get(0));
/* 156:197 */     this.handler = ((Statement)this.stats.get(1));
/* 157:    */   }
/* 158:    */   
/* 159:    */   public Statement getHandler()
/* 160:    */   {
/* 161:205 */     return this.handler;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void setHandler(Statement handler)
/* 165:    */   {
/* 166:210 */     this.handler = handler;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public boolean isFinally()
/* 170:    */   {
/* 171:215 */     return this.isFinally;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void setFinally(boolean isFinally)
/* 175:    */   {
/* 176:220 */     this.isFinally = isFinally;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public VarExprent getMonitor()
/* 180:    */   {
/* 181:225 */     return this.monitor;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void setMonitor(VarExprent monitor)
/* 185:    */   {
/* 186:230 */     this.monitor = monitor;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public List<VarExprent> getVars()
/* 190:    */   {
/* 191:234 */     return this.vars;
/* 192:    */   }
/* 193:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.CatchAllStatement
 * JD-Core Version:    0.7.0.1
 */