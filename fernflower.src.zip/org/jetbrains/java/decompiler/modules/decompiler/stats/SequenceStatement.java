/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*   2:    */ 
/*   3:    */ import java.util.Arrays;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   6:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.DecHelper;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  10:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  11:    */ 
/*  12:    */ public class SequenceStatement
/*  13:    */   extends Statement
/*  14:    */ {
/*  15:    */   private SequenceStatement()
/*  16:    */   {
/*  17: 36 */     this.type = 15;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public SequenceStatement(List<Statement> lst)
/*  21:    */   {
/*  22: 41 */     this();
/*  23:    */     
/*  24: 43 */     this.lastBasicType = ((Statement)lst.get(lst.size() - 1)).getLastBasicType();
/*  25: 45 */     for (Statement st : lst) {
/*  26: 46 */       this.stats.addWithKey(st, st.id);
/*  27:    */     }
/*  28: 49 */     this.first = ((Statement)this.stats.get(0));
/*  29:    */   }
/*  30:    */   
/*  31:    */   private SequenceStatement(Statement head, Statement tail)
/*  32:    */   {
/*  33: 54 */     this(Arrays.asList(new Statement[] { head, tail }));
/*  34:    */     
/*  35: 56 */     List<StatEdge> lstSuccs = tail.getSuccessorEdges(1073741824);
/*  36: 57 */     if (!lstSuccs.isEmpty())
/*  37:    */     {
/*  38: 58 */       StatEdge edge = (StatEdge)lstSuccs.get(0);
/*  39: 60 */       if ((edge.getType() == 1) && (edge.getDestination() != head)) {
/*  40: 61 */         this.post = edge.getDestination();
/*  41:    */       }
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static Statement isHead2Block(Statement head)
/*  46:    */   {
/*  47: 73 */     if (head.getLastBasicType() != 2) {
/*  48: 74 */       return null;
/*  49:    */     }
/*  50: 78 */     StatEdge edge = null;
/*  51: 79 */     List<StatEdge> lstSuccs = head.getSuccessorEdges(1073741824);
/*  52: 80 */     if (!lstSuccs.isEmpty()) {
/*  53: 81 */       edge = (StatEdge)lstSuccs.get(0);
/*  54:    */     }
/*  55: 84 */     if ((edge != null) && (edge.getType() == 1))
/*  56:    */     {
/*  57: 85 */       Statement stat = edge.getDestination();
/*  58: 87 */       if ((stat != head) && (stat.getPredecessorEdges(1).size() == 1) && (!stat.isMonitorEnter())) {
/*  59: 90 */         if (stat.getLastBasicType() == 2) {
/*  60: 91 */           if (DecHelper.checkStatementExceptions(Arrays.asList(new Statement[] { head, stat }))) {
/*  61: 92 */             return new SequenceStatement(head, stat);
/*  62:    */           }
/*  63:    */         }
/*  64:    */       }
/*  65:    */     }
/*  66: 98 */     return null;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  70:    */   {
/*  71:102 */     TextBuffer buf = new TextBuffer();
/*  72:103 */     boolean islabeled = isLabeled();
/*  73:    */     
/*  74:105 */     buf.append(ExprProcessor.listToJava(this.varDefinitions, indent, tracer));
/*  75:107 */     if (islabeled)
/*  76:    */     {
/*  77:108 */       buf.appendIndent(indent++).append("label").append(this.id.toString()).append(": {").appendLineSeparator();
/*  78:109 */       tracer.incrementCurrentSourceLine();
/*  79:    */     }
/*  80:112 */     boolean notempty = false;
/*  81:114 */     for (int i = 0; i < this.stats.size(); i++)
/*  82:    */     {
/*  83:116 */       Statement st = (Statement)this.stats.get(i);
/*  84:118 */       if ((i > 0) && (notempty))
/*  85:    */       {
/*  86:119 */         buf.appendLineSeparator();
/*  87:120 */         tracer.incrementCurrentSourceLine();
/*  88:    */       }
/*  89:123 */       TextBuffer str = ExprProcessor.jmpWrapper(st, indent, false, tracer);
/*  90:124 */       buf.append(str);
/*  91:    */       
/*  92:126 */       notempty = !str.containsOnlyWhitespaces();
/*  93:    */     }
/*  94:129 */     if (islabeled)
/*  95:    */     {
/*  96:130 */       buf.appendIndent(indent - 1).append("}").appendLineSeparator();
/*  97:131 */       tracer.incrementCurrentSourceLine();
/*  98:    */     }
/*  99:134 */     return buf;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Statement getSimpleCopy()
/* 103:    */   {
/* 104:138 */     return new SequenceStatement();
/* 105:    */   }
/* 106:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement
 * JD-Core Version:    0.7.0.1
 */