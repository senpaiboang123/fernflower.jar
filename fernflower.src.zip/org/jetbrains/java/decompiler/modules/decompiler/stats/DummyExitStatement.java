/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.stats;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import java.util.HashSet;
/*  5:   */ import java.util.Set;
/*  6:   */ 
/*  7:   */ public class DummyExitStatement
/*  8:   */   extends Statement
/*  9:   */ {
/* 10:26 */   public Set<Integer> bytecode = null;
/* 11:   */   
/* 12:   */   public DummyExitStatement()
/* 13:   */   {
/* 14:29 */     this.type = 14;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void addBytecodeOffsets(Collection<Integer> bytecodeOffsets)
/* 18:   */   {
/* 19:33 */     if ((bytecodeOffsets != null) && (!bytecodeOffsets.isEmpty())) {
/* 20:34 */       if (this.bytecode == null) {
/* 21:35 */         this.bytecode = new HashSet(bytecodeOffsets);
/* 22:   */       } else {
/* 23:38 */         this.bytecode.addAll(bytecodeOffsets);
/* 24:   */       }
/* 25:   */     }
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.stats.DummyExitStatement
 * JD-Core Version:    0.7.0.1
 */