/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.Arrays;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.LinkedList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.jetbrains.java.decompiler.code.CodeConstants;
/*  12:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*  13:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*  14:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*  15:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  16:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  17:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  18:    */ import org.jetbrains.java.decompiler.main.collectors.ImportCollector;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ArrayExprent;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  24:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FieldExprent;
/*  25:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*  26:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.IfExprent;
/*  27:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*  28:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.MonitorExprent;
/*  29:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*  30:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.SwitchExprent;
/*  31:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  32:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*  33:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectNode;
/*  34:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.FlattenStatementsHelper;
/*  35:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.FlattenStatementsHelper.FinallyPathWrapper;
/*  36:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  37:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchAllStatement;
/*  38:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement;
/*  39:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  40:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  41:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  42:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  43:    */ import org.jetbrains.java.decompiler.struct.StructContext;
/*  44:    */ import org.jetbrains.java.decompiler.struct.attr.StructBootstrapMethodsAttribute;
/*  45:    */ import org.jetbrains.java.decompiler.struct.consts.ConstantPool;
/*  46:    */ import org.jetbrains.java.decompiler.struct.consts.LinkConstant;
/*  47:    */ import org.jetbrains.java.decompiler.struct.consts.PooledConstant;
/*  48:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  49:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  50:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  51:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  52:    */ 
/*  53:    */ public class ExprProcessor
/*  54:    */   implements CodeConstants
/*  55:    */ {
/*  56:    */   public static final String UNDEFINED_TYPE_STRING = "<undefinedtype>";
/*  57:    */   public static final String UNKNOWN_TYPE_STRING = "<unknown>";
/*  58:    */   public static final String NULL_TYPE_STRING = "<null>";
/*  59: 50 */   private static final HashMap<Integer, Integer> mapConsts = new HashMap();
/*  60:    */   
/*  61:    */   static
/*  62:    */   {
/*  63: 85 */     mapConsts.put(new Integer(190), new Integer(31));
/*  64: 86 */     mapConsts.put(new Integer(192), new Integer(29));
/*  65: 87 */     mapConsts.put(new Integer(193), new Integer(30));
/*  66:    */   }
/*  67:    */   
/*  68: 90 */   private static final VarType[] consts = { VarType.VARTYPE_INT, VarType.VARTYPE_FLOAT, VarType.VARTYPE_LONG, VarType.VARTYPE_DOUBLE, VarType.VARTYPE_CLASS, VarType.VARTYPE_STRING };
/*  69: 94 */   private static final VarType[] vartypes = { VarType.VARTYPE_INT, VarType.VARTYPE_LONG, VarType.VARTYPE_FLOAT, VarType.VARTYPE_DOUBLE, VarType.VARTYPE_OBJECT };
/*  70: 97 */   private static final VarType[] arrtypes = { VarType.VARTYPE_INT, VarType.VARTYPE_LONG, VarType.VARTYPE_FLOAT, VarType.VARTYPE_DOUBLE, VarType.VARTYPE_OBJECT, VarType.VARTYPE_BOOLEAN, VarType.VARTYPE_CHAR, VarType.VARTYPE_SHORT };
/*  71:101 */   private static final int[] func1 = { 0, 1, 2, 3, 7 };
/*  72:105 */   private static final int[] func2 = { 8, 9, 10, 4, 5, 6 };
/*  73:109 */   private static final int[] func3 = { 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28 };
/*  74:117 */   private static final int[] func4 = { 37, 38, 39, 40, 41 };
/*  75:121 */   private static final int[] func5 = { 0, 1, 2, 3, 4, 5 };
/*  76:124 */   private static final int[] func6 = { 8, 9, 10, 11, 12, 13, 14, 15 };
/*  77:128 */   private static final int[] func7 = { 6, 7 };
/*  78:130 */   private static final int[] func8 = { 0, 1 };
/*  79:132 */   private static final int[] arr_type = { 7, 1, 3, 2, 0, 6, 4, 5 };
/*  80:136 */   private static final int[] negifs = { 1, 0, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14 };
/*  81:142 */   private static final String[] typeNames = { "byte", "char", "double", "float", "int", "long", "short", "boolean" };
/*  82:144 */   private final VarProcessor varProcessor = (VarProcessor)DecompilerContext.getProperty("CURRENT_VAR_PROCESSOR");
/*  83:    */   
/*  84:    */   public void processStatement(RootStatement root, StructClass cl)
/*  85:    */   {
/*  86:148 */     FlattenStatementsHelper flatthelper = new FlattenStatementsHelper();
/*  87:149 */     DirectGraph dgraph = flatthelper.buildDirectGraph(root);
/*  88:    */     
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:158 */     Set<String> setFinallyShortRangeEntryPoints = new HashSet();
/*  97:159 */     for (List<FlattenStatementsHelper.FinallyPathWrapper> lst : dgraph.mapShortRangeFinallyPaths.values()) {
/*  98:160 */       for (FlattenStatementsHelper.FinallyPathWrapper finwrap : lst) {
/*  99:161 */         setFinallyShortRangeEntryPoints.add(finwrap.entry);
/* 100:    */       }
/* 101:    */     }
/* 102:165 */     Set<String> setFinallyLongRangeEntryPaths = new HashSet();
/* 103:166 */     for (List<FlattenStatementsHelper.FinallyPathWrapper> lst : dgraph.mapLongRangeFinallyPaths.values()) {
/* 104:167 */       for (FlattenStatementsHelper.FinallyPathWrapper finwrap : lst) {
/* 105:168 */         setFinallyLongRangeEntryPaths.add(finwrap.source + "##" + finwrap.entry);
/* 106:    */       }
/* 107:    */     }
/* 108:172 */     Map<String, VarExprent> mapCatch = new HashMap();
/* 109:173 */     collectCatchVars(root, flatthelper, mapCatch);
/* 110:    */     
/* 111:175 */     Map<DirectNode, Map<String, PrimitiveExprsList>> mapData = new HashMap();
/* 112:    */     
/* 113:177 */     LinkedList<DirectNode> stack = new LinkedList();
/* 114:178 */     LinkedList<LinkedList<String>> stackEntryPoint = new LinkedList();
/* 115:    */     
/* 116:180 */     stack.add(dgraph.first);
/* 117:181 */     stackEntryPoint.add(new LinkedList());
/* 118:    */     
/* 119:183 */     Map<String, PrimitiveExprsList> map = new HashMap();
/* 120:184 */     map.put(null, new PrimitiveExprsList());
/* 121:185 */     mapData.put(dgraph.first, map);
/* 122:    */     DirectNode node;
/* 123:    */     LinkedList<String> entrypoints;
/* 124:    */     PrimitiveExprsList data;
/* 125:    */     String currentEntrypoint;
/* 126:187 */     while (!stack.isEmpty())
/* 127:    */     {
/* 128:189 */       node = (DirectNode)stack.removeFirst();
/* 129:190 */       entrypoints = (LinkedList)stackEntryPoint.removeFirst();
/* 130:    */       PrimitiveExprsList data;
/* 131:193 */       if (mapCatch.containsKey(node.id)) {
/* 132:194 */         data = getExpressionData((VarExprent)mapCatch.get(node.id));
/* 133:    */       } else {
/* 134:197 */         data = (PrimitiveExprsList)((Map)mapData.get(node)).get(buildEntryPointKey(entrypoints));
/* 135:    */       }
/* 136:200 */       BasicBlockStatement block = node.block;
/* 137:201 */       if (block != null)
/* 138:    */       {
/* 139:202 */         processBlock(block, data, cl);
/* 140:203 */         block.setExprents(data.getLstExprents());
/* 141:    */       }
/* 142:206 */       currentEntrypoint = entrypoints.isEmpty() ? null : (String)entrypoints.getLast();
/* 143:208 */       for (DirectNode nd : node.succs)
/* 144:    */       {
/* 145:210 */         boolean isSuccessor = true;
/* 146:211 */         if ((currentEntrypoint != null) && (dgraph.mapLongRangeFinallyPaths.containsKey(node.id)))
/* 147:    */         {
/* 148:212 */           isSuccessor = false;
/* 149:213 */           for (FlattenStatementsHelper.FinallyPathWrapper finwraplong : (List)dgraph.mapLongRangeFinallyPaths.get(node.id)) {
/* 150:214 */             if ((finwraplong.source.equals(currentEntrypoint)) && (finwraplong.destination.equals(nd.id)))
/* 151:    */             {
/* 152:215 */               isSuccessor = true;
/* 153:216 */               break;
/* 154:    */             }
/* 155:    */           }
/* 156:    */         }
/* 157:221 */         if (isSuccessor)
/* 158:    */         {
/* 159:223 */           Map<String, PrimitiveExprsList> mapSucc = (Map)mapData.get(nd);
/* 160:224 */           if (mapSucc == null) {
/* 161:225 */             mapData.put(nd, mapSucc = new HashMap());
/* 162:    */           }
/* 163:228 */           LinkedList<String> ndentrypoints = new LinkedList(entrypoints);
/* 164:230 */           if (setFinallyLongRangeEntryPaths.contains(node.id + "##" + nd.id)) {
/* 165:231 */             ndentrypoints.addLast(node.id);
/* 166:233 */           } else if ((!setFinallyShortRangeEntryPoints.contains(nd.id)) && (dgraph.mapLongRangeFinallyPaths.containsKey(node.id))) {
/* 167:234 */             ndentrypoints.removeLast();
/* 168:    */           }
/* 169:239 */           int succ_entry_index = ndentrypoints.indexOf(nd.id);
/* 170:240 */           if (succ_entry_index >= 0) {
/* 171:242 */             for (int elements_to_remove = ndentrypoints.size() - succ_entry_index; elements_to_remove > 0; elements_to_remove--) {
/* 172:243 */               ndentrypoints.removeLast();
/* 173:    */             }
/* 174:    */           }
/* 175:247 */           String ndentrykey = buildEntryPointKey(ndentrypoints);
/* 176:248 */           if (!mapSucc.containsKey(ndentrykey))
/* 177:    */           {
/* 178:250 */             mapSucc.put(ndentrykey, copyVarExprents(data.copyStack()));
/* 179:    */             
/* 180:252 */             stack.add(nd);
/* 181:253 */             stackEntryPoint.add(ndentrypoints);
/* 182:    */           }
/* 183:    */         }
/* 184:    */       }
/* 185:    */     }
/* 186:259 */     initStatementExprents(root);
/* 187:    */   }
/* 188:    */   
/* 189:    */   private static String buildEntryPointKey(LinkedList<String> entrypoints)
/* 190:    */   {
/* 191:264 */     if (entrypoints.isEmpty()) {
/* 192:265 */       return null;
/* 193:    */     }
/* 194:268 */     StringBuilder buffer = new StringBuilder();
/* 195:269 */     for (String point : entrypoints)
/* 196:    */     {
/* 197:270 */       buffer.append(point);
/* 198:271 */       buffer.append(":");
/* 199:    */     }
/* 200:273 */     return buffer.toString();
/* 201:    */   }
/* 202:    */   
/* 203:    */   private static PrimitiveExprsList copyVarExprents(PrimitiveExprsList data)
/* 204:    */   {
/* 205:278 */     ExprentStack stack = data.getStack();
/* 206:279 */     copyEntries(stack);
/* 207:280 */     return data;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public static void copyEntries(List<Exprent> stack)
/* 211:    */   {
/* 212:284 */     for (int i = 0; i < stack.size(); i++) {
/* 213:285 */       stack.set(i, ((Exprent)stack.get(i)).copy());
/* 214:    */     }
/* 215:    */   }
/* 216:    */   
/* 217:    */   private static void collectCatchVars(Statement stat, FlattenStatementsHelper flatthelper, Map<String, VarExprent> map)
/* 218:    */   {
/* 219:291 */     List<VarExprent> lst = null;
/* 220:293 */     if (stat.type == 12)
/* 221:    */     {
/* 222:294 */       CatchAllStatement catchall = (CatchAllStatement)stat;
/* 223:295 */       if (!catchall.isFinally()) {
/* 224:296 */         lst = catchall.getVars();
/* 225:    */       }
/* 226:    */     }
/* 227:299 */     else if (stat.type == 7)
/* 228:    */     {
/* 229:300 */       lst = ((CatchStatement)stat).getVars();
/* 230:    */     }
/* 231:303 */     if (lst != null) {
/* 232:304 */       for (int i = 1; i < stat.getStats().size(); i++) {
/* 233:305 */         map.put(((String[])flatthelper.getMapDestinationNodes().get(((Statement)stat.getStats().get(i)).id))[0], lst.get(i - 1));
/* 234:    */       }
/* 235:    */     }
/* 236:309 */     for (Statement st : stat.getStats()) {
/* 237:310 */       collectCatchVars(st, flatthelper, map);
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   private static void initStatementExprents(Statement stat)
/* 242:    */   {
/* 243:315 */     stat.initExprents();
/* 244:317 */     for (Statement st : stat.getStats()) {
/* 245:318 */       initStatementExprents(st);
/* 246:    */     }
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void processBlock(BasicBlockStatement stat, PrimitiveExprsList data, StructClass cl)
/* 250:    */   {
/* 251:324 */     ConstantPool pool = cl.getPool();
/* 252:325 */     StructBootstrapMethodsAttribute bootstrap = (StructBootstrapMethodsAttribute)cl.getAttributes().getWithKey("BootstrapMethods");
/* 253:    */     
/* 254:    */ 
/* 255:328 */     BasicBlock block = stat.getBlock();
/* 256:    */     
/* 257:330 */     ExprentStack stack = data.getStack();
/* 258:331 */     List<Exprent> exprlist = data.getLstExprents();
/* 259:    */     
/* 260:333 */     InstructionSequence seq = block.getSeq();
/* 261:335 */     for (int i = 0; i < seq.length(); i++)
/* 262:    */     {
/* 263:337 */       Instruction instr = seq.getInstr(i);
/* 264:338 */       Integer bytecode_offset = block.getOldOffset(i);
/* 265:339 */       Set<Integer> bytecode_offsets = bytecode_offset.intValue() >= 0 ? Collections.singleton(bytecode_offset) : null;
/* 266:341 */       switch (instr.opcode)
/* 267:    */       {
/* 268:    */       case 1: 
/* 269:343 */         pushEx(stack, exprlist, new ConstExprent(VarType.VARTYPE_NULL, null, bytecode_offsets));
/* 270:344 */         break;
/* 271:    */       case 16: 
/* 272:    */       case 17: 
/* 273:347 */         pushEx(stack, exprlist, new ConstExprent(instr.getOperand(0), true, bytecode_offsets));
/* 274:348 */         break;
/* 275:    */       case 9: 
/* 276:    */       case 10: 
/* 277:351 */         pushEx(stack, exprlist, new ConstExprent(VarType.VARTYPE_LONG, new Long(instr.opcode - 9), bytecode_offsets));
/* 278:352 */         break;
/* 279:    */       case 11: 
/* 280:    */       case 12: 
/* 281:    */       case 13: 
/* 282:356 */         pushEx(stack, exprlist, new ConstExprent(VarType.VARTYPE_FLOAT, new Float(instr.opcode - 11), bytecode_offsets));
/* 283:357 */         break;
/* 284:    */       case 14: 
/* 285:    */       case 15: 
/* 286:360 */         pushEx(stack, exprlist, new ConstExprent(VarType.VARTYPE_DOUBLE, new Double(instr.opcode - 14), bytecode_offsets));
/* 287:361 */         break;
/* 288:    */       case 18: 
/* 289:    */       case 19: 
/* 290:    */       case 20: 
/* 291:365 */         PooledConstant cn = pool.getConstant(instr.getOperand(0));
/* 292:366 */         if ((cn instanceof PrimitiveConstant)) {
/* 293:367 */           pushEx(stack, exprlist, new ConstExprent(consts[(cn.type - 3)], ((PrimitiveConstant)cn).value, bytecode_offsets));
/* 294:369 */         } else if ((cn instanceof LinkConstant)) {
/* 295:371 */           pushEx(stack, exprlist, new ConstExprent(VarType.VARTYPE_STRING, ((LinkConstant)cn).elementname, bytecode_offsets));
/* 296:    */         }
/* 297:    */         break;
/* 298:    */       case 21: 
/* 299:    */       case 22: 
/* 300:    */       case 23: 
/* 301:    */       case 24: 
/* 302:    */       case 25: 
/* 303:379 */         pushEx(stack, exprlist, new VarExprent(instr.getOperand(0), vartypes[(instr.opcode - 21)], this.varProcessor));
/* 304:380 */         break;
/* 305:    */       case 46: 
/* 306:    */       case 47: 
/* 307:    */       case 48: 
/* 308:    */       case 49: 
/* 309:    */       case 50: 
/* 310:    */       case 51: 
/* 311:    */       case 52: 
/* 312:    */       case 53: 
/* 313:389 */         Exprent index = stack.pop();
/* 314:390 */         Exprent arr = stack.pop();
/* 315:    */         
/* 316:392 */         VarType vartype = null;
/* 317:393 */         switch (instr.opcode)
/* 318:    */         {
/* 319:    */         case 47: 
/* 320:395 */           vartype = VarType.VARTYPE_LONG;
/* 321:396 */           break;
/* 322:    */         case 49: 
/* 323:398 */           vartype = VarType.VARTYPE_DOUBLE;
/* 324:    */         }
/* 325:400 */         pushEx(stack, exprlist, new ArrayExprent(arr, index, arrtypes[(instr.opcode - 46)], bytecode_offsets), vartype);
/* 326:401 */         break;
/* 327:    */       case 54: 
/* 328:    */       case 55: 
/* 329:    */       case 56: 
/* 330:    */       case 57: 
/* 331:    */       case 58: 
/* 332:407 */         Exprent top = stack.pop();
/* 333:408 */         int varindex = instr.getOperand(0);
/* 334:409 */         AssignmentExprent assign = new AssignmentExprent(new VarExprent(varindex, vartypes[(instr.opcode - 54)], this.varProcessor), top, bytecode_offsets);
/* 335:    */         
/* 336:411 */         exprlist.add(assign);
/* 337:412 */         break;
/* 338:    */       case 79: 
/* 339:    */       case 80: 
/* 340:    */       case 81: 
/* 341:    */       case 82: 
/* 342:    */       case 83: 
/* 343:    */       case 84: 
/* 344:    */       case 85: 
/* 345:    */       case 86: 
/* 346:421 */         Exprent value = stack.pop();
/* 347:422 */         Exprent index_store = stack.pop();
/* 348:423 */         Exprent arr_store = stack.pop();
/* 349:424 */         AssignmentExprent arrassign = new AssignmentExprent(new ArrayExprent(arr_store, index_store, arrtypes[(instr.opcode - 79)], bytecode_offsets), value, bytecode_offsets);
/* 350:    */         
/* 351:426 */         exprlist.add(arrassign);
/* 352:427 */         break;
/* 353:    */       case 96: 
/* 354:    */       case 97: 
/* 355:    */       case 98: 
/* 356:    */       case 99: 
/* 357:    */       case 100: 
/* 358:    */       case 101: 
/* 359:    */       case 102: 
/* 360:    */       case 103: 
/* 361:    */       case 104: 
/* 362:    */       case 105: 
/* 363:    */       case 106: 
/* 364:    */       case 107: 
/* 365:    */       case 108: 
/* 366:    */       case 109: 
/* 367:    */       case 110: 
/* 368:    */       case 111: 
/* 369:    */       case 112: 
/* 370:    */       case 113: 
/* 371:    */       case 114: 
/* 372:    */       case 115: 
/* 373:448 */         pushEx(stack, exprlist, new FunctionExprent(func1[((instr.opcode - 96) / 4)], stack, bytecode_offsets));
/* 374:449 */         break;
/* 375:    */       case 120: 
/* 376:    */       case 121: 
/* 377:    */       case 122: 
/* 378:    */       case 123: 
/* 379:    */       case 124: 
/* 380:    */       case 125: 
/* 381:    */       case 126: 
/* 382:    */       case 127: 
/* 383:    */       case 128: 
/* 384:    */       case 129: 
/* 385:    */       case 130: 
/* 386:    */       case 131: 
/* 387:462 */         pushEx(stack, exprlist, new FunctionExprent(func2[((instr.opcode - 120) / 2)], stack, bytecode_offsets));
/* 388:463 */         break;
/* 389:    */       case 116: 
/* 390:    */       case 117: 
/* 391:    */       case 118: 
/* 392:    */       case 119: 
/* 393:468 */         pushEx(stack, exprlist, new FunctionExprent(13, stack, bytecode_offsets));
/* 394:469 */         break;
/* 395:    */       case 132: 
/* 396:471 */         VarExprent vevar = new VarExprent(instr.getOperand(0), VarType.VARTYPE_INT, this.varProcessor);
/* 397:472 */         exprlist.add(new AssignmentExprent(vevar, new FunctionExprent(instr.getOperand(1) < 0 ? 1 : 0, Arrays.asList(new Exprent[] { vevar.copy(), new ConstExprent(VarType.VARTYPE_INT, Integer.valueOf(Math.abs(instr.getOperand(1))), null) }), bytecode_offsets), bytecode_offsets));
/* 398:    */         
/* 399:    */ 
/* 400:    */ 
/* 401:476 */         break;
/* 402:    */       case 133: 
/* 403:    */       case 134: 
/* 404:    */       case 135: 
/* 405:    */       case 136: 
/* 406:    */       case 137: 
/* 407:    */       case 138: 
/* 408:    */       case 139: 
/* 409:    */       case 140: 
/* 410:    */       case 141: 
/* 411:    */       case 142: 
/* 412:    */       case 143: 
/* 413:    */       case 144: 
/* 414:    */       case 145: 
/* 415:    */       case 146: 
/* 416:    */       case 147: 
/* 417:492 */         pushEx(stack, exprlist, new FunctionExprent(func3[(instr.opcode - 133)], stack, bytecode_offsets));
/* 418:493 */         break;
/* 419:    */       case 148: 
/* 420:    */       case 149: 
/* 421:    */       case 150: 
/* 422:    */       case 151: 
/* 423:    */       case 152: 
/* 424:499 */         pushEx(stack, exprlist, new FunctionExprent(func4[(instr.opcode - 148)], stack, bytecode_offsets));
/* 425:500 */         break;
/* 426:    */       case 153: 
/* 427:    */       case 154: 
/* 428:    */       case 155: 
/* 429:    */       case 156: 
/* 430:    */       case 157: 
/* 431:    */       case 158: 
/* 432:507 */         exprlist.add(new IfExprent(negifs[func5[(instr.opcode - 153)]], stack, bytecode_offsets));
/* 433:508 */         break;
/* 434:    */       case 159: 
/* 435:    */       case 160: 
/* 436:    */       case 161: 
/* 437:    */       case 162: 
/* 438:    */       case 163: 
/* 439:    */       case 164: 
/* 440:    */       case 165: 
/* 441:    */       case 166: 
/* 442:517 */         exprlist.add(new IfExprent(negifs[func6[(instr.opcode - 159)]], stack, bytecode_offsets));
/* 443:518 */         break;
/* 444:    */       case 198: 
/* 445:    */       case 199: 
/* 446:521 */         exprlist.add(new IfExprent(negifs[func7[(instr.opcode - 198)]], stack, bytecode_offsets));
/* 447:522 */         break;
/* 448:    */       case 170: 
/* 449:    */       case 171: 
/* 450:525 */         exprlist.add(new SwitchExprent(stack.pop(), bytecode_offsets));
/* 451:526 */         break;
/* 452:    */       case 172: 
/* 453:    */       case 173: 
/* 454:    */       case 174: 
/* 455:    */       case 175: 
/* 456:    */       case 176: 
/* 457:    */       case 177: 
/* 458:    */       case 191: 
/* 459:534 */         exprlist.add(new ExitExprent(instr.opcode == 191 ? 1 : 0, instr.opcode == 177 ? null : stack.pop(), instr.opcode == 191 ? null : ((MethodDescriptor)DecompilerContext.getProperty("CURRENT_METHOD_DESCRIPTOR")).ret, bytecode_offsets));
/* 460:    */         
/* 461:    */ 
/* 462:    */ 
/* 463:    */ 
/* 464:    */ 
/* 465:    */ 
/* 466:541 */         break;
/* 467:    */       case 194: 
/* 468:    */       case 195: 
/* 469:544 */         exprlist.add(new MonitorExprent(func8[(instr.opcode - 194)], stack.pop(), bytecode_offsets));
/* 470:545 */         break;
/* 471:    */       case 192: 
/* 472:    */       case 193: 
/* 473:548 */         stack.push(new ConstExprent(new VarType(pool.getPrimitiveConstant(instr.getOperand(0)).getString(), true), null, null));
/* 474:    */       case 190: 
/* 475:550 */         pushEx(stack, exprlist, new FunctionExprent(((Integer)mapConsts.get(Integer.valueOf(instr.opcode))).intValue(), stack, bytecode_offsets));
/* 476:551 */         break;
/* 477:    */       case 178: 
/* 478:    */       case 180: 
/* 479:554 */         pushEx(stack, exprlist, new FieldExprent(pool.getLinkConstant(instr.getOperand(0)), instr.opcode == 178 ? null : stack.pop(), bytecode_offsets));
/* 480:    */         
/* 481:556 */         break;
/* 482:    */       case 179: 
/* 483:    */       case 181: 
/* 484:559 */         Exprent valfield = stack.pop();
/* 485:560 */         Exprent exprfield = new FieldExprent(pool.getLinkConstant(instr.getOperand(0)), instr.opcode == 179 ? null : stack.pop(), bytecode_offsets);
/* 486:    */         
/* 487:562 */         exprlist.add(new AssignmentExprent(exprfield, valfield, bytecode_offsets));
/* 488:563 */         break;
/* 489:    */       case 182: 
/* 490:    */       case 183: 
/* 491:    */       case 184: 
/* 492:    */       case 185: 
/* 493:    */       case 186: 
/* 494:569 */         if ((instr.opcode != 186) || (instr.bytecode_version >= 4))
/* 495:    */         {
/* 496:571 */           LinkConstant invoke_constant = pool.getLinkConstant(instr.getOperand(0));
/* 497:572 */           int dynamic_invokation_type = -1;
/* 498:574 */           if ((instr.opcode == 186) && (bootstrap != null))
/* 499:    */           {
/* 500:575 */             List<PooledConstant> bootstrap_arguments = bootstrap.getMethodArguments(invoke_constant.index1);
/* 501:576 */             LinkConstant content_method_handle = (LinkConstant)bootstrap_arguments.get(1);
/* 502:    */             
/* 503:578 */             dynamic_invokation_type = content_method_handle.index1;
/* 504:    */           }
/* 505:581 */           InvocationExprent exprinv = new InvocationExprent(instr.opcode, invoke_constant, stack, dynamic_invokation_type, bytecode_offsets);
/* 506:582 */           if (exprinv.getDescriptor().ret.type == 10) {
/* 507:583 */             exprlist.add(exprinv);
/* 508:    */           } else {
/* 509:586 */             pushEx(stack, exprlist, exprinv);
/* 510:    */           }
/* 511:    */         }
/* 512:588 */         break;
/* 513:    */       case 187: 
/* 514:    */       case 189: 
/* 515:    */       case 197: 
/* 516:593 */         int dimensions = instr.opcode == 189 ? 1 : instr.opcode == 187 ? 0 : instr.getOperand(1);
/* 517:594 */         VarType arrType = new VarType(pool.getPrimitiveConstant(instr.getOperand(0)).getString(), true);
/* 518:595 */         if (instr.opcode != 197) {
/* 519:596 */           arrType = arrType.resizeArrayDim(arrType.arrayDim + dimensions);
/* 520:    */         }
/* 521:598 */         pushEx(stack, exprlist, new NewExprent(arrType, stack, dimensions, bytecode_offsets));
/* 522:599 */         break;
/* 523:    */       case 188: 
/* 524:601 */         pushEx(stack, exprlist, new NewExprent(new VarType(arr_type[(instr.getOperand(0) - 4)], 1), stack, 1, bytecode_offsets));
/* 525:602 */         break;
/* 526:    */       case 89: 
/* 527:604 */         pushEx(stack, exprlist, ((Exprent)stack.getByOffset(-1)).copy());
/* 528:605 */         break;
/* 529:    */       case 90: 
/* 530:607 */         insertByOffsetEx(-2, stack, exprlist, -1);
/* 531:608 */         break;
/* 532:    */       case 91: 
/* 533:610 */         if (((Exprent)stack.getByOffset(-2)).getExprType().stackSize == 2) {
/* 534:611 */           insertByOffsetEx(-2, stack, exprlist, -1);
/* 535:    */         } else {
/* 536:614 */           insertByOffsetEx(-3, stack, exprlist, -1);
/* 537:    */         }
/* 538:616 */         break;
/* 539:    */       case 92: 
/* 540:618 */         if (((Exprent)stack.getByOffset(-1)).getExprType().stackSize == 2)
/* 541:    */         {
/* 542:619 */           pushEx(stack, exprlist, ((Exprent)stack.getByOffset(-1)).copy());
/* 543:    */         }
/* 544:    */         else
/* 545:    */         {
/* 546:622 */           pushEx(stack, exprlist, ((Exprent)stack.getByOffset(-2)).copy());
/* 547:623 */           pushEx(stack, exprlist, ((Exprent)stack.getByOffset(-2)).copy());
/* 548:    */         }
/* 549:625 */         break;
/* 550:    */       case 93: 
/* 551:627 */         if (((Exprent)stack.getByOffset(-1)).getExprType().stackSize == 2)
/* 552:    */         {
/* 553:628 */           insertByOffsetEx(-2, stack, exprlist, -1);
/* 554:    */         }
/* 555:    */         else
/* 556:    */         {
/* 557:631 */           insertByOffsetEx(-3, stack, exprlist, -2);
/* 558:632 */           insertByOffsetEx(-3, stack, exprlist, -1);
/* 559:    */         }
/* 560:634 */         break;
/* 561:    */       case 94: 
/* 562:636 */         if (((Exprent)stack.getByOffset(-1)).getExprType().stackSize == 2)
/* 563:    */         {
/* 564:637 */           if (((Exprent)stack.getByOffset(-2)).getExprType().stackSize == 2) {
/* 565:638 */             insertByOffsetEx(-2, stack, exprlist, -1);
/* 566:    */           } else {
/* 567:641 */             insertByOffsetEx(-3, stack, exprlist, -1);
/* 568:    */           }
/* 569:    */         }
/* 570:645 */         else if (((Exprent)stack.getByOffset(-3)).getExprType().stackSize == 2)
/* 571:    */         {
/* 572:646 */           insertByOffsetEx(-3, stack, exprlist, -2);
/* 573:647 */           insertByOffsetEx(-3, stack, exprlist, -1);
/* 574:    */         }
/* 575:    */         else
/* 576:    */         {
/* 577:650 */           insertByOffsetEx(-4, stack, exprlist, -2);
/* 578:651 */           insertByOffsetEx(-4, stack, exprlist, -1);
/* 579:    */         }
/* 580:654 */         break;
/* 581:    */       case 95: 
/* 582:656 */         insertByOffsetEx(-2, stack, exprlist, -1);
/* 583:657 */         stack.pop();
/* 584:658 */         break;
/* 585:    */       case 87: 
/* 586:    */       case 88: 
/* 587:661 */         stack.pop();
/* 588:    */       }
/* 589:    */     }
/* 590:    */   }
/* 591:    */   
/* 592:    */   private void pushEx(ExprentStack stack, List<Exprent> exprlist, Exprent exprent)
/* 593:    */   {
/* 594:667 */     pushEx(stack, exprlist, exprent, null);
/* 595:    */   }
/* 596:    */   
/* 597:    */   private void pushEx(ExprentStack stack, List<Exprent> exprlist, Exprent exprent, VarType vartype)
/* 598:    */   {
/* 599:671 */     int varindex = 10000 + stack.size();
/* 600:672 */     VarExprent var = new VarExprent(varindex, vartype == null ? exprent.getExprType() : vartype, this.varProcessor);
/* 601:673 */     var.setStack(true);
/* 602:    */     
/* 603:675 */     exprlist.add(new AssignmentExprent(var, exprent, null));
/* 604:676 */     stack.push(var.copy());
/* 605:    */   }
/* 606:    */   
/* 607:    */   private void insertByOffsetEx(int offset, ExprentStack stack, List<Exprent> exprlist, int copyoffset)
/* 608:    */   {
/* 609:681 */     int base = 10000 + stack.size();
/* 610:    */     
/* 611:683 */     LinkedList<VarExprent> lst = new LinkedList();
/* 612:685 */     for (int i = -1; i >= offset; i--)
/* 613:    */     {
/* 614:686 */       Exprent varex = stack.pop();
/* 615:687 */       VarExprent varnew = new VarExprent(base + i + 1, varex.getExprType(), this.varProcessor);
/* 616:688 */       varnew.setStack(true);
/* 617:689 */       exprlist.add(new AssignmentExprent(varnew, varex, null));
/* 618:690 */       lst.add(0, (VarExprent)varnew.copy());
/* 619:    */     }
/* 620:693 */     Exprent exprent = ((VarExprent)lst.get(lst.size() + copyoffset)).copy();
/* 621:694 */     VarExprent var = new VarExprent(base + offset, exprent.getExprType(), this.varProcessor);
/* 622:695 */     var.setStack(true);
/* 623:696 */     exprlist.add(new AssignmentExprent(var, exprent, null));
/* 624:697 */     lst.add(0, (VarExprent)var.copy());
/* 625:699 */     for (VarExprent expr : lst) {
/* 626:700 */       stack.push(expr);
/* 627:    */     }
/* 628:    */   }
/* 629:    */   
/* 630:    */   public static String getTypeName(VarType type)
/* 631:    */   {
/* 632:705 */     return getTypeName(type, true);
/* 633:    */   }
/* 634:    */   
/* 635:    */   public static String getTypeName(VarType type, boolean getShort)
/* 636:    */   {
/* 637:710 */     int tp = type.type;
/* 638:711 */     if (tp <= 7) {
/* 639:712 */       return typeNames[tp];
/* 640:    */     }
/* 641:714 */     if (tp == 17) {
/* 642:715 */       return "<unknown>";
/* 643:    */     }
/* 644:717 */     if (tp == 13) {
/* 645:718 */       return "<null>";
/* 646:    */     }
/* 647:720 */     if (tp == 10) {
/* 648:721 */       return "void";
/* 649:    */     }
/* 650:723 */     if (tp == 8)
/* 651:    */     {
/* 652:724 */       String ret = buildJavaClassName(type.value);
/* 653:725 */       if (getShort) {
/* 654:726 */         ret = DecompilerContext.getImportCollector().getShortName(ret);
/* 655:    */       }
/* 656:729 */       if (ret == null) {
/* 657:731 */         ret = "<undefinedtype>";
/* 658:    */       }
/* 659:733 */       return ret;
/* 660:    */     }
/* 661:736 */     throw new RuntimeException("invalid type");
/* 662:    */   }
/* 663:    */   
/* 664:    */   public static String getCastTypeName(VarType type)
/* 665:    */   {
/* 666:740 */     return getCastTypeName(type, true);
/* 667:    */   }
/* 668:    */   
/* 669:    */   public static String getCastTypeName(VarType type, boolean getShort)
/* 670:    */   {
/* 671:744 */     String s = getTypeName(type, getShort);
/* 672:745 */     int dim = type.arrayDim;
/* 673:746 */     while (dim-- > 0) {
/* 674:747 */       s = s + "[]";
/* 675:    */     }
/* 676:749 */     return s;
/* 677:    */   }
/* 678:    */   
/* 679:    */   public static PrimitiveExprsList getExpressionData(VarExprent var)
/* 680:    */   {
/* 681:753 */     PrimitiveExprsList prlst = new PrimitiveExprsList();
/* 682:754 */     VarExprent vartmp = new VarExprent(10000, var.getExprType(), var.getProcessor());
/* 683:755 */     vartmp.setStack(true);
/* 684:    */     
/* 685:757 */     prlst.getLstExprents().add(new AssignmentExprent(vartmp, var.copy(), null));
/* 686:758 */     prlst.getStack().push(vartmp.copy());
/* 687:759 */     return prlst;
/* 688:    */   }
/* 689:    */   
/* 690:    */   public static boolean endsWithSemikolon(Exprent expr)
/* 691:    */   {
/* 692:763 */     int type = expr.type;
/* 693:764 */     return (type != 11) && (type != 9) && (type != 7) && ((type != 12) || (!((VarExprent)expr).isClassDef()));
/* 694:    */   }
/* 695:    */   
/* 696:    */   private static void addDeletedGotoInstructionMapping(Statement stat, BytecodeMappingTracer tracer)
/* 697:    */   {
/* 698:772 */     if ((stat instanceof BasicBlockStatement))
/* 699:    */     {
/* 700:773 */       BasicBlock block = ((BasicBlockStatement)stat).getBlock();
/* 701:774 */       List<Integer> offsets = block.getInstrOldOffsets();
/* 702:775 */       if ((!offsets.isEmpty()) && (offsets.size() > block.getSeq().length())) {
/* 703:776 */         tracer.addMapping(((Integer)offsets.get(offsets.size() - 1)).intValue());
/* 704:    */       }
/* 705:    */     }
/* 706:    */   }
/* 707:    */   
/* 708:    */   public static TextBuffer jmpWrapper(Statement stat, int indent, boolean semicolon, BytecodeMappingTracer tracer)
/* 709:    */   {
/* 710:782 */     TextBuffer buf = stat.toJava(indent, tracer);
/* 711:    */     
/* 712:784 */     List<StatEdge> lstSuccs = stat.getSuccessorEdges(1073741824);
/* 713:785 */     if (lstSuccs.size() == 1)
/* 714:    */     {
/* 715:786 */       StatEdge edge = (StatEdge)lstSuccs.get(0);
/* 716:787 */       if ((edge.getType() != 1) && (edge.explicit) && (edge.getDestination().type != 14))
/* 717:    */       {
/* 718:788 */         buf.appendIndent(indent);
/* 719:790 */         switch (edge.getType())
/* 720:    */         {
/* 721:    */         case 4: 
/* 722:792 */           addDeletedGotoInstructionMapping(stat, tracer);
/* 723:793 */           buf.append("break");
/* 724:794 */           break;
/* 725:    */         case 8: 
/* 726:796 */           addDeletedGotoInstructionMapping(stat, tracer);
/* 727:797 */           buf.append("continue");
/* 728:    */         }
/* 729:800 */         if (edge.labeled) {
/* 730:801 */           buf.append(" label").append(edge.closure.id.toString());
/* 731:    */         }
/* 732:803 */         buf.append(";").appendLineSeparator();
/* 733:804 */         tracer.incrementCurrentSourceLine();
/* 734:    */       }
/* 735:    */     }
/* 736:808 */     if ((buf.length() == 0) && (semicolon))
/* 737:    */     {
/* 738:809 */       buf.appendIndent(indent).append(";").appendLineSeparator();
/* 739:810 */       tracer.incrementCurrentSourceLine();
/* 740:    */     }
/* 741:813 */     return buf;
/* 742:    */   }
/* 743:    */   
/* 744:    */   public static String buildJavaClassName(String name)
/* 745:    */   {
/* 746:817 */     String res = name.replace('/', '.');
/* 747:819 */     if (res.contains("$"))
/* 748:    */     {
/* 749:821 */       StructClass cl = DecompilerContext.getStructContext().getClass(name);
/* 750:822 */       if ((cl == null) || (!cl.isOwn())) {
/* 751:823 */         res = res.replace('$', '.');
/* 752:    */       }
/* 753:    */     }
/* 754:827 */     return res;
/* 755:    */   }
/* 756:    */   
/* 757:    */   public static TextBuffer listToJava(List<Exprent> lst, int indent, BytecodeMappingTracer tracer)
/* 758:    */   {
/* 759:831 */     if ((lst == null) || (lst.isEmpty())) {
/* 760:832 */       return new TextBuffer();
/* 761:    */     }
/* 762:835 */     TextBuffer buf = new TextBuffer();
/* 763:837 */     for (Exprent expr : lst)
/* 764:    */     {
/* 765:838 */       TextBuffer content = expr.toJava(indent, tracer);
/* 766:839 */       if (content.length() > 0)
/* 767:    */       {
/* 768:840 */         if ((expr.type != 12) || (!((VarExprent)expr).isClassDef())) {
/* 769:841 */           buf.appendIndent(indent);
/* 770:    */         }
/* 771:843 */         buf.append(content);
/* 772:844 */         if ((expr.type == 9) && (((MonitorExprent)expr).getMonType() == 0)) {
/* 773:845 */           buf.append("{}");
/* 774:    */         }
/* 775:847 */         if (endsWithSemikolon(expr)) {
/* 776:848 */           buf.append(";");
/* 777:    */         }
/* 778:850 */         buf.appendLineSeparator();
/* 779:851 */         tracer.incrementCurrentSourceLine();
/* 780:    */       }
/* 781:    */     }
/* 782:855 */     return buf;
/* 783:    */   }
/* 784:    */   
/* 785:    */   public static ConstExprent getDefaultArrayValue(VarType arrtype)
/* 786:    */   {
/* 787:    */     ConstExprent defaultval;
/* 788:    */     ConstExprent defaultval;
/* 789:861 */     if ((arrtype.type == 8) || (arrtype.arrayDim > 0))
/* 790:    */     {
/* 791:862 */       defaultval = new ConstExprent(VarType.VARTYPE_NULL, null, null);
/* 792:    */     }
/* 793:    */     else
/* 794:    */     {
/* 795:    */       ConstExprent defaultval;
/* 796:864 */       if (arrtype.type == 3)
/* 797:    */       {
/* 798:865 */         defaultval = new ConstExprent(VarType.VARTYPE_FLOAT, new Float(0.0F), null);
/* 799:    */       }
/* 800:    */       else
/* 801:    */       {
/* 802:    */         ConstExprent defaultval;
/* 803:867 */         if (arrtype.type == 5)
/* 804:    */         {
/* 805:868 */           defaultval = new ConstExprent(VarType.VARTYPE_LONG, new Long(0L), null);
/* 806:    */         }
/* 807:    */         else
/* 808:    */         {
/* 809:    */           ConstExprent defaultval;
/* 810:870 */           if (arrtype.type == 2) {
/* 811:871 */             defaultval = new ConstExprent(VarType.VARTYPE_DOUBLE, new Double(0.0D), null);
/* 812:    */           } else {
/* 813:874 */             defaultval = new ConstExprent(0, true, null);
/* 814:    */           }
/* 815:    */         }
/* 816:    */       }
/* 817:    */     }
/* 818:877 */     return defaultval;
/* 819:    */   }
/* 820:    */   
/* 821:    */   public static boolean getCastedExprent(Exprent exprent, VarType leftType, TextBuffer buffer, int indent, boolean castNull, BytecodeMappingTracer tracer)
/* 822:    */   {
/* 823:886 */     return getCastedExprent(exprent, leftType, buffer, indent, castNull, false, tracer);
/* 824:    */   }
/* 825:    */   
/* 826:    */   public static boolean getCastedExprent(Exprent exprent, VarType leftType, TextBuffer buffer, int indent, boolean castNull, boolean castAlways, BytecodeMappingTracer tracer)
/* 827:    */   {
/* 828:897 */     VarType rightType = exprent.getExprType();
/* 829:    */     
/* 830:899 */     TextBuffer res = exprent.toJava(indent, tracer);
/* 831:    */     
/* 832:901 */     boolean cast = (castAlways) || ((!leftType.isSuperset(rightType)) && ((rightType.equals(VarType.VARTYPE_OBJECT)) || (leftType.type != 8))) || ((castNull) && (rightType.type == 13) && (!"<undefinedtype>".equals(getTypeName(leftType)))) || ((isIntConstant(exprent)) && (VarType.VARTYPE_INT.isStrictSuperset(leftType)));
/* 833:907 */     if (cast)
/* 834:    */     {
/* 835:908 */       if (exprent.getPrecedence() >= FunctionExprent.getPrecedence(29)) {
/* 836:909 */         res.enclose("(", ")");
/* 837:    */       }
/* 838:912 */       res.prepend("(" + getCastTypeName(leftType) + ")");
/* 839:    */     }
/* 840:915 */     buffer.append(res);
/* 841:    */     
/* 842:917 */     return cast;
/* 843:    */   }
/* 844:    */   
/* 845:    */   private static boolean isIntConstant(Exprent exprent)
/* 846:    */   {
/* 847:922 */     if (exprent.type == 3)
/* 848:    */     {
/* 849:923 */       ConstExprent cexpr = (ConstExprent)exprent;
/* 850:924 */       switch (cexpr.getConstType().type)
/* 851:    */       {
/* 852:    */       case 0: 
/* 853:    */       case 4: 
/* 854:    */       case 6: 
/* 855:    */       case 15: 
/* 856:    */       case 16: 
/* 857:930 */         return true;
/* 858:    */       }
/* 859:    */     }
/* 860:934 */     return false;
/* 861:    */   }
/* 862:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor
 * JD-Core Version:    0.7.0.1
 */