/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler;
/*  2:   */ 
/*  3:   */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  4:   */ import org.jetbrains.java.decompiler.util.ListStack;
/*  5:   */ 
/*  6:   */ public class ExprentStack
/*  7:   */   extends ListStack<Exprent>
/*  8:   */ {
/*  9:   */   public ExprentStack() {}
/* 10:   */   
/* 11:   */   public ExprentStack(ListStack<Exprent> list)
/* 12:   */   {
/* 13:27 */     super(list);
/* 14:28 */     this.pointer = list.getPointer();
/* 15:   */   }
/* 16:   */   
/* 17:   */   public Exprent push(Exprent item)
/* 18:   */   {
/* 19:32 */     super.push(item);
/* 20:   */     
/* 21:34 */     return item;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Exprent pop()
/* 25:   */   {
/* 26:39 */     return (Exprent)remove(--this.pointer);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public ExprentStack clone()
/* 30:   */   {
/* 31:43 */     return new ExprentStack(this);
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.ExprentStack
 * JD-Core Version:    0.7.0.1
 */