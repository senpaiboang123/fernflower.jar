/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.vars;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.LinkedList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  13:    */ import org.jetbrains.java.decompiler.main.collectors.VarNamesCollector;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchAllStatement;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  21:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  22:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  23:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  24:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  25:    */ 
/*  26:    */ public class VarDefinitionHelper
/*  27:    */ {
/*  28:    */   private final HashMap<Integer, Statement> mapVarDefStatements;
/*  29:    */   private final HashMap<Integer, HashSet<Integer>> mapStatementVars;
/*  30:    */   private final HashSet<Integer> implDefVars;
/*  31:    */   private final VarProcessor varproc;
/*  32:    */   
/*  33:    */   public VarDefinitionHelper(Statement root, StructMethod mt, VarProcessor varproc)
/*  34:    */   {
/*  35: 48 */     this.mapVarDefStatements = new HashMap();
/*  36: 49 */     this.mapStatementVars = new HashMap();
/*  37: 50 */     this.implDefVars = new HashSet();
/*  38:    */     
/*  39: 52 */     this.varproc = varproc;
/*  40:    */     
/*  41: 54 */     VarNamesCollector vc = DecompilerContext.getVarNamesCollector();
/*  42:    */     
/*  43: 56 */     boolean thisvar = !mt.hasModifier(8);
/*  44:    */     
/*  45: 58 */     MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/*  46:    */     
/*  47: 60 */     int paramcount = 0;
/*  48: 61 */     if (thisvar) {
/*  49: 62 */       paramcount = 1;
/*  50:    */     }
/*  51: 64 */     paramcount += md.params.length;
/*  52:    */     
/*  53:    */ 
/*  54:    */ 
/*  55: 68 */     int varindex = 0;
/*  56: 69 */     for (int i = 0; i < paramcount; i++)
/*  57:    */     {
/*  58: 70 */       this.implDefVars.add(Integer.valueOf(varindex));
/*  59: 71 */       varproc.setVarName(new VarVersionPair(varindex, 0), vc.getFreeName(varindex));
/*  60: 73 */       if (thisvar)
/*  61:    */       {
/*  62: 74 */         if (i == 0) {
/*  63: 75 */           varindex++;
/*  64:    */         } else {
/*  65: 78 */           varindex += md.params[(i - 1)].stackSize;
/*  66:    */         }
/*  67:    */       }
/*  68:    */       else {
/*  69: 82 */         varindex += md.params[i].stackSize;
/*  70:    */       }
/*  71:    */     }
/*  72: 86 */     if (thisvar)
/*  73:    */     {
/*  74: 87 */       StructClass current_class = (StructClass)DecompilerContext.getProperty("CURRENT_CLASS");
/*  75:    */       
/*  76: 89 */       varproc.getThisVars().put(new VarVersionPair(0, 0), current_class.qualifiedName);
/*  77: 90 */       varproc.setVarName(new VarVersionPair(0, 0), "this");
/*  78: 91 */       vc.addName("this");
/*  79:    */     }
/*  80: 95 */     LinkedList<Statement> stack = new LinkedList();
/*  81: 96 */     stack.add(root);
/*  82: 98 */     while (!stack.isEmpty())
/*  83:    */     {
/*  84: 99 */       Statement st = (Statement)stack.removeFirst();
/*  85:    */       
/*  86:101 */       List<VarExprent> lstVars = null;
/*  87:102 */       if (st.type == 12) {
/*  88:103 */         lstVars = ((CatchAllStatement)st).getVars();
/*  89:105 */       } else if (st.type == 7) {
/*  90:106 */         lstVars = ((CatchStatement)st).getVars();
/*  91:    */       }
/*  92:109 */       if (lstVars != null) {
/*  93:110 */         for (VarExprent var : lstVars)
/*  94:    */         {
/*  95:111 */           this.implDefVars.add(Integer.valueOf(var.getIndex()));
/*  96:112 */           varproc.setVarName(new VarVersionPair(var), vc.getFreeName(var.getIndex()));
/*  97:113 */           var.setDefinition(true);
/*  98:    */         }
/*  99:    */       }
/* 100:117 */       stack.addAll(st.getStats());
/* 101:    */     }
/* 102:120 */     initStatement(root);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setVarDefinitions()
/* 106:    */   {
/* 107:126 */     VarNamesCollector vc = DecompilerContext.getVarNamesCollector();
/* 108:128 */     for (Map.Entry<Integer, Statement> en : this.mapVarDefStatements.entrySet())
/* 109:    */     {
/* 110:129 */       Statement stat = (Statement)en.getValue();
/* 111:130 */       Integer index = (Integer)en.getKey();
/* 112:132 */       if (!this.implDefVars.contains(index))
/* 113:    */       {
/* 114:137 */         this.varproc.setVarName(new VarVersionPair(index.intValue(), 0), vc.getFreeName(index.intValue()));
/* 115:140 */         if (stat.type == 5)
/* 116:    */         {
/* 117:141 */           DoStatement dstat = (DoStatement)stat;
/* 118:142 */           if (dstat.getLooptype() == 3)
/* 119:    */           {
/* 120:144 */             if ((dstat.getInitExprent() != null) && (setDefinition(dstat.getInitExprent(), index))) {
/* 121:    */               continue;
/* 122:    */             }
/* 123:148 */             List<Exprent> lstSpecial = Arrays.asList(new Exprent[] { dstat.getConditionExprent(), dstat.getIncExprent() });
/* 124:149 */             for (VarExprent var : getAllVars(lstSpecial)) {
/* 125:150 */               if (var.getIndex() == index.intValue())
/* 126:    */               {
/* 127:151 */                 stat = stat.getParent();
/* 128:152 */                 break;
/* 129:    */               }
/* 130:    */             }
/* 131:    */           }
/* 132:    */         }
/* 133:160 */         Statement first = findFirstBlock(stat, index);
/* 134:    */         List<Exprent> lst;
/* 135:    */         List<Exprent> lst;
/* 136:163 */         if (first == null)
/* 137:    */         {
/* 138:164 */           lst = stat.getVarDefinitions();
/* 139:    */         }
/* 140:    */         else
/* 141:    */         {
/* 142:    */           List<Exprent> lst;
/* 143:166 */           if (first.getExprents() == null) {
/* 144:167 */             lst = first.getVarDefinitions();
/* 145:    */           } else {
/* 146:170 */             lst = first.getExprents();
/* 147:    */           }
/* 148:    */         }
/* 149:174 */         boolean defset = false;
/* 150:    */         
/* 151:    */ 
/* 152:177 */         int addindex = 0;
/* 153:178 */         for (Exprent expr : lst)
/* 154:    */         {
/* 155:179 */           if (setDefinition(expr, index))
/* 156:    */           {
/* 157:180 */             defset = true;
/* 158:181 */             break;
/* 159:    */           }
/* 160:184 */           boolean foundvar = false;
/* 161:185 */           for (Exprent exp : expr.getAllExprents(true)) {
/* 162:186 */             if ((exp.type == 12) && (((VarExprent)exp).getIndex() == index.intValue()))
/* 163:    */             {
/* 164:187 */               foundvar = true;
/* 165:188 */               break;
/* 166:    */             }
/* 167:    */           }
/* 168:191 */           if (foundvar) {
/* 169:    */             break;
/* 170:    */           }
/* 171:195 */           addindex++;
/* 172:    */         }
/* 173:198 */         if (!defset)
/* 174:    */         {
/* 175:199 */           VarExprent var = new VarExprent(index.intValue(), this.varproc.getVarType(new VarVersionPair(index.intValue(), 0)), this.varproc);
/* 176:200 */           var.setDefinition(true);
/* 177:    */           
/* 178:202 */           lst.add(addindex, var);
/* 179:    */         }
/* 180:    */       }
/* 181:    */     }
/* 182:    */   }
/* 183:    */   
/* 184:    */   private Statement findFirstBlock(Statement stat, Integer varindex)
/* 185:    */   {
/* 186:214 */     LinkedList<Statement> stack = new LinkedList();
/* 187:215 */     stack.add(stat);
/* 188:217 */     while (!stack.isEmpty())
/* 189:    */     {
/* 190:218 */       Statement st = (Statement)stack.remove(0);
/* 191:220 */       if ((stack.isEmpty()) || (((HashSet)this.mapStatementVars.get(st.id)).contains(varindex)))
/* 192:    */       {
/* 193:222 */         if ((st.isLabeled()) && (!stack.isEmpty())) {
/* 194:223 */           return st;
/* 195:    */         }
/* 196:226 */         if (st.getExprents() != null) {
/* 197:227 */           return st;
/* 198:    */         }
/* 199:230 */         stack.clear();
/* 200:232 */         switch (st.type)
/* 201:    */         {
/* 202:    */         case 15: 
/* 203:234 */           stack.addAll(0, st.getStats());
/* 204:235 */           break;
/* 205:    */         case 2: 
/* 206:    */         case 6: 
/* 207:    */         case 10: 
/* 208:    */         case 13: 
/* 209:240 */           stack.add(st.getFirst());
/* 210:241 */           break;
/* 211:    */         case 3: 
/* 212:    */         case 4: 
/* 213:    */         case 5: 
/* 214:    */         case 7: 
/* 215:    */         case 8: 
/* 216:    */         case 9: 
/* 217:    */         case 11: 
/* 218:    */         case 12: 
/* 219:    */         case 14: 
/* 220:    */         default: 
/* 221:243 */           return st;
/* 222:    */         }
/* 223:    */       }
/* 224:    */     }
/* 225:249 */     return null;
/* 226:    */   }
/* 227:    */   
/* 228:    */   private Set<Integer> initStatement(Statement stat)
/* 229:    */   {
/* 230:254 */     HashMap<Integer, Integer> mapCount = new HashMap();
/* 231:    */     List<VarExprent> condlst;
/* 232:    */     List<VarExprent> condlst;
/* 233:258 */     if (stat.getExprents() == null)
/* 234:    */     {
/* 235:261 */       List<Integer> childVars = new ArrayList();
/* 236:262 */       List<Exprent> currVars = new ArrayList();
/* 237:264 */       for (Object obj : stat.getSequentialObjects()) {
/* 238:265 */         if ((obj instanceof Statement))
/* 239:    */         {
/* 240:266 */           Statement st = (Statement)obj;
/* 241:267 */           childVars.addAll(initStatement(st));
/* 242:269 */           if (st.type == 5)
/* 243:    */           {
/* 244:270 */             DoStatement dost = (DoStatement)st;
/* 245:271 */             if ((dost.getLooptype() != 3) && (dost.getLooptype() != 0)) {
/* 246:273 */               currVars.add(dost.getConditionExprent());
/* 247:    */             }
/* 248:    */           }
/* 249:276 */           else if (st.type == 12)
/* 250:    */           {
/* 251:277 */             CatchAllStatement fin = (CatchAllStatement)st;
/* 252:278 */             if ((fin.isFinally()) && (fin.getMonitor() != null)) {
/* 253:279 */               currVars.add(fin.getMonitor());
/* 254:    */             }
/* 255:    */           }
/* 256:    */         }
/* 257:283 */         else if ((obj instanceof Exprent))
/* 258:    */         {
/* 259:284 */           currVars.add((Exprent)obj);
/* 260:    */         }
/* 261:    */       }
/* 262:289 */       for (Integer index : childVars)
/* 263:    */       {
/* 264:290 */         Integer count = (Integer)mapCount.get(index);
/* 265:291 */         if (count == null) {
/* 266:292 */           count = new Integer(0);
/* 267:    */         }
/* 268:294 */         mapCount.put(index, new Integer(count.intValue() + 1));
/* 269:    */       }
/* 270:297 */       condlst = getAllVars(currVars);
/* 271:    */     }
/* 272:    */     else
/* 273:    */     {
/* 274:300 */       condlst = getAllVars(stat.getExprents());
/* 275:    */     }
/* 276:304 */     for (VarExprent var : condlst) {
/* 277:305 */       mapCount.put(new Integer(var.getIndex()), new Integer(2));
/* 278:    */     }
/* 279:309 */     HashSet<Integer> set = new HashSet(mapCount.keySet());
/* 280:312 */     for (Map.Entry<Integer, Integer> en : mapCount.entrySet()) {
/* 281:313 */       if (((Integer)en.getValue()).intValue() > 1) {
/* 282:314 */         this.mapVarDefStatements.put(en.getKey(), stat);
/* 283:    */       }
/* 284:    */     }
/* 285:318 */     this.mapStatementVars.put(stat.id, set);
/* 286:    */     
/* 287:320 */     return set;
/* 288:    */   }
/* 289:    */   
/* 290:    */   private static List<VarExprent> getAllVars(List<Exprent> lst)
/* 291:    */   {
/* 292:325 */     List<VarExprent> res = new ArrayList();
/* 293:326 */     List<Exprent> listTemp = new ArrayList();
/* 294:328 */     for (Exprent expr : lst)
/* 295:    */     {
/* 296:329 */       listTemp.addAll(expr.getAllExprents(true));
/* 297:330 */       listTemp.add(expr);
/* 298:    */     }
/* 299:333 */     for (Exprent exprent : listTemp) {
/* 300:334 */       if (exprent.type == 12) {
/* 301:335 */         res.add((VarExprent)exprent);
/* 302:    */       }
/* 303:    */     }
/* 304:339 */     return res;
/* 305:    */   }
/* 306:    */   
/* 307:    */   private static boolean setDefinition(Exprent expr, Integer index)
/* 308:    */   {
/* 309:343 */     if (expr.type == 2)
/* 310:    */     {
/* 311:344 */       Exprent left = ((AssignmentExprent)expr).getLeft();
/* 312:345 */       if (left.type == 12)
/* 313:    */       {
/* 314:346 */         VarExprent var = (VarExprent)left;
/* 315:347 */         if (var.getIndex() == index.intValue())
/* 316:    */         {
/* 317:348 */           var.setDefinition(true);
/* 318:349 */           return true;
/* 319:    */         }
/* 320:    */       }
/* 321:    */     }
/* 322:353 */     return false;
/* 323:    */   }
/* 324:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.vars.VarDefinitionHelper
 * JD-Core Version:    0.7.0.1
 */