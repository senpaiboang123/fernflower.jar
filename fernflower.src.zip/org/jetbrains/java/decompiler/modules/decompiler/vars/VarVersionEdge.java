/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.vars;
/*  2:   */ 
/*  3:   */ public class VarVersionEdge
/*  4:   */ {
/*  5:   */   public static final int EDGE_GENERAL = 0;
/*  6:   */   public static final int EDGE_PHANTOM = 1;
/*  7:   */   public final int type;
/*  8:   */   public final VarVersionNode source;
/*  9:   */   public final VarVersionNode dest;
/* 10:   */   private final int hashCode;
/* 11:   */   
/* 12:   */   public VarVersionEdge(int type, VarVersionNode source, VarVersionNode dest)
/* 13:   */   {
/* 14:32 */     this.type = type;
/* 15:33 */     this.source = source;
/* 16:34 */     this.dest = dest;
/* 17:35 */     this.hashCode = (source.hashCode() ^ dest.hashCode() + type);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean equals(Object o)
/* 21:   */   {
/* 22:40 */     if (o == this) {
/* 23:40 */       return true;
/* 24:   */     }
/* 25:41 */     if ((o == null) || (!(o instanceof VarVersionEdge))) {
/* 26:41 */       return false;
/* 27:   */     }
/* 28:43 */     VarVersionEdge edge = (VarVersionEdge)o;
/* 29:44 */     return (this.type == edge.type) && (this.source == edge.source) && (this.dest == edge.dest);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public int hashCode()
/* 33:   */   {
/* 34:49 */     return this.hashCode;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String toString()
/* 38:   */   {
/* 39:54 */     return this.source.toString() + " ->" + this.type + "-> " + this.dest.toString();
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionEdge
 * JD-Core Version:    0.7.0.1
 */