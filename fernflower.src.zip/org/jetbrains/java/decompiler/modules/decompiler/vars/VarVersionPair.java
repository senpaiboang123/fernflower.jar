/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.vars;
/*  2:   */ 
/*  3:   */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  4:   */ 
/*  5:   */ public class VarVersionPair
/*  6:   */ {
/*  7:   */   public final int var;
/*  8:   */   public final int version;
/*  9:25 */   private int hashCode = -1;
/* 10:   */   
/* 11:   */   public VarVersionPair(int var, int version)
/* 12:   */   {
/* 13:28 */     this.var = var;
/* 14:29 */     this.version = version;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public VarVersionPair(Integer var, Integer version)
/* 18:   */   {
/* 19:33 */     this.var = var.intValue();
/* 20:34 */     this.version = version.intValue();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public VarVersionPair(VarExprent var)
/* 24:   */   {
/* 25:38 */     this.var = var.getIndex();
/* 26:39 */     this.version = var.getVersion();
/* 27:   */   }
/* 28:   */   
/* 29:   */   public boolean equals(Object o)
/* 30:   */   {
/* 31:44 */     if (o == this) {
/* 32:44 */       return true;
/* 33:   */     }
/* 34:45 */     if ((o == null) || (!(o instanceof VarVersionPair))) {
/* 35:45 */       return false;
/* 36:   */     }
/* 37:47 */     VarVersionPair paar = (VarVersionPair)o;
/* 38:48 */     return (this.var == paar.var) && (this.version == paar.version);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public int hashCode()
/* 42:   */   {
/* 43:53 */     if (this.hashCode == -1) {
/* 44:54 */       this.hashCode = (this.var * 3 + this.version);
/* 45:   */     }
/* 46:56 */     return this.hashCode;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public String toString()
/* 50:   */   {
/* 51:61 */     return "(" + this.var + "," + this.version + ")";
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair
 * JD-Core Version:    0.7.0.1
 */