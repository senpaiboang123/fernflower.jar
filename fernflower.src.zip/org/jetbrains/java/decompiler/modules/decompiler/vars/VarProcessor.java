/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.vars;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  13:    */ import org.jetbrains.java.decompiler.main.collectors.VarNamesCollector;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  16:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  17:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  18:    */ 
/*  19:    */ public class VarProcessor
/*  20:    */ {
/*  21: 30 */   private Map<VarVersionPair, String> mapVarNames = new HashMap();
/*  22:    */   private VarVersionsProcessor varVersions;
/*  23: 32 */   private final Map<VarVersionPair, String> thisVars = new HashMap();
/*  24: 33 */   private final Set<VarVersionPair> externalVars = new HashSet();
/*  25:    */   
/*  26:    */   public void setVarVersions(RootStatement root)
/*  27:    */   {
/*  28: 36 */     this.varVersions = new VarVersionsProcessor();
/*  29: 37 */     this.varVersions.setVarVersions(root);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setVarDefinitions(Statement root)
/*  33:    */   {
/*  34: 41 */     this.mapVarNames = new HashMap();
/*  35:    */     
/*  36: 43 */     StructMethod mt = (StructMethod)DecompilerContext.getProperty("CURRENT_METHOD");
/*  37: 44 */     new VarDefinitionHelper(root, mt, this).setVarDefinitions();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void setDebugVarNames(Map<Integer, String> mapDebugVarNames)
/*  41:    */   {
/*  42: 48 */     if (this.varVersions == null) {
/*  43: 49 */       return;
/*  44:    */     }
/*  45: 52 */     Map<Integer, Integer> mapOriginalVarIndices = this.varVersions.getMapOriginalVarIndices();
/*  46:    */     
/*  47: 54 */     List<VarVersionPair> listVars = new ArrayList(this.mapVarNames.keySet());
/*  48: 55 */     Collections.sort(listVars, new Comparator()
/*  49:    */     {
/*  50:    */       public int compare(VarVersionPair o1, VarVersionPair o2)
/*  51:    */       {
/*  52: 58 */         return o1.var - o2.var;
/*  53:    */       }
/*  54: 61 */     });
/*  55: 62 */     Map<String, Integer> mapNames = new HashMap();
/*  56: 64 */     for (VarVersionPair pair : listVars)
/*  57:    */     {
/*  58: 65 */       String name = (String)this.mapVarNames.get(pair);
/*  59:    */       
/*  60: 67 */       Integer index = (Integer)mapOriginalVarIndices.get(Integer.valueOf(pair.var));
/*  61: 68 */       if ((index != null) && (mapDebugVarNames.containsKey(index))) {
/*  62: 69 */         name = (String)mapDebugVarNames.get(index);
/*  63:    */       }
/*  64: 72 */       Integer counter = (Integer)mapNames.get(name);
/*  65: 73 */       mapNames.put(name, counter = Integer.valueOf(counter.intValue() + 1));
/*  66: 75 */       if (counter.intValue() > 0) {
/*  67: 76 */         name = name + String.valueOf(counter);
/*  68:    */       }
/*  69: 79 */       this.mapVarNames.put(pair, name);
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void refreshVarNames(VarNamesCollector vc)
/*  74:    */   {
/*  75: 84 */     Map<VarVersionPair, String> tempVarNames = new HashMap(this.mapVarNames);
/*  76: 85 */     for (Map.Entry<VarVersionPair, String> ent : tempVarNames.entrySet()) {
/*  77: 86 */       this.mapVarNames.put(ent.getKey(), vc.getFreeName((String)ent.getValue()));
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public VarType getVarType(VarVersionPair pair)
/*  82:    */   {
/*  83: 91 */     return this.varVersions == null ? null : this.varVersions.getVarType(pair);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void setVarType(VarVersionPair pair, VarType type)
/*  87:    */   {
/*  88: 95 */     this.varVersions.setVarType(pair, type);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public String getVarName(VarVersionPair pair)
/*  92:    */   {
/*  93: 99 */     return this.mapVarNames == null ? null : (String)this.mapVarNames.get(pair);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void setVarName(VarVersionPair pair, String name)
/*  97:    */   {
/*  98:103 */     this.mapVarNames.put(pair, name);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public int getVarFinal(VarVersionPair pair)
/* 102:    */   {
/* 103:107 */     return this.varVersions == null ? 3 : this.varVersions.getVarFinal(pair);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void setVarFinal(VarVersionPair pair, int finalType)
/* 107:    */   {
/* 108:111 */     this.varVersions.setVarFinal(pair, finalType);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public Map<VarVersionPair, String> getThisVars()
/* 112:    */   {
/* 113:115 */     return this.thisVars;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public Set<VarVersionPair> getExternalVars()
/* 117:    */   {
/* 118:119 */     return this.externalVars;
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor
 * JD-Core Version:    0.7.0.1
 */