/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.vars;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.HashSet;
/*  5:   */ import java.util.List;
/*  6:   */ import java.util.Set;
/*  7:   */ import org.jetbrains.java.decompiler.modules.decompiler.decompose.IGraphNode;
/*  8:   */ import org.jetbrains.java.decompiler.util.SFormsFastMapDirect;
/*  9:   */ 
/* 10:   */ public class VarVersionNode
/* 11:   */   implements IGraphNode
/* 12:   */ {
/* 13:   */   public static final int FLAG_PHANTOM_FINEXIT = 2;
/* 14:   */   public final int var;
/* 15:   */   public final int version;
/* 16:34 */   public final Set<VarVersionEdge> succs = new HashSet();
/* 17:36 */   public final Set<VarVersionEdge> preds = new HashSet();
/* 18:   */   public int flags;
/* 19:40 */   public SFormsFastMapDirect live = new SFormsFastMapDirect();
/* 20:   */   
/* 21:   */   public VarVersionNode(int var, int version)
/* 22:   */   {
/* 23:44 */     this.var = var;
/* 24:45 */     this.version = version;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public VarVersionPair getVarPaar()
/* 28:   */   {
/* 29:49 */     return new VarVersionPair(this.var, this.version);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public List<IGraphNode> getPredecessors()
/* 33:   */   {
/* 34:53 */     List<IGraphNode> lst = new ArrayList(this.preds.size());
/* 35:54 */     for (VarVersionEdge edge : this.preds) {
/* 36:55 */       lst.add(edge.source);
/* 37:   */     }
/* 38:57 */     return lst;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void removeSuccessor(VarVersionEdge edge)
/* 42:   */   {
/* 43:61 */     this.succs.remove(edge);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void removePredecessor(VarVersionEdge edge)
/* 47:   */   {
/* 48:65 */     this.preds.remove(edge);
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void addSuccessor(VarVersionEdge edge)
/* 52:   */   {
/* 53:69 */     this.succs.add(edge);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void addPredecessor(VarVersionEdge edge)
/* 57:   */   {
/* 58:73 */     this.preds.add(edge);
/* 59:   */   }
/* 60:   */   
/* 61:   */   public String toString()
/* 62:   */   {
/* 63:78 */     return "(" + this.var + "_" + this.version + ")";
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionNode
 * JD-Core Version:    0.7.0.1
 */