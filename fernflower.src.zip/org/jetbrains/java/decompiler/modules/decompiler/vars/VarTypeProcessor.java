/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.vars;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.LinkedList;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph.ExprentIterator;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchAllStatement;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  19:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  20:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  21:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  22:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  23:    */ 
/*  24:    */ public class VarTypeProcessor
/*  25:    */ {
/*  26:    */   public static final int VAR_NON_FINAL = 1;
/*  27:    */   public static final int VAR_EXPLICIT_FINAL = 2;
/*  28:    */   public static final int VAR_FINAL = 3;
/*  29: 42 */   private final Map<VarVersionPair, VarType> mapExprentMinTypes = new HashMap();
/*  30: 43 */   private final Map<VarVersionPair, VarType> mapExprentMaxTypes = new HashMap();
/*  31: 44 */   private final Map<VarVersionPair, Integer> mapFinalVars = new HashMap();
/*  32:    */   
/*  33:    */   private void setInitVars(RootStatement root)
/*  34:    */   {
/*  35: 47 */     StructMethod mt = (StructMethod)DecompilerContext.getProperty("CURRENT_METHOD");
/*  36:    */     
/*  37: 49 */     boolean thisVar = !mt.hasModifier(8);
/*  38:    */     
/*  39: 51 */     MethodDescriptor md = (MethodDescriptor)DecompilerContext.getProperty("CURRENT_METHOD_DESCRIPTOR");
/*  40: 53 */     if (thisVar)
/*  41:    */     {
/*  42: 54 */       StructClass cl = (StructClass)DecompilerContext.getProperty("CURRENT_CLASS");
/*  43: 55 */       VarType clType = new VarType(8, 0, cl.qualifiedName);
/*  44: 56 */       this.mapExprentMinTypes.put(new VarVersionPair(0, 1), clType);
/*  45: 57 */       this.mapExprentMaxTypes.put(new VarVersionPair(0, 1), clType);
/*  46:    */     }
/*  47: 60 */     int varIndex = 0;
/*  48: 61 */     for (int i = 0; i < md.params.length; i++)
/*  49:    */     {
/*  50: 62 */       this.mapExprentMinTypes.put(new VarVersionPair(varIndex + (thisVar ? 1 : 0), 1), md.params[i]);
/*  51: 63 */       this.mapExprentMaxTypes.put(new VarVersionPair(varIndex + (thisVar ? 1 : 0), 1), md.params[i]);
/*  52: 64 */       varIndex += md.params[i].stackSize;
/*  53:    */     }
/*  54: 68 */     LinkedList<Statement> stack = new LinkedList();
/*  55: 69 */     stack.add(root);
/*  56: 71 */     while (!stack.isEmpty())
/*  57:    */     {
/*  58: 72 */       Statement stat = (Statement)stack.removeFirst();
/*  59:    */       
/*  60: 74 */       List<VarExprent> lstVars = null;
/*  61: 75 */       if (stat.type == 12) {
/*  62: 76 */         lstVars = ((CatchAllStatement)stat).getVars();
/*  63: 78 */       } else if (stat.type == 7) {
/*  64: 79 */         lstVars = ((CatchStatement)stat).getVars();
/*  65:    */       }
/*  66: 82 */       if (lstVars != null) {
/*  67: 83 */         for (VarExprent var : lstVars)
/*  68:    */         {
/*  69: 84 */           this.mapExprentMinTypes.put(new VarVersionPair(var.getIndex(), 1), var.getVarType());
/*  70: 85 */           this.mapExprentMaxTypes.put(new VarVersionPair(var.getIndex(), 1), var.getVarType());
/*  71:    */         }
/*  72:    */       }
/*  73: 89 */       stack.addAll(stat.getStats());
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void calculateVarTypes(RootStatement root, DirectGraph graph)
/*  78:    */   {
/*  79: 94 */     setInitVars(root);
/*  80:    */     
/*  81: 96 */     resetExprentTypes(graph);
/*  82: 99 */     while (!processVarTypes(graph)) {}
/*  83:    */   }
/*  84:    */   
/*  85:    */   private static void resetExprentTypes(DirectGraph graph)
/*  86:    */   {
/*  87:103 */     graph.iterateExprents(new DirectGraph.ExprentIterator()
/*  88:    */     {
/*  89:    */       public int processExprent(Exprent exprent)
/*  90:    */       {
/*  91:106 */         List<Exprent> lst = exprent.getAllExprents(true);
/*  92:107 */         lst.add(exprent);
/*  93:109 */         for (Exprent expr : lst) {
/*  94:110 */           if (expr.type == 12)
/*  95:    */           {
/*  96:111 */             ((VarExprent)expr).setVarType(VarType.VARTYPE_UNKNOWN);
/*  97:    */           }
/*  98:113 */           else if (expr.type == 3)
/*  99:    */           {
/* 100:114 */             ConstExprent constExpr = (ConstExprent)expr;
/* 101:115 */             if (constExpr.getConstType().typeFamily == 2) {
/* 102:116 */               constExpr.setConstType(new ConstExprent(constExpr.getIntValue(), constExpr.isBoolPermitted(), null).getConstType());
/* 103:    */             }
/* 104:    */           }
/* 105:    */         }
/* 106:120 */         return 0;
/* 107:    */       }
/* 108:    */     });
/* 109:    */   }
/* 110:    */   
/* 111:    */   private boolean processVarTypes(DirectGraph graph)
/* 112:    */   {
/* 113:126 */     graph.iterateExprents(new DirectGraph.ExprentIterator()
/* 114:    */     {
/* 115:    */       public int processExprent(Exprent exprent)
/* 116:    */       {
/* 117:129 */         return VarTypeProcessor.this.checkTypeExprent(exprent) ? 0 : 1;
/* 118:    */       }
/* 119:    */     });
/* 120:    */   }
/* 121:    */   
/* 122:    */   private boolean checkTypeExprent(Exprent exprent)
/* 123:    */   {
/* 124:136 */     for (Exprent expr : exprent.getAllExprents()) {
/* 125:137 */       if (!checkTypeExprent(expr)) {
/* 126:138 */         return false;
/* 127:    */       }
/* 128:    */     }
/* 129:142 */     if (exprent.type == 3)
/* 130:    */     {
/* 131:143 */       ConstExprent constExpr = (ConstExprent)exprent;
/* 132:144 */       if (constExpr.getConstType().typeFamily <= 2)
/* 133:    */       {
/* 134:145 */         VarVersionPair pair = new VarVersionPair(constExpr.id, -1);
/* 135:146 */         if (!this.mapExprentMinTypes.containsKey(pair)) {
/* 136:147 */           this.mapExprentMinTypes.put(pair, constExpr.getConstType());
/* 137:    */         }
/* 138:    */       }
/* 139:    */     }
/* 140:152 */     CheckTypesResult result = exprent.checkExprTypeBounds();
/* 141:154 */     for (CheckTypesResult.ExprentTypePair entry : result.getLstMaxTypeExprents()) {
/* 142:155 */       if (entry.type.typeFamily != 6) {
/* 143:156 */         changeExprentType(entry.exprent, entry.type, 1);
/* 144:    */       }
/* 145:    */     }
/* 146:160 */     boolean res = true;
/* 147:161 */     for (CheckTypesResult.ExprentTypePair entry : result.getLstMinTypeExprents()) {
/* 148:162 */       res &= changeExprentType(entry.exprent, entry.type, 0);
/* 149:    */     }
/* 150:165 */     return res;
/* 151:    */   }
/* 152:    */   
/* 153:    */   private boolean changeExprentType(Exprent exprent, VarType newType, int minMax)
/* 154:    */   {
/* 155:170 */     boolean res = true;
/* 156:172 */     switch (exprent.type)
/* 157:    */     {
/* 158:    */     case 3: 
/* 159:174 */       ConstExprent constExpr = (ConstExprent)exprent;
/* 160:175 */       VarType constType = constExpr.getConstType();
/* 161:177 */       if ((newType.typeFamily > 2) || (constType.typeFamily > 2)) {
/* 162:178 */         return true;
/* 163:    */       }
/* 164:180 */       if (newType.typeFamily == 2)
/* 165:    */       {
/* 166:181 */         VarType minInteger = new ConstExprent(((Integer)constExpr.getValue()).intValue(), false, null).getConstType();
/* 167:182 */         if (minInteger.isStrictSuperset(newType)) {
/* 168:183 */           newType = minInteger;
/* 169:    */         }
/* 170:    */       }
/* 171:    */     case 12: 
/* 172:187 */       VarVersionPair pair = null;
/* 173:188 */       if (exprent.type == 3) {
/* 174:189 */         pair = new VarVersionPair(((ConstExprent)exprent).id, -1);
/* 175:191 */       } else if (exprent.type == 12) {
/* 176:193 */         pair = new VarVersionPair((VarExprent)exprent);
/* 177:    */       }
/* 178:196 */       if (minMax == 0)
/* 179:    */       {
/* 180:197 */         VarType currentMinType = (VarType)this.mapExprentMinTypes.get(pair);
/* 181:    */         VarType newMinType;
/* 182:    */         VarType newMinType;
/* 183:199 */         if ((currentMinType == null) || (newType.typeFamily > currentMinType.typeFamily))
/* 184:    */         {
/* 185:200 */           newMinType = newType;
/* 186:    */         }
/* 187:    */         else
/* 188:    */         {
/* 189:202 */           if (newType.typeFamily < currentMinType.typeFamily) {
/* 190:203 */             return true;
/* 191:    */           }
/* 192:206 */           newMinType = VarType.getCommonSupertype(currentMinType, newType);
/* 193:    */         }
/* 194:209 */         this.mapExprentMinTypes.put(pair, newMinType);
/* 195:210 */         if (exprent.type == 3) {
/* 196:212 */           ((ConstExprent)exprent).setConstType(newMinType);
/* 197:    */         }
/* 198:215 */         if ((currentMinType != null) && ((newMinType.typeFamily > currentMinType.typeFamily) || (newMinType.isStrictSuperset(currentMinType)))) {
/* 199:216 */           return false;
/* 200:    */         }
/* 201:    */       }
/* 202:    */       else
/* 203:    */       {
/* 204:220 */         VarType currentMaxType = (VarType)this.mapExprentMaxTypes.get(pair);
/* 205:    */         VarType newMaxType;
/* 206:    */         VarType newMaxType;
/* 207:222 */         if ((currentMaxType == null) || (newType.typeFamily < currentMaxType.typeFamily))
/* 208:    */         {
/* 209:223 */           newMaxType = newType;
/* 210:    */         }
/* 211:    */         else
/* 212:    */         {
/* 213:225 */           if (newType.typeFamily > currentMaxType.typeFamily) {
/* 214:226 */             return true;
/* 215:    */           }
/* 216:229 */           newMaxType = VarType.getCommonMinType(currentMaxType, newType);
/* 217:    */         }
/* 218:232 */         this.mapExprentMaxTypes.put(pair, newMaxType);
/* 219:    */       }
/* 220:234 */       break;
/* 221:    */     case 2: 
/* 222:237 */       return changeExprentType(((AssignmentExprent)exprent).getRight(), newType, minMax);
/* 223:    */     case 6: 
/* 224:240 */       FunctionExprent func = (FunctionExprent)exprent;
/* 225:241 */       switch (func.getFuncType())
/* 226:    */       {
/* 227:    */       case 36: 
/* 228:243 */         res = changeExprentType((Exprent)func.getLstOperands().get(1), newType, minMax) & changeExprentType((Exprent)func.getLstOperands().get(2), newType, minMax);
/* 229:    */         
/* 230:245 */         break;
/* 231:    */       case 4: 
/* 232:    */       case 5: 
/* 233:    */       case 6: 
/* 234:249 */         res = changeExprentType((Exprent)func.getLstOperands().get(0), newType, minMax) & changeExprentType((Exprent)func.getLstOperands().get(1), newType, minMax);
/* 235:    */       }
/* 236:    */       break;
/* 237:    */     }
/* 238:255 */     return res;
/* 239:    */   }
/* 240:    */   
/* 241:    */   public Map<VarVersionPair, VarType> getMapExprentMaxTypes()
/* 242:    */   {
/* 243:259 */     return this.mapExprentMaxTypes;
/* 244:    */   }
/* 245:    */   
/* 246:    */   public Map<VarVersionPair, VarType> getMapExprentMinTypes()
/* 247:    */   {
/* 248:263 */     return this.mapExprentMinTypes;
/* 249:    */   }
/* 250:    */   
/* 251:    */   public Map<VarVersionPair, Integer> getMapFinalVars()
/* 252:    */   {
/* 253:267 */     return this.mapFinalVars;
/* 254:    */   }
/* 255:    */   
/* 256:    */   public void setVarType(VarVersionPair pair, VarType type)
/* 257:    */   {
/* 258:271 */     this.mapExprentMinTypes.put(pair, type);
/* 259:    */   }
/* 260:    */   
/* 261:    */   public VarType getVarType(VarVersionPair pair)
/* 262:    */   {
/* 263:275 */     return (VarType)this.mapExprentMinTypes.get(pair);
/* 264:    */   }
/* 265:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.vars.VarTypeProcessor
 * JD-Core Version:    0.7.0.1
 */