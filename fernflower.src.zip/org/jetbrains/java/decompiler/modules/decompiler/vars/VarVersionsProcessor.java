/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.vars;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.Collections;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  13:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph.ExprentIterator;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.FlattenStatementsHelper;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAConstructorSparseEx;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  22:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  23:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  24:    */ import org.jetbrains.java.decompiler.util.FastSparseSetFactory.FastSparseSet;
/*  25:    */ 
/*  26:    */ public class VarVersionsProcessor
/*  27:    */ {
/*  28: 37 */   private Map<Integer, Integer> mapOriginalVarIndices = new HashMap();
/*  29:    */   private VarTypeProcessor typeProcessor;
/*  30:    */   
/*  31:    */   public void setVarVersions(RootStatement root)
/*  32:    */   {
/*  33: 41 */     StructMethod mt = (StructMethod)DecompilerContext.getProperty("CURRENT_METHOD");
/*  34:    */     
/*  35: 43 */     SSAConstructorSparseEx ssa = new SSAConstructorSparseEx();
/*  36: 44 */     ssa.splitVariables(root, mt);
/*  37:    */     
/*  38: 46 */     FlattenStatementsHelper flattenHelper = new FlattenStatementsHelper();
/*  39: 47 */     DirectGraph graph = flattenHelper.buildDirectGraph(root);
/*  40:    */     
/*  41: 49 */     mergePhiVersions(ssa, graph);
/*  42:    */     
/*  43: 51 */     this.typeProcessor = new VarTypeProcessor();
/*  44: 52 */     this.typeProcessor.calculateVarTypes(root, graph);
/*  45:    */     
/*  46: 54 */     simpleMerge(this.typeProcessor, graph, mt);
/*  47:    */     
/*  48:    */ 
/*  49:    */ 
/*  50: 58 */     eliminateNonJavaTypes(this.typeProcessor);
/*  51:    */     
/*  52: 60 */     setNewVarIndices(this.typeProcessor, graph);
/*  53:    */   }
/*  54:    */   
/*  55:    */   private static void mergePhiVersions(SSAConstructorSparseEx ssa, DirectGraph graph)
/*  56:    */   {
/*  57: 65 */     List<Set<VarVersionPair>> lst = new ArrayList();
/*  58: 66 */     for (Map.Entry<VarVersionPair, FastSparseSetFactory.FastSparseSet<Integer>> ent : ssa.getPhi().entrySet())
/*  59:    */     {
/*  60: 67 */       Set<VarVersionPair> set = new HashSet();
/*  61: 68 */       set.add(ent.getKey());
/*  62: 69 */       for (Integer version : (FastSparseSetFactory.FastSparseSet)ent.getValue()) {
/*  63: 70 */         set.add(new VarVersionPair(((VarVersionPair)ent.getKey()).var, version.intValue()));
/*  64:    */       }
/*  65: 73 */       for (int i = lst.size() - 1; i >= 0; i--)
/*  66:    */       {
/*  67: 74 */         Set<VarVersionPair> tset = (Set)lst.get(i);
/*  68: 75 */         Set<VarVersionPair> intersection = new HashSet(set);
/*  69: 76 */         intersection.retainAll(tset);
/*  70: 78 */         if (!intersection.isEmpty())
/*  71:    */         {
/*  72: 79 */           set.addAll(tset);
/*  73: 80 */           lst.remove(i);
/*  74:    */         }
/*  75:    */       }
/*  76: 84 */       lst.add(set);
/*  77:    */     }
/*  78: 87 */     Map<VarVersionPair, Integer> phiVersions = new HashMap();
/*  79: 88 */     for (Set<VarVersionPair> set : lst)
/*  80:    */     {
/*  81: 89 */       min = 2147483647;
/*  82: 90 */       for (VarVersionPair paar : set) {
/*  83: 91 */         if (paar.version < min) {
/*  84: 92 */           min = paar.version;
/*  85:    */         }
/*  86:    */       }
/*  87: 96 */       for (VarVersionPair paar : set) {
/*  88: 97 */         phiVersions.put(new VarVersionPair(paar.var, paar.version), Integer.valueOf(min));
/*  89:    */       }
/*  90:    */     }
/*  91:    */     int min;
/*  92:101 */     updateVersions(graph, phiVersions);
/*  93:    */   }
/*  94:    */   
/*  95:    */   private static void updateVersions(DirectGraph graph, Map<VarVersionPair, Integer> versions)
/*  96:    */   {
/*  97:105 */     graph.iterateExprents(new DirectGraph.ExprentIterator()
/*  98:    */     {
/*  99:    */       public int processExprent(Exprent exprent)
/* 100:    */       {
/* 101:108 */         List<Exprent> lst = exprent.getAllExprents(true);
/* 102:109 */         lst.add(exprent);
/* 103:111 */         for (Exprent expr : lst) {
/* 104:112 */           if (expr.type == 12)
/* 105:    */           {
/* 106:113 */             VarExprent var = (VarExprent)expr;
/* 107:114 */             Integer version = (Integer)this.val$versions.get(new VarVersionPair(var));
/* 108:115 */             if (version != null) {
/* 109:116 */               var.setVersion(version.intValue());
/* 110:    */             }
/* 111:    */           }
/* 112:    */         }
/* 113:121 */         return 0;
/* 114:    */       }
/* 115:    */     });
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static void eliminateNonJavaTypes(VarTypeProcessor typeProcessor)
/* 119:    */   {
/* 120:127 */     Map<VarVersionPair, VarType> mapExprentMaxTypes = typeProcessor.getMapExprentMaxTypes();
/* 121:128 */     Map<VarVersionPair, VarType> mapExprentMinTypes = typeProcessor.getMapExprentMinTypes();
/* 122:    */     
/* 123:130 */     Set<VarVersionPair> set = new HashSet(mapExprentMinTypes.keySet());
/* 124:131 */     for (VarVersionPair paar : set)
/* 125:    */     {
/* 126:132 */       VarType type = (VarType)mapExprentMinTypes.get(paar);
/* 127:133 */       VarType maxType = (VarType)mapExprentMaxTypes.get(paar);
/* 128:135 */       if ((type.type == 15) || (type.type == 16))
/* 129:    */       {
/* 130:136 */         if ((maxType != null) && (maxType.type == 1)) {
/* 131:137 */           type = VarType.VARTYPE_CHAR;
/* 132:    */         } else {
/* 133:140 */           type = type.type == 15 ? VarType.VARTYPE_BYTE : VarType.VARTYPE_SHORT;
/* 134:    */         }
/* 135:142 */         mapExprentMinTypes.put(paar, type);
/* 136:    */       }
/* 137:146 */       else if (type.type == 13)
/* 138:    */       {
/* 139:147 */         mapExprentMinTypes.put(paar, VarType.VARTYPE_OBJECT);
/* 140:    */       }
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   private static void simpleMerge(VarTypeProcessor typeProcessor, DirectGraph graph, StructMethod mt)
/* 145:    */   {
/* 146:153 */     Map<VarVersionPair, VarType> mapExprentMaxTypes = typeProcessor.getMapExprentMaxTypes();
/* 147:154 */     Map<VarVersionPair, VarType> mapExprentMinTypes = typeProcessor.getMapExprentMinTypes();
/* 148:    */     
/* 149:156 */     Map<Integer, Set<Integer>> mapVarVersions = new HashMap();
/* 150:158 */     for (VarVersionPair pair : mapExprentMinTypes.keySet()) {
/* 151:159 */       if (pair.version >= 0)
/* 152:    */       {
/* 153:160 */         Set<Integer> set = (Set)mapVarVersions.get(Integer.valueOf(pair.var));
/* 154:161 */         if (set == null)
/* 155:    */         {
/* 156:162 */           set = new HashSet();
/* 157:163 */           mapVarVersions.put(Integer.valueOf(pair.var), set);
/* 158:    */         }
/* 159:165 */         set.add(Integer.valueOf(pair.version));
/* 160:    */       }
/* 161:    */     }
/* 162:169 */     boolean is_method_static = mt.hasModifier(8);
/* 163:    */     
/* 164:171 */     Map<VarVersionPair, Integer> mapMergedVersions = new HashMap();
/* 165:173 */     for (Map.Entry<Integer, Set<Integer>> ent : mapVarVersions.entrySet()) {
/* 166:175 */       if (((Set)ent.getValue()).size() > 1)
/* 167:    */       {
/* 168:176 */         List<Integer> lstVersions = new ArrayList((Collection)ent.getValue());
/* 169:177 */         Collections.sort(lstVersions);
/* 170:179 */         for (int i = 0; i < lstVersions.size(); i++)
/* 171:    */         {
/* 172:180 */           VarVersionPair firstPair = new VarVersionPair((Integer)ent.getKey(), (Integer)lstVersions.get(i));
/* 173:181 */           VarType firstType = (VarType)mapExprentMinTypes.get(firstPair);
/* 174:183 */           if ((firstPair.var != 0) || (firstPair.version != 1) || (is_method_static)) {
/* 175:187 */             for (int j = i + 1; j < lstVersions.size(); j++)
/* 176:    */             {
/* 177:188 */               VarVersionPair secondPair = new VarVersionPair((Integer)ent.getKey(), (Integer)lstVersions.get(j));
/* 178:189 */               VarType secondType = (VarType)mapExprentMinTypes.get(secondPair);
/* 179:191 */               if ((firstType.equals(secondType)) || ((firstType.equals(VarType.VARTYPE_NULL)) && (secondType.type == 8)) || ((secondType.equals(VarType.VARTYPE_NULL)) && (firstType.type == 8)))
/* 180:    */               {
/* 181:195 */                 VarType firstMaxType = (VarType)mapExprentMaxTypes.get(firstPair);
/* 182:196 */                 VarType secondMaxType = (VarType)mapExprentMaxTypes.get(secondPair);
/* 183:197 */                 VarType type = secondMaxType == null ? firstMaxType : firstMaxType == null ? secondMaxType : VarType.getCommonMinType(firstMaxType, secondMaxType);
/* 184:    */                 
/* 185:    */ 
/* 186:    */ 
/* 187:201 */                 mapExprentMaxTypes.put(firstPair, type);
/* 188:202 */                 mapMergedVersions.put(secondPair, Integer.valueOf(firstPair.version));
/* 189:203 */                 mapExprentMaxTypes.remove(secondPair);
/* 190:204 */                 mapExprentMinTypes.remove(secondPair);
/* 191:206 */                 if (firstType.equals(VarType.VARTYPE_NULL))
/* 192:    */                 {
/* 193:207 */                   mapExprentMinTypes.put(firstPair, secondType);
/* 194:208 */                   firstType = secondType;
/* 195:    */                 }
/* 196:211 */                 typeProcessor.getMapFinalVars().put(firstPair, Integer.valueOf(1));
/* 197:    */                 
/* 198:213 */                 lstVersions.remove(j);
/* 199:    */                 
/* 200:215 */                 j--;
/* 201:    */               }
/* 202:    */             }
/* 203:    */           }
/* 204:    */         }
/* 205:    */       }
/* 206:    */     }
/* 207:222 */     if (!mapMergedVersions.isEmpty()) {
/* 208:223 */       updateVersions(graph, mapMergedVersions);
/* 209:    */     }
/* 210:    */   }
/* 211:    */   
/* 212:    */   private void setNewVarIndices(VarTypeProcessor typeProcessor, DirectGraph graph)
/* 213:    */   {
/* 214:228 */     final Map<VarVersionPair, VarType> mapExprentMaxTypes = typeProcessor.getMapExprentMaxTypes();
/* 215:229 */     Map<VarVersionPair, VarType> mapExprentMinTypes = typeProcessor.getMapExprentMinTypes();
/* 216:230 */     Map<VarVersionPair, Integer> mapFinalVars = typeProcessor.getMapFinalVars();
/* 217:    */     
/* 218:232 */     CounterContainer counters = DecompilerContext.getCounterContainer();
/* 219:    */     
/* 220:234 */     final Map<VarVersionPair, Integer> mapVarPaar = new HashMap();
/* 221:235 */     Map<Integer, Integer> mapOriginalVarIndices = new HashMap();
/* 222:    */     
/* 223:    */ 
/* 224:238 */     Set<VarVersionPair> set = new HashSet(mapExprentMinTypes.keySet());
/* 225:239 */     for (VarVersionPair pair : set) {
/* 226:241 */       if (pair.version >= 0)
/* 227:    */       {
/* 228:242 */         int newIndex = pair.version == 1 ? pair.var : counters.getCounterAndIncrement(2);
/* 229:    */         
/* 230:244 */         VarVersionPair newVar = new VarVersionPair(newIndex, 0);
/* 231:    */         
/* 232:246 */         mapExprentMinTypes.put(newVar, mapExprentMinTypes.get(pair));
/* 233:247 */         mapExprentMaxTypes.put(newVar, mapExprentMaxTypes.get(pair));
/* 234:249 */         if (mapFinalVars.containsKey(pair)) {
/* 235:250 */           mapFinalVars.put(newVar, mapFinalVars.remove(pair));
/* 236:    */         }
/* 237:253 */         mapVarPaar.put(pair, Integer.valueOf(newIndex));
/* 238:254 */         mapOriginalVarIndices.put(Integer.valueOf(newIndex), Integer.valueOf(pair.var));
/* 239:    */       }
/* 240:    */     }
/* 241:259 */     graph.iterateExprents(new DirectGraph.ExprentIterator()
/* 242:    */     {
/* 243:    */       public int processExprent(Exprent exprent)
/* 244:    */       {
/* 245:262 */         List<Exprent> lst = exprent.getAllExprents(true);
/* 246:263 */         lst.add(exprent);
/* 247:265 */         for (Exprent expr : lst) {
/* 248:266 */           if (expr.type == 12)
/* 249:    */           {
/* 250:267 */             VarExprent newVar = (VarExprent)expr;
/* 251:268 */             Integer newVarIndex = (Integer)mapVarPaar.get(new VarVersionPair(newVar));
/* 252:269 */             if (newVarIndex != null)
/* 253:    */             {
/* 254:270 */               newVar.setIndex(newVarIndex.intValue());
/* 255:271 */               newVar.setVersion(0);
/* 256:    */             }
/* 257:    */           }
/* 258:274 */           else if (expr.type == 3)
/* 259:    */           {
/* 260:275 */             VarType maxType = (VarType)mapExprentMaxTypes.get(new VarVersionPair(expr.id, -1));
/* 261:276 */             if ((maxType != null) && (maxType.equals(VarType.VARTYPE_CHAR))) {
/* 262:277 */               ((ConstExprent)expr).setConstType(maxType);
/* 263:    */             }
/* 264:    */           }
/* 265:    */         }
/* 266:282 */         return 0;
/* 267:    */       }
/* 268:285 */     });
/* 269:286 */     this.mapOriginalVarIndices = mapOriginalVarIndices;
/* 270:    */   }
/* 271:    */   
/* 272:    */   public VarType getVarType(VarVersionPair pair)
/* 273:    */   {
/* 274:290 */     return this.typeProcessor == null ? null : this.typeProcessor.getVarType(pair);
/* 275:    */   }
/* 276:    */   
/* 277:    */   public void setVarType(VarVersionPair pair, VarType type)
/* 278:    */   {
/* 279:294 */     this.typeProcessor.setVarType(pair, type);
/* 280:    */   }
/* 281:    */   
/* 282:    */   public int getVarFinal(VarVersionPair pair)
/* 283:    */   {
/* 284:298 */     int ret = 3;
/* 285:299 */     if (this.typeProcessor != null)
/* 286:    */     {
/* 287:300 */       Integer fin = (Integer)this.typeProcessor.getMapFinalVars().get(pair);
/* 288:301 */       ret = fin == null ? 3 : fin.intValue();
/* 289:    */     }
/* 290:304 */     return ret;
/* 291:    */   }
/* 292:    */   
/* 293:    */   public void setVarFinal(VarVersionPair pair, int finalType)
/* 294:    */   {
/* 295:308 */     this.typeProcessor.getMapFinalVars().put(pair, Integer.valueOf(finalType));
/* 296:    */   }
/* 297:    */   
/* 298:    */   public Map<Integer, Integer> getMapOriginalVarIndices()
/* 299:    */   {
/* 300:312 */     return this.mapOriginalVarIndices;
/* 301:    */   }
/* 302:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionsProcessor
 * JD-Core Version:    0.7.0.1
 */