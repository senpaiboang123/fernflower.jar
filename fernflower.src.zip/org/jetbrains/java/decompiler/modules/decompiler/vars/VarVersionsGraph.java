/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.vars;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.LinkedList;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.decompose.GenericDominatorEngine;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.decompose.IGraph;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.decompose.IGraphNode;
/*  14:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  15:    */ 
/*  16:    */ public class VarVersionsGraph
/*  17:    */ {
/*  18: 28 */   public int counter = 0;
/*  19: 30 */   public final VBStyleCollection<VarVersionNode, VarVersionPair> nodes = new VBStyleCollection();
/*  20:    */   private GenericDominatorEngine engine;
/*  21:    */   
/*  22:    */   public VarVersionNode createNode(VarVersionPair ver)
/*  23:    */   {
/*  24:    */     VarVersionNode node;
/*  25: 36 */     this.nodes.addWithKey(node = new VarVersionNode(ver.var, ver.version), ver);
/*  26: 37 */     return node;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void addNodes(Collection<VarVersionNode> colnodes, Collection<VarVersionPair> colpaars)
/*  30:    */   {
/*  31: 41 */     this.nodes.addAllWithKey(colnodes, colpaars);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public boolean isDominatorSet(VarVersionNode node, HashSet<VarVersionNode> domnodes)
/*  35:    */   {
/*  36: 46 */     if (domnodes.size() == 1) {
/*  37: 47 */       return this.engine.isDominator(node, (IGraphNode)domnodes.iterator().next());
/*  38:    */     }
/*  39: 51 */     HashSet<VarVersionNode> marked = new HashSet();
/*  40: 53 */     if (domnodes.contains(node)) {
/*  41: 54 */       return true;
/*  42:    */     }
/*  43: 57 */     LinkedList<VarVersionNode> lstNodes = new LinkedList();
/*  44: 58 */     lstNodes.add(node);
/*  45: 60 */     while (!lstNodes.isEmpty())
/*  46:    */     {
/*  47: 62 */       VarVersionNode nd = (VarVersionNode)lstNodes.remove(0);
/*  48: 63 */       if (!marked.contains(nd))
/*  49:    */       {
/*  50: 67 */         marked.add(nd);
/*  51: 70 */         if (nd.preds.isEmpty()) {
/*  52: 71 */           return false;
/*  53:    */         }
/*  54: 74 */         for (VarVersionEdge edge : nd.preds)
/*  55:    */         {
/*  56: 75 */           VarVersionNode pred = edge.source;
/*  57: 76 */           if ((!marked.contains(pred)) && (!domnodes.contains(pred))) {
/*  58: 77 */             lstNodes.add(pred);
/*  59:    */           }
/*  60:    */         }
/*  61:    */       }
/*  62:    */     }
/*  63: 83 */     return true;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void initDominators()
/*  67:    */   {
/*  68: 88 */     final HashSet<VarVersionNode> roots = new HashSet();
/*  69: 90 */     for (VarVersionNode node : this.nodes) {
/*  70: 91 */       if (node.preds.isEmpty()) {
/*  71: 92 */         roots.add(node);
/*  72:    */       }
/*  73:    */     }
/*  74: 96 */     this.engine = new GenericDominatorEngine(new IGraph()
/*  75:    */     {
/*  76:    */       public List<? extends IGraphNode> getReversePostOrderList()
/*  77:    */       {
/*  78: 98 */         return VarVersionsGraph.getReversedPostOrder(roots);
/*  79:    */       }
/*  80:    */       
/*  81:    */       public Set<? extends IGraphNode> getRoots()
/*  82:    */       {
/*  83:102 */         return new HashSet(roots);
/*  84:    */       }
/*  85:105 */     });
/*  86:106 */     this.engine.initialize();
/*  87:    */   }
/*  88:    */   
/*  89:    */   private static LinkedList<VarVersionNode> getReversedPostOrder(Collection<VarVersionNode> roots)
/*  90:    */   {
/*  91:111 */     LinkedList<VarVersionNode> lst = new LinkedList();
/*  92:112 */     HashSet<VarVersionNode> setVisited = new HashSet();
/*  93:114 */     for (VarVersionNode root : roots)
/*  94:    */     {
/*  95:116 */       LinkedList<VarVersionNode> lstTemp = new LinkedList();
/*  96:117 */       addToReversePostOrderListIterative(root, lstTemp, setVisited);
/*  97:    */       
/*  98:119 */       lst.addAll(lstTemp);
/*  99:    */     }
/* 100:122 */     return lst;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private static void addToReversePostOrderListIterative(VarVersionNode root, List<VarVersionNode> lst, HashSet<VarVersionNode> setVisited)
/* 104:    */   {
/* 105:127 */     HashMap<VarVersionNode, List<VarVersionEdge>> mapNodeSuccs = new HashMap();
/* 106:    */     
/* 107:129 */     LinkedList<VarVersionNode> stackNode = new LinkedList();
/* 108:130 */     LinkedList<Integer> stackIndex = new LinkedList();
/* 109:    */     
/* 110:132 */     stackNode.add(root);
/* 111:133 */     stackIndex.add(Integer.valueOf(0));
/* 112:135 */     while (!stackNode.isEmpty())
/* 113:    */     {
/* 114:137 */       VarVersionNode node = (VarVersionNode)stackNode.getLast();
/* 115:138 */       int index = ((Integer)stackIndex.removeLast()).intValue();
/* 116:    */       
/* 117:140 */       setVisited.add(node);
/* 118:    */       
/* 119:142 */       List<VarVersionEdge> lstSuccs = (List)mapNodeSuccs.get(node);
/* 120:143 */       if (lstSuccs == null) {
/* 121:144 */         mapNodeSuccs.put(node, lstSuccs = new ArrayList(node.succs));
/* 122:    */       }
/* 123:147 */       for (; index < lstSuccs.size(); index++)
/* 124:    */       {
/* 125:148 */         VarVersionNode succ = ((VarVersionEdge)lstSuccs.get(index)).dest;
/* 126:150 */         if (!setVisited.contains(succ))
/* 127:    */         {
/* 128:151 */           stackIndex.add(Integer.valueOf(index + 1));
/* 129:    */           
/* 130:153 */           stackNode.add(succ);
/* 131:154 */           stackIndex.add(Integer.valueOf(0));
/* 132:    */           
/* 133:156 */           break;
/* 134:    */         }
/* 135:    */       }
/* 136:160 */       if (index == lstSuccs.size())
/* 137:    */       {
/* 138:161 */         lst.add(0, node);
/* 139:    */         
/* 140:163 */         stackNode.removeLast();
/* 141:    */       }
/* 142:    */     }
/* 143:    */   }
/* 144:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionsGraph
 * JD-Core Version:    0.7.0.1
 */