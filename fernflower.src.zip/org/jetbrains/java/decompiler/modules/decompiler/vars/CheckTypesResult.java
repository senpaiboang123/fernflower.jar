/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.vars;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  6:   */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  7:   */ 
/*  8:   */ public class CheckTypesResult
/*  9:   */ {
/* 10:   */   private final List<ExprentTypePair> lstMaxTypeExprents;
/* 11:   */   private final List<ExprentTypePair> lstMinTypeExprents;
/* 12:   */   
/* 13:   */   public CheckTypesResult()
/* 14:   */   {
/* 15:26 */     this.lstMaxTypeExprents = new ArrayList();
/* 16:   */     
/* 17:28 */     this.lstMinTypeExprents = new ArrayList();
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void addMaxTypeExprent(Exprent exprent, VarType type)
/* 21:   */   {
/* 22:31 */     this.lstMaxTypeExprents.add(new ExprentTypePair(exprent, type, null));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void addMinTypeExprent(Exprent exprent, VarType type)
/* 26:   */   {
/* 27:35 */     this.lstMinTypeExprents.add(new ExprentTypePair(exprent, type, null));
/* 28:   */   }
/* 29:   */   
/* 30:   */   public List<ExprentTypePair> getLstMaxTypeExprents()
/* 31:   */   {
/* 32:39 */     return this.lstMaxTypeExprents;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public List<ExprentTypePair> getLstMinTypeExprents()
/* 36:   */   {
/* 37:43 */     return this.lstMinTypeExprents;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public static class ExprentTypePair
/* 41:   */   {
/* 42:   */     public final Exprent exprent;
/* 43:   */     public final VarType type;
/* 44:   */     public final VarType desttype;
/* 45:   */     
/* 46:   */     public ExprentTypePair(Exprent exprent, VarType type, VarType desttype)
/* 47:   */     {
/* 48:52 */       this.exprent = exprent;
/* 49:53 */       this.type = type;
/* 50:54 */       this.desttype = desttype;
/* 51:   */     }
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.vars.CheckTypesResult
 * JD-Core Version:    0.7.0.1
 */