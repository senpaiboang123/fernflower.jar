/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.List;
/*   6:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*   8:    */ 
/*   9:    */ public class EliminateLoopsHelper
/*  10:    */ {
/*  11:    */   private static boolean eliminateLoopsRec(Statement stat)
/*  12:    */   {
/*  13: 49 */     for (Statement st : stat.getStats()) {
/*  14: 50 */       if (eliminateLoopsRec(st)) {
/*  15: 51 */         return true;
/*  16:    */       }
/*  17:    */     }
/*  18: 55 */     if ((stat.type == 5) && (isLoopRedundant((DoStatement)stat))) {
/*  19: 56 */       return true;
/*  20:    */     }
/*  21: 59 */     return false;
/*  22:    */   }
/*  23:    */   
/*  24:    */   private static boolean isLoopRedundant(DoStatement loop)
/*  25:    */   {
/*  26: 64 */     if (loop.getLooptype() != 0) {
/*  27: 65 */       return false;
/*  28:    */     }
/*  29: 69 */     Statement parentloop = loop.getParent();
/*  30: 70 */     while ((parentloop != null) && (parentloop.type != 5)) {
/*  31: 71 */       parentloop = parentloop.getParent();
/*  32:    */     }
/*  33: 74 */     if ((parentloop == null) || (parentloop.getBasichead() != loop.getBasichead())) {
/*  34: 75 */       return false;
/*  35:    */     }
/*  36: 79 */     List<StatEdge> lstBreakEdges = new ArrayList();
/*  37: 80 */     for (StatEdge edge : loop.getLabelEdges()) {
/*  38: 81 */       if (edge.getType() == 4) {
/*  39: 82 */         lstBreakEdges.add(edge);
/*  40:    */       }
/*  41:    */     }
/*  42: 87 */     Statement loopcontent = loop.getFirst();
/*  43:    */     
/*  44: 89 */     boolean firstok = loopcontent.getAllSuccessorEdges().isEmpty();
/*  45: 90 */     if (!firstok)
/*  46:    */     {
/*  47: 91 */       StatEdge edge = (StatEdge)loopcontent.getAllSuccessorEdges().get(0);
/*  48: 92 */       firstok = (edge.closure == loop) && (edge.getType() == 4);
/*  49: 93 */       if (firstok) {
/*  50: 94 */         lstBreakEdges.remove(edge);
/*  51:    */       }
/*  52:    */     }
/*  53: 99 */     if (!lstBreakEdges.isEmpty()) {
/*  54:100 */       if (firstok)
/*  55:    */       {
/*  56:102 */         HashMap<Integer, Boolean> statLabeled = new HashMap();
/*  57:103 */         List<Statement> lstEdgeClosures = new ArrayList();
/*  58:105 */         for (StatEdge edge : lstBreakEdges)
/*  59:    */         {
/*  60:106 */           Statement minclosure = LowBreakHelper.getMinClosure(loopcontent, edge.getSource());
/*  61:107 */           lstEdgeClosures.add(minclosure);
/*  62:    */         }
/*  63:110 */         int precount = loop.isLabeled() ? 1 : 0;
/*  64:111 */         for (Statement st : lstEdgeClosures) {
/*  65:112 */           if (!statLabeled.containsKey(st.id))
/*  66:    */           {
/*  67:113 */             boolean btemp = st.isLabeled();
/*  68:114 */             precount += (btemp ? 1 : 0);
/*  69:115 */             statLabeled.put(st.id, Boolean.valueOf(btemp));
/*  70:    */           }
/*  71:    */         }
/*  72:119 */         for (int i = 0; i < lstBreakEdges.size(); i++)
/*  73:    */         {
/*  74:120 */           Statement st = (Statement)lstEdgeClosures.get(i);
/*  75:121 */           statLabeled.put(st.id, Boolean.valueOf(LowBreakHelper.isBreakEdgeLabeled(((StatEdge)lstBreakEdges.get(i)).getSource(), st) | ((Boolean)statLabeled.get(st.id)).booleanValue()));
/*  76:    */         }
/*  77:124 */         for (int i = 0; i < lstBreakEdges.size(); i++) {
/*  78:125 */           lstEdgeClosures.set(i, getMaxBreakLift((Statement)lstEdgeClosures.get(i), (StatEdge)lstBreakEdges.get(i), statLabeled, loop));
/*  79:    */         }
/*  80:128 */         statLabeled.clear();
/*  81:129 */         for (Statement st : lstEdgeClosures) {
/*  82:130 */           statLabeled.put(st.id, Boolean.valueOf(st.isLabeled()));
/*  83:    */         }
/*  84:133 */         for (int i = 0; i < lstBreakEdges.size(); i++)
/*  85:    */         {
/*  86:134 */           Statement st = (Statement)lstEdgeClosures.get(i);
/*  87:135 */           statLabeled.put(st.id, Boolean.valueOf(LowBreakHelper.isBreakEdgeLabeled(((StatEdge)lstBreakEdges.get(i)).getSource(), st) | ((Boolean)statLabeled.get(st.id)).booleanValue()));
/*  88:    */         }
/*  89:138 */         int postcount = 0;
/*  90:139 */         for (Boolean val : statLabeled.values()) {
/*  91:140 */           postcount += (val.booleanValue() ? 1 : 0);
/*  92:    */         }
/*  93:143 */         if (precount <= postcount) {
/*  94:144 */           return false;
/*  95:    */         }
/*  96:147 */         for (int i = 0; i < lstBreakEdges.size(); i++) {
/*  97:148 */           ((Statement)lstEdgeClosures.get(i)).addLabeledEdge((StatEdge)lstBreakEdges.get(i));
/*  98:    */         }
/*  99:    */       }
/* 100:    */       else
/* 101:    */       {
/* 102:153 */         return false;
/* 103:    */       }
/* 104:    */     }
/* 105:157 */     eliminateLoop(loop, parentloop);
/* 106:    */     
/* 107:159 */     return true;
/* 108:    */   }
/* 109:    */   
/* 110:    */   private static Statement getMaxBreakLift(Statement stat, StatEdge edge, HashMap<Integer, Boolean> statLabeled, Statement max)
/* 111:    */   {
/* 112:164 */     Statement closure = stat;
/* 113:165 */     Statement newclosure = stat;
/* 114:167 */     while ((newclosure = getNextBreakLift(newclosure, edge, statLabeled, max)) != null) {
/* 115:168 */       closure = newclosure;
/* 116:    */     }
/* 117:171 */     return closure;
/* 118:    */   }
/* 119:    */   
/* 120:    */   private static Statement getNextBreakLift(Statement stat, StatEdge edge, HashMap<Integer, Boolean> statLabeled, Statement max)
/* 121:    */   {
/* 122:176 */     Statement closure = stat.getParent();
/* 123:178 */     while ((closure != null) && (closure != max) && (!closure.containsStatementStrict(edge.getDestination())))
/* 124:    */     {
/* 125:180 */       boolean edge_labeled = LowBreakHelper.isBreakEdgeLabeled(edge.getSource(), closure);
/* 126:181 */       boolean stat_labeled = statLabeled.containsKey(closure.id) ? ((Boolean)statLabeled.get(closure.id)).booleanValue() : closure.isLabeled();
/* 127:183 */       if ((stat_labeled) || (!edge_labeled)) {
/* 128:184 */         return closure;
/* 129:    */       }
/* 130:187 */       closure = closure.getParent();
/* 131:    */     }
/* 132:190 */     return null;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static void eliminateLoop(Statement loop, Statement parentloop)
/* 136:    */   {
/* 137:196 */     List<StatEdge> lst = new ArrayList(loop.getLabelEdges());
/* 138:197 */     for (StatEdge edge : lst)
/* 139:    */     {
/* 140:198 */       loop.removePredecessor(edge);
/* 141:199 */       edge.getSource().changeEdgeNode(1, edge, parentloop);
/* 142:200 */       parentloop.addPredecessor(edge);
/* 143:    */       
/* 144:202 */       parentloop.addLabeledEdge(edge);
/* 145:    */     }
/* 146:206 */     Statement loopcontent = loop.getFirst();
/* 147:207 */     if (!loopcontent.getAllSuccessorEdges().isEmpty()) {
/* 148:208 */       loopcontent.removeSuccessor((StatEdge)loopcontent.getAllSuccessorEdges().get(0));
/* 149:    */     }
/* 150:212 */     loop.getParent().replaceStatement(loop, loopcontent);
/* 151:    */   }
/* 152:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.EliminateLoopsHelper
 * JD-Core Version:    0.7.0.1
 */