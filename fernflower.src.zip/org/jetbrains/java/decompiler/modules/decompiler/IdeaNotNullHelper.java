/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AnnotationExprent;
/*   5:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent;
/*   6:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.IfExprent;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  13:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  14:    */ import org.jetbrains.java.decompiler.struct.attr.StructAnnotationAttribute;
/*  15:    */ import org.jetbrains.java.decompiler.struct.attr.StructAnnotationParameterAttribute;
/*  16:    */ import org.jetbrains.java.decompiler.struct.attr.StructGeneralAttribute;
/*  17:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  18:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  19:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  20:    */ 
/*  21:    */ public class IdeaNotNullHelper
/*  22:    */ {
/*  23:    */   public static boolean removeHardcodedChecks(Statement root, StructMethod mt)
/*  24:    */   {
/*  25: 37 */     boolean checks_removed = false;
/*  26: 40 */     while (findAndRemoveParameterCheck(root, mt)) {
/*  27: 41 */       checks_removed = true;
/*  28:    */     }
/*  29: 45 */     while (findAndRemoveReturnCheck(root, mt)) {
/*  30: 46 */       checks_removed = true;
/*  31:    */     }
/*  32: 49 */     return checks_removed;
/*  33:    */   }
/*  34:    */   
/*  35:    */   private static boolean findAndRemoveParameterCheck(Statement stat, StructMethod mt)
/*  36:    */   {
/*  37: 54 */     Statement st = stat.getFirst();
/*  38: 55 */     while (st.type == 15) {
/*  39: 56 */       st = st.getFirst();
/*  40:    */     }
/*  41: 59 */     if (st.type == 2)
/*  42:    */     {
/*  43: 61 */       IfStatement ifstat = (IfStatement)st;
/*  44: 62 */       Statement ifbranch = ifstat.getIfstat();
/*  45:    */       
/*  46: 64 */       Exprent if_condition = ifstat.getHeadexprent().getCondition();
/*  47:    */       
/*  48: 66 */       boolean is_notnull_check = false;
/*  49: 69 */       if ((ifbranch != null) && (if_condition.type == 6) && (((FunctionExprent)if_condition).getFuncType() == 42) && (ifbranch.type == 8) && (ifbranch.getExprents().size() == 1) && (((Exprent)ifbranch.getExprents().get(0)).type == 4))
/*  50:    */       {
/*  51: 76 */         FunctionExprent func = (FunctionExprent)if_condition;
/*  52: 77 */         Exprent first_param = (Exprent)func.getLstOperands().get(0);
/*  53: 78 */         Exprent second_param = (Exprent)func.getLstOperands().get(1);
/*  54: 80 */         if ((second_param.type == 3) && (second_param.getExprType().type == 13)) {
/*  55: 82 */           if (first_param.type == 12)
/*  56:    */           {
/*  57: 83 */             VarExprent var = (VarExprent)first_param;
/*  58:    */             
/*  59: 85 */             boolean thisvar = !mt.hasModifier(8);
/*  60:    */             
/*  61: 87 */             MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/*  62: 88 */             VBStyleCollection<StructGeneralAttribute, String> attributes = mt.getAttributes();
/*  63:    */             
/*  64:    */ 
/*  65: 91 */             StructAnnotationParameterAttribute param_annotations = (StructAnnotationParameterAttribute)attributes.getWithKey("RuntimeInvisibleParameterAnnotations");
/*  66: 93 */             if (param_annotations != null)
/*  67:    */             {
/*  68: 95 */               List<List<AnnotationExprent>> param_annotations_lists = param_annotations.getParamAnnotations();
/*  69: 96 */               int method_param_number = md.params.length;
/*  70:    */               
/*  71: 98 */               int index = thisvar ? 1 : 0;
/*  72: 99 */               for (int i = 0; i < method_param_number; i++)
/*  73:    */               {
/*  74:101 */                 if (index == var.getIndex())
/*  75:    */                 {
/*  76:102 */                   if (param_annotations_lists.size() < method_param_number - i) {
/*  77:    */                     break;
/*  78:    */                   }
/*  79:103 */                   int shift = method_param_number - param_annotations_lists.size();
/*  80:    */                   
/*  81:    */ 
/*  82:    */ 
/*  83:107 */                   List<AnnotationExprent> annotations = (List)param_annotations_lists.get(i - shift);
/*  84:109 */                   for (AnnotationExprent ann : annotations) {
/*  85:110 */                     if (ann.getClassName().equals("org/jetbrains/annotations/NotNull")) {
/*  86:111 */                       is_notnull_check = true;
/*  87:    */                     }
/*  88:    */                   }
/*  89:114 */                   break;
/*  90:    */                 }
/*  91:119 */                 index += md.params[i].stackSize;
/*  92:    */               }
/*  93:    */             }
/*  94:    */           }
/*  95:    */         }
/*  96:    */       }
/*  97:126 */       if (!is_notnull_check) {
/*  98:127 */         return false;
/*  99:    */       }
/* 100:130 */       removeParameterCheck(stat, mt);
/* 101:    */       
/* 102:132 */       return true;
/* 103:    */     }
/* 104:135 */     return false;
/* 105:    */   }
/* 106:    */   
/* 107:    */   private static void removeParameterCheck(Statement stat, StructMethod mt)
/* 108:    */   {
/* 109:140 */     Statement st = stat.getFirst();
/* 110:141 */     while (st.type == 15) {
/* 111:142 */       st = st.getFirst();
/* 112:    */     }
/* 113:145 */     IfStatement ifstat = (IfStatement)st;
/* 114:147 */     if (ifstat.getElsestat() != null)
/* 115:    */     {
/* 116:152 */       StatEdge ifedge = ifstat.getIfEdge();
/* 117:153 */       StatEdge elseedge = ifstat.getElseEdge();
/* 118:    */       
/* 119:155 */       Statement ifbranch = ifstat.getIfstat();
/* 120:156 */       Statement elsebranch = ifstat.getElsestat();
/* 121:    */       
/* 122:158 */       ifstat.getFirst().removeSuccessor(ifedge);
/* 123:159 */       ifstat.getFirst().removeSuccessor(elseedge);
/* 124:    */       
/* 125:161 */       ifstat.getStats().removeWithKey(ifbranch.id);
/* 126:162 */       ifstat.getStats().removeWithKey(elsebranch.id);
/* 127:164 */       if (!ifbranch.getAllSuccessorEdges().isEmpty()) {
/* 128:165 */         ifbranch.removeSuccessor((StatEdge)ifbranch.getAllSuccessorEdges().get(0));
/* 129:    */       }
/* 130:168 */       ifstat.getParent().replaceStatement(ifstat, elsebranch);
/* 131:169 */       ifstat.getParent().setAllParent();
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static boolean findAndRemoveReturnCheck(Statement stat, StructMethod mt)
/* 136:    */   {
/* 137:175 */     VBStyleCollection<StructGeneralAttribute, String> attributes = mt.getAttributes();
/* 138:    */     
/* 139:177 */     boolean is_notnull_check = false;
/* 140:    */     
/* 141:    */ 
/* 142:180 */     StructAnnotationAttribute attr = (StructAnnotationAttribute)attributes.getWithKey("RuntimeInvisibleAnnotations");
/* 143:182 */     if (attr != null)
/* 144:    */     {
/* 145:183 */       List<AnnotationExprent> annotations = attr.getAnnotations();
/* 146:185 */       for (AnnotationExprent ann : annotations) {
/* 147:186 */         if (ann.getClassName().equals("org/jetbrains/annotations/NotNull")) {
/* 148:187 */           is_notnull_check = true;
/* 149:    */         }
/* 150:    */       }
/* 151:    */     }
/* 152:192 */     if (is_notnull_check) {
/* 153:193 */       return removeReturnCheck(stat, mt);
/* 154:    */     }
/* 155:196 */     return false;
/* 156:    */   }
/* 157:    */   
/* 158:    */   private static boolean removeReturnCheck(Statement stat, StructMethod mt)
/* 159:    */   {
/* 160:202 */     Statement parent = stat.getParent();
/* 161:204 */     if ((parent != null) && (parent.type == 2) && (stat.type == 8) && (stat.getExprents().size() == 1))
/* 162:    */     {
/* 163:205 */       Exprent exprent = (Exprent)stat.getExprents().get(0);
/* 164:206 */       if (exprent.type == 4)
/* 165:    */       {
/* 166:207 */         ExitExprent exit_exprent = (ExitExprent)exprent;
/* 167:208 */         if (exit_exprent.getExitType() == 0)
/* 168:    */         {
/* 169:209 */           Exprent exprent_value = exit_exprent.getValue();
/* 170:    */           
/* 171:    */ 
/* 172:    */ 
/* 173:213 */           IfStatement ifparent = (IfStatement)parent;
/* 174:214 */           Exprent if_condition = ifparent.getHeadexprent().getCondition();
/* 175:216 */           if ((ifparent.getElsestat() == stat) && (if_condition.type == 6) && (((FunctionExprent)if_condition).getFuncType() == 42))
/* 176:    */           {
/* 177:219 */             FunctionExprent func = (FunctionExprent)if_condition;
/* 178:220 */             Exprent first_param = (Exprent)func.getLstOperands().get(0);
/* 179:221 */             Exprent second_param = (Exprent)func.getLstOperands().get(1);
/* 180:    */             
/* 181:223 */             StatEdge ifedge = ifparent.getIfEdge();
/* 182:224 */             StatEdge elseedge = ifparent.getElseEdge();
/* 183:    */             
/* 184:226 */             Statement ifbranch = ifparent.getIfstat();
/* 185:227 */             Statement elsebranch = ifparent.getElsestat();
/* 186:229 */             if ((second_param.type == 3) && (second_param.getExprType().type == 13)) {
/* 187:232 */               if ((first_param.equals(exprent_value)) && 
/* 188:233 */                 (ifbranch.type == 8) && (ifbranch.getExprents().size() == 1) && (((Exprent)ifbranch.getExprents().get(0)).type == 4))
/* 189:    */               {
/* 190:238 */                 ifparent.getFirst().removeSuccessor(ifedge);
/* 191:239 */                 ifparent.getFirst().removeSuccessor(elseedge);
/* 192:    */                 
/* 193:241 */                 ifparent.getStats().removeWithKey(ifbranch.id);
/* 194:242 */                 ifparent.getStats().removeWithKey(elsebranch.id);
/* 195:244 */                 if (!ifbranch.getAllSuccessorEdges().isEmpty()) {
/* 196:245 */                   ifbranch.removeSuccessor((StatEdge)ifbranch.getAllSuccessorEdges().get(0));
/* 197:    */                 }
/* 198:248 */                 if (!ifparent.getFirst().getExprents().isEmpty()) {
/* 199:249 */                   elsebranch.getExprents().addAll(0, ifparent.getFirst().getExprents());
/* 200:    */                 }
/* 201:252 */                 ifparent.getParent().replaceStatement(ifparent, elsebranch);
/* 202:253 */                 ifparent.getParent().setAllParent();
/* 203:    */                 
/* 204:255 */                 return true;
/* 205:    */               }
/* 206:    */             }
/* 207:    */           }
/* 208:    */         }
/* 209:    */       }
/* 210:    */     }
/* 211:264 */     else if ((parent != null) && (parent.type == 15) && (stat.type == 8) && (stat.getExprents().size() == 1))
/* 212:    */     {
/* 213:268 */       Exprent exprent = (Exprent)stat.getExprents().get(0);
/* 214:269 */       if (exprent.type == 4)
/* 215:    */       {
/* 216:270 */         ExitExprent exit_exprent = (ExitExprent)exprent;
/* 217:271 */         if (exit_exprent.getExitType() == 0)
/* 218:    */         {
/* 219:272 */           Exprent exprent_value = exit_exprent.getValue();
/* 220:    */           
/* 221:274 */           SequenceStatement sequence = (SequenceStatement)parent;
/* 222:275 */           int sequence_stats_number = sequence.getStats().size();
/* 223:277 */           if ((sequence_stats_number > 1) && (sequence.getStats().getLast() == stat) && (((Statement)sequence.getStats().get(sequence_stats_number - 2)).type == 2))
/* 224:    */           {
/* 225:281 */             IfStatement ifstat = (IfStatement)sequence.getStats().get(sequence_stats_number - 2);
/* 226:282 */             Exprent if_condition = ifstat.getHeadexprent().getCondition();
/* 227:284 */             if ((ifstat.iftype == 0) && (if_condition.type == 6) && (((FunctionExprent)if_condition).getFuncType() == 42))
/* 228:    */             {
/* 229:287 */               FunctionExprent func = (FunctionExprent)if_condition;
/* 230:288 */               Exprent first_param = (Exprent)func.getLstOperands().get(0);
/* 231:289 */               Exprent second_param = (Exprent)func.getLstOperands().get(1);
/* 232:    */               
/* 233:291 */               Statement ifbranch = ifstat.getIfstat();
/* 234:293 */               if ((second_param.type == 3) && (second_param.getExprType().type == 13)) {
/* 235:295 */                 if ((first_param.equals(exprent_value)) && 
/* 236:296 */                   (ifbranch.type == 8) && (ifbranch.getExprents().size() == 1) && (((Exprent)ifbranch.getExprents().get(0)).type == 4))
/* 237:    */                 {
/* 238:301 */                   ifstat.removeSuccessor((StatEdge)ifstat.getAllSuccessorEdges().get(0));
/* 239:303 */                   if (!ifstat.getFirst().getExprents().isEmpty()) {
/* 240:304 */                     stat.getExprents().addAll(0, ifstat.getFirst().getExprents());
/* 241:    */                   }
/* 242:307 */                   for (StatEdge edge : ifstat.getAllPredecessorEdges())
/* 243:    */                   {
/* 244:309 */                     ifstat.removePredecessor(edge);
/* 245:310 */                     edge.getSource().changeEdgeNode(1, edge, stat);
/* 246:311 */                     stat.addPredecessor(edge);
/* 247:    */                   }
/* 248:314 */                   sequence.getStats().removeWithKey(ifstat.id);
/* 249:315 */                   sequence.setFirst((Statement)sequence.getStats().get(0));
/* 250:    */                   
/* 251:317 */                   return true;
/* 252:    */                 }
/* 253:    */               }
/* 254:    */             }
/* 255:    */           }
/* 256:    */         }
/* 257:    */       }
/* 258:    */     }
/* 259:328 */     for (Statement st : stat.getStats()) {
/* 260:329 */       if (removeReturnCheck(st, mt)) {
/* 261:330 */         return true;
/* 262:    */       }
/* 263:    */     }
/* 264:334 */     return false;
/* 265:    */   }
/* 266:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.IdeaNotNullHelper
 * JD-Core Version:    0.7.0.1
 */