/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*   8:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   9:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  13:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  14:    */ 
/*  15:    */ public class SequenceHelper
/*  16:    */ {
/*  17:    */   public static void condenseSequences(Statement root)
/*  18:    */   {
/*  19: 35 */     condenseSequencesRec(root);
/*  20:    */   }
/*  21:    */   
/*  22:    */   private static void condenseSequencesRec(Statement stat)
/*  23:    */   {
/*  24: 40 */     if (stat.type == 15)
/*  25:    */     {
/*  26: 42 */       List<Statement> lst = new ArrayList();
/*  27: 43 */       lst.addAll(stat.getStats());
/*  28:    */       
/*  29: 45 */       boolean unfolded = false;
/*  30: 48 */       for (int i = 0; i < lst.size(); i++)
/*  31:    */       {
/*  32: 49 */         Statement st = (Statement)lst.get(i);
/*  33: 50 */         if (st.type == 15)
/*  34:    */         {
/*  35: 52 */           removeEmptyStatements((SequenceStatement)st);
/*  36: 54 */           if ((i == lst.size() - 1) || (isSequenceDisbandable(st, (Statement)lst.get(i + 1))))
/*  37:    */           {
/*  38: 56 */             Statement first = st.getFirst();
/*  39: 57 */             for (StatEdge edge : st.getAllPredecessorEdges())
/*  40:    */             {
/*  41: 58 */               st.removePredecessor(edge);
/*  42: 59 */               edge.getSource().changeEdgeNode(1, edge, first);
/*  43: 60 */               first.addPredecessor(edge);
/*  44:    */             }
/*  45: 64 */             Statement last = (Statement)st.getStats().getLast();
/*  46: 65 */             if ((last.getAllSuccessorEdges().isEmpty()) && (i < lst.size() - 1)) {
/*  47: 66 */               last.addSuccessor(new StatEdge(1, last, (Statement)lst.get(i + 1)));
/*  48:    */             } else {
/*  49: 69 */               for (StatEdge edge : last.getAllSuccessorEdges()) {
/*  50: 70 */                 if (i == lst.size() - 1)
/*  51:    */                 {
/*  52: 71 */                   if (edge.closure == st) {
/*  53: 72 */                     stat.addLabeledEdge(edge);
/*  54:    */                   }
/*  55:    */                 }
/*  56:    */                 else
/*  57:    */                 {
/*  58: 76 */                   edge.getSource().changeEdgeType(1, edge, 1);
/*  59: 77 */                   edge.closure.getLabelEdges().remove(edge);
/*  60: 78 */                   edge.closure = null;
/*  61:    */                 }
/*  62:    */               }
/*  63:    */             }
/*  64: 83 */             for (StatEdge edge : st.getAllSuccessorEdges()) {
/*  65: 84 */               st.removeSuccessor(edge);
/*  66:    */             }
/*  67: 87 */             for (StatEdge edge : new HashSet(st.getLabelEdges())) {
/*  68: 88 */               if (edge.getSource() != last) {
/*  69: 89 */                 last.addLabeledEdge(edge);
/*  70:    */               }
/*  71:    */             }
/*  72: 93 */             lst.remove(i);
/*  73: 94 */             lst.addAll(i, st.getStats());
/*  74: 95 */             i--;
/*  75:    */             
/*  76: 97 */             unfolded = true;
/*  77:    */           }
/*  78:    */         }
/*  79:    */       }
/*  80:102 */       if (unfolded)
/*  81:    */       {
/*  82:103 */         SequenceStatement sequence = new SequenceStatement(lst);
/*  83:104 */         sequence.setAllParent();
/*  84:    */         
/*  85:106 */         stat.getParent().replaceStatement(stat, sequence);
/*  86:    */         
/*  87:108 */         stat = sequence;
/*  88:    */       }
/*  89:    */     }
/*  90:113 */     if (stat.type == 15)
/*  91:    */     {
/*  92:115 */       removeEmptyStatements((SequenceStatement)stat);
/*  93:117 */       if (stat.getStats().size() == 1)
/*  94:    */       {
/*  95:119 */         Statement st = stat.getFirst();
/*  96:    */         
/*  97:121 */         boolean ok = st.getAllSuccessorEdges().isEmpty();
/*  98:122 */         if (!ok)
/*  99:    */         {
/* 100:123 */           StatEdge edge = (StatEdge)st.getAllSuccessorEdges().get(0);
/* 101:    */           
/* 102:125 */           ok = stat.getAllSuccessorEdges().isEmpty();
/* 103:126 */           if (!ok)
/* 104:    */           {
/* 105:127 */             StatEdge statedge = (StatEdge)stat.getAllSuccessorEdges().get(0);
/* 106:128 */             ok = edge.getDestination() == statedge.getDestination();
/* 107:130 */             if (ok) {
/* 108:131 */               st.removeSuccessor(edge);
/* 109:    */             }
/* 110:    */           }
/* 111:    */         }
/* 112:136 */         if (ok)
/* 113:    */         {
/* 114:137 */           stat.getParent().replaceStatement(stat, st);
/* 115:138 */           stat = st;
/* 116:    */         }
/* 117:    */       }
/* 118:    */     }
/* 119:146 */     Iterator i$ = stat.getStats().iterator();
/* 120:    */     for (;;)
/* 121:    */     {
/* 122:146 */       if (!i$.hasNext()) {
/* 123:    */         break label700;
/* 124:    */       }
/* 125:146 */       Statement st = (Statement)i$.next();
/* 126:147 */       if (((st.getStats().isEmpty()) || (st.getExprents() != null)) && (st.type != 8))
/* 127:    */       {
/* 128:148 */         destroyAndFlattenStatement(st);
/* 129:149 */         break;
/* 130:    */       }
/* 131:    */     }
/* 132:    */     label700:
/* 133:156 */     for (int i = 0; i < stat.getStats().size(); i++) {
/* 134:157 */       condenseSequencesRec((Statement)stat.getStats().get(i));
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   private static boolean isSequenceDisbandable(Statement block, Statement next)
/* 139:    */   {
/* 140:163 */     Statement last = (Statement)block.getStats().getLast();
/* 141:164 */     List<StatEdge> lstSuccs = last.getAllSuccessorEdges();
/* 142:165 */     if ((!lstSuccs.isEmpty()) && 
/* 143:166 */       (((StatEdge)lstSuccs.get(0)).getDestination() != next)) {
/* 144:167 */       return false;
/* 145:    */     }
/* 146:171 */     for (StatEdge edge : next.getPredecessorEdges(4)) {
/* 147:172 */       if ((last != edge.getSource()) && (!last.containsStatementStrict(edge.getSource()))) {
/* 148:173 */         return false;
/* 149:    */       }
/* 150:    */     }
/* 151:177 */     return true;
/* 152:    */   }
/* 153:    */   
/* 154:    */   private static void removeEmptyStatements(SequenceStatement sequence)
/* 155:    */   {
/* 156:182 */     if (sequence.getStats().size() <= 1) {
/* 157:183 */       return;
/* 158:    */     }
/* 159:186 */     mergeFlatStatements(sequence);
/* 160:    */     for (;;)
/* 161:    */     {
/* 162:190 */       boolean found = false;
/* 163:192 */       for (Statement st : sequence.getStats()) {
/* 164:194 */         if ((st.getExprents() != null) && (st.getExprents().isEmpty()))
/* 165:    */         {
/* 166:196 */           if (st.getAllSuccessorEdges().isEmpty())
/* 167:    */           {
/* 168:197 */             List<StatEdge> lstBreaks = st.getPredecessorEdges(4);
/* 169:199 */             if (lstBreaks.isEmpty())
/* 170:    */             {
/* 171:200 */               for (StatEdge edge : st.getAllPredecessorEdges()) {
/* 172:201 */                 edge.getSource().removeSuccessor(edge);
/* 173:    */               }
/* 174:203 */               found = true;
/* 175:    */             }
/* 176:    */           }
/* 177:    */           else
/* 178:    */           {
/* 179:207 */             StatEdge sucedge = (StatEdge)st.getAllSuccessorEdges().get(0);
/* 180:208 */             if (sucedge.getType() != 32)
/* 181:    */             {
/* 182:209 */               st.removeSuccessor(sucedge);
/* 183:211 */               for (StatEdge edge : st.getAllPredecessorEdges())
/* 184:    */               {
/* 185:212 */                 if (sucedge.getType() != 1) {
/* 186:213 */                   edge.getSource().changeEdgeType(1, edge, sucedge.getType());
/* 187:    */                 }
/* 188:216 */                 st.removePredecessor(edge);
/* 189:217 */                 edge.getSource().changeEdgeNode(1, edge, sucedge.getDestination());
/* 190:218 */                 sucedge.getDestination().addPredecessor(edge);
/* 191:220 */                 if (sucedge.closure != null) {
/* 192:221 */                   sucedge.closure.addLabeledEdge(edge);
/* 193:    */                 }
/* 194:    */               }
/* 195:224 */               found = true;
/* 196:    */             }
/* 197:    */           }
/* 198:228 */           if (found)
/* 199:    */           {
/* 200:229 */             sequence.getStats().removeWithKey(st.id);
/* 201:230 */             break;
/* 202:    */           }
/* 203:    */         }
/* 204:    */       }
/* 205:235 */       if (!found) {
/* 206:    */         break;
/* 207:    */       }
/* 208:    */     }
/* 209:240 */     sequence.setFirst((Statement)sequence.getStats().get(0));
/* 210:    */   }
/* 211:    */   
/* 212:    */   private static void mergeFlatStatements(SequenceStatement sequence)
/* 213:    */   {
/* 214:    */     for (;;)
/* 215:    */     {
/* 216:248 */       Statement current = null;
/* 217:    */       
/* 218:250 */       boolean found = false;
/* 219:252 */       for (int i = sequence.getStats().size() - 1; i >= 0; i--)
/* 220:    */       {
/* 221:254 */         Statement next = current;
/* 222:255 */         current = (Statement)sequence.getStats().get(i);
/* 223:257 */         if ((next != null) && (current.getExprents() != null) && (!current.getExprents().isEmpty())) {
/* 224:258 */           if (next.getExprents() != null)
/* 225:    */           {
/* 226:259 */             next.getExprents().addAll(0, current.getExprents());
/* 227:260 */             current.getExprents().clear();
/* 228:261 */             found = true;
/* 229:    */           }
/* 230:    */           else
/* 231:    */           {
/* 232:264 */             Statement first = getFirstExprentlist(next);
/* 233:265 */             if (first != null)
/* 234:    */             {
/* 235:266 */               first.getExprents().addAll(0, current.getExprents());
/* 236:267 */               current.getExprents().clear();
/* 237:268 */               found = true;
/* 238:    */             }
/* 239:    */           }
/* 240:    */         }
/* 241:    */       }
/* 242:274 */       if (!found) {
/* 243:    */         break;
/* 244:    */       }
/* 245:    */     }
/* 246:    */   }
/* 247:    */   
/* 248:    */   private static Statement getFirstExprentlist(Statement stat)
/* 249:    */   {
/* 250:282 */     if (stat.getExprents() != null) {
/* 251:283 */       return stat;
/* 252:    */     }
/* 253:286 */     switch (stat.type)
/* 254:    */     {
/* 255:    */     case 2: 
/* 256:    */     case 6: 
/* 257:    */     case 10: 
/* 258:    */     case 15: 
/* 259:291 */       return getFirstExprentlist(stat.getFirst());
/* 260:    */     }
/* 261:294 */     return null;
/* 262:    */   }
/* 263:    */   
/* 264:    */   public static void destroyAndFlattenStatement(Statement stat)
/* 265:    */   {
/* 266:300 */     destroyStatementContent(stat, false);
/* 267:    */     
/* 268:302 */     BasicBlockStatement bstat = new BasicBlockStatement(new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0)));
/* 269:304 */     if (stat.getExprents() == null) {
/* 270:305 */       bstat.setExprents(new ArrayList());
/* 271:    */     } else {
/* 272:308 */       bstat.setExprents(DecHelper.copyExprentList(stat.getExprents()));
/* 273:    */     }
/* 274:311 */     stat.getParent().replaceStatement(stat, bstat);
/* 275:    */   }
/* 276:    */   
/* 277:    */   public static void destroyStatementContent(Statement stat, boolean self)
/* 278:    */   {
/* 279:316 */     for (Statement st : stat.getStats()) {
/* 280:317 */       destroyStatementContent(st, true);
/* 281:    */     }
/* 282:319 */     stat.getStats().clear();
/* 283:321 */     if (self) {
/* 284:322 */       for (StatEdge edge : stat.getAllSuccessorEdges()) {
/* 285:323 */         stat.removeSuccessor(edge);
/* 286:    */       }
/* 287:    */     }
/* 288:    */   }
/* 289:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.SequenceHelper
 * JD-Core Version:    0.7.0.1
 */