/*    1:     */ package org.jetbrains.java.decompiler.modules.decompiler;
/*    2:     */ 
/*    3:     */ import java.util.ArrayList;
/*    4:     */ import java.util.HashMap;
/*    5:     */ import java.util.HashSet;
/*    6:     */ import java.util.Iterator;
/*    7:     */ import java.util.LinkedList;
/*    8:     */ import java.util.List;
/*    9:     */ import java.util.Map;
/*   10:     */ import java.util.Map.Entry;
/*   11:     */ import java.util.Set;
/*   12:     */ import org.jetbrains.java.decompiler.code.ConstantsUtil;
/*   13:     */ import org.jetbrains.java.decompiler.code.Instruction;
/*   14:     */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*   15:     */ import org.jetbrains.java.decompiler.code.SimpleInstructionSequence;
/*   16:     */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*   17:     */ import org.jetbrains.java.decompiler.code.cfg.ControlFlowGraph;
/*   18:     */ import org.jetbrains.java.decompiler.code.cfg.ExceptionRangeCFG;
/*   19:     */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   20:     */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*   21:     */ import org.jetbrains.java.decompiler.modules.code.DeadCodeHelper;
/*   22:     */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*   23:     */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent;
/*   24:     */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*   25:     */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*   26:     */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*   27:     */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectNode;
/*   28:     */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.FlattenStatementsHelper;
/*   29:     */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAConstructorSparseEx;
/*   30:     */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*   31:     */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchAllStatement;
/*   32:     */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*   33:     */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*   34:     */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*   35:     */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*   36:     */ import org.jetbrains.java.decompiler.struct.StructClass;
/*   37:     */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*   38:     */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*   39:     */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*   40:     */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*   41:     */ 
/*   42:     */ public class FinallyProcessor
/*   43:     */ {
/*   44:  49 */   private final Map<Integer, Integer> finallyBlockIDs = new HashMap();
/*   45:  50 */   private final Map<Integer, Integer> catchallBlockIDs = new HashMap();
/*   46:     */   private final VarProcessor varprocessor;
/*   47:     */   
/*   48:     */   public FinallyProcessor(VarProcessor varprocessor)
/*   49:     */   {
/*   50:  55 */     this.varprocessor = varprocessor;
/*   51:     */   }
/*   52:     */   
/*   53:     */   public boolean iterateGraph(StructMethod mt, RootStatement root, ControlFlowGraph graph)
/*   54:     */   {
/*   55:  60 */     return processStatementEx(mt, root, graph);
/*   56:     */   }
/*   57:     */   
/*   58:     */   private boolean processStatementEx(StructMethod mt, RootStatement root, ControlFlowGraph graph)
/*   59:     */   {
/*   60:  65 */     int bytecode_version = mt.getClassStruct().getBytecodeVersion();
/*   61:     */     
/*   62:  67 */     LinkedList<Statement> stack = new LinkedList();
/*   63:  68 */     stack.add(root);
/*   64:  70 */     while (!stack.isEmpty())
/*   65:     */     {
/*   66:  72 */       Statement stat = (Statement)stack.removeLast();
/*   67:     */       
/*   68:  74 */       Statement parent = stat.getParent();
/*   69:  75 */       if ((parent != null) && (parent.type == 12) && (stat == parent.getFirst()) && (!parent.isCopied()))
/*   70:     */       {
/*   71:  78 */         CatchAllStatement fin = (CatchAllStatement)parent;
/*   72:  79 */         BasicBlock head = fin.getBasichead().getBlock();
/*   73:  80 */         BasicBlock handler = fin.getHandler().getBasichead().getBlock();
/*   74:  82 */         if (!this.catchallBlockIDs.containsKey(Integer.valueOf(handler.id))) {
/*   75:  85 */           if (this.finallyBlockIDs.containsKey(Integer.valueOf(handler.id)))
/*   76:     */           {
/*   77:  87 */             fin.setFinally(true);
/*   78:     */             
/*   79:  89 */             Integer var = (Integer)this.finallyBlockIDs.get(Integer.valueOf(handler.id));
/*   80:  90 */             fin.setMonitor(var == null ? null : new VarExprent(var.intValue(), VarType.VARTYPE_INT, this.varprocessor));
/*   81:     */           }
/*   82:     */           else
/*   83:     */           {
/*   84:  94 */             Record inf = getFinallyInformation(mt, root, fin);
/*   85:  96 */             if (inf == null)
/*   86:     */             {
/*   87:  97 */               this.catchallBlockIDs.put(Integer.valueOf(handler.id), null);
/*   88:     */             }
/*   89:     */             else
/*   90:     */             {
/*   91: 101 */               if ((DecompilerContext.getOption("fdi")) && (verifyFinallyEx(graph, fin, inf)))
/*   92:     */               {
/*   93: 102 */                 this.finallyBlockIDs.put(Integer.valueOf(handler.id), null);
/*   94:     */               }
/*   95:     */               else
/*   96:     */               {
/*   97: 106 */                 int varindex = DecompilerContext.getCounterContainer().getCounterAndIncrement(2);
/*   98: 107 */                 insertSemaphore(graph, getAllBasicBlocks(fin.getFirst()), head, handler, varindex, inf, bytecode_version);
/*   99:     */                 
/*  100: 109 */                 this.finallyBlockIDs.put(Integer.valueOf(handler.id), Integer.valueOf(varindex));
/*  101:     */               }
/*  102: 112 */               DeadCodeHelper.removeDeadBlocks(graph);
/*  103: 113 */               DeadCodeHelper.removeEmptyBlocks(graph);
/*  104: 114 */               DeadCodeHelper.mergeBasicBlocks(graph);
/*  105:     */             }
/*  106: 117 */             return true;
/*  107:     */           }
/*  108:     */         }
/*  109:     */       }
/*  110: 121 */       stack.addAll(stat.getStats());
/*  111:     */     }
/*  112: 124 */     return false;
/*  113:     */   }
/*  114:     */   
/*  115:     */   private static class Record
/*  116:     */   {
/*  117:     */     private final int firstCode;
/*  118:     */     private final Map<BasicBlock, Boolean> mapLast;
/*  119:     */     
/*  120:     */     private Record(int firstCode, Map<BasicBlock, Boolean> mapLast)
/*  121:     */     {
/*  122: 188 */       this.firstCode = firstCode;
/*  123: 189 */       this.mapLast = mapLast;
/*  124:     */     }
/*  125:     */   }
/*  126:     */   
/*  127:     */   private static Record getFinallyInformation(StructMethod mt, RootStatement root, CatchAllStatement fstat)
/*  128:     */   {
/*  129: 196 */     Map<BasicBlock, Boolean> mapLast = new HashMap();
/*  130:     */     
/*  131: 198 */     BasicBlockStatement firstBlockStatement = fstat.getHandler().getBasichead();
/*  132: 199 */     BasicBlock firstBasicBlock = firstBlockStatement.getBlock();
/*  133: 200 */     Instruction instrFirst = firstBasicBlock.getInstruction(0);
/*  134:     */     
/*  135: 202 */     int firstcode = 0;
/*  136: 204 */     switch (instrFirst.opcode)
/*  137:     */     {
/*  138:     */     case 87: 
/*  139: 206 */       firstcode = 1;
/*  140: 207 */       break;
/*  141:     */     case 58: 
/*  142: 209 */       firstcode = 2;
/*  143:     */     }
/*  144: 212 */     ExprProcessor proc = new ExprProcessor();
/*  145: 213 */     proc.processStatement(root, mt.getClassStruct());
/*  146:     */     
/*  147: 215 */     SSAConstructorSparseEx ssa = new SSAConstructorSparseEx();
/*  148: 216 */     ssa.splitVariables(root, mt);
/*  149:     */     
/*  150: 218 */     List<Exprent> lstExprents = firstBlockStatement.getExprents();
/*  151:     */     
/*  152: 220 */     VarVersionPair varpaar = new VarVersionPair((VarExprent)((AssignmentExprent)lstExprents.get(firstcode == 2 ? 1 : 0)).getLeft());
/*  153:     */     
/*  154: 222 */     FlattenStatementsHelper flatthelper = new FlattenStatementsHelper();
/*  155: 223 */     DirectGraph dgraph = flatthelper.buildDirectGraph(root);
/*  156:     */     
/*  157: 225 */     LinkedList<DirectNode> stack = new LinkedList();
/*  158: 226 */     stack.add(dgraph.first);
/*  159:     */     
/*  160: 228 */     Set<DirectNode> setVisited = new HashSet();
/*  161: 230 */     while (!stack.isEmpty())
/*  162:     */     {
/*  163: 232 */       DirectNode node = (DirectNode)stack.removeFirst();
/*  164: 234 */       if (!setVisited.contains(node))
/*  165:     */       {
/*  166: 237 */         setVisited.add(node);
/*  167:     */         
/*  168: 239 */         BasicBlockStatement blockStatement = null;
/*  169: 240 */         if (node.block != null) {
/*  170: 241 */           blockStatement = node.block;
/*  171: 243 */         } else if (node.preds.size() == 1) {
/*  172: 244 */           blockStatement = ((DirectNode)node.preds.get(0)).block;
/*  173:     */         }
/*  174: 247 */         boolean isTrueExit = true;
/*  175: 249 */         if (firstcode != 1)
/*  176:     */         {
/*  177: 251 */           isTrueExit = false;
/*  178: 253 */           for (int i = 0; i < node.exprents.size(); i++)
/*  179:     */           {
/*  180: 254 */             Exprent exprent = (Exprent)node.exprents.get(i);
/*  181: 256 */             if (firstcode == 0)
/*  182:     */             {
/*  183: 257 */               List<Exprent> lst = exprent.getAllExprents();
/*  184: 258 */               lst.add(exprent);
/*  185:     */               
/*  186: 260 */               boolean found = false;
/*  187: 261 */               for (Exprent expr : lst) {
/*  188: 262 */                 if ((expr.type == 12) && (new VarVersionPair((VarExprent)expr).equals(varpaar)))
/*  189:     */                 {
/*  190: 263 */                   found = true;
/*  191: 264 */                   break;
/*  192:     */                 }
/*  193:     */               }
/*  194: 268 */               if (found)
/*  195:     */               {
/*  196: 269 */                 found = false;
/*  197: 270 */                 if (exprent.type == 4)
/*  198:     */                 {
/*  199: 271 */                   ExitExprent exexpr = (ExitExprent)exprent;
/*  200: 272 */                   if ((exexpr.getExitType() == 1) && (exexpr.getValue().type == 12)) {
/*  201: 273 */                     found = true;
/*  202:     */                   }
/*  203:     */                 }
/*  204: 277 */                 if (!found) {
/*  205: 278 */                   return null;
/*  206:     */                 }
/*  207: 281 */                 isTrueExit = true;
/*  208:     */               }
/*  209:     */             }
/*  210: 285 */             else if (firstcode == 2)
/*  211:     */             {
/*  212: 287 */               if (exprent.type == 2)
/*  213:     */               {
/*  214: 288 */                 AssignmentExprent assexpr = (AssignmentExprent)exprent;
/*  215: 289 */                 if ((assexpr.getRight().type == 12) && (new VarVersionPair((VarExprent)assexpr.getRight()).equals(varpaar)))
/*  216:     */                 {
/*  217: 292 */                   Exprent next = null;
/*  218: 293 */                   if (i == node.exprents.size() - 1)
/*  219:     */                   {
/*  220: 294 */                     if (node.succs.size() == 1)
/*  221:     */                     {
/*  222: 295 */                       DirectNode nd = (DirectNode)node.succs.get(0);
/*  223: 296 */                       if (!nd.exprents.isEmpty()) {
/*  224: 297 */                         next = (Exprent)nd.exprents.get(0);
/*  225:     */                       }
/*  226:     */                     }
/*  227:     */                   }
/*  228:     */                   else {
/*  229: 302 */                     next = (Exprent)node.exprents.get(i + 1);
/*  230:     */                   }
/*  231: 305 */                   boolean found = false;
/*  232: 306 */                   if ((next != null) && (next.type == 4))
/*  233:     */                   {
/*  234: 307 */                     ExitExprent exexpr = (ExitExprent)next;
/*  235: 308 */                     if ((exexpr.getExitType() == 1) && (exexpr.getValue().type == 12) && (assexpr.getLeft().equals(exexpr.getValue()))) {
/*  236: 310 */                       found = true;
/*  237:     */                     }
/*  238:     */                   }
/*  239: 314 */                   if (!found) {
/*  240: 315 */                     return null;
/*  241:     */                   }
/*  242: 318 */                   isTrueExit = true;
/*  243:     */                 }
/*  244:     */               }
/*  245:     */             }
/*  246:     */           }
/*  247:     */         }
/*  248:     */         Statement handler;
/*  249: 327 */         if ((blockStatement != null) && (blockStatement.getBlock() != null))
/*  250:     */         {
/*  251: 328 */           handler = fstat.getHandler();
/*  252: 329 */           for (StatEdge edge : blockStatement.getSuccessorEdges(1073741824)) {
/*  253: 330 */             if ((edge.getType() != 1) && (handler.containsStatement(blockStatement)) && (!handler.containsStatement(edge.getDestination())))
/*  254:     */             {
/*  255: 332 */               Boolean existingFlag = (Boolean)mapLast.get(blockStatement.getBlock());
/*  256: 334 */               if ((existingFlag == null) || (!existingFlag.booleanValue()))
/*  257:     */               {
/*  258: 335 */                 mapLast.put(blockStatement.getBlock(), Boolean.valueOf(isTrueExit));
/*  259: 336 */                 break;
/*  260:     */               }
/*  261:     */             }
/*  262:     */           }
/*  263:     */         }
/*  264: 342 */         stack.addAll(node.succs);
/*  265:     */       }
/*  266:     */     }
/*  267: 346 */     if (fstat.getHandler().type == 8)
/*  268:     */     {
/*  269: 348 */       boolean isEmpty = false;
/*  270: 349 */       boolean isFirstLast = mapLast.containsKey(firstBasicBlock);
/*  271: 350 */       InstructionSequence seq = firstBasicBlock.getSeq();
/*  272: 352 */       switch (firstcode)
/*  273:     */       {
/*  274:     */       case 0: 
/*  275: 354 */         isEmpty = (isFirstLast) && (seq.length() == 1);
/*  276: 355 */         break;
/*  277:     */       case 1: 
/*  278: 357 */         isEmpty = seq.length() == 1;
/*  279: 358 */         break;
/*  280:     */       case 2: 
/*  281: 360 */         isEmpty = seq.length() == 3;
/*  282:     */       }
/*  283: 363 */       if (isEmpty) {
/*  284: 364 */         firstcode = 3;
/*  285:     */       }
/*  286:     */     }
/*  287: 368 */     return new Record(firstcode, mapLast, null);
/*  288:     */   }
/*  289:     */   
/*  290:     */   private static void insertSemaphore(ControlFlowGraph graph, Set<BasicBlock> setTry, BasicBlock head, BasicBlock handler, int var, Record information, int bytecode_version)
/*  291:     */   {
/*  292: 379 */     Set<BasicBlock> setCopy = new HashSet(setTry);
/*  293:     */     
/*  294: 381 */     int finallytype = information.firstCode;
/*  295: 382 */     Map<BasicBlock, Boolean> mapLast = information.mapLast;
/*  296:     */     
/*  297:     */ 
/*  298: 385 */     removeExceptionInstructionsEx(handler, 1, finallytype);
/*  299: 386 */     for (Map.Entry<BasicBlock, Boolean> entry : mapLast.entrySet())
/*  300:     */     {
/*  301: 387 */       BasicBlock last = (BasicBlock)entry.getKey();
/*  302: 389 */       if (((Boolean)entry.getValue()).booleanValue())
/*  303:     */       {
/*  304: 390 */         removeExceptionInstructionsEx(last, 2, finallytype);
/*  305: 391 */         graph.getFinallyExits().add(last);
/*  306:     */       }
/*  307:     */     }
/*  308: 396 */     for (Iterator i$ = setTry.iterator(); i$.hasNext();)
/*  309:     */     {
/*  310: 396 */       block = (BasicBlock)i$.next();
/*  311:     */       
/*  312: 398 */       List<BasicBlock> lstSucc = block.getSuccs();
/*  313: 399 */       for (BasicBlock dest : lstSucc) {
/*  314: 402 */         if ((!setCopy.contains(dest)) && (dest != graph.getLast()))
/*  315:     */         {
/*  316: 404 */           SimpleInstructionSequence seq = new SimpleInstructionSequence();
/*  317:     */           
/*  318: 406 */           seq.addInstruction(ConstantsUtil.getInstructionInstance(16, false, 1, bytecode_version, new int[] { 0 }), -1);
/*  319:     */           
/*  320:     */ 
/*  321: 409 */           seq.addInstruction(ConstantsUtil.getInstructionInstance(54, false, 1, bytecode_version, new int[] { var }), -1);
/*  322:     */           
/*  323:     */ 
/*  324:     */ 
/*  325:     */ 
/*  326: 414 */           BasicBlock newblock = new BasicBlock(++graph.last_id);
/*  327: 415 */           newblock.setSeq(seq);
/*  328:     */           
/*  329:     */ 
/*  330: 418 */           block.replaceSuccessor(dest, newblock);
/*  331: 419 */           newblock.addSuccessor(dest);
/*  332: 420 */           setCopy.add(newblock);
/*  333: 421 */           graph.getBlocks().addWithKey(newblock, Integer.valueOf(newblock.id));
/*  334: 427 */           for (int j = 0; j < block.getSuccExceptions().size(); j++)
/*  335:     */           {
/*  336: 428 */             BasicBlock hd = (BasicBlock)block.getSuccExceptions().get(j);
/*  337: 429 */             newblock.addSuccessorException(hd);
/*  338:     */             
/*  339: 431 */             ExceptionRangeCFG range = graph.getExceptionRange(hd, block);
/*  340: 432 */             range.getProtectedRange().add(newblock);
/*  341:     */           }
/*  342:     */         }
/*  343:     */       }
/*  344:     */     }
/*  345:     */     BasicBlock block;
/*  346: 439 */     SimpleInstructionSequence seq = new SimpleInstructionSequence();
/*  347: 440 */     seq.addInstruction(ConstantsUtil.getInstructionInstance(16, false, 1, bytecode_version, new int[] { 1 }), -1);
/*  348:     */     
/*  349:     */ 
/*  350: 443 */     seq.addInstruction(ConstantsUtil.getInstructionInstance(54, false, 1, bytecode_version, new int[] { var }), -1);
/*  351:     */     
/*  352:     */ 
/*  353:     */ 
/*  354: 447 */     BasicBlock newhead = new BasicBlock(++graph.last_id);
/*  355: 448 */     newhead.setSeq(seq);
/*  356:     */     
/*  357: 450 */     insertBlockBefore(graph, head, newhead);
/*  358:     */     
/*  359:     */ 
/*  360: 453 */     seq = new SimpleInstructionSequence();
/*  361: 454 */     seq.addInstruction(ConstantsUtil.getInstructionInstance(16, false, 1, bytecode_version, new int[] { 0 }), -1);
/*  362:     */     
/*  363:     */ 
/*  364: 457 */     seq.addInstruction(ConstantsUtil.getInstructionInstance(54, false, 1, bytecode_version, new int[] { var }), -1);
/*  365:     */     
/*  366:     */ 
/*  367:     */ 
/*  368: 461 */     BasicBlock newheadinit = new BasicBlock(++graph.last_id);
/*  369: 462 */     newheadinit.setSeq(seq);
/*  370:     */     
/*  371: 464 */     insertBlockBefore(graph, newhead, newheadinit);
/*  372:     */     
/*  373: 466 */     setCopy.add(newhead);
/*  374: 467 */     setCopy.add(newheadinit);
/*  375: 469 */     for (BasicBlock hd : new HashSet(newheadinit.getSuccExceptions()))
/*  376:     */     {
/*  377: 470 */       ExceptionRangeCFG range = graph.getExceptionRange(hd, newheadinit);
/*  378: 472 */       if (setCopy.containsAll(range.getProtectedRange()))
/*  379:     */       {
/*  380: 473 */         newheadinit.removeSuccessorException(hd);
/*  381: 474 */         range.getProtectedRange().remove(newheadinit);
/*  382:     */       }
/*  383:     */     }
/*  384:     */   }
/*  385:     */   
/*  386:     */   private static void insertBlockBefore(ControlFlowGraph graph, BasicBlock oldblock, BasicBlock newblock)
/*  387:     */   {
/*  388: 482 */     List<BasicBlock> lstTemp = new ArrayList();
/*  389: 483 */     lstTemp.addAll(oldblock.getPreds());
/*  390: 484 */     lstTemp.addAll(oldblock.getPredExceptions());
/*  391: 487 */     for (BasicBlock pred : lstTemp) {
/*  392: 488 */       pred.replaceSuccessor(oldblock, newblock);
/*  393:     */     }
/*  394: 492 */     for (BasicBlock hd : oldblock.getSuccExceptions())
/*  395:     */     {
/*  396: 493 */       newblock.addSuccessorException(hd);
/*  397:     */       
/*  398: 495 */       ExceptionRangeCFG range = graph.getExceptionRange(hd, oldblock);
/*  399: 496 */       range.getProtectedRange().add(newblock);
/*  400:     */     }
/*  401: 500 */     for (ExceptionRangeCFG range : graph.getExceptions()) {
/*  402: 501 */       if (range.getHandler() == oldblock) {
/*  403: 502 */         range.setHandler(newblock);
/*  404:     */       }
/*  405:     */     }
/*  406: 506 */     newblock.addSuccessor(oldblock);
/*  407: 507 */     graph.getBlocks().addWithKey(newblock, Integer.valueOf(newblock.id));
/*  408: 508 */     if (graph.getFirst() == oldblock) {
/*  409: 509 */       graph.setFirst(newblock);
/*  410:     */     }
/*  411:     */   }
/*  412:     */   
/*  413:     */   private static HashSet<BasicBlock> getAllBasicBlocks(Statement stat)
/*  414:     */   {
/*  415: 515 */     List<Statement> lst = new LinkedList();
/*  416: 516 */     lst.add(stat);
/*  417:     */     
/*  418: 518 */     int index = 0;
/*  419:     */     do
/*  420:     */     {
/*  421: 520 */       Statement st = (Statement)lst.get(index);
/*  422: 522 */       if (st.type == 8)
/*  423:     */       {
/*  424: 523 */         index++;
/*  425:     */       }
/*  426:     */       else
/*  427:     */       {
/*  428: 526 */         lst.addAll(st.getStats());
/*  429: 527 */         lst.remove(index);
/*  430:     */       }
/*  431: 530 */     } while (index < lst.size());
/*  432: 532 */     HashSet<BasicBlock> res = new HashSet();
/*  433: 534 */     for (Statement st : lst) {
/*  434: 535 */       res.add(((BasicBlockStatement)st).getBlock());
/*  435:     */     }
/*  436: 538 */     return res;
/*  437:     */   }
/*  438:     */   
/*  439:     */   private boolean verifyFinallyEx(ControlFlowGraph graph, CatchAllStatement fstat, Record information)
/*  440:     */   {
/*  441: 544 */     HashSet<BasicBlock> tryBlocks = getAllBasicBlocks(fstat.getFirst());
/*  442: 545 */     HashSet<BasicBlock> catchBlocks = getAllBasicBlocks(fstat.getHandler());
/*  443:     */     
/*  444: 547 */     int finallytype = information.firstCode;
/*  445: 548 */     Map<BasicBlock, Boolean> mapLast = information.mapLast;
/*  446:     */     
/*  447: 550 */     BasicBlock first = fstat.getHandler().getBasichead().getBlock();
/*  448: 551 */     boolean skippedFirst = false;
/*  449: 553 */     if (finallytype == 3)
/*  450:     */     {
/*  451: 555 */       removeExceptionInstructionsEx(first, 3, finallytype);
/*  452: 557 */       if (mapLast.containsKey(first)) {
/*  453: 558 */         graph.getFinallyExits().add(first);
/*  454:     */       }
/*  455: 561 */       return true;
/*  456:     */     }
/*  457: 564 */     if ((first.getSeq().length() == 1) && (finallytype > 0))
/*  458:     */     {
/*  459: 565 */       BasicBlock firstsuc = (BasicBlock)first.getSuccs().get(0);
/*  460: 566 */       if (catchBlocks.contains(firstsuc))
/*  461:     */       {
/*  462: 567 */         first = firstsuc;
/*  463: 568 */         skippedFirst = true;
/*  464:     */       }
/*  465:     */     }
/*  466: 574 */     HashSet<BasicBlock> startBlocks = new HashSet();
/*  467: 575 */     for (BasicBlock block : tryBlocks) {
/*  468: 576 */       startBlocks.addAll(block.getSuccs());
/*  469:     */     }
/*  470: 580 */     startBlocks.remove(graph.getLast());
/*  471: 581 */     startBlocks.removeAll(tryBlocks);
/*  472:     */     
/*  473: 583 */     List<Area> lstAreas = new ArrayList();
/*  474: 585 */     for (BasicBlock start : startBlocks)
/*  475:     */     {
/*  476: 587 */       Area arr = compareSubgraphsEx(graph, start, catchBlocks, first, finallytype, mapLast, skippedFirst);
/*  477: 588 */       if (arr == null) {
/*  478: 589 */         return false;
/*  479:     */       }
/*  480: 592 */       lstAreas.add(arr);
/*  481:     */     }
/*  482: 600 */     for (Area area : lstAreas) {
/*  483: 601 */       deleteArea(graph, area);
/*  484:     */     }
/*  485: 609 */     for (Map.Entry<BasicBlock, Boolean> entry : mapLast.entrySet())
/*  486:     */     {
/*  487: 610 */       BasicBlock last = (BasicBlock)entry.getKey();
/*  488: 612 */       if (((Boolean)entry.getValue()).booleanValue())
/*  489:     */       {
/*  490: 613 */         removeExceptionInstructionsEx(last, 2, finallytype);
/*  491: 614 */         graph.getFinallyExits().add(last);
/*  492:     */       }
/*  493:     */     }
/*  494: 618 */     removeExceptionInstructionsEx(fstat.getHandler().getBasichead().getBlock(), 1, finallytype);
/*  495:     */     
/*  496: 620 */     return true;
/*  497:     */   }
/*  498:     */   
/*  499:     */   private static class Area
/*  500:     */   {
/*  501:     */     private final BasicBlock start;
/*  502:     */     private final Set<BasicBlock> sample;
/*  503:     */     private final BasicBlock next;
/*  504:     */     
/*  505:     */     private Area(BasicBlock start, Set<BasicBlock> sample, BasicBlock next)
/*  506:     */     {
/*  507: 629 */       this.start = start;
/*  508: 630 */       this.sample = sample;
/*  509: 631 */       this.next = next;
/*  510:     */     }
/*  511:     */   }
/*  512:     */   
/*  513:     */   private Area compareSubgraphsEx(ControlFlowGraph graph, BasicBlock startSample, HashSet<BasicBlock> catchBlocks, BasicBlock startCatch, int finallytype, Map<BasicBlock, Boolean> mapLast, boolean skippedFirst)
/*  514:     */   {
/*  515: 657 */     List<1BlockStackEntry> stack = new LinkedList();
/*  516:     */     
/*  517: 659 */     Set<BasicBlock> setSample = new HashSet();
/*  518:     */     
/*  519: 661 */     Map<String, BasicBlock[]> mapNext = new HashMap();
/*  520:     */     
/*  521: 663 */     stack.add(new Object()
/*  522:     */     {
/*  523:     */       public BasicBlock blockCatch;
/*  524:     */       public BasicBlock blockSample;
/*  525:     */       public List<int[]> lstStoreVars;
/*  526:     */     });
/*  527:     */     BasicBlock blockSample;
/*  528:     */     boolean isTrueLastBlock;
/*  529: 665 */     while (!stack.isEmpty())
/*  530:     */     {
/*  531: 667 */       Object entry = (1BlockStackEntry)stack.remove(0);
/*  532: 668 */       BasicBlock blockCatch = entry.blockCatch;
/*  533: 669 */       blockSample = entry.blockSample;
/*  534:     */       
/*  535: 671 */       boolean isFirstBlock = (!skippedFirst) && (blockCatch == startCatch);
/*  536: 672 */       boolean isLastBlock = mapLast.containsKey(blockCatch);
/*  537: 673 */       isTrueLastBlock = (isLastBlock) && (((Boolean)mapLast.get(blockCatch)).booleanValue());
/*  538: 675 */       if (!compareBasicBlocksEx(graph, blockCatch, blockSample, (isFirstBlock ? 1 : 0) | (isTrueLastBlock ? 2 : 0), finallytype, entry.lstStoreVars)) {
/*  539: 677 */         return null;
/*  540:     */       }
/*  541: 680 */       if (blockSample.getSuccs().size() != blockCatch.getSuccs().size()) {
/*  542: 681 */         return null;
/*  543:     */       }
/*  544: 684 */       setSample.add(blockSample);
/*  545: 687 */       for (int i = 0; i < blockCatch.getSuccs().size(); i++)
/*  546:     */       {
/*  547: 688 */         BasicBlock sucCatch = (BasicBlock)blockCatch.getSuccs().get(i);
/*  548: 689 */         BasicBlock sucSample = (BasicBlock)blockSample.getSuccs().get(i);
/*  549: 691 */         if ((catchBlocks.contains(sucCatch)) && (!setSample.contains(sucSample))) {
/*  550: 692 */           stack.add(new Object()
/*  551:     */           {
/*  552:     */             public BasicBlock blockCatch;
/*  553:     */             public BasicBlock blockSample;
/*  554:     */             public List<int[]> lstStoreVars;
/*  555:     */           });
/*  556:     */         }
/*  557:     */       }
/*  558: 698 */       if ((!isLastBlock) || (!blockSample.getSeq().isEmpty())) {
/*  559: 702 */         if (blockCatch.getSuccExceptions().size() == blockSample.getSuccExceptions().size()) {
/*  560: 703 */           for (int i = 0; i < blockCatch.getSuccExceptions().size(); i++)
/*  561:     */           {
/*  562: 704 */             BasicBlock sucCatch = (BasicBlock)blockCatch.getSuccExceptions().get(i);
/*  563: 705 */             BasicBlock sucSample = (BasicBlock)blockSample.getSuccExceptions().get(i);
/*  564:     */             
/*  565: 707 */             String excCatch = graph.getExceptionRange(sucCatch, blockCatch).getUniqueExceptionsString();
/*  566: 708 */             String excSample = graph.getExceptionRange(sucSample, blockSample).getUniqueExceptionsString();
/*  567:     */             
/*  568:     */ 
/*  569: 711 */             boolean equalexc = excCatch == null ? false : excSample == null ? true : excCatch.equals(excSample);
/*  570: 713 */             if (equalexc)
/*  571:     */             {
/*  572: 714 */               if ((catchBlocks.contains(sucCatch)) && (!setSample.contains(sucSample)))
/*  573:     */               {
/*  574: 716 */                 List<int[]> lst = entry.lstStoreVars;
/*  575: 718 */                 if ((sucCatch.getSeq().length() > 0) && (sucSample.getSeq().length() > 0))
/*  576:     */                 {
/*  577: 719 */                   Instruction instrCatch = sucCatch.getSeq().getInstr(0);
/*  578: 720 */                   Instruction instrSample = sucSample.getSeq().getInstr(0);
/*  579: 722 */                   if ((instrCatch.opcode == 58) && (instrSample.opcode == 58))
/*  580:     */                   {
/*  581: 724 */                     lst = new ArrayList(lst);
/*  582: 725 */                     lst.add(new int[] { instrCatch.getOperand(0), instrSample.getOperand(0) });
/*  583:     */                   }
/*  584:     */                 }
/*  585: 729 */                 stack.add(new Object()
/*  586:     */                 {
/*  587:     */                   public BasicBlock blockCatch;
/*  588:     */                   public BasicBlock blockSample;
/*  589:     */                   public List<int[]> lstStoreVars;
/*  590:     */                 });
/*  591:     */               }
/*  592:     */             }
/*  593:     */             else {
/*  594: 733 */               return null;
/*  595:     */             }
/*  596:     */           }
/*  597:     */         } else {
/*  598: 738 */           return null;
/*  599:     */         }
/*  600:     */       }
/*  601: 742 */       if (isLastBlock)
/*  602:     */       {
/*  603: 743 */         Set<BasicBlock> setSuccs = new HashSet(blockSample.getSuccs());
/*  604: 744 */         setSuccs.removeAll(setSample);
/*  605: 746 */         for (Object stackent : stack) {
/*  606: 747 */           setSuccs.remove(stackent.blockSample);
/*  607:     */         }
/*  608: 750 */         for (BasicBlock succ : setSuccs) {
/*  609: 751 */           if (graph.getLast() != succ) {
/*  610: 752 */             mapNext.put(blockSample.id + "#" + succ.id, new BasicBlock[] { blockSample, succ, isTrueLastBlock ? succ : null });
/*  611:     */           }
/*  612:     */         }
/*  613:     */       }
/*  614:     */     }
/*  615: 758 */     return new Area(startSample, setSample, getUniqueNext(graph, new HashSet(mapNext.values())), null);
/*  616:     */   }
/*  617:     */   
/*  618:     */   private static BasicBlock getUniqueNext(ControlFlowGraph graph, Set<BasicBlock[]> setNext)
/*  619:     */   {
/*  620: 765 */     BasicBlock next = null;
/*  621: 766 */     boolean multiple = false;
/*  622: 768 */     for (BasicBlock[] arr : setNext)
/*  623:     */     {
/*  624: 770 */       if (arr[2] != null)
/*  625:     */       {
/*  626: 771 */         next = arr[1];
/*  627: 772 */         multiple = false;
/*  628: 773 */         break;
/*  629:     */       }
/*  630: 776 */       if (next == null) {
/*  631: 777 */         next = arr[1];
/*  632: 779 */       } else if (next != arr[1]) {
/*  633: 780 */         multiple = true;
/*  634:     */       }
/*  635: 783 */       if (arr[1].getPreds().size() == 1) {
/*  636: 784 */         next = arr[1];
/*  637:     */       }
/*  638:     */     }
/*  639: 789 */     if (multiple)
/*  640:     */     {
/*  641: 790 */       for (BasicBlock[] arr : setNext)
/*  642:     */       {
/*  643: 791 */         BasicBlock block = arr[1];
/*  644: 793 */         if (block != next) {
/*  645: 794 */           if (InterpreterUtil.equalSets(next.getSuccs(), block.getSuccs()))
/*  646:     */           {
/*  647: 795 */             InstructionSequence seqNext = next.getSeq();
/*  648: 796 */             InstructionSequence seqBlock = block.getSeq();
/*  649: 798 */             if (seqNext.length() == seqBlock.length()) {
/*  650: 799 */               for (int i = 0; i < seqNext.length(); i++)
/*  651:     */               {
/*  652: 800 */                 Instruction instrNext = seqNext.getInstr(i);
/*  653: 801 */                 Instruction instrBlock = seqBlock.getInstr(i);
/*  654: 803 */                 if ((instrNext.opcode != instrBlock.opcode) || (instrNext.wide != instrBlock.wide) || (instrNext.operandsCount() != instrBlock.operandsCount())) {
/*  655: 805 */                   return null;
/*  656:     */                 }
/*  657: 808 */                 for (int j = 0; j < instrNext.getOperands().length; j++) {
/*  658: 809 */                   if (instrNext.getOperand(j) != instrBlock.getOperand(j)) {
/*  659: 810 */                     return null;
/*  660:     */                   }
/*  661:     */                 }
/*  662:     */               }
/*  663:     */             } else {
/*  664: 816 */               return null;
/*  665:     */             }
/*  666:     */           }
/*  667:     */           else
/*  668:     */           {
/*  669: 820 */             return null;
/*  670:     */           }
/*  671:     */         }
/*  672:     */       }
/*  673: 831 */       for (BasicBlock[] arr : setNext) {
/*  674: 832 */         if (arr[1] != next)
/*  675:     */         {
/*  676: 834 */           arr[0].removeSuccessor(arr[1]);
/*  677: 835 */           arr[0].addSuccessor(next);
/*  678:     */         }
/*  679:     */       }
/*  680: 839 */       DeadCodeHelper.removeDeadBlocks(graph);
/*  681:     */     }
/*  682: 842 */     return next;
/*  683:     */   }
/*  684:     */   
/*  685:     */   private boolean compareBasicBlocksEx(ControlFlowGraph graph, BasicBlock pattern, BasicBlock sample, int type, int finallytype, List<int[]> lstStoreVars)
/*  686:     */   {
/*  687: 852 */     InstructionSequence seqPattern = pattern.getSeq();
/*  688: 853 */     InstructionSequence seqSample = sample.getSeq();
/*  689: 855 */     if (type != 0)
/*  690:     */     {
/*  691: 856 */       seqPattern = seqPattern.clone();
/*  692: 858 */       if (((type & 0x1) > 0) && 
/*  693: 859 */         (finallytype > 0)) {
/*  694: 860 */         seqPattern.removeInstruction(0);
/*  695:     */       }
/*  696: 864 */       if ((type & 0x2) > 0)
/*  697:     */       {
/*  698: 865 */         if ((finallytype == 0) || (finallytype == 2)) {
/*  699: 866 */           seqPattern.removeLast();
/*  700:     */         }
/*  701: 869 */         if (finallytype == 2) {
/*  702: 870 */           seqPattern.removeLast();
/*  703:     */         }
/*  704:     */       }
/*  705:     */     }
/*  706: 875 */     if (seqPattern.length() > seqSample.length()) {
/*  707: 876 */       return false;
/*  708:     */     }
/*  709: 879 */     for (int i = 0; i < seqPattern.length(); i++)
/*  710:     */     {
/*  711: 880 */       Instruction instrPattern = seqPattern.getInstr(i);
/*  712: 881 */       Instruction instrSample = seqSample.getInstr(i);
/*  713: 884 */       if (!equalInstructions(instrPattern, instrSample, lstStoreVars)) {
/*  714: 885 */         return false;
/*  715:     */       }
/*  716:     */     }
/*  717: 889 */     if (seqPattern.length() < seqSample.length())
/*  718:     */     {
/*  719: 891 */       SimpleInstructionSequence seq = new SimpleInstructionSequence();
/*  720: 892 */       LinkedList<Integer> oldOffsets = new LinkedList();
/*  721: 893 */       for (int i = seqSample.length() - 1; i >= seqPattern.length(); i--)
/*  722:     */       {
/*  723: 894 */         seq.addInstruction(0, seqSample.getInstr(i), -1);
/*  724: 895 */         oldOffsets.addFirst(sample.getOldOffset(i));
/*  725: 896 */         seqSample.removeInstruction(i);
/*  726:     */       }
/*  727: 899 */       BasicBlock newblock = new BasicBlock(++graph.last_id);
/*  728: 900 */       newblock.setSeq(seq);
/*  729: 901 */       newblock.getInstrOldOffsets().addAll(oldOffsets);
/*  730:     */       
/*  731: 903 */       List<BasicBlock> lstTemp = new ArrayList();
/*  732: 904 */       lstTemp.addAll(sample.getSuccs());
/*  733: 907 */       for (BasicBlock suc : lstTemp)
/*  734:     */       {
/*  735: 908 */         sample.removeSuccessor(suc);
/*  736: 909 */         newblock.addSuccessor(suc);
/*  737:     */       }
/*  738: 912 */       sample.addSuccessor(newblock);
/*  739:     */       
/*  740: 914 */       graph.getBlocks().addWithKey(newblock, Integer.valueOf(newblock.id));
/*  741:     */       
/*  742: 916 */       Set<BasicBlock> setFinallyExits = graph.getFinallyExits();
/*  743: 917 */       if (setFinallyExits.contains(sample))
/*  744:     */       {
/*  745: 918 */         setFinallyExits.remove(sample);
/*  746: 919 */         setFinallyExits.add(newblock);
/*  747:     */       }
/*  748: 923 */       for (int j = 0; j < sample.getSuccExceptions().size(); j++)
/*  749:     */       {
/*  750: 924 */         BasicBlock hd = (BasicBlock)sample.getSuccExceptions().get(j);
/*  751: 925 */         newblock.addSuccessorException(hd);
/*  752:     */         
/*  753: 927 */         ExceptionRangeCFG range = graph.getExceptionRange(hd, sample);
/*  754: 928 */         range.getProtectedRange().add(newblock);
/*  755:     */       }
/*  756:     */     }
/*  757: 932 */     return true;
/*  758:     */   }
/*  759:     */   
/*  760:     */   public boolean equalInstructions(Instruction first, Instruction second, List<int[]> lstStoreVars)
/*  761:     */   {
/*  762: 936 */     if ((first.opcode != second.opcode) || (first.wide != second.wide) || (first.operandsCount() != second.operandsCount())) {
/*  763: 938 */       return false;
/*  764:     */     }
/*  765: 941 */     if ((first.group != 2) && (first.getOperands() != null)) {
/*  766: 942 */       for (int i = 0; i < first.getOperands().length; i++)
/*  767:     */       {
/*  768: 944 */         int firstOp = first.getOperand(i);
/*  769: 945 */         int secondOp = second.getOperand(i);
/*  770: 947 */         if (firstOp != secondOp)
/*  771:     */         {
/*  772: 950 */           if ((first.opcode == 25) || (first.opcode == 58)) {
/*  773: 951 */             for (int[] arr : lstStoreVars) {
/*  774: 952 */               if ((arr[0] == firstOp) && (arr[1] == secondOp)) {
/*  775: 953 */                 return true;
/*  776:     */               }
/*  777:     */             }
/*  778:     */           }
/*  779: 958 */           return false;
/*  780:     */         }
/*  781:     */       }
/*  782:     */     }
/*  783: 963 */     return true;
/*  784:     */   }
/*  785:     */   
/*  786:     */   private static void deleteArea(ControlFlowGraph graph, Area area)
/*  787:     */   {
/*  788: 968 */     BasicBlock start = area.start;
/*  789: 969 */     BasicBlock next = area.next;
/*  790: 971 */     if (start == next) {
/*  791: 972 */       return;
/*  792:     */     }
/*  793: 975 */     if (next == null) {
/*  794: 977 */       next = graph.getLast();
/*  795:     */     }
/*  796: 981 */     Set<BasicBlock> setCommonExceptionHandlers = new HashSet(next.getSuccExceptions());
/*  797: 982 */     for (BasicBlock pred : start.getPreds()) {
/*  798: 983 */       setCommonExceptionHandlers.retainAll(pred.getSuccExceptions());
/*  799:     */     }
/*  800: 986 */     boolean is_outside_range = false;
/*  801:     */     
/*  802: 988 */     Set<BasicBlock> setPredecessors = new HashSet(start.getPreds());
/*  803: 991 */     for (BasicBlock pred : setPredecessors) {
/*  804: 992 */       pred.replaceSuccessor(start, next);
/*  805:     */     }
/*  806: 995 */     Set<BasicBlock> setBlocks = area.sample;
/*  807:     */     
/*  808: 997 */     Set<ExceptionRangeCFG> setCommonRemovedExceptionRanges = null;
/*  809:1000 */     for (BasicBlock block : setBlocks) {
/*  810:1004 */       if (graph.getBlocks().containsKey(Integer.valueOf(block.id)))
/*  811:     */       {
/*  812:1006 */         if (!block.getSuccExceptions().containsAll(setCommonExceptionHandlers)) {
/*  813:1007 */           is_outside_range = true;
/*  814:     */         }
/*  815:1010 */         Set<ExceptionRangeCFG> setRemovedExceptionRanges = new HashSet();
/*  816:1011 */         for (BasicBlock handler : block.getSuccExceptions()) {
/*  817:1012 */           setRemovedExceptionRanges.add(graph.getExceptionRange(handler, block));
/*  818:     */         }
/*  819:1015 */         if (setCommonRemovedExceptionRanges == null) {
/*  820:1016 */           setCommonRemovedExceptionRanges = setRemovedExceptionRanges;
/*  821:     */         } else {
/*  822:1019 */           setCommonRemovedExceptionRanges.retainAll(setRemovedExceptionRanges);
/*  823:     */         }
/*  824:1023 */         if ((block.getSeq().isEmpty()) && (block.getSuccs().size() == 1))
/*  825:     */         {
/*  826:1024 */           BasicBlock succs = (BasicBlock)block.getSuccs().get(0);
/*  827:1025 */           for (BasicBlock pred : new ArrayList(block.getPreds())) {
/*  828:1026 */             if (!setBlocks.contains(pred)) {
/*  829:1027 */               pred.replaceSuccessor(block, succs);
/*  830:     */             }
/*  831:     */           }
/*  832:1031 */           if (graph.getFirst() == block) {
/*  833:1032 */             graph.setFirst(succs);
/*  834:     */           }
/*  835:     */         }
/*  836:1036 */         graph.removeBlock(block);
/*  837:     */       }
/*  838:     */     }
/*  839:     */     BasicBlock emptyblock;
/*  840:1040 */     if (is_outside_range)
/*  841:     */     {
/*  842:1043 */       emptyblock = new BasicBlock(++graph.last_id);
/*  843:     */       
/*  844:1045 */       graph.getBlocks().addWithKey(emptyblock, Integer.valueOf(emptyblock.id));
/*  845:1048 */       if (setCommonRemovedExceptionRanges != null) {
/*  846:1049 */         for (ExceptionRangeCFG range : setCommonRemovedExceptionRanges)
/*  847:     */         {
/*  848:1050 */           emptyblock.addSuccessorException(range.getHandler());
/*  849:1051 */           range.getProtectedRange().add(emptyblock);
/*  850:     */         }
/*  851:     */       }
/*  852:1056 */       emptyblock.addSuccessor(next);
/*  853:1057 */       for (BasicBlock pred : setPredecessors) {
/*  854:1058 */         pred.replaceSuccessor(next, emptyblock);
/*  855:     */       }
/*  856:     */     }
/*  857:     */   }
/*  858:     */   
/*  859:     */   private static void removeExceptionInstructionsEx(BasicBlock block, int blocktype, int finallytype)
/*  860:     */   {
/*  861:1065 */     InstructionSequence seq = block.getSeq();
/*  862:1067 */     if (finallytype == 3)
/*  863:     */     {
/*  864:1068 */       for (int i = seq.length() - 1; i >= 0; i--) {
/*  865:1069 */         seq.removeInstruction(i);
/*  866:     */       }
/*  867:     */     }
/*  868:     */     else
/*  869:     */     {
/*  870:1073 */       if (((blocktype & 0x1) > 0) && (
/*  871:1074 */         (finallytype == 2) || (finallytype == 1))) {
/*  872:1075 */         seq.removeInstruction(0);
/*  873:     */       }
/*  874:1079 */       if ((blocktype & 0x2) > 0)
/*  875:     */       {
/*  876:1080 */         if ((finallytype == 2) || (finallytype == 0)) {
/*  877:1081 */           seq.removeLast();
/*  878:     */         }
/*  879:1084 */         if (finallytype == 2) {
/*  880:1085 */           seq.removeLast();
/*  881:     */         }
/*  882:     */       }
/*  883:     */     }
/*  884:     */   }
/*  885:     */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.FinallyProcessor
 * JD-Core Version:    0.7.0.1
 */