/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import java.util.Set;
/*  10:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  11:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  12:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  13:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.CheckTypesResult;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  16:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  17:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable;
/*  18:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable.MatchProperties;
/*  19:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  20:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode;
/*  21:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode.RuleValue;
/*  22:    */ 
/*  23:    */ public class Exprent
/*  24:    */   implements IMatchable
/*  25:    */ {
/*  26:    */   public static final int MULTIPLE_USES = 1;
/*  27:    */   public static final int SIDE_EFFECTS_FREE = 2;
/*  28:    */   public static final int BOTH_FLAGS = 3;
/*  29:    */   public static final int EXPRENT_ARRAY = 1;
/*  30:    */   public static final int EXPRENT_ASSIGNMENT = 2;
/*  31:    */   public static final int EXPRENT_CONST = 3;
/*  32:    */   public static final int EXPRENT_EXIT = 4;
/*  33:    */   public static final int EXPRENT_FIELD = 5;
/*  34:    */   public static final int EXPRENT_FUNCTION = 6;
/*  35:    */   public static final int EXPRENT_IF = 7;
/*  36:    */   public static final int EXPRENT_INVOCATION = 8;
/*  37:    */   public static final int EXPRENT_MONITOR = 9;
/*  38:    */   public static final int EXPRENT_NEW = 10;
/*  39:    */   public static final int EXPRENT_SWITCH = 11;
/*  40:    */   public static final int EXPRENT_VAR = 12;
/*  41:    */   public static final int EXPRENT_ANNOTATION = 13;
/*  42:    */   public static final int EXPRENT_ASSERT = 14;
/*  43:    */   public final int type;
/*  44:    */   public final int id;
/*  45: 60 */   public Set<Integer> bytecode = null;
/*  46:    */   
/*  47:    */   public Exprent(int type)
/*  48:    */   {
/*  49: 63 */     this.type = type;
/*  50: 64 */     this.id = DecompilerContext.getCounterContainer().getCounterAndIncrement(1);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public int getPrecedence()
/*  54:    */   {
/*  55: 68 */     return 0;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public VarType getExprType()
/*  59:    */   {
/*  60: 72 */     return VarType.VARTYPE_VOID;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public int getExprentUse()
/*  64:    */   {
/*  65: 76 */     return 0;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public CheckTypesResult checkExprTypeBounds()
/*  69:    */   {
/*  70: 80 */     return new CheckTypesResult();
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean containsExprent(Exprent exprent)
/*  74:    */   {
/*  75: 84 */     List<Exprent> listTemp = new ArrayList(getAllExprents(true));
/*  76: 85 */     listTemp.add(this);
/*  77: 87 */     for (Exprent lstExpr : listTemp) {
/*  78: 88 */       if (lstExpr.equals(exprent)) {
/*  79: 89 */         return true;
/*  80:    */       }
/*  81:    */     }
/*  82: 93 */     return false;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public List<Exprent> getAllExprents(boolean recursive)
/*  86:    */   {
/*  87: 97 */     List<Exprent> lst = getAllExprents();
/*  88: 98 */     if (recursive) {
/*  89: 99 */       for (int i = lst.size() - 1; i >= 0; i--) {
/*  90:100 */         lst.addAll(((Exprent)lst.get(i)).getAllExprents(true));
/*  91:    */       }
/*  92:    */     }
/*  93:103 */     return lst;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public Set<VarVersionPair> getAllVariables()
/*  97:    */   {
/*  98:107 */     List<Exprent> lstAllExprents = getAllExprents(true);
/*  99:108 */     lstAllExprents.add(this);
/* 100:    */     
/* 101:110 */     Set<VarVersionPair> set = new HashSet();
/* 102:111 */     for (Exprent expr : lstAllExprents) {
/* 103:112 */       if (expr.type == 12) {
/* 104:113 */         set.add(new VarVersionPair((VarExprent)expr));
/* 105:    */       }
/* 106:    */     }
/* 107:116 */     return set;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public List<Exprent> getAllExprents()
/* 111:    */   {
/* 112:120 */     throw new RuntimeException("not implemented");
/* 113:    */   }
/* 114:    */   
/* 115:    */   public Exprent copy()
/* 116:    */   {
/* 117:124 */     throw new RuntimeException("not implemented");
/* 118:    */   }
/* 119:    */   
/* 120:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 121:    */   {
/* 122:128 */     throw new RuntimeException("not implemented");
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr) {}
/* 126:    */   
/* 127:    */   public void addBytecodeOffsets(Collection<Integer> bytecodeOffsets)
/* 128:    */   {
/* 129:134 */     if ((bytecodeOffsets != null) && (!bytecodeOffsets.isEmpty())) {
/* 130:135 */       if (this.bytecode == null) {
/* 131:136 */         this.bytecode = new HashSet(bytecodeOffsets);
/* 132:    */       } else {
/* 133:139 */         this.bytecode.addAll(bytecodeOffsets);
/* 134:    */       }
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public IMatchable findObject(MatchNode matchNode, int index)
/* 139:    */   {
/* 140:150 */     if (matchNode.getType() != 1) {
/* 141:151 */       return null;
/* 142:    */     }
/* 143:154 */     List<Exprent> lstAllExprents = getAllExprents();
/* 144:156 */     if ((lstAllExprents == null) || (lstAllExprents.isEmpty())) {
/* 145:157 */       return null;
/* 146:    */     }
/* 147:160 */     String position = (String)matchNode.getRuleValue(IMatchable.MatchProperties.EXPRENT_POSITION);
/* 148:161 */     if (position != null)
/* 149:    */     {
/* 150:162 */       if (position.matches("-?\\d+")) {
/* 151:163 */         return (IMatchable)lstAllExprents.get((lstAllExprents.size() + Integer.parseInt(position)) % lstAllExprents.size());
/* 152:    */       }
/* 153:    */     }
/* 154:165 */     else if (index < lstAllExprents.size()) {
/* 155:166 */       return (IMatchable)lstAllExprents.get(index);
/* 156:    */     }
/* 157:169 */     return null;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public boolean match(MatchNode matchNode, MatchEngine engine)
/* 161:    */   {
/* 162:174 */     if (matchNode.getType() != 1) {
/* 163:175 */       return false;
/* 164:    */     }
/* 165:178 */     for (Map.Entry<IMatchable.MatchProperties, MatchNode.RuleValue> rule : matchNode.getRules().entrySet()) {
/* 166:179 */       switch (1.$SwitchMap$org$jetbrains$java$decompiler$struct$match$IMatchable$MatchProperties[((IMatchable.MatchProperties)rule.getKey()).ordinal()])
/* 167:    */       {
/* 168:    */       case 1: 
/* 169:181 */         if (this.type != ((Integer)((MatchNode.RuleValue)rule.getValue()).value).intValue()) {
/* 170:182 */           return false;
/* 171:    */         }
/* 172:    */         break;
/* 173:    */       case 2: 
/* 174:186 */         if (!engine.checkAndSetVariableValue((String)((MatchNode.RuleValue)rule.getValue()).value, this)) {
/* 175:187 */           return false;
/* 176:    */         }
/* 177:    */         break;
/* 178:    */       }
/* 179:    */     }
/* 180:194 */     return true;
/* 181:    */   }
/* 182:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent
 * JD-Core Version:    0.7.0.1
 */