/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   7:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.CheckTypesResult;
/*  10:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  11:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  12:    */ 
/*  13:    */ public class ArrayExprent
/*  14:    */   extends Exprent
/*  15:    */ {
/*  16:    */   private Exprent array;
/*  17:    */   private Exprent index;
/*  18:    */   private final VarType hardType;
/*  19:    */   
/*  20:    */   public ArrayExprent(Exprent array, Exprent index, VarType hardType, Set<Integer> bytecodeOffsets)
/*  21:    */   {
/*  22: 36 */     super(1);
/*  23: 37 */     this.array = array;
/*  24: 38 */     this.index = index;
/*  25: 39 */     this.hardType = hardType;
/*  26:    */     
/*  27: 41 */     addBytecodeOffsets(bytecodeOffsets);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public Exprent copy()
/*  31:    */   {
/*  32: 46 */     return new ArrayExprent(this.array.copy(), this.index.copy(), this.hardType, this.bytecode);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public VarType getExprType()
/*  36:    */   {
/*  37: 51 */     VarType exprType = this.array.getExprType();
/*  38: 52 */     if (exprType.equals(VarType.VARTYPE_NULL)) {
/*  39: 53 */       return this.hardType.copy();
/*  40:    */     }
/*  41: 56 */     return exprType.decreaseArrayDim();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public int getExprentUse()
/*  45:    */   {
/*  46: 61 */     return this.array.getExprentUse() & this.index.getExprentUse() & 0x1;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public CheckTypesResult checkExprTypeBounds()
/*  50:    */   {
/*  51: 65 */     CheckTypesResult result = new CheckTypesResult();
/*  52: 66 */     result.addMinTypeExprent(this.index, VarType.VARTYPE_BYTECHAR);
/*  53: 67 */     result.addMaxTypeExprent(this.index, VarType.VARTYPE_INT);
/*  54: 68 */     return result;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public List<Exprent> getAllExprents()
/*  58:    */   {
/*  59: 72 */     List<Exprent> lst = new ArrayList();
/*  60: 73 */     lst.add(this.array);
/*  61: 74 */     lst.add(this.index);
/*  62: 75 */     return lst;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  66:    */   {
/*  67: 80 */     TextBuffer res = this.array.toJava(indent, tracer);
/*  68: 82 */     if (this.array.getPrecedence() > getPrecedence()) {
/*  69: 83 */       res.enclose("(", ")");
/*  70:    */     }
/*  71: 86 */     VarType arrType = this.array.getExprType();
/*  72: 87 */     if (arrType.arrayDim == 0)
/*  73:    */     {
/*  74: 88 */       VarType objArr = VarType.VARTYPE_OBJECT.resizeArrayDim(1);
/*  75: 89 */       res.enclose("((" + ExprProcessor.getCastTypeName(objArr) + ")", ")");
/*  76:    */     }
/*  77: 92 */     tracer.addMapping(this.bytecode);
/*  78:    */     
/*  79: 94 */     return res.append("[").append(this.index.toJava(indent, tracer)).append("]");
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/*  83:    */   {
/*  84: 99 */     if (oldExpr == this.array) {
/*  85:100 */       this.array = newExpr;
/*  86:    */     }
/*  87:102 */     if (oldExpr == this.index) {
/*  88:103 */       this.index = newExpr;
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean equals(Object o)
/*  93:    */   {
/*  94:109 */     if (o == this) {
/*  95:109 */       return true;
/*  96:    */     }
/*  97:110 */     if ((o == null) || (!(o instanceof ArrayExprent))) {
/*  98:110 */       return false;
/*  99:    */     }
/* 100:112 */     ArrayExprent arr = (ArrayExprent)o;
/* 101:113 */     return (InterpreterUtil.equalObjects(this.array, arr.getArray())) && (InterpreterUtil.equalObjects(this.index, arr.getIndex()));
/* 102:    */   }
/* 103:    */   
/* 104:    */   public Exprent getArray()
/* 105:    */   {
/* 106:118 */     return this.array;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public Exprent getIndex()
/* 110:    */   {
/* 111:122 */     return this.index;
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.ArrayExprent
 * JD-Core Version:    0.7.0.1
 */