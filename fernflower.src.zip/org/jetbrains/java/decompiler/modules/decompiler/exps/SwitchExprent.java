/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   7:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.CheckTypesResult;
/*   9:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  10:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  11:    */ 
/*  12:    */ public class SwitchExprent
/*  13:    */   extends Exprent
/*  14:    */ {
/*  15:    */   private Exprent value;
/*  16: 31 */   private List<List<ConstExprent>> caseValues = new ArrayList();
/*  17:    */   
/*  18:    */   public SwitchExprent(Exprent value, Set<Integer> bytecodeOffsets)
/*  19:    */   {
/*  20: 34 */     super(11);
/*  21: 35 */     this.value = value;
/*  22:    */     
/*  23: 37 */     addBytecodeOffsets(bytecodeOffsets);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public Exprent copy()
/*  27:    */   {
/*  28: 42 */     SwitchExprent swExpr = new SwitchExprent(this.value.copy(), this.bytecode);
/*  29:    */     
/*  30: 44 */     List<List<ConstExprent>> lstCaseValues = new ArrayList();
/*  31: 45 */     for (List<ConstExprent> lst : this.caseValues) {
/*  32: 46 */       lstCaseValues.add(new ArrayList(lst));
/*  33:    */     }
/*  34: 48 */     swExpr.setCaseValues(lstCaseValues);
/*  35:    */     
/*  36: 50 */     return swExpr;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public VarType getExprType()
/*  40:    */   {
/*  41: 55 */     return this.value.getExprType();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public CheckTypesResult checkExprTypeBounds()
/*  45:    */   {
/*  46: 60 */     CheckTypesResult result = new CheckTypesResult();
/*  47:    */     
/*  48: 62 */     result.addMinTypeExprent(this.value, VarType.VARTYPE_BYTECHAR);
/*  49: 63 */     result.addMaxTypeExprent(this.value, VarType.VARTYPE_INT);
/*  50:    */     
/*  51: 65 */     VarType valType = this.value.getExprType();
/*  52: 66 */     for (List<ConstExprent> lst : this.caseValues) {
/*  53: 67 */       for (ConstExprent expr : lst) {
/*  54: 68 */         if (expr != null)
/*  55:    */         {
/*  56: 69 */           VarType caseType = expr.getExprType();
/*  57: 70 */           if (!caseType.equals(valType))
/*  58:    */           {
/*  59: 71 */             valType = VarType.getCommonSupertype(caseType, valType);
/*  60: 72 */             result.addMinTypeExprent(this.value, valType);
/*  61:    */           }
/*  62:    */         }
/*  63:    */       }
/*  64:    */     }
/*  65: 78 */     return result;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public List<Exprent> getAllExprents()
/*  69:    */   {
/*  70: 83 */     List<Exprent> lst = new ArrayList();
/*  71: 84 */     lst.add(this.value);
/*  72: 85 */     return lst;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  76:    */   {
/*  77: 90 */     tracer.addMapping(this.bytecode);
/*  78: 91 */     return this.value.toJava(indent, tracer).enclose("switch(", ")");
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/*  82:    */   {
/*  83: 96 */     if (oldExpr == this.value) {
/*  84: 97 */       this.value = newExpr;
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public boolean equals(Object o)
/*  89:    */   {
/*  90:103 */     if (o == this) {
/*  91:104 */       return true;
/*  92:    */     }
/*  93:107 */     if ((o == null) || (!(o instanceof SwitchExprent))) {
/*  94:108 */       return false;
/*  95:    */     }
/*  96:111 */     SwitchExprent sw = (SwitchExprent)o;
/*  97:112 */     return InterpreterUtil.equalObjects(this.value, sw.getValue());
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Exprent getValue()
/* 101:    */   {
/* 102:116 */     return this.value;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setCaseValues(List<List<ConstExprent>> caseValues)
/* 106:    */   {
/* 107:120 */     this.caseValues = caseValues;
/* 108:    */   }
/* 109:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.SwitchExprent
 * JD-Core Version:    0.7.0.1
 */