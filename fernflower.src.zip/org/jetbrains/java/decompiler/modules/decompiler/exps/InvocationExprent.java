/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.BitSet;
/*   5:    */ import java.util.Collections;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import java.util.Set;
/*  10:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor;
/*  11:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*  12:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  13:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  14:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  15:    */ import org.jetbrains.java.decompiler.main.collectors.ImportCollector;
/*  16:    */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*  17:    */ import org.jetbrains.java.decompiler.main.rels.MethodWrapper;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.CheckTypesResult;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  22:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  23:    */ import org.jetbrains.java.decompiler.struct.StructContext;
/*  24:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  25:    */ import org.jetbrains.java.decompiler.struct.consts.LinkConstant;
/*  26:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  27:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  28:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable.MatchProperties;
/*  29:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  30:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode;
/*  31:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode.RuleValue;
/*  32:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  33:    */ import org.jetbrains.java.decompiler.util.ListStack;
/*  34:    */ import org.jetbrains.java.decompiler.util.TextUtil;
/*  35:    */ 
/*  36:    */ public class InvocationExprent
/*  37:    */   extends Exprent
/*  38:    */ {
/*  39:    */   public static final int INVOKE_SPECIAL = 1;
/*  40:    */   public static final int INVOKE_VIRTUAL = 2;
/*  41:    */   public static final int INVOKE_STATIC = 3;
/*  42:    */   public static final int INVOKE_INTERFACE = 4;
/*  43:    */   public static final int INVOKE_DYNAMIC = 5;
/*  44:    */   public static final int TYP_GENERAL = 1;
/*  45:    */   public static final int TYP_INIT = 2;
/*  46:    */   public static final int TYP_CLINIT = 3;
/*  47: 60 */   private static final BitSet EMPTY_BIT_SET = new BitSet(0);
/*  48:    */   private String name;
/*  49:    */   private String classname;
/*  50:    */   private boolean isStatic;
/*  51: 65 */   private int functype = 1;
/*  52:    */   private Exprent instance;
/*  53:    */   private MethodDescriptor descriptor;
/*  54:    */   private String stringDescriptor;
/*  55:    */   private String invokeDynamicClassSuffix;
/*  56: 70 */   private int invocationTyp = 2;
/*  57: 71 */   private List<Exprent> lstParameters = new ArrayList();
/*  58:    */   
/*  59:    */   public InvocationExprent()
/*  60:    */   {
/*  61: 74 */     super(8);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public InvocationExprent(int opcode, LinkConstant cn, ListStack<Exprent> stack, int dynamicInvocationType, Set<Integer> bytecodeOffsets)
/*  65:    */   {
/*  66: 78 */     this();
/*  67:    */     
/*  68: 80 */     this.name = cn.elementname;
/*  69: 81 */     this.classname = cn.classname;
/*  70: 83 */     switch (opcode)
/*  71:    */     {
/*  72:    */     case 184: 
/*  73: 85 */       this.invocationTyp = 3;
/*  74: 86 */       break;
/*  75:    */     case 183: 
/*  76: 88 */       this.invocationTyp = 1;
/*  77: 89 */       break;
/*  78:    */     case 182: 
/*  79: 91 */       this.invocationTyp = 2;
/*  80: 92 */       break;
/*  81:    */     case 185: 
/*  82: 94 */       this.invocationTyp = 4;
/*  83: 95 */       break;
/*  84:    */     case 186: 
/*  85: 97 */       this.invocationTyp = 5;
/*  86:    */       
/*  87: 99 */       this.classname = "java/lang/Class";
/*  88:100 */       this.invokeDynamicClassSuffix = ("##Lambda_" + cn.index1 + "_" + cn.index2);
/*  89:    */     }
/*  90:103 */     if ("<init>".equals(this.name)) {
/*  91:104 */       this.functype = 2;
/*  92:106 */     } else if ("<clinit>".equals(this.name)) {
/*  93:107 */       this.functype = 3;
/*  94:    */     }
/*  95:110 */     this.stringDescriptor = cn.descriptor;
/*  96:111 */     this.descriptor = MethodDescriptor.parseDescriptor(cn.descriptor);
/*  97:113 */     for (VarType ignored : this.descriptor.params) {
/*  98:114 */       this.lstParameters.add(0, stack.pop());
/*  99:    */     }
/* 100:117 */     if (opcode == 186)
/* 101:    */     {
/* 102:118 */       if (dynamicInvocationType == 6) {
/* 103:119 */         this.isStatic = true;
/* 104:123 */       } else if (!this.lstParameters.isEmpty()) {
/* 105:124 */         this.instance = ((Exprent)this.lstParameters.get(0));
/* 106:    */       }
/* 107:    */     }
/* 108:128 */     else if (opcode == 184) {
/* 109:129 */       this.isStatic = true;
/* 110:    */     } else {
/* 111:132 */       this.instance = ((Exprent)stack.pop());
/* 112:    */     }
/* 113:135 */     addBytecodeOffsets(bytecodeOffsets);
/* 114:    */   }
/* 115:    */   
/* 116:    */   private InvocationExprent(InvocationExprent expr)
/* 117:    */   {
/* 118:139 */     this();
/* 119:    */     
/* 120:141 */     this.name = expr.getName();
/* 121:142 */     this.classname = expr.getClassname();
/* 122:143 */     this.isStatic = expr.isStatic();
/* 123:144 */     this.functype = expr.getFunctype();
/* 124:145 */     this.instance = expr.getInstance();
/* 125:146 */     if (this.instance != null) {
/* 126:147 */       this.instance = this.instance.copy();
/* 127:    */     }
/* 128:149 */     this.invocationTyp = expr.getInvocationTyp();
/* 129:150 */     this.invokeDynamicClassSuffix = expr.getInvokeDynamicClassSuffix();
/* 130:151 */     this.stringDescriptor = expr.getStringDescriptor();
/* 131:152 */     this.descriptor = expr.getDescriptor();
/* 132:153 */     this.lstParameters = new ArrayList(expr.getLstParameters());
/* 133:154 */     ExprProcessor.copyEntries(this.lstParameters);
/* 134:    */     
/* 135:156 */     addBytecodeOffsets(expr.bytecode);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public VarType getExprType()
/* 139:    */   {
/* 140:161 */     return this.descriptor.ret;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public CheckTypesResult checkExprTypeBounds()
/* 144:    */   {
/* 145:166 */     CheckTypesResult result = new CheckTypesResult();
/* 146:168 */     for (int i = 0; i < this.lstParameters.size(); i++)
/* 147:    */     {
/* 148:169 */       Exprent parameter = (Exprent)this.lstParameters.get(i);
/* 149:    */       
/* 150:171 */       VarType leftType = this.descriptor.params[i];
/* 151:    */       
/* 152:173 */       result.addMinTypeExprent(parameter, VarType.getMinTypeInFamily(leftType.typeFamily));
/* 153:174 */       result.addMaxTypeExprent(parameter, leftType);
/* 154:    */     }
/* 155:177 */     return result;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public List<Exprent> getAllExprents()
/* 159:    */   {
/* 160:182 */     List<Exprent> lst = new ArrayList();
/* 161:183 */     if (this.instance != null) {
/* 162:184 */       lst.add(this.instance);
/* 163:    */     }
/* 164:186 */     lst.addAll(this.lstParameters);
/* 165:187 */     return lst;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public Exprent copy()
/* 169:    */   {
/* 170:193 */     return new InvocationExprent(this);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 174:    */   {
/* 175:198 */     TextBuffer buf = new TextBuffer();
/* 176:    */     
/* 177:200 */     String super_qualifier = null;
/* 178:201 */     boolean isInstanceThis = false;
/* 179:    */     
/* 180:203 */     tracer.addMapping(this.bytecode);
/* 181:205 */     if (this.isStatic)
/* 182:    */     {
/* 183:206 */       ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)DecompilerContext.getProperty("CURRENT_CLASS_NODE");
/* 184:207 */       if ((node == null) || (!this.classname.equals(node.classStruct.qualifiedName))) {
/* 185:208 */         buf.append(DecompilerContext.getImportCollector().getShortName(ExprProcessor.buildJavaClassName(this.classname)));
/* 186:    */       }
/* 187:    */     }
/* 188:    */     else
/* 189:    */     {
/* 190:213 */       if ((this.instance != null) && (this.instance.type == 12))
/* 191:    */       {
/* 192:214 */         VarExprent instvar = (VarExprent)this.instance;
/* 193:215 */         VarVersionPair varpaar = new VarVersionPair(instvar);
/* 194:    */         
/* 195:217 */         VarProcessor vproc = instvar.getProcessor();
/* 196:218 */         if (vproc == null)
/* 197:    */         {
/* 198:219 */           MethodWrapper current_meth = (MethodWrapper)DecompilerContext.getProperty("CURRENT_METHOD_WRAPPER");
/* 199:220 */           if (current_meth != null) {
/* 200:221 */             vproc = current_meth.varproc;
/* 201:    */           }
/* 202:    */         }
/* 203:225 */         String this_classname = null;
/* 204:226 */         if (vproc != null) {
/* 205:227 */           this_classname = (String)vproc.getThisVars().get(varpaar);
/* 206:    */         }
/* 207:230 */         if (this_classname != null)
/* 208:    */         {
/* 209:231 */           isInstanceThis = true;
/* 210:233 */           if ((this.invocationTyp == 1) && 
/* 211:234 */             (!this.classname.equals(this_classname))) {
/* 212:235 */             super_qualifier = this_classname;
/* 213:    */           }
/* 214:    */         }
/* 215:    */       }
/* 216:241 */       if (this.functype == 1) {
/* 217:242 */         if (super_qualifier != null)
/* 218:    */         {
/* 219:243 */           TextUtil.writeQualifiedSuper(buf, super_qualifier);
/* 220:    */         }
/* 221:245 */         else if (this.instance != null)
/* 222:    */         {
/* 223:246 */           TextBuffer res = this.instance.toJava(indent, tracer);
/* 224:    */           
/* 225:248 */           VarType rightType = this.instance.getExprType();
/* 226:249 */           VarType leftType = new VarType(8, 0, this.classname);
/* 227:251 */           if ((rightType.equals(VarType.VARTYPE_OBJECT)) && (!leftType.equals(rightType)))
/* 228:    */           {
/* 229:252 */             buf.append("((").append(ExprProcessor.getCastTypeName(leftType)).append(")");
/* 230:254 */             if (this.instance.getPrecedence() >= FunctionExprent.getPrecedence(29)) {
/* 231:255 */               res.enclose("(", ")");
/* 232:    */             }
/* 233:257 */             buf.append(res).append(")");
/* 234:    */           }
/* 235:259 */           else if (this.instance.getPrecedence() > getPrecedence())
/* 236:    */           {
/* 237:260 */             buf.append("(").append(res).append(")");
/* 238:    */           }
/* 239:    */           else
/* 240:    */           {
/* 241:263 */             buf.append(res);
/* 242:    */           }
/* 243:    */         }
/* 244:    */       }
/* 245:    */     }
/* 246:269 */     switch (this.functype)
/* 247:    */     {
/* 248:    */     case 1: 
/* 249:271 */       if ("<VAR_NAMELESS_ENCLOSURE>".equals(buf.toString())) {
/* 250:272 */         buf = new TextBuffer();
/* 251:    */       }
/* 252:275 */       if (buf.length() > 0) {
/* 253:276 */         buf.append(".");
/* 254:    */       }
/* 255:279 */       buf.append(this.name);
/* 256:280 */       if (this.invocationTyp == 5) {
/* 257:281 */         buf.append("<invokedynamic>");
/* 258:    */       }
/* 259:283 */       buf.append("(");
/* 260:    */       
/* 261:285 */       break;
/* 262:    */     case 3: 
/* 263:287 */       throw new RuntimeException("Explicit invocation of <clinit>");
/* 264:    */     case 2: 
/* 265:289 */       if (super_qualifier != null) {
/* 266:290 */         buf.append("super(");
/* 267:292 */       } else if (isInstanceThis) {
/* 268:293 */         buf.append("this(");
/* 269:    */       } else {
/* 270:296 */         throw new RuntimeException("Unrecognized invocation of <init>");
/* 271:    */       }
/* 272:    */       break;
/* 273:    */     }
/* 274:300 */     List<VarVersionPair> sigFields = null;
/* 275:301 */     boolean isEnum = false;
/* 276:302 */     if (this.functype == 2)
/* 277:    */     {
/* 278:303 */       ClassesProcessor.ClassNode newNode = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(this.classname);
/* 279:305 */       if (newNode != null)
/* 280:    */       {
/* 281:306 */         if (newNode.getWrapper() != null)
/* 282:    */         {
/* 283:307 */           sigFields = newNode.getWrapper().getMethodWrapper("<init>", this.stringDescriptor).signatureFields;
/* 284:    */         }
/* 285:310 */         else if ((newNode.type == 1) && ((newNode.access & 0x8) == 0))
/* 286:    */         {
/* 287:311 */           sigFields = new ArrayList(Collections.nCopies(this.lstParameters.size(), (VarVersionPair)null));
/* 288:312 */           sigFields.set(0, new VarVersionPair(-1, 0));
/* 289:    */         }
/* 290:315 */         isEnum = (newNode.classStruct.hasModifier(16384)) && (DecompilerContext.getOption("den"));
/* 291:    */       }
/* 292:    */     }
/* 293:319 */     BitSet setAmbiguousParameters = getAmbiguousParameters();
/* 294:    */     
/* 295:321 */     boolean firstParameter = true;
/* 296:322 */     int start = isEnum ? 2 : 0;
/* 297:323 */     for (int i = start; i < this.lstParameters.size(); i++) {
/* 298:324 */       if (sigFields == null)
/* 299:    */       {
/* 300:325 */         if (!firstParameter) {
/* 301:326 */           buf.append(", ");
/* 302:    */         }
/* 303:329 */         TextBuffer buff = new TextBuffer();
/* 304:330 */         boolean ambiguous = setAmbiguousParameters.get(i);
/* 305:331 */         ExprProcessor.getCastedExprent((Exprent)this.lstParameters.get(i), this.descriptor.params[i], buff, indent, true, ambiguous, tracer);
/* 306:332 */         buf.append(buff);
/* 307:    */         
/* 308:334 */         firstParameter = false;
/* 309:    */       }
/* 310:    */     }
/* 311:338 */     buf.append(")");
/* 312:    */     
/* 313:340 */     return buf;
/* 314:    */   }
/* 315:    */   
/* 316:    */   private BitSet getAmbiguousParameters()
/* 317:    */   {
/* 318:344 */     StructClass cl = DecompilerContext.getStructContext().getClass(this.classname);
/* 319:345 */     if (cl == null) {
/* 320:345 */       return EMPTY_BIT_SET;
/* 321:    */     }
/* 322:348 */     List<MethodDescriptor> matches = new ArrayList();
/* 323:350 */     for (StructMethod mt : cl.getMethods()) {
/* 324:351 */       if (this.name.equals(mt.getName()))
/* 325:    */       {
/* 326:352 */         MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/* 327:353 */         if (md.params.length == this.descriptor.params.length)
/* 328:    */         {
/* 329:354 */           for (int i = 0;; i++)
/* 330:    */           {
/* 331:354 */             if (i >= md.params.length) {
/* 332:    */               break label147;
/* 333:    */             }
/* 334:355 */             if (md.params[i].typeFamily != this.descriptor.params[i].typeFamily) {
/* 335:    */               break;
/* 336:    */             }
/* 337:    */           }
/* 338:359 */           matches.add(md);
/* 339:    */         }
/* 340:    */       }
/* 341:    */     }
/* 342:    */     label147:
/* 343:363 */     if (matches.size() == 1) {
/* 344:363 */       return EMPTY_BIT_SET;
/* 345:    */     }
/* 346:366 */     StructMethod mt = cl.getMethod(InterpreterUtil.makeUniqueKey(this.name, this.stringDescriptor));
/* 347:367 */     if (mt != null)
/* 348:    */     {
/* 349:368 */       MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/* 350:369 */       if (md.params.length == this.lstParameters.size())
/* 351:    */       {
/* 352:370 */         boolean exact = true;
/* 353:371 */         for (int i = 0; i < md.params.length; i++) {
/* 354:372 */           if (!md.params[i].equals(((Exprent)this.lstParameters.get(i)).getExprType()))
/* 355:    */           {
/* 356:373 */             exact = false;
/* 357:374 */             break;
/* 358:    */           }
/* 359:    */         }
/* 360:377 */         if (exact) {
/* 361:377 */           return EMPTY_BIT_SET;
/* 362:    */         }
/* 363:    */       }
/* 364:    */     }
/* 365:382 */     BitSet ambiguous = new BitSet(this.descriptor.params.length);
/* 366:    */     VarType paramType;
/* 367:383 */     for (int i = 0; i < this.descriptor.params.length; i++)
/* 368:    */     {
/* 369:384 */       paramType = this.descriptor.params[i];
/* 370:385 */       for (MethodDescriptor md : matches) {
/* 371:386 */         if (!paramType.equals(md.params[i]))
/* 372:    */         {
/* 373:387 */           ambiguous.set(i);
/* 374:388 */           break;
/* 375:    */         }
/* 376:    */       }
/* 377:    */     }
/* 378:392 */     return ambiguous;
/* 379:    */   }
/* 380:    */   
/* 381:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/* 382:    */   {
/* 383:397 */     if (oldExpr == this.instance) {
/* 384:398 */       this.instance = newExpr;
/* 385:    */     }
/* 386:401 */     for (int i = 0; i < this.lstParameters.size(); i++) {
/* 387:402 */       if (oldExpr == this.lstParameters.get(i)) {
/* 388:403 */         this.lstParameters.set(i, newExpr);
/* 389:    */       }
/* 390:    */     }
/* 391:    */   }
/* 392:    */   
/* 393:    */   public boolean equals(Object o)
/* 394:    */   {
/* 395:410 */     if (o == this) {
/* 396:410 */       return true;
/* 397:    */     }
/* 398:411 */     if ((o == null) || (!(o instanceof InvocationExprent))) {
/* 399:411 */       return false;
/* 400:    */     }
/* 401:413 */     InvocationExprent it = (InvocationExprent)o;
/* 402:414 */     return (InterpreterUtil.equalObjects(this.name, it.getName())) && (InterpreterUtil.equalObjects(this.classname, it.getClassname())) && (this.isStatic == it.isStatic()) && (InterpreterUtil.equalObjects(this.instance, it.getInstance())) && (InterpreterUtil.equalObjects(this.descriptor, it.getDescriptor())) && (this.functype == it.getFunctype()) && (InterpreterUtil.equalLists(this.lstParameters, it.getLstParameters()));
/* 403:    */   }
/* 404:    */   
/* 405:    */   public List<Exprent> getLstParameters()
/* 406:    */   {
/* 407:424 */     return this.lstParameters;
/* 408:    */   }
/* 409:    */   
/* 410:    */   public void setLstParameters(List<Exprent> lstParameters)
/* 411:    */   {
/* 412:428 */     this.lstParameters = lstParameters;
/* 413:    */   }
/* 414:    */   
/* 415:    */   public MethodDescriptor getDescriptor()
/* 416:    */   {
/* 417:432 */     return this.descriptor;
/* 418:    */   }
/* 419:    */   
/* 420:    */   public void setDescriptor(MethodDescriptor descriptor)
/* 421:    */   {
/* 422:436 */     this.descriptor = descriptor;
/* 423:    */   }
/* 424:    */   
/* 425:    */   public String getClassname()
/* 426:    */   {
/* 427:440 */     return this.classname;
/* 428:    */   }
/* 429:    */   
/* 430:    */   public void setClassname(String classname)
/* 431:    */   {
/* 432:444 */     this.classname = classname;
/* 433:    */   }
/* 434:    */   
/* 435:    */   public int getFunctype()
/* 436:    */   {
/* 437:448 */     return this.functype;
/* 438:    */   }
/* 439:    */   
/* 440:    */   public void setFunctype(int functype)
/* 441:    */   {
/* 442:452 */     this.functype = functype;
/* 443:    */   }
/* 444:    */   
/* 445:    */   public Exprent getInstance()
/* 446:    */   {
/* 447:456 */     return this.instance;
/* 448:    */   }
/* 449:    */   
/* 450:    */   public void setInstance(Exprent instance)
/* 451:    */   {
/* 452:460 */     this.instance = instance;
/* 453:    */   }
/* 454:    */   
/* 455:    */   public boolean isStatic()
/* 456:    */   {
/* 457:464 */     return this.isStatic;
/* 458:    */   }
/* 459:    */   
/* 460:    */   public void setStatic(boolean isStatic)
/* 461:    */   {
/* 462:468 */     this.isStatic = isStatic;
/* 463:    */   }
/* 464:    */   
/* 465:    */   public String getName()
/* 466:    */   {
/* 467:472 */     return this.name;
/* 468:    */   }
/* 469:    */   
/* 470:    */   public void setName(String name)
/* 471:    */   {
/* 472:476 */     this.name = name;
/* 473:    */   }
/* 474:    */   
/* 475:    */   public String getStringDescriptor()
/* 476:    */   {
/* 477:480 */     return this.stringDescriptor;
/* 478:    */   }
/* 479:    */   
/* 480:    */   public void setStringDescriptor(String stringDescriptor)
/* 481:    */   {
/* 482:484 */     this.stringDescriptor = stringDescriptor;
/* 483:    */   }
/* 484:    */   
/* 485:    */   public int getInvocationTyp()
/* 486:    */   {
/* 487:488 */     return this.invocationTyp;
/* 488:    */   }
/* 489:    */   
/* 490:    */   public String getInvokeDynamicClassSuffix()
/* 491:    */   {
/* 492:492 */     return this.invokeDynamicClassSuffix;
/* 493:    */   }
/* 494:    */   
/* 495:    */   public boolean match(MatchNode matchNode, MatchEngine engine)
/* 496:    */   {
/* 497:501 */     if (!super.match(matchNode, engine)) {
/* 498:502 */       return false;
/* 499:    */     }
/* 500:505 */     for (Map.Entry<IMatchable.MatchProperties, MatchNode.RuleValue> rule : matchNode.getRules().entrySet())
/* 501:    */     {
/* 502:506 */       MatchNode.RuleValue value = (MatchNode.RuleValue)rule.getValue();
/* 503:508 */       switch (1.$SwitchMap$org$jetbrains$java$decompiler$struct$match$IMatchable$MatchProperties[((IMatchable.MatchProperties)rule.getKey()).ordinal()])
/* 504:    */       {
/* 505:    */       case 1: 
/* 506:510 */         if (value.isVariable()) {
/* 507:511 */           if (value.parameter < this.lstParameters.size())
/* 508:    */           {
/* 509:512 */             if (!engine.checkAndSetVariableValue(value.value.toString(), this.lstParameters.get(value.parameter))) {
/* 510:513 */               return false;
/* 511:    */             }
/* 512:    */           }
/* 513:    */           else {
/* 514:516 */             return false;
/* 515:    */           }
/* 516:    */         }
/* 517:    */         break;
/* 518:    */       case 2: 
/* 519:521 */         if (!value.value.equals(this.classname)) {
/* 520:522 */           return false;
/* 521:    */         }
/* 522:    */         break;
/* 523:    */       case 3: 
/* 524:526 */         if (!value.value.equals(this.name + this.stringDescriptor)) {
/* 525:527 */           return false;
/* 526:    */         }
/* 527:    */         break;
/* 528:    */       }
/* 529:    */     }
/* 530:534 */     return true;
/* 531:    */   }
/* 532:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent
 * JD-Core Version:    0.7.0.1
 */