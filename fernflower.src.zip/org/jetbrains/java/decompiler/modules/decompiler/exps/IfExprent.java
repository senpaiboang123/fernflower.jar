/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   7:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*   8:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*   9:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  10:    */ import org.jetbrains.java.decompiler.util.ListStack;
/*  11:    */ 
/*  12:    */ public class IfExprent
/*  13:    */   extends Exprent
/*  14:    */ {
/*  15:    */   public static final int IF_EQ = 0;
/*  16:    */   public static final int IF_NE = 1;
/*  17:    */   public static final int IF_LT = 2;
/*  18:    */   public static final int IF_GE = 3;
/*  19:    */   public static final int IF_GT = 4;
/*  20:    */   public static final int IF_LE = 5;
/*  21:    */   public static final int IF_NULL = 6;
/*  22:    */   public static final int IF_NONNULL = 7;
/*  23:    */   public static final int IF_ICMPEQ = 8;
/*  24:    */   public static final int IF_ICMPNE = 9;
/*  25:    */   public static final int IF_ICMPLT = 10;
/*  26:    */   public static final int IF_ICMPGE = 11;
/*  27:    */   public static final int IF_ICMPGT = 12;
/*  28:    */   public static final int IF_ICMPLE = 13;
/*  29:    */   public static final int IF_ACMPEQ = 14;
/*  30:    */   public static final int IF_ACMPNE = 15;
/*  31:    */   public static final int IF_CAND = 16;
/*  32:    */   public static final int IF_COR = 17;
/*  33:    */   public static final int IF_NOT = 18;
/*  34:    */   public static final int IF_VALUE = 19;
/*  35: 53 */   private static final int[] FUNC_TYPES = { 42, 43, 44, 45, 46, 47, 42, 43, 42, 43, 44, 45, 46, 47, 42, 43, 48, 49, 12, -1 };
/*  36:    */   private Exprent condition;
/*  37:    */   
/*  38:    */   public IfExprent(int ifType, ListStack<Exprent> stack, Set<Integer> bytecodeOffsets)
/*  39:    */   {
/*  40: 79 */     this(null, bytecodeOffsets);
/*  41: 81 */     if (ifType <= 5) {
/*  42: 82 */       stack.push(new ConstExprent(0, true, null));
/*  43: 84 */     } else if (ifType <= 7) {
/*  44: 85 */       stack.push(new ConstExprent(VarType.VARTYPE_NULL, null, null));
/*  45:    */     }
/*  46: 88 */     if (ifType == 19) {
/*  47: 89 */       this.condition = ((Exprent)stack.pop());
/*  48:    */     } else {
/*  49: 92 */       this.condition = new FunctionExprent(FUNC_TYPES[ifType], stack, bytecodeOffsets);
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   private IfExprent(Exprent condition, Set<Integer> bytecodeOffsets)
/*  54:    */   {
/*  55: 97 */     super(7);
/*  56: 98 */     this.condition = condition;
/*  57:    */     
/*  58:100 */     addBytecodeOffsets(bytecodeOffsets);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public Exprent copy()
/*  62:    */   {
/*  63:105 */     return new IfExprent(this.condition.copy(), this.bytecode);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public List<Exprent> getAllExprents()
/*  67:    */   {
/*  68:110 */     List<Exprent> lst = new ArrayList();
/*  69:111 */     lst.add(this.condition);
/*  70:112 */     return lst;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  74:    */   {
/*  75:117 */     tracer.addMapping(this.bytecode);
/*  76:118 */     return this.condition.toJava(indent, tracer).enclose("if(", ")");
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/*  80:    */   {
/*  81:123 */     if (oldExpr == this.condition) {
/*  82:124 */       this.condition = newExpr;
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean equals(Object o)
/*  87:    */   {
/*  88:130 */     if (o == this) {
/*  89:130 */       return true;
/*  90:    */     }
/*  91:131 */     if ((o == null) || (!(o instanceof IfExprent))) {
/*  92:131 */       return false;
/*  93:    */     }
/*  94:133 */     IfExprent ie = (IfExprent)o;
/*  95:134 */     return InterpreterUtil.equalObjects(this.condition, ie.getCondition());
/*  96:    */   }
/*  97:    */   
/*  98:    */   public IfExprent negateIf()
/*  99:    */   {
/* 100:138 */     this.condition = new FunctionExprent(12, this.condition, this.condition.bytecode);
/* 101:139 */     return this;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public Exprent getCondition()
/* 105:    */   {
/* 106:143 */     return this.condition;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void setCondition(Exprent condition)
/* 110:    */   {
/* 111:147 */     this.condition = condition;
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.IfExprent
 * JD-Core Version:    0.7.0.1
 */