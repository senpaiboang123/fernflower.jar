/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import java.util.Set;
/*   9:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  10:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  11:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  13:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  14:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  15:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable.MatchProperties;
/*  16:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  17:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode;
/*  18:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode.RuleValue;
/*  19:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  20:    */ 
/*  21:    */ public class ConstExprent
/*  22:    */   extends Exprent
/*  23:    */ {
/*  24: 36 */   private static final Map<Integer, String> ESCAPES = new HashMap() {};
/*  25:    */   private VarType constType;
/*  26:    */   private final Object value;
/*  27:    */   private final boolean boolPermitted;
/*  28:    */   
/*  29:    */   public ConstExprent(int val, boolean boolPermitted, Set<Integer> bytecodeOffsets)
/*  30:    */   {
/*  31: 52 */     this(guessType(val, boolPermitted), new Integer(val), boolPermitted, bytecodeOffsets);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public ConstExprent(VarType constType, Object value, Set<Integer> bytecodeOffsets)
/*  35:    */   {
/*  36: 56 */     this(constType, value, false, bytecodeOffsets);
/*  37:    */   }
/*  38:    */   
/*  39:    */   private ConstExprent(VarType constType, Object value, boolean boolPermitted, Set<Integer> bytecodeOffsets)
/*  40:    */   {
/*  41: 60 */     super(3);
/*  42: 61 */     this.constType = constType;
/*  43: 62 */     this.value = value;
/*  44: 63 */     this.boolPermitted = boolPermitted;
/*  45: 64 */     addBytecodeOffsets(bytecodeOffsets);
/*  46:    */   }
/*  47:    */   
/*  48:    */   private static VarType guessType(int val, boolean boolPermitted)
/*  49:    */   {
/*  50: 68 */     if (boolPermitted)
/*  51:    */     {
/*  52: 69 */       VarType constType = VarType.VARTYPE_BOOLEAN;
/*  53: 70 */       if ((val != 0) && (val != 1)) {
/*  54: 71 */         constType = constType.copy(true);
/*  55:    */       }
/*  56: 73 */       return constType;
/*  57:    */     }
/*  58: 75 */     if ((0 <= val) && (val <= 127)) {
/*  59: 76 */       return VarType.VARTYPE_BYTECHAR;
/*  60:    */     }
/*  61: 78 */     if ((-128 <= val) && (val <= 127)) {
/*  62: 79 */       return VarType.VARTYPE_BYTE;
/*  63:    */     }
/*  64: 81 */     if ((0 <= val) && (val <= 32767)) {
/*  65: 82 */       return VarType.VARTYPE_SHORTCHAR;
/*  66:    */     }
/*  67: 84 */     if ((-32768 <= val) && (val <= 32767)) {
/*  68: 85 */       return VarType.VARTYPE_SHORT;
/*  69:    */     }
/*  70: 87 */     if ((0 <= val) && (val <= 65535)) {
/*  71: 88 */       return VarType.VARTYPE_CHAR;
/*  72:    */     }
/*  73: 91 */     return VarType.VARTYPE_INT;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Exprent copy()
/*  77:    */   {
/*  78: 97 */     return new ConstExprent(this.constType, this.value, this.bytecode);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public VarType getExprType()
/*  82:    */   {
/*  83:102 */     return this.constType;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public int getExprentUse()
/*  87:    */   {
/*  88:107 */     return 3;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public List<Exprent> getAllExprents()
/*  92:    */   {
/*  93:111 */     return new ArrayList();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  97:    */   {
/*  98:116 */     boolean literal = DecompilerContext.getOption("lit");
/*  99:117 */     boolean ascii = DecompilerContext.getOption("asc");
/* 100:    */     
/* 101:119 */     tracer.addMapping(this.bytecode);
/* 102:121 */     if ((this.constType.type != 13) && (this.value == null)) {
/* 103:122 */       return new TextBuffer(ExprProcessor.getCastTypeName(this.constType));
/* 104:    */     }
/* 105:125 */     switch (this.constType.type)
/* 106:    */     {
/* 107:    */     case 7: 
/* 108:127 */       return new TextBuffer(Boolean.toString(((Integer)this.value).intValue() != 0));
/* 109:    */     case 1: 
/* 110:129 */       Integer val = (Integer)this.value;
/* 111:130 */       String ret = (String)ESCAPES.get(val);
/* 112:131 */       if (ret == null)
/* 113:    */       {
/* 114:132 */         char c = (char)val.intValue();
/* 115:133 */         if (((c >= ' ') && (c < '')) || ((!ascii) && (InterpreterUtil.isPrintableUnicode(c)))) {
/* 116:134 */           ret = String.valueOf(c);
/* 117:    */         } else {
/* 118:137 */           ret = InterpreterUtil.charToUnicodeLiteral(c);
/* 119:    */         }
/* 120:    */       }
/* 121:140 */       return new TextBuffer(ret).enclose("'", "'");
/* 122:    */     case 0: 
/* 123:    */     case 4: 
/* 124:    */     case 6: 
/* 125:    */     case 15: 
/* 126:    */     case 16: 
/* 127:146 */       int ival = ((Integer)this.value).intValue();
/* 128:149 */       if (literal) {
/* 129:150 */         return new TextBuffer(this.value.toString());
/* 130:    */       }
/* 131:    */       String intfield;
/* 132:152 */       if (ival == 2147483647)
/* 133:    */       {
/* 134:153 */         intfield = "MAX_VALUE";
/* 135:    */       }
/* 136:    */       else
/* 137:    */       {
/* 138:    */         String intfield;
/* 139:155 */         if (ival == -2147483648) {
/* 140:156 */           intfield = "MIN_VALUE";
/* 141:    */         } else {
/* 142:159 */           return new TextBuffer(this.value.toString());
/* 143:    */         }
/* 144:    */       }
/* 145:    */       String intfield;
/* 146:161 */       return new FieldExprent(intfield, "java/lang/Integer", true, null, FieldDescriptor.INTEGER_DESCRIPTOR, this.bytecode).toJava(0, tracer);
/* 147:    */     case 5: 
/* 148:163 */       long lval = ((Long)this.value).longValue();
/* 149:166 */       if (literal) {
/* 150:167 */         return new TextBuffer(this.value.toString()).append("L");
/* 151:    */       }
/* 152:    */       String longfield;
/* 153:169 */       if (lval == 9223372036854775807L)
/* 154:    */       {
/* 155:170 */         longfield = "MAX_VALUE";
/* 156:    */       }
/* 157:    */       else
/* 158:    */       {
/* 159:    */         String longfield;
/* 160:172 */         if (lval == -9223372036854775808L) {
/* 161:173 */           longfield = "MIN_VALUE";
/* 162:    */         } else {
/* 163:176 */           return new TextBuffer(this.value.toString()).append("L");
/* 164:    */         }
/* 165:    */       }
/* 166:    */       String longfield;
/* 167:178 */       return new FieldExprent(longfield, "java/lang/Long", true, null, FieldDescriptor.LONG_DESCRIPTOR, this.bytecode).toJava(0, tracer);
/* 168:    */     case 2: 
/* 169:180 */       double dval = ((Double)this.value).doubleValue();
/* 170:183 */       if (literal)
/* 171:    */       {
/* 172:184 */         if (Double.isNaN(dval)) {
/* 173:185 */           return new TextBuffer("0.0D / 0.0");
/* 174:    */         }
/* 175:187 */         if (dval == (1.0D / 0.0D)) {
/* 176:188 */           return new TextBuffer("1.0D / 0.0");
/* 177:    */         }
/* 178:190 */         if (dval == (-1.0D / 0.0D)) {
/* 179:191 */           return new TextBuffer("-1.0D / 0.0");
/* 180:    */         }
/* 181:194 */         return new TextBuffer(this.value.toString()).append("D");
/* 182:    */       }
/* 183:    */       String doublefield;
/* 184:197 */       if (Double.isNaN(dval))
/* 185:    */       {
/* 186:198 */         doublefield = "NaN";
/* 187:    */       }
/* 188:    */       else
/* 189:    */       {
/* 190:    */         String doublefield;
/* 191:200 */         if (dval == (1.0D / 0.0D))
/* 192:    */         {
/* 193:201 */           doublefield = "POSITIVE_INFINITY";
/* 194:    */         }
/* 195:    */         else
/* 196:    */         {
/* 197:    */           String doublefield;
/* 198:203 */           if (dval == (-1.0D / 0.0D))
/* 199:    */           {
/* 200:204 */             doublefield = "NEGATIVE_INFINITY";
/* 201:    */           }
/* 202:    */           else
/* 203:    */           {
/* 204:    */             String doublefield;
/* 205:206 */             if (dval == 1.7976931348623157E+308D)
/* 206:    */             {
/* 207:207 */               doublefield = "MAX_VALUE";
/* 208:    */             }
/* 209:    */             else
/* 210:    */             {
/* 211:    */               String doublefield;
/* 212:209 */               if (dval == 4.9E-324D) {
/* 213:210 */                 doublefield = "MIN_VALUE";
/* 214:    */               } else {
/* 215:213 */                 return new TextBuffer(this.value.toString()).append("D");
/* 216:    */               }
/* 217:    */             }
/* 218:    */           }
/* 219:    */         }
/* 220:    */       }
/* 221:    */       String doublefield;
/* 222:215 */       return new FieldExprent(doublefield, "java/lang/Double", true, null, FieldDescriptor.DOUBLE_DESCRIPTOR, this.bytecode).toJava(0, tracer);
/* 223:    */     case 3: 
/* 224:217 */       float fval = ((Float)this.value).floatValue();
/* 225:220 */       if (literal)
/* 226:    */       {
/* 227:221 */         if (Double.isNaN(fval)) {
/* 228:222 */           return new TextBuffer("0.0F / 0.0");
/* 229:    */         }
/* 230:224 */         if (fval == (1.0D / 0.0D)) {
/* 231:225 */           return new TextBuffer("1.0F / 0.0");
/* 232:    */         }
/* 233:227 */         if (fval == (-1.0D / 0.0D)) {
/* 234:228 */           return new TextBuffer("-1.0F / 0.0");
/* 235:    */         }
/* 236:231 */         return new TextBuffer(this.value.toString()).append("F");
/* 237:    */       }
/* 238:    */       String floatfield;
/* 239:234 */       if (Float.isNaN(fval))
/* 240:    */       {
/* 241:235 */         floatfield = "NaN";
/* 242:    */       }
/* 243:    */       else
/* 244:    */       {
/* 245:    */         String floatfield;
/* 246:237 */         if (fval == (1.0F / 1.0F))
/* 247:    */         {
/* 248:238 */           floatfield = "POSITIVE_INFINITY";
/* 249:    */         }
/* 250:    */         else
/* 251:    */         {
/* 252:    */           String floatfield;
/* 253:240 */           if (fval == (1.0F / -1.0F))
/* 254:    */           {
/* 255:241 */             floatfield = "NEGATIVE_INFINITY";
/* 256:    */           }
/* 257:    */           else
/* 258:    */           {
/* 259:    */             String floatfield;
/* 260:243 */             if (fval == 3.4028235E+38F)
/* 261:    */             {
/* 262:244 */               floatfield = "MAX_VALUE";
/* 263:    */             }
/* 264:    */             else
/* 265:    */             {
/* 266:    */               String floatfield;
/* 267:246 */               if (fval == 1.4E-45F) {
/* 268:247 */                 floatfield = "MIN_VALUE";
/* 269:    */               } else {
/* 270:250 */                 return new TextBuffer(this.value.toString()).append("F");
/* 271:    */               }
/* 272:    */             }
/* 273:    */           }
/* 274:    */         }
/* 275:    */       }
/* 276:    */       String floatfield;
/* 277:252 */       return new FieldExprent(floatfield, "java/lang/Float", true, null, FieldDescriptor.FLOAT_DESCRIPTOR, this.bytecode).toJava(0, tracer);
/* 278:    */     case 13: 
/* 279:254 */       return new TextBuffer("null");
/* 280:    */     case 8: 
/* 281:256 */       if (this.constType.equals(VarType.VARTYPE_STRING)) {
/* 282:257 */         return new TextBuffer(convertStringToJava(this.value.toString(), ascii)).enclose("\"", "\"");
/* 283:    */       }
/* 284:259 */       if (this.constType.equals(VarType.VARTYPE_CLASS))
/* 285:    */       {
/* 286:260 */         String strval = this.value.toString();
/* 287:    */         VarType classtype;
/* 288:    */         VarType classtype;
/* 289:263 */         if (strval.startsWith("[")) {
/* 290:264 */           classtype = new VarType(strval, false);
/* 291:    */         } else {
/* 292:267 */           classtype = new VarType(strval, true);
/* 293:    */         }
/* 294:270 */         return new TextBuffer(ExprProcessor.getCastTypeName(classtype)).append(".class");
/* 295:    */       }
/* 296:    */       break;
/* 297:    */     }
/* 298:275 */     throw new RuntimeException("invalid constant type");
/* 299:    */   }
/* 300:    */   
/* 301:    */   private static String convertStringToJava(String value, boolean ascii)
/* 302:    */   {
/* 303:279 */     char[] arr = value.toCharArray();
/* 304:280 */     StringBuilder buffer = new StringBuilder(arr.length);
/* 305:282 */     for (char c : arr) {
/* 306:283 */       switch (c)
/* 307:    */       {
/* 308:    */       case '\\': 
/* 309:285 */         buffer.append("\\\\");
/* 310:286 */         break;
/* 311:    */       case '\b': 
/* 312:288 */         buffer.append("\\b");
/* 313:289 */         break;
/* 314:    */       case '\t': 
/* 315:291 */         buffer.append("\\t");
/* 316:292 */         break;
/* 317:    */       case '\n': 
/* 318:294 */         buffer.append("\\n");
/* 319:295 */         break;
/* 320:    */       case '\f': 
/* 321:297 */         buffer.append("\\f");
/* 322:298 */         break;
/* 323:    */       case '\r': 
/* 324:300 */         buffer.append("\\r");
/* 325:301 */         break;
/* 326:    */       case '"': 
/* 327:303 */         buffer.append("\\\"");
/* 328:304 */         break;
/* 329:    */       case '\'': 
/* 330:306 */         buffer.append("\\'");
/* 331:307 */         break;
/* 332:    */       default: 
/* 333:309 */         if (((c >= ' ') && (c < '')) || ((!ascii) && (InterpreterUtil.isPrintableUnicode(c)))) {
/* 334:310 */           buffer.append(c);
/* 335:    */         } else {
/* 336:313 */           buffer.append(InterpreterUtil.charToUnicodeLiteral(c));
/* 337:    */         }
/* 338:    */         break;
/* 339:    */       }
/* 340:    */     }
/* 341:318 */     return buffer.toString();
/* 342:    */   }
/* 343:    */   
/* 344:    */   public boolean equals(Object o)
/* 345:    */   {
/* 346:323 */     if (o == this) {
/* 347:323 */       return true;
/* 348:    */     }
/* 349:324 */     if ((o == null) || (!(o instanceof ConstExprent))) {
/* 350:324 */       return false;
/* 351:    */     }
/* 352:326 */     ConstExprent cn = (ConstExprent)o;
/* 353:327 */     return (InterpreterUtil.equalObjects(this.constType, cn.getConstType())) && (InterpreterUtil.equalObjects(this.value, cn.getValue()));
/* 354:    */   }
/* 355:    */   
/* 356:    */   public boolean hasBooleanValue()
/* 357:    */   {
/* 358:332 */     switch (this.constType.type)
/* 359:    */     {
/* 360:    */     case 0: 
/* 361:    */     case 1: 
/* 362:    */     case 4: 
/* 363:    */     case 6: 
/* 364:    */     case 7: 
/* 365:    */     case 15: 
/* 366:    */     case 16: 
/* 367:340 */       Integer ival = (Integer)this.value;
/* 368:341 */       return (ival.intValue() == 0) || ((DecompilerContext.getOption("bto")) && (ival.intValue() == 1));
/* 369:    */     }
/* 370:345 */     return false;
/* 371:    */   }
/* 372:    */   
/* 373:    */   public boolean hasValueOne()
/* 374:    */   {
/* 375:349 */     switch (this.constType.type)
/* 376:    */     {
/* 377:    */     case 0: 
/* 378:    */     case 1: 
/* 379:    */     case 4: 
/* 380:    */     case 6: 
/* 381:    */     case 7: 
/* 382:    */     case 15: 
/* 383:    */     case 16: 
/* 384:357 */       return ((Integer)this.value).intValue() == 1;
/* 385:    */     case 5: 
/* 386:359 */       return ((Long)this.value).intValue() == 1;
/* 387:    */     case 2: 
/* 388:361 */       return ((Double)this.value).intValue() == 1;
/* 389:    */     case 3: 
/* 390:363 */       return ((Float)this.value).intValue() == 1;
/* 391:    */     }
/* 392:366 */     return false;
/* 393:    */   }
/* 394:    */   
/* 395:    */   public static ConstExprent getZeroConstant(int type)
/* 396:    */   {
/* 397:370 */     switch (type)
/* 398:    */     {
/* 399:    */     case 4: 
/* 400:372 */       return new ConstExprent(VarType.VARTYPE_INT, new Integer(0), null);
/* 401:    */     case 5: 
/* 402:374 */       return new ConstExprent(VarType.VARTYPE_LONG, new Long(0L), null);
/* 403:    */     case 2: 
/* 404:376 */       return new ConstExprent(VarType.VARTYPE_DOUBLE, new Double(0.0D), null);
/* 405:    */     case 3: 
/* 406:378 */       return new ConstExprent(VarType.VARTYPE_FLOAT, new Float(0.0F), null);
/* 407:    */     }
/* 408:381 */     throw new RuntimeException("Invalid argument!");
/* 409:    */   }
/* 410:    */   
/* 411:    */   public VarType getConstType()
/* 412:    */   {
/* 413:385 */     return this.constType;
/* 414:    */   }
/* 415:    */   
/* 416:    */   public void setConstType(VarType constType)
/* 417:    */   {
/* 418:389 */     this.constType = constType;
/* 419:    */   }
/* 420:    */   
/* 421:    */   public Object getValue()
/* 422:    */   {
/* 423:393 */     return this.value;
/* 424:    */   }
/* 425:    */   
/* 426:    */   public int getIntValue()
/* 427:    */   {
/* 428:397 */     return ((Integer)this.value).intValue();
/* 429:    */   }
/* 430:    */   
/* 431:    */   public boolean isBoolPermitted()
/* 432:    */   {
/* 433:401 */     return this.boolPermitted;
/* 434:    */   }
/* 435:    */   
/* 436:    */   public boolean match(MatchNode matchNode, MatchEngine engine)
/* 437:    */   {
/* 438:410 */     if (!super.match(matchNode, engine)) {
/* 439:411 */       return false;
/* 440:    */     }
/* 441:414 */     for (Map.Entry<IMatchable.MatchProperties, MatchNode.RuleValue> rule : matchNode.getRules().entrySet())
/* 442:    */     {
/* 443:415 */       MatchNode.RuleValue rule_value = (MatchNode.RuleValue)rule.getValue();
/* 444:417 */       switch (2.$SwitchMap$org$jetbrains$java$decompiler$struct$match$IMatchable$MatchProperties[((IMatchable.MatchProperties)rule.getKey()).ordinal()])
/* 445:    */       {
/* 446:    */       case 1: 
/* 447:419 */         if (!rule_value.value.equals(this.constType)) {
/* 448:420 */           return false;
/* 449:    */         }
/* 450:    */         break;
/* 451:    */       case 2: 
/* 452:424 */         if ((rule_value.isVariable()) && 
/* 453:425 */           (!engine.checkAndSetVariableValue(rule_value.value.toString(), this.value))) {
/* 454:426 */           return false;
/* 455:    */         }
/* 456:    */         break;
/* 457:    */       }
/* 458:    */     }
/* 459:433 */     return true;
/* 460:    */   }
/* 461:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent
 * JD-Core Version:    0.7.0.1
 */