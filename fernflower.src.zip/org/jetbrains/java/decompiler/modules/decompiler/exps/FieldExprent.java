/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*   8:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   9:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  10:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  11:    */ import org.jetbrains.java.decompiler.main.collectors.ImportCollector;
/*  12:    */ import org.jetbrains.java.decompiler.main.rels.MethodWrapper;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  16:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  17:    */ import org.jetbrains.java.decompiler.struct.consts.LinkConstant;
/*  18:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  19:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  20:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable.MatchProperties;
/*  21:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  22:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode;
/*  23:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode.RuleValue;
/*  24:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  25:    */ import org.jetbrains.java.decompiler.util.TextUtil;
/*  26:    */ 
/*  27:    */ public class FieldExprent
/*  28:    */   extends Exprent
/*  29:    */ {
/*  30:    */   private final String name;
/*  31:    */   private final String classname;
/*  32:    */   private final boolean isStatic;
/*  33:    */   private Exprent instance;
/*  34:    */   private final FieldDescriptor descriptor;
/*  35:    */   
/*  36:    */   public FieldExprent(LinkConstant cn, Exprent instance, Set<Integer> bytecodeOffsets)
/*  37:    */   {
/*  38: 49 */     this(cn.elementname, cn.classname, instance == null, instance, FieldDescriptor.parseDescriptor(cn.descriptor), bytecodeOffsets);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public FieldExprent(String name, String classname, boolean isStatic, Exprent instance, FieldDescriptor descriptor, Set<Integer> bytecodeOffsets)
/*  42:    */   {
/*  43: 53 */     super(5);
/*  44: 54 */     this.name = name;
/*  45: 55 */     this.classname = classname;
/*  46: 56 */     this.isStatic = isStatic;
/*  47: 57 */     this.instance = instance;
/*  48: 58 */     this.descriptor = descriptor;
/*  49:    */     
/*  50: 60 */     addBytecodeOffsets(bytecodeOffsets);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public VarType getExprType()
/*  54:    */   {
/*  55: 65 */     return this.descriptor.type;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public int getExprentUse()
/*  59:    */   {
/*  60: 70 */     return this.instance == null ? 1 : this.instance.getExprentUse() & 0x1;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public List<Exprent> getAllExprents()
/*  64:    */   {
/*  65: 75 */     List<Exprent> lst = new ArrayList();
/*  66: 76 */     if (this.instance != null) {
/*  67: 77 */       lst.add(this.instance);
/*  68:    */     }
/*  69: 79 */     return lst;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public Exprent copy()
/*  73:    */   {
/*  74: 84 */     return new FieldExprent(this.name, this.classname, this.isStatic, this.instance == null ? null : this.instance.copy(), this.descriptor, this.bytecode);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  78:    */   {
/*  79: 89 */     TextBuffer buf = new TextBuffer();
/*  80: 91 */     if (this.isStatic)
/*  81:    */     {
/*  82: 92 */       ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)DecompilerContext.getProperty("CURRENT_CLASS_NODE");
/*  83: 93 */       if ((node == null) || (!this.classname.equals(node.classStruct.qualifiedName)))
/*  84:    */       {
/*  85: 94 */         buf.append(DecompilerContext.getImportCollector().getShortName(ExprProcessor.buildJavaClassName(this.classname)));
/*  86: 95 */         buf.append(".");
/*  87:    */       }
/*  88:    */     }
/*  89:    */     else
/*  90:    */     {
/*  91: 99 */       String super_qualifier = null;
/*  92:101 */       if ((this.instance != null) && (this.instance.type == 12))
/*  93:    */       {
/*  94:102 */         VarExprent instVar = (VarExprent)this.instance;
/*  95:103 */         VarVersionPair pair = new VarVersionPair(instVar);
/*  96:    */         
/*  97:105 */         MethodWrapper currentMethod = (MethodWrapper)DecompilerContext.getProperty("CURRENT_METHOD_WRAPPER");
/*  98:107 */         if (currentMethod != null)
/*  99:    */         {
/* 100:108 */           String this_classname = (String)currentMethod.varproc.getThisVars().get(pair);
/* 101:110 */           if ((this_classname != null) && 
/* 102:111 */             (!this.classname.equals(this_classname))) {
/* 103:112 */             super_qualifier = this_classname;
/* 104:    */           }
/* 105:    */         }
/* 106:    */       }
/* 107:118 */       if (super_qualifier != null)
/* 108:    */       {
/* 109:119 */         TextUtil.writeQualifiedSuper(buf, super_qualifier);
/* 110:    */       }
/* 111:    */       else
/* 112:    */       {
/* 113:122 */         TextBuffer buff = new TextBuffer();
/* 114:123 */         boolean casted = ExprProcessor.getCastedExprent(this.instance, new VarType(8, 0, this.classname), buff, indent, true, tracer);
/* 115:124 */         String res = buff.toString();
/* 116:126 */         if ((casted) || (this.instance.getPrecedence() > getPrecedence())) {
/* 117:127 */           res = "(" + res + ")";
/* 118:    */         }
/* 119:130 */         buf.append(res);
/* 120:    */       }
/* 121:133 */       if (buf.toString().equals("<VAR_NAMELESS_ENCLOSURE>")) {
/* 122:135 */         buf.setLength(0);
/* 123:    */       } else {
/* 124:138 */         buf.append(".");
/* 125:    */       }
/* 126:    */     }
/* 127:142 */     buf.append(this.name);
/* 128:    */     
/* 129:144 */     tracer.addMapping(this.bytecode);
/* 130:    */     
/* 131:146 */     return buf;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/* 135:    */   {
/* 136:151 */     if (oldExpr == this.instance) {
/* 137:152 */       this.instance = newExpr;
/* 138:    */     }
/* 139:    */   }
/* 140:    */   
/* 141:    */   public boolean equals(Object o)
/* 142:    */   {
/* 143:158 */     if (o == this) {
/* 144:158 */       return true;
/* 145:    */     }
/* 146:159 */     if ((o == null) || (!(o instanceof FieldExprent))) {
/* 147:159 */       return false;
/* 148:    */     }
/* 149:161 */     FieldExprent ft = (FieldExprent)o;
/* 150:162 */     return (InterpreterUtil.equalObjects(this.name, ft.getName())) && (InterpreterUtil.equalObjects(this.classname, ft.getClassname())) && (this.isStatic == ft.isStatic()) && (InterpreterUtil.equalObjects(this.instance, ft.getInstance())) && (InterpreterUtil.equalObjects(this.descriptor, ft.getDescriptor()));
/* 151:    */   }
/* 152:    */   
/* 153:    */   public String getClassname()
/* 154:    */   {
/* 155:170 */     return this.classname;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public FieldDescriptor getDescriptor()
/* 159:    */   {
/* 160:174 */     return this.descriptor;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public Exprent getInstance()
/* 164:    */   {
/* 165:178 */     return this.instance;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public boolean isStatic()
/* 169:    */   {
/* 170:182 */     return this.isStatic;
/* 171:    */   }
/* 172:    */   
/* 173:    */   public String getName()
/* 174:    */   {
/* 175:186 */     return this.name;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public boolean match(MatchNode matchNode, MatchEngine engine)
/* 179:    */   {
/* 180:195 */     if (!super.match(matchNode, engine)) {
/* 181:196 */       return false;
/* 182:    */     }
/* 183:199 */     MatchNode.RuleValue rule = (MatchNode.RuleValue)matchNode.getRules().get(IMatchable.MatchProperties.EXPRENT_FIELD_NAME);
/* 184:200 */     if (rule != null) {
/* 185:201 */       if (rule.isVariable())
/* 186:    */       {
/* 187:202 */         if (!engine.checkAndSetVariableValue((String)rule.value, this.name)) {
/* 188:203 */           return false;
/* 189:    */         }
/* 190:    */       }
/* 191:206 */       else if (!rule.value.equals(this.name)) {
/* 192:207 */         return false;
/* 193:    */       }
/* 194:    */     }
/* 195:212 */     return true;
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.FieldExprent
 * JD-Core Version:    0.7.0.1
 */