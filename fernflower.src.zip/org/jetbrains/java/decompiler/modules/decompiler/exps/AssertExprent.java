/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  5:   */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  6:   */ 
/*  7:   */ public class AssertExprent
/*  8:   */   extends Exprent
/*  9:   */ {
/* 10:   */   private final List<Exprent> parameters;
/* 11:   */   
/* 12:   */   public AssertExprent(List<Exprent> parameters)
/* 13:   */   {
/* 14:28 */     super(14);
/* 15:29 */     this.parameters = parameters;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 19:   */   {
/* 20:34 */     TextBuffer buffer = new TextBuffer();
/* 21:   */     
/* 22:36 */     buffer.append("assert ");
/* 23:   */     
/* 24:38 */     tracer.addMapping(this.bytecode);
/* 25:40 */     if (this.parameters.get(0) == null) {
/* 26:41 */       buffer.append("false");
/* 27:   */     } else {
/* 28:44 */       buffer.append(((Exprent)this.parameters.get(0)).toJava(indent, tracer));
/* 29:   */     }
/* 30:47 */     if (this.parameters.size() > 1)
/* 31:   */     {
/* 32:48 */       buffer.append(" : ");
/* 33:49 */       buffer.append(((Exprent)this.parameters.get(1)).toJava(indent, tracer));
/* 34:   */     }
/* 35:52 */     return buffer;
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.AssertExprent
 * JD-Core Version:    0.7.0.1
 */