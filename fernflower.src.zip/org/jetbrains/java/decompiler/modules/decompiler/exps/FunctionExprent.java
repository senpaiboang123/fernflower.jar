/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   9:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.CheckTypesResult;
/*  12:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  13:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable.MatchProperties;
/*  14:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  15:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode;
/*  16:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  17:    */ import org.jetbrains.java.decompiler.util.ListStack;
/*  18:    */ 
/*  19:    */ public class FunctionExprent
/*  20:    */   extends Exprent
/*  21:    */ {
/*  22:    */   public static final int FUNCTION_ADD = 0;
/*  23:    */   public static final int FUNCTION_SUB = 1;
/*  24:    */   public static final int FUNCTION_MUL = 2;
/*  25:    */   public static final int FUNCTION_DIV = 3;
/*  26:    */   public static final int FUNCTION_AND = 4;
/*  27:    */   public static final int FUNCTION_OR = 5;
/*  28:    */   public static final int FUNCTION_XOR = 6;
/*  29:    */   public static final int FUNCTION_REM = 7;
/*  30:    */   public static final int FUNCTION_SHL = 8;
/*  31:    */   public static final int FUNCTION_SHR = 9;
/*  32:    */   public static final int FUNCTION_USHR = 10;
/*  33:    */   public static final int FUNCTION_BIT_NOT = 11;
/*  34:    */   public static final int FUNCTION_BOOL_NOT = 12;
/*  35:    */   public static final int FUNCTION_NEG = 13;
/*  36:    */   public static final int FUNCTION_I2L = 14;
/*  37:    */   public static final int FUNCTION_I2F = 15;
/*  38:    */   public static final int FUNCTION_I2D = 16;
/*  39:    */   public static final int FUNCTION_L2I = 17;
/*  40:    */   public static final int FUNCTION_L2F = 18;
/*  41:    */   public static final int FUNCTION_L2D = 19;
/*  42:    */   public static final int FUNCTION_F2I = 20;
/*  43:    */   public static final int FUNCTION_F2L = 21;
/*  44:    */   public static final int FUNCTION_F2D = 22;
/*  45:    */   public static final int FUNCTION_D2I = 23;
/*  46:    */   public static final int FUNCTION_D2L = 24;
/*  47:    */   public static final int FUNCTION_D2F = 25;
/*  48:    */   public static final int FUNCTION_I2B = 26;
/*  49:    */   public static final int FUNCTION_I2C = 27;
/*  50:    */   public static final int FUNCTION_I2S = 28;
/*  51:    */   public static final int FUNCTION_CAST = 29;
/*  52:    */   public static final int FUNCTION_INSTANCEOF = 30;
/*  53:    */   public static final int FUNCTION_ARRAY_LENGTH = 31;
/*  54:    */   public static final int FUNCTION_IMM = 32;
/*  55:    */   public static final int FUNCTION_MMI = 33;
/*  56:    */   public static final int FUNCTION_IPP = 34;
/*  57:    */   public static final int FUNCTION_PPI = 35;
/*  58:    */   public static final int FUNCTION_IIF = 36;
/*  59:    */   public static final int FUNCTION_LCMP = 37;
/*  60:    */   public static final int FUNCTION_FCMPL = 38;
/*  61:    */   public static final int FUNCTION_FCMPG = 39;
/*  62:    */   public static final int FUNCTION_DCMPL = 40;
/*  63:    */   public static final int FUNCTION_DCMPG = 41;
/*  64:    */   public static final int FUNCTION_EQ = 42;
/*  65:    */   public static final int FUNCTION_NE = 43;
/*  66:    */   public static final int FUNCTION_LT = 44;
/*  67:    */   public static final int FUNCTION_GE = 45;
/*  68:    */   public static final int FUNCTION_GT = 46;
/*  69:    */   public static final int FUNCTION_LE = 47;
/*  70:    */   public static final int FUNCTION_CADD = 48;
/*  71:    */   public static final int FUNCTION_COR = 49;
/*  72:    */   public static final int FUNCTION_STR_CONCAT = 50;
/*  73: 99 */   private static final VarType[] TYPES = { VarType.VARTYPE_LONG, VarType.VARTYPE_FLOAT, VarType.VARTYPE_DOUBLE, VarType.VARTYPE_INT, VarType.VARTYPE_FLOAT, VarType.VARTYPE_DOUBLE, VarType.VARTYPE_INT, VarType.VARTYPE_LONG, VarType.VARTYPE_DOUBLE, VarType.VARTYPE_INT, VarType.VARTYPE_LONG, VarType.VARTYPE_FLOAT, VarType.VARTYPE_BYTE, VarType.VARTYPE_CHAR, VarType.VARTYPE_SHORT };
/*  74:117 */   private static final String[] OPERATORS = { " + ", " - ", " * ", " / ", " & ", " | ", " ^ ", " % ", " << ", " >> ", " >>> ", " == ", " != ", " < ", " >= ", " > ", " <= ", " && ", " || ", " + " };
/*  75:140 */   private static final int[] PRECEDENCE = { 3, 3, 2, 2, 7, 9, 8, 2, 4, 4, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 0, 1, 1, 1, 1, 12, -1, -1, -1, -1, -1, 6, 6, 5, 5, 5, 5, 10, 11, 3 };
/*  76:194 */   private static final Set<Integer> ASSOCIATIVITY = new HashSet(Arrays.asList(new Integer[] { Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(48), Integer.valueOf(49), Integer.valueOf(50) }));
/*  77:    */   private int funcType;
/*  78:    */   private VarType implicitType;
/*  79:    */   private final List<Exprent> lstOperands;
/*  80:    */   
/*  81:    */   public FunctionExprent(int funcType, ListStack<Exprent> stack, Set<Integer> bytecodeOffsets)
/*  82:    */   {
/*  83:202 */     this(funcType, new ArrayList(), bytecodeOffsets);
/*  84:204 */     if ((funcType >= 11) && (funcType <= 35) && (funcType != 29) && (funcType != 30))
/*  85:    */     {
/*  86:205 */       this.lstOperands.add(stack.pop());
/*  87:    */     }
/*  88:    */     else
/*  89:    */     {
/*  90:207 */       if (funcType == 36) {
/*  91:208 */         throw new RuntimeException("no direct instantiation possible");
/*  92:    */       }
/*  93:211 */       Exprent expr = (Exprent)stack.pop();
/*  94:212 */       this.lstOperands.add(stack.pop());
/*  95:213 */       this.lstOperands.add(expr);
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public FunctionExprent(int funcType, List<Exprent> operands, Set<Integer> bytecodeOffsets)
/* 100:    */   {
/* 101:218 */     super(6);
/* 102:219 */     this.funcType = funcType;
/* 103:220 */     this.lstOperands = operands;
/* 104:    */     
/* 105:222 */     addBytecodeOffsets(bytecodeOffsets);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public FunctionExprent(int funcType, Exprent operand, Set<Integer> bytecodeOffsets)
/* 109:    */   {
/* 110:226 */     this(funcType, new ArrayList(1), bytecodeOffsets);
/* 111:227 */     this.lstOperands.add(operand);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public VarType getExprType()
/* 115:    */   {
/* 116:232 */     VarType exprType = null;
/* 117:234 */     if ((this.funcType <= 13) || (this.funcType == 34) || (this.funcType == 35) || (this.funcType == 32) || (this.funcType == 33))
/* 118:    */     {
/* 119:237 */       VarType type1 = ((Exprent)this.lstOperands.get(0)).getExprType();
/* 120:238 */       VarType type2 = null;
/* 121:239 */       if (this.lstOperands.size() > 1) {
/* 122:240 */         type2 = ((Exprent)this.lstOperands.get(1)).getExprType();
/* 123:    */       }
/* 124:243 */       switch (this.funcType)
/* 125:    */       {
/* 126:    */       case 32: 
/* 127:    */       case 33: 
/* 128:    */       case 34: 
/* 129:    */       case 35: 
/* 130:248 */         exprType = this.implicitType;
/* 131:249 */         break;
/* 132:    */       case 12: 
/* 133:251 */         exprType = VarType.VARTYPE_BOOLEAN;
/* 134:252 */         break;
/* 135:    */       case 8: 
/* 136:    */       case 9: 
/* 137:    */       case 10: 
/* 138:    */       case 11: 
/* 139:    */       case 13: 
/* 140:258 */         exprType = getMaxVarType(new VarType[] { type1 });
/* 141:259 */         break;
/* 142:    */       case 0: 
/* 143:    */       case 1: 
/* 144:    */       case 2: 
/* 145:    */       case 3: 
/* 146:    */       case 7: 
/* 147:265 */         exprType = getMaxVarType(new VarType[] { type1, type2 });
/* 148:266 */         break;
/* 149:    */       case 4: 
/* 150:    */       case 5: 
/* 151:    */       case 6: 
/* 152:270 */         if (((type1.type == 7 ? 1 : 0) & (type2.type == 7 ? 1 : 0)) != 0) {
/* 153:271 */           exprType = VarType.VARTYPE_BOOLEAN;
/* 154:    */         } else {
/* 155:274 */           exprType = getMaxVarType(new VarType[] { type1, type2 });
/* 156:    */         }
/* 157:    */         break;
/* 158:    */       }
/* 159:    */     }
/* 160:278 */     else if (this.funcType == 29)
/* 161:    */     {
/* 162:279 */       exprType = ((Exprent)this.lstOperands.get(1)).getExprType();
/* 163:    */     }
/* 164:281 */     else if (this.funcType == 36)
/* 165:    */     {
/* 166:282 */       Exprent param1 = (Exprent)this.lstOperands.get(1);
/* 167:283 */       Exprent param2 = (Exprent)this.lstOperands.get(2);
/* 168:284 */       VarType supertype = VarType.getCommonSupertype(param1.getExprType(), param2.getExprType());
/* 169:286 */       if ((param1.type == 3) && (param2.type == 3) && (supertype.type != 7) && (VarType.VARTYPE_INT.isSuperset(supertype))) {
/* 170:288 */         exprType = VarType.VARTYPE_INT;
/* 171:    */       } else {
/* 172:291 */         exprType = supertype;
/* 173:    */       }
/* 174:    */     }
/* 175:294 */     else if (this.funcType == 50)
/* 176:    */     {
/* 177:295 */       exprType = VarType.VARTYPE_STRING;
/* 178:    */     }
/* 179:297 */     else if ((this.funcType >= 42) || (this.funcType == 30))
/* 180:    */     {
/* 181:298 */       exprType = VarType.VARTYPE_BOOLEAN;
/* 182:    */     }
/* 183:300 */     else if (this.funcType >= 31)
/* 184:    */     {
/* 185:301 */       exprType = VarType.VARTYPE_INT;
/* 186:    */     }
/* 187:    */     else
/* 188:    */     {
/* 189:304 */       exprType = TYPES[(this.funcType - 14)];
/* 190:    */     }
/* 191:307 */     return exprType;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public int getExprentUse()
/* 195:    */   {
/* 196:312 */     if ((this.funcType >= 32) && (this.funcType <= 35)) {
/* 197:313 */       return 0;
/* 198:    */     }
/* 199:316 */     int ret = 3;
/* 200:317 */     for (Exprent expr : this.lstOperands) {
/* 201:318 */       ret &= expr.getExprentUse();
/* 202:    */     }
/* 203:320 */     return ret;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public CheckTypesResult checkExprTypeBounds()
/* 207:    */   {
/* 208:326 */     CheckTypesResult result = new CheckTypesResult();
/* 209:    */     
/* 210:328 */     Exprent param1 = (Exprent)this.lstOperands.get(0);
/* 211:329 */     VarType type1 = param1.getExprType();
/* 212:330 */     Exprent param2 = null;
/* 213:331 */     VarType type2 = null;
/* 214:333 */     if (this.lstOperands.size() > 1)
/* 215:    */     {
/* 216:334 */       param2 = (Exprent)this.lstOperands.get(1);
/* 217:335 */       type2 = param2.getExprType();
/* 218:    */     }
/* 219:338 */     switch (this.funcType)
/* 220:    */     {
/* 221:    */     case 36: 
/* 222:340 */       VarType supertype = getExprType();
/* 223:341 */       if (supertype == null) {
/* 224:342 */         supertype = getExprType();
/* 225:    */       }
/* 226:344 */       result.addMinTypeExprent(param1, VarType.VARTYPE_BOOLEAN);
/* 227:345 */       result.addMinTypeExprent(param2, VarType.getMinTypeInFamily(supertype.typeFamily));
/* 228:346 */       result.addMinTypeExprent((Exprent)this.lstOperands.get(2), VarType.getMinTypeInFamily(supertype.typeFamily));
/* 229:347 */       break;
/* 230:    */     case 14: 
/* 231:    */     case 15: 
/* 232:    */     case 16: 
/* 233:    */     case 26: 
/* 234:    */     case 27: 
/* 235:    */     case 28: 
/* 236:354 */       result.addMinTypeExprent(param1, VarType.VARTYPE_BYTECHAR);
/* 237:355 */       result.addMaxTypeExprent(param1, VarType.VARTYPE_INT);
/* 238:356 */       break;
/* 239:    */     case 32: 
/* 240:    */     case 33: 
/* 241:    */     case 34: 
/* 242:    */     case 35: 
/* 243:361 */       result.addMinTypeExprent(param1, this.implicitType);
/* 244:362 */       result.addMaxTypeExprent(param1, this.implicitType);
/* 245:363 */       break;
/* 246:    */     case 0: 
/* 247:    */     case 1: 
/* 248:    */     case 2: 
/* 249:    */     case 3: 
/* 250:    */     case 7: 
/* 251:    */     case 8: 
/* 252:    */     case 9: 
/* 253:    */     case 10: 
/* 254:    */     case 44: 
/* 255:    */     case 45: 
/* 256:    */     case 46: 
/* 257:    */     case 47: 
/* 258:376 */       result.addMinTypeExprent(param2, VarType.VARTYPE_BYTECHAR);
/* 259:    */     case 11: 
/* 260:    */     case 13: 
/* 261:380 */       result.addMinTypeExprent(param1, VarType.VARTYPE_BYTECHAR);
/* 262:381 */       break;
/* 263:    */     case 4: 
/* 264:    */     case 5: 
/* 265:    */     case 6: 
/* 266:    */     case 42: 
/* 267:    */     case 43: 
/* 268:387 */       if (type1.type == 7)
/* 269:    */       {
/* 270:388 */         if (type2.isStrictSuperset(type1))
/* 271:    */         {
/* 272:389 */           result.addMinTypeExprent(param1, VarType.VARTYPE_BYTECHAR);
/* 273:    */         }
/* 274:    */         else
/* 275:    */         {
/* 276:392 */           boolean param1_false_boolean = (type1.isFalseBoolean()) || ((param1.type == 3) && (!((ConstExprent)param1).hasBooleanValue()));
/* 277:    */           
/* 278:394 */           boolean param2_false_boolean = (type1.isFalseBoolean()) || ((param2.type == 3) && (!((ConstExprent)param2).hasBooleanValue()));
/* 279:397 */           if ((param1_false_boolean) || (param2_false_boolean))
/* 280:    */           {
/* 281:398 */             result.addMinTypeExprent(param1, VarType.VARTYPE_BYTECHAR);
/* 282:399 */             result.addMinTypeExprent(param2, VarType.VARTYPE_BYTECHAR);
/* 283:    */           }
/* 284:    */         }
/* 285:    */       }
/* 286:403 */       else if ((type2.type == 7) && 
/* 287:404 */         (type1.isStrictSuperset(type2))) {
/* 288:405 */         result.addMinTypeExprent(param2, VarType.VARTYPE_BYTECHAR);
/* 289:    */       }
/* 290:    */       break;
/* 291:    */     }
/* 292:411 */     return result;
/* 293:    */   }
/* 294:    */   
/* 295:    */   public List<Exprent> getAllExprents()
/* 296:    */   {
/* 297:416 */     List<Exprent> lst = new ArrayList();
/* 298:417 */     lst.addAll(this.lstOperands);
/* 299:418 */     return lst;
/* 300:    */   }
/* 301:    */   
/* 302:    */   public Exprent copy()
/* 303:    */   {
/* 304:423 */     List<Exprent> lst = new ArrayList();
/* 305:424 */     for (Exprent expr : this.lstOperands) {
/* 306:425 */       lst.add(expr.copy());
/* 307:    */     }
/* 308:427 */     FunctionExprent func = new FunctionExprent(this.funcType, lst, this.bytecode);
/* 309:428 */     func.setImplicitType(this.implicitType);
/* 310:    */     
/* 311:430 */     return func;
/* 312:    */   }
/* 313:    */   
/* 314:    */   public boolean equals(Object o)
/* 315:    */   {
/* 316:435 */     if (o == this) {
/* 317:435 */       return true;
/* 318:    */     }
/* 319:436 */     if ((o == null) || (!(o instanceof FunctionExprent))) {
/* 320:436 */       return false;
/* 321:    */     }
/* 322:438 */     FunctionExprent fe = (FunctionExprent)o;
/* 323:439 */     return (this.funcType == fe.getFuncType()) && (InterpreterUtil.equalLists(this.lstOperands, fe.getLstOperands()));
/* 324:    */   }
/* 325:    */   
/* 326:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/* 327:    */   {
/* 328:445 */     for (int i = 0; i < this.lstOperands.size(); i++) {
/* 329:446 */       if (oldExpr == this.lstOperands.get(i)) {
/* 330:447 */         this.lstOperands.set(i, newExpr);
/* 331:    */       }
/* 332:    */     }
/* 333:    */   }
/* 334:    */   
/* 335:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 336:    */   {
/* 337:454 */     tracer.addMapping(this.bytecode);
/* 338:456 */     if (this.funcType <= 10) {
/* 339:457 */       return wrapOperandString((Exprent)this.lstOperands.get(0), false, indent, tracer).append(OPERATORS[this.funcType]).append(wrapOperandString((Exprent)this.lstOperands.get(1), true, indent, tracer));
/* 340:    */     }
/* 341:462 */     if (this.funcType >= 42) {
/* 342:463 */       return wrapOperandString((Exprent)this.lstOperands.get(0), false, indent, tracer).append(OPERATORS[(this.funcType - 42 + 11)]).append(wrapOperandString((Exprent)this.lstOperands.get(1), true, indent, tracer));
/* 343:    */     }
/* 344:468 */     switch (this.funcType)
/* 345:    */     {
/* 346:    */     case 11: 
/* 347:470 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("~");
/* 348:    */     case 12: 
/* 349:472 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("!");
/* 350:    */     case 13: 
/* 351:474 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("-");
/* 352:    */     case 29: 
/* 353:476 */       return ((Exprent)this.lstOperands.get(1)).toJava(indent, tracer).enclose("(", ")").append(wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer));
/* 354:    */     case 31: 
/* 355:478 */       Exprent arr = (Exprent)this.lstOperands.get(0);
/* 356:    */       
/* 357:480 */       TextBuffer res = wrapOperandString(arr, false, indent, tracer);
/* 358:481 */       if (arr.getExprType().arrayDim == 0)
/* 359:    */       {
/* 360:482 */         VarType objArr = VarType.VARTYPE_OBJECT.resizeArrayDim(1);
/* 361:483 */         res.enclose("((" + ExprProcessor.getCastTypeName(objArr) + ")", ")");
/* 362:    */       }
/* 363:485 */       return res.append(".length");
/* 364:    */     case 36: 
/* 365:487 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).append("?").append(wrapOperandString((Exprent)this.lstOperands.get(1), true, indent, tracer)).append(":").append(wrapOperandString((Exprent)this.lstOperands.get(2), true, indent, tracer));
/* 366:    */     case 34: 
/* 367:493 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).append("++");
/* 368:    */     case 35: 
/* 369:495 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("++");
/* 370:    */     case 32: 
/* 371:497 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).append("--");
/* 372:    */     case 33: 
/* 373:499 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("--");
/* 374:    */     case 30: 
/* 375:501 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).append(" instanceof ").append(wrapOperandString((Exprent)this.lstOperands.get(1), true, indent, tracer));
/* 376:    */     case 37: 
/* 377:503 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("__lcmp__(").append(",").append(wrapOperandString((Exprent)this.lstOperands.get(1), true, indent, tracer)).append(")");
/* 378:    */     case 38: 
/* 379:508 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("__fcmpl__(").append(",").append(wrapOperandString((Exprent)this.lstOperands.get(1), true, indent, tracer)).append(")");
/* 380:    */     case 39: 
/* 381:513 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("__fcmpg__(").append(",").append(wrapOperandString((Exprent)this.lstOperands.get(1), true, indent, tracer)).append(")");
/* 382:    */     case 40: 
/* 383:518 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("__dcmpl__(").append(",").append(wrapOperandString((Exprent)this.lstOperands.get(1), true, indent, tracer)).append(")");
/* 384:    */     case 41: 
/* 385:523 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("__dcmpg__(").append(",").append(wrapOperandString((Exprent)this.lstOperands.get(1), true, indent, tracer)).append(")");
/* 386:    */     }
/* 387:529 */     if (this.funcType <= 28) {
/* 388:530 */       return wrapOperandString((Exprent)this.lstOperands.get(0), true, indent, tracer).prepend("(" + ExprProcessor.getTypeName(TYPES[(this.funcType - 14)]) + ")");
/* 389:    */     }
/* 390:535 */     throw new RuntimeException("invalid function");
/* 391:    */   }
/* 392:    */   
/* 393:    */   public int getPrecedence()
/* 394:    */   {
/* 395:540 */     return getPrecedence(this.funcType);
/* 396:    */   }
/* 397:    */   
/* 398:    */   public static int getPrecedence(int func)
/* 399:    */   {
/* 400:544 */     return PRECEDENCE[func];
/* 401:    */   }
/* 402:    */   
/* 403:    */   public VarType getSimpleCastType()
/* 404:    */   {
/* 405:548 */     return TYPES[(this.funcType - 14)];
/* 406:    */   }
/* 407:    */   
/* 408:    */   private TextBuffer wrapOperandString(Exprent expr, boolean eq, int indent, BytecodeMappingTracer tracer)
/* 409:    */   {
/* 410:552 */     int myprec = getPrecedence();
/* 411:553 */     int exprprec = expr.getPrecedence();
/* 412:    */     
/* 413:555 */     boolean parentheses = exprprec > myprec;
/* 414:556 */     if ((!parentheses) && (eq))
/* 415:    */     {
/* 416:557 */       parentheses = exprprec == myprec;
/* 417:558 */       if ((parentheses) && 
/* 418:559 */         (expr.type == 6) && (((FunctionExprent)expr).getFuncType() == this.funcType)) {
/* 419:561 */         parentheses = !ASSOCIATIVITY.contains(Integer.valueOf(this.funcType));
/* 420:    */       }
/* 421:    */     }
/* 422:566 */     TextBuffer res = expr.toJava(indent, tracer);
/* 423:568 */     if (parentheses) {
/* 424:569 */       res.enclose("(", ")");
/* 425:    */     }
/* 426:572 */     return res;
/* 427:    */   }
/* 428:    */   
/* 429:    */   private static VarType getMaxVarType(VarType[] arr)
/* 430:    */   {
/* 431:576 */     int[] types = { 2, 3, 5 };
/* 432:577 */     VarType[] vartypes = { VarType.VARTYPE_DOUBLE, VarType.VARTYPE_FLOAT, VarType.VARTYPE_LONG };
/* 433:579 */     for (int i = 0; i < types.length; i++) {
/* 434:580 */       for (int j = 0; j < arr.length; j++) {
/* 435:581 */         if (arr[j].type == types[i]) {
/* 436:582 */           return vartypes[i];
/* 437:    */         }
/* 438:    */       }
/* 439:    */     }
/* 440:587 */     return VarType.VARTYPE_INT;
/* 441:    */   }
/* 442:    */   
/* 443:    */   public int getFuncType()
/* 444:    */   {
/* 445:595 */     return this.funcType;
/* 446:    */   }
/* 447:    */   
/* 448:    */   public void setFuncType(int funcType)
/* 449:    */   {
/* 450:599 */     this.funcType = funcType;
/* 451:    */   }
/* 452:    */   
/* 453:    */   public List<Exprent> getLstOperands()
/* 454:    */   {
/* 455:603 */     return this.lstOperands;
/* 456:    */   }
/* 457:    */   
/* 458:    */   public void setImplicitType(VarType implicitType)
/* 459:    */   {
/* 460:607 */     this.implicitType = implicitType;
/* 461:    */   }
/* 462:    */   
/* 463:    */   public boolean match(MatchNode matchNode, MatchEngine engine)
/* 464:    */   {
/* 465:616 */     if (!super.match(matchNode, engine)) {
/* 466:617 */       return false;
/* 467:    */     }
/* 468:620 */     Integer type = (Integer)matchNode.getRuleValue(IMatchable.MatchProperties.EXPRENT_FUNCTYPE);
/* 469:621 */     if ((type != null) && 
/* 470:622 */       (this.funcType != type.intValue())) {
/* 471:623 */       return false;
/* 472:    */     }
/* 473:627 */     return true;
/* 474:    */   }
/* 475:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent
 * JD-Core Version:    0.7.0.1
 */