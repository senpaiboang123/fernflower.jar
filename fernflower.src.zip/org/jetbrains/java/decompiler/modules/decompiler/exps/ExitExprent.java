/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   9:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  10:    */ import org.jetbrains.java.decompiler.main.rels.MethodWrapper;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.CheckTypesResult;
/*  13:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  14:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  15:    */ import org.jetbrains.java.decompiler.struct.attr.StructExceptionsAttribute;
/*  16:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  17:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable.MatchProperties;
/*  18:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  19:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode;
/*  20:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  21:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  22:    */ 
/*  23:    */ public class ExitExprent
/*  24:    */   extends Exprent
/*  25:    */ {
/*  26:    */   public static final int EXIT_RETURN = 0;
/*  27:    */   public static final int EXIT_THROW = 1;
/*  28:    */   private final int exitType;
/*  29:    */   private Exprent value;
/*  30:    */   private final VarType retType;
/*  31:    */   
/*  32:    */   public ExitExprent(int exitType, Exprent value, VarType retType, Set<Integer> bytecodeOffsets)
/*  33:    */   {
/*  34: 47 */     super(4);
/*  35: 48 */     this.exitType = exitType;
/*  36: 49 */     this.value = value;
/*  37: 50 */     this.retType = retType;
/*  38:    */     
/*  39: 52 */     addBytecodeOffsets(bytecodeOffsets);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Exprent copy()
/*  43:    */   {
/*  44: 57 */     return new ExitExprent(this.exitType, this.value == null ? null : this.value.copy(), this.retType, this.bytecode);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public CheckTypesResult checkExprTypeBounds()
/*  48:    */   {
/*  49: 62 */     CheckTypesResult result = new CheckTypesResult();
/*  50: 64 */     if ((this.exitType == 0) && (this.retType.type != 10))
/*  51:    */     {
/*  52: 65 */       result.addMinTypeExprent(this.value, VarType.getMinTypeInFamily(this.retType.typeFamily));
/*  53: 66 */       result.addMaxTypeExprent(this.value, this.retType);
/*  54:    */     }
/*  55: 69 */     return result;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public List<Exprent> getAllExprents()
/*  59:    */   {
/*  60: 74 */     List<Exprent> lst = new ArrayList();
/*  61: 75 */     if (this.value != null) {
/*  62: 76 */       lst.add(this.value);
/*  63:    */     }
/*  64: 78 */     return lst;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  68:    */   {
/*  69: 83 */     tracer.addMapping(this.bytecode);
/*  70: 85 */     if (this.exitType == 0)
/*  71:    */     {
/*  72: 86 */       TextBuffer buffer = new TextBuffer();
/*  73: 88 */       if (this.retType.type != 10)
/*  74:    */       {
/*  75: 89 */         buffer.append(" ");
/*  76: 90 */         ExprProcessor.getCastedExprent(this.value, this.retType, buffer, indent, false, tracer);
/*  77:    */       }
/*  78: 93 */       return buffer.prepend("return");
/*  79:    */     }
/*  80: 96 */     MethodWrapper method = (MethodWrapper)DecompilerContext.getProperty("CURRENT_METHOD_WRAPPER");
/*  81: 97 */     ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)DecompilerContext.getProperty("CURRENT_CLASS_NODE");
/*  82: 99 */     if ((method != null) && (node != null))
/*  83:    */     {
/*  84:100 */       StructExceptionsAttribute attr = (StructExceptionsAttribute)method.methodStruct.getAttributes().getWithKey("Exceptions");
/*  85:102 */       if (attr != null)
/*  86:    */       {
/*  87:103 */         String classname = null;
/*  88:105 */         for (int i = 0; i < attr.getThrowsExceptions().size(); i++)
/*  89:    */         {
/*  90:106 */           String exClassName = attr.getExcClassname(i, node.classStruct.getPool());
/*  91:107 */           if ("java/lang/Throwable".equals(exClassName))
/*  92:    */           {
/*  93:108 */             classname = exClassName;
/*  94:109 */             break;
/*  95:    */           }
/*  96:111 */           if ("java/lang/Exception".equals(exClassName)) {
/*  97:112 */             classname = exClassName;
/*  98:    */           }
/*  99:    */         }
/* 100:116 */         if (classname != null)
/* 101:    */         {
/* 102:117 */           VarType exType = new VarType(classname, true);
/* 103:118 */           TextBuffer buffer = new TextBuffer();
/* 104:119 */           ExprProcessor.getCastedExprent(this.value, exType, buffer, indent, false, tracer);
/* 105:120 */           return buffer.prepend("throw ");
/* 106:    */         }
/* 107:    */       }
/* 108:    */     }
/* 109:125 */     return this.value.toJava(indent, tracer).prepend("throw ");
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/* 113:    */   {
/* 114:131 */     if (oldExpr == this.value) {
/* 115:132 */       this.value = newExpr;
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   public boolean equals(Object o)
/* 120:    */   {
/* 121:138 */     if (o == this) {
/* 122:138 */       return true;
/* 123:    */     }
/* 124:139 */     if ((o == null) || (!(o instanceof ExitExprent))) {
/* 125:139 */       return false;
/* 126:    */     }
/* 127:141 */     ExitExprent et = (ExitExprent)o;
/* 128:142 */     return (this.exitType == et.getExitType()) && (InterpreterUtil.equalObjects(this.value, et.getValue()));
/* 129:    */   }
/* 130:    */   
/* 131:    */   public int getExitType()
/* 132:    */   {
/* 133:147 */     return this.exitType;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public Exprent getValue()
/* 137:    */   {
/* 138:151 */     return this.value;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public VarType getRetType()
/* 142:    */   {
/* 143:155 */     return this.retType;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public boolean match(MatchNode matchNode, MatchEngine engine)
/* 147:    */   {
/* 148:164 */     if (!super.match(matchNode, engine)) {
/* 149:165 */       return false;
/* 150:    */     }
/* 151:168 */     Integer type = (Integer)matchNode.getRuleValue(IMatchable.MatchProperties.EXPRENT_EXITTYPE);
/* 152:169 */     if ((type != null) && 
/* 153:170 */       (this.exitType != type.intValue())) {
/* 154:171 */       return false;
/* 155:    */     }
/* 156:175 */     return true;
/* 157:    */   }
/* 158:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent
 * JD-Core Version:    0.7.0.1
 */