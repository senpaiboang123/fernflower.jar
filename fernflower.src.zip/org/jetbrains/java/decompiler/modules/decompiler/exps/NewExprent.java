/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.jetbrains.java.decompiler.main.ClassWriter;
/*   9:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor;
/*  10:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*  11:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  12:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  13:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  14:    */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*  15:    */ import org.jetbrains.java.decompiler.main.rels.MethodWrapper;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.CheckTypesResult;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  20:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  21:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  22:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  23:    */ import org.jetbrains.java.decompiler.util.ListStack;
/*  24:    */ 
/*  25:    */ public class NewExprent
/*  26:    */   extends Exprent
/*  27:    */ {
/*  28:    */   private InvocationExprent constructor;
/*  29:    */   private final VarType newType;
/*  30: 41 */   private List<Exprent> lstDims = new ArrayList();
/*  31: 42 */   private List<Exprent> lstArrayElements = new ArrayList();
/*  32:    */   private boolean directArrayInit;
/*  33:    */   private boolean anonymous;
/*  34:    */   private boolean lambda;
/*  35:    */   private boolean enumConst;
/*  36:    */   
/*  37:    */   public NewExprent(VarType newType, ListStack<Exprent> stack, int arrayDim, Set<Integer> bytecodeOffsets)
/*  38:    */   {
/*  39: 49 */     this(newType, getDimensions(arrayDim, stack), bytecodeOffsets);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public NewExprent(VarType newType, List<Exprent> lstDims, Set<Integer> bytecodeOffsets)
/*  43:    */   {
/*  44: 53 */     super(10);
/*  45: 54 */     this.newType = newType;
/*  46: 55 */     this.lstDims = lstDims;
/*  47:    */     
/*  48: 57 */     this.anonymous = false;
/*  49: 58 */     this.lambda = false;
/*  50: 59 */     if ((newType.type == 8) && (newType.arrayDim == 0))
/*  51:    */     {
/*  52: 60 */       ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(newType.value);
/*  53: 61 */       if ((node != null) && ((node.type == 2) || (node.type == 8)))
/*  54:    */       {
/*  55: 62 */         this.anonymous = true;
/*  56: 63 */         if (node.type == 8) {
/*  57: 64 */           this.lambda = true;
/*  58:    */         }
/*  59:    */       }
/*  60:    */     }
/*  61: 69 */     addBytecodeOffsets(bytecodeOffsets);
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static List<Exprent> getDimensions(int arrayDim, ListStack<Exprent> stack)
/*  65:    */   {
/*  66: 73 */     List<Exprent> lstDims = new ArrayList();
/*  67: 74 */     for (int i = 0; i < arrayDim; i++) {
/*  68: 75 */       lstDims.add(0, stack.pop());
/*  69:    */     }
/*  70: 77 */     return lstDims;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public VarType getExprType()
/*  74:    */   {
/*  75: 82 */     return this.anonymous ? ((ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(this.newType.value)).anonymousClassType : this.newType;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public CheckTypesResult checkExprTypeBounds()
/*  79:    */   {
/*  80: 87 */     CheckTypesResult result = new CheckTypesResult();
/*  81:    */     VarType leftType;
/*  82: 89 */     if (this.newType.arrayDim != 0)
/*  83:    */     {
/*  84: 90 */       for (Exprent dim : this.lstDims)
/*  85:    */       {
/*  86: 91 */         result.addMinTypeExprent(dim, VarType.VARTYPE_BYTECHAR);
/*  87: 92 */         result.addMaxTypeExprent(dim, VarType.VARTYPE_INT);
/*  88:    */       }
/*  89: 95 */       if (this.newType.arrayDim == 1)
/*  90:    */       {
/*  91: 96 */         leftType = this.newType.decreaseArrayDim();
/*  92: 97 */         for (Exprent element : this.lstArrayElements)
/*  93:    */         {
/*  94: 98 */           result.addMinTypeExprent(element, VarType.getMinTypeInFamily(leftType.typeFamily));
/*  95: 99 */           result.addMaxTypeExprent(element, leftType);
/*  96:    */         }
/*  97:    */       }
/*  98:    */     }
/*  99:104 */     else if (this.constructor != null)
/* 100:    */     {
/* 101:105 */       return this.constructor.checkExprTypeBounds();
/* 102:    */     }
/* 103:109 */     return result;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public List<Exprent> getAllExprents()
/* 107:    */   {
/* 108:114 */     List<Exprent> lst = new ArrayList();
/* 109:115 */     if (this.newType.arrayDim == 0)
/* 110:    */     {
/* 111:116 */       if (this.constructor != null)
/* 112:    */       {
/* 113:117 */         Exprent constructor_instance = this.constructor.getInstance();
/* 114:119 */         if (constructor_instance != null) {
/* 115:120 */           lst.add(constructor_instance);
/* 116:    */         }
/* 117:123 */         lst.addAll(this.constructor.getLstParameters());
/* 118:    */       }
/* 119:    */     }
/* 120:    */     else
/* 121:    */     {
/* 122:127 */       lst.addAll(this.lstDims);
/* 123:128 */       lst.addAll(this.lstArrayElements);
/* 124:    */     }
/* 125:131 */     return lst;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public Exprent copy()
/* 129:    */   {
/* 130:136 */     List<Exprent> lst = new ArrayList();
/* 131:137 */     for (Exprent expr : this.lstDims) {
/* 132:138 */       lst.add(expr.copy());
/* 133:    */     }
/* 134:141 */     NewExprent ret = new NewExprent(this.newType, lst, this.bytecode);
/* 135:142 */     ret.setConstructor(this.constructor == null ? null : (InvocationExprent)this.constructor.copy());
/* 136:143 */     ret.setLstArrayElements(this.lstArrayElements);
/* 137:144 */     ret.setDirectArrayInit(this.directArrayInit);
/* 138:145 */     ret.setAnonymous(this.anonymous);
/* 139:146 */     ret.setEnumConst(this.enumConst);
/* 140:147 */     return ret;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public int getPrecedence()
/* 144:    */   {
/* 145:152 */     return 1;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 149:    */   {
/* 150:157 */     TextBuffer buf = new TextBuffer();
/* 151:159 */     if (this.anonymous)
/* 152:    */     {
/* 153:160 */       ClassesProcessor.ClassNode child = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(this.newType.value);
/* 154:    */       
/* 155:162 */       buf.append("(");
/* 156:164 */       if ((!this.lambda) && (this.constructor != null))
/* 157:    */       {
/* 158:165 */         InvocationExprent invSuper = child.superInvocation;
/* 159:    */         
/* 160:167 */         ClassesProcessor.ClassNode newNode = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(invSuper.getClassname());
/* 161:    */         
/* 162:169 */         List<VarVersionPair> sigFields = null;
/* 163:170 */         if (newNode != null) {
/* 164:171 */           if (newNode.getWrapper() != null)
/* 165:    */           {
/* 166:172 */             sigFields = newNode.getWrapper().getMethodWrapper("<init>", invSuper.getStringDescriptor()).signatureFields;
/* 167:    */           }
/* 168:175 */           else if ((newNode.type == 1) && ((newNode.access & 0x8) == 0) && (!this.constructor.getLstParameters().isEmpty()))
/* 169:    */           {
/* 170:177 */             sigFields = new ArrayList(Collections.nCopies(this.constructor.getLstParameters().size(), (VarVersionPair)null));
/* 171:178 */             sigFields.set(0, new VarVersionPair(-1, 0));
/* 172:    */           }
/* 173:    */         }
/* 174:183 */         boolean firstParam = true;
/* 175:184 */         int start = 0;int end = invSuper.getLstParameters().size();
/* 176:185 */         if (this.enumConst)
/* 177:    */         {
/* 178:186 */           start += 2;
/* 179:187 */           end--;
/* 180:    */         }
/* 181:189 */         for (int i = start; i < end; i++) {
/* 182:190 */           if ((sigFields == null) || (sigFields.get(i) == null))
/* 183:    */           {
/* 184:191 */             if (!firstParam) {
/* 185:192 */               buf.append(", ");
/* 186:    */             }
/* 187:195 */             Exprent param = (Exprent)invSuper.getLstParameters().get(i);
/* 188:196 */             if (param.type == 12)
/* 189:    */             {
/* 190:197 */               int varIndex = ((VarExprent)param).getIndex();
/* 191:198 */               if ((varIndex > 0) && (varIndex <= this.constructor.getLstParameters().size())) {
/* 192:199 */                 param = (Exprent)this.constructor.getLstParameters().get(varIndex - 1);
/* 193:    */               }
/* 194:    */             }
/* 195:203 */             ExprProcessor.getCastedExprent(param, invSuper.getDescriptor().params[i], buf, indent, true, tracer);
/* 196:    */             
/* 197:205 */             firstParam = false;
/* 198:    */           }
/* 199:    */         }
/* 200:    */       }
/* 201:210 */       if (!this.enumConst)
/* 202:    */       {
/* 203:211 */         String enclosing = null;
/* 204:212 */         if ((!this.lambda) && (this.constructor != null)) {
/* 205:213 */           enclosing = getQualifiedNewInstance(child.anonymousClassType.value, this.constructor.getLstParameters(), indent, tracer);
/* 206:    */         }
/* 207:216 */         String typename = ExprProcessor.getCastTypeName(child.anonymousClassType);
/* 208:218 */         if (enclosing != null)
/* 209:    */         {
/* 210:219 */           ClassesProcessor.ClassNode anonymousNode = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(child.anonymousClassType.value);
/* 211:220 */           if (anonymousNode != null) {
/* 212:221 */             typename = anonymousNode.simpleName;
/* 213:    */           } else {
/* 214:224 */             typename = typename.substring(typename.lastIndexOf('.') + 1);
/* 215:    */           }
/* 216:    */         }
/* 217:228 */         buf.prepend("new " + typename);
/* 218:230 */         if (enclosing != null) {
/* 219:231 */           buf.prepend(enclosing + ".");
/* 220:    */         }
/* 221:    */       }
/* 222:235 */       buf.append(")");
/* 223:237 */       if ((this.enumConst) && (buf.length() == 2)) {
/* 224:238 */         buf.setLength(0);
/* 225:    */       }
/* 226:241 */       if (this.lambda)
/* 227:    */       {
/* 228:242 */         if (!DecompilerContext.getOption("lac")) {
/* 229:243 */           buf.setLength(0);
/* 230:    */         }
/* 231:245 */         Exprent methodObject = this.constructor == null ? null : this.constructor.getInstance();
/* 232:246 */         TextBuffer clsBuf = new TextBuffer();
/* 233:247 */         new ClassWriter().classLambdaToJava(child, clsBuf, methodObject, indent, tracer);
/* 234:248 */         buf.append(clsBuf);
/* 235:249 */         tracer.incrementCurrentSourceLine(clsBuf.countLines());
/* 236:    */       }
/* 237:    */       else
/* 238:    */       {
/* 239:252 */         TextBuffer clsBuf = new TextBuffer();
/* 240:253 */         new ClassWriter().classToJava(child, clsBuf, indent, tracer);
/* 241:254 */         buf.append(clsBuf);
/* 242:255 */         tracer.incrementCurrentSourceLine(clsBuf.countLines());
/* 243:    */       }
/* 244:    */     }
/* 245:258 */     else if (this.directArrayInit)
/* 246:    */     {
/* 247:259 */       VarType leftType = this.newType.decreaseArrayDim();
/* 248:260 */       buf.append("{");
/* 249:261 */       for (int i = 0; i < this.lstArrayElements.size(); i++)
/* 250:    */       {
/* 251:262 */         if (i > 0) {
/* 252:263 */           buf.append(", ");
/* 253:    */         }
/* 254:265 */         ExprProcessor.getCastedExprent((Exprent)this.lstArrayElements.get(i), leftType, buf, indent, false, tracer);
/* 255:    */       }
/* 256:267 */       buf.append("}");
/* 257:    */     }
/* 258:269 */     else if (this.newType.arrayDim == 0)
/* 259:    */     {
/* 260:270 */       if (this.constructor != null)
/* 261:    */       {
/* 262:271 */         List<Exprent> lstParameters = this.constructor.getLstParameters();
/* 263:    */         
/* 264:273 */         ClassesProcessor.ClassNode newNode = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(this.constructor.getClassname());
/* 265:    */         
/* 266:275 */         List<VarVersionPair> sigFields = null;
/* 267:276 */         if (newNode != null) {
/* 268:277 */           if (newNode.getWrapper() != null)
/* 269:    */           {
/* 270:278 */             sigFields = newNode.getWrapper().getMethodWrapper("<init>", this.constructor.getStringDescriptor()).signatureFields;
/* 271:    */           }
/* 272:280 */           else if ((newNode.type == 1) && ((newNode.access & 0x8) == 0) && (!this.constructor.getLstParameters().isEmpty()))
/* 273:    */           {
/* 274:282 */             sigFields = new ArrayList(Collections.nCopies(lstParameters.size(), (VarVersionPair)null));
/* 275:283 */             sigFields.set(0, new VarVersionPair(-1, 0));
/* 276:    */           }
/* 277:    */         }
/* 278:287 */         int start = this.enumConst ? 2 : 0;
/* 279:288 */         if ((!this.enumConst) || (start < lstParameters.size()))
/* 280:    */         {
/* 281:289 */           buf.append("(");
/* 282:    */           
/* 283:291 */           boolean firstParam = true;
/* 284:292 */           for (int i = start; i < lstParameters.size(); i++) {
/* 285:293 */             if ((sigFields == null) || (sigFields.get(i) == null))
/* 286:    */             {
/* 287:294 */               Exprent expr = (Exprent)lstParameters.get(i);
/* 288:295 */               VarType leftType = this.constructor.getDescriptor().params[i];
/* 289:297 */               if ((i == lstParameters.size() - 1) && (expr.getExprType() == VarType.VARTYPE_NULL))
/* 290:    */               {
/* 291:298 */                 ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(leftType.value);
/* 292:299 */                 if ((node != null) && (node.namelessConstructorStub)) {
/* 293:    */                   break;
/* 294:    */                 }
/* 295:    */               }
/* 296:304 */               if (!firstParam) {
/* 297:305 */                 buf.append(", ");
/* 298:    */               }
/* 299:308 */               ExprProcessor.getCastedExprent(expr, leftType, buf, indent, true, tracer);
/* 300:    */               
/* 301:310 */               firstParam = false;
/* 302:    */             }
/* 303:    */           }
/* 304:314 */           buf.append(")");
/* 305:    */         }
/* 306:    */       }
/* 307:318 */       if (!this.enumConst)
/* 308:    */       {
/* 309:319 */         String enclosing = null;
/* 310:320 */         if (this.constructor != null) {
/* 311:321 */           enclosing = getQualifiedNewInstance(this.newType.value, this.constructor.getLstParameters(), indent, tracer);
/* 312:    */         }
/* 313:324 */         String typename = ExprProcessor.getTypeName(this.newType);
/* 314:326 */         if (enclosing != null)
/* 315:    */         {
/* 316:327 */           ClassesProcessor.ClassNode newNode = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(this.newType.value);
/* 317:328 */           if (newNode != null) {
/* 318:329 */             typename = newNode.simpleName;
/* 319:    */           } else {
/* 320:332 */             typename = typename.substring(typename.lastIndexOf('.') + 1);
/* 321:    */           }
/* 322:    */         }
/* 323:335 */         buf.prepend("new " + typename);
/* 324:337 */         if (enclosing != null) {
/* 325:338 */           buf.prepend(enclosing + ".");
/* 326:    */         }
/* 327:    */       }
/* 328:    */     }
/* 329:    */     else
/* 330:    */     {
/* 331:343 */       buf.append("new ").append(ExprProcessor.getTypeName(this.newType));
/* 332:345 */       if (this.lstArrayElements.isEmpty())
/* 333:    */       {
/* 334:346 */         for (int i = 0; i < this.newType.arrayDim; i++)
/* 335:    */         {
/* 336:347 */           buf.append("[");
/* 337:348 */           if (i < this.lstDims.size()) {
/* 338:349 */             buf.append(((Exprent)this.lstDims.get(i)).toJava(indent, tracer));
/* 339:    */           }
/* 340:351 */           buf.append("]");
/* 341:    */         }
/* 342:    */       }
/* 343:    */       else
/* 344:    */       {
/* 345:355 */         for (int i = 0; i < this.newType.arrayDim; i++) {
/* 346:356 */           buf.append("[]");
/* 347:    */         }
/* 348:359 */         VarType leftType = this.newType.decreaseArrayDim();
/* 349:360 */         buf.append("{");
/* 350:361 */         for (int i = 0; i < this.lstArrayElements.size(); i++)
/* 351:    */         {
/* 352:362 */           if (i > 0) {
/* 353:363 */             buf.append(", ");
/* 354:    */           }
/* 355:365 */           ExprProcessor.getCastedExprent((Exprent)this.lstArrayElements.get(i), leftType, buf, indent, false, tracer);
/* 356:    */         }
/* 357:367 */         buf.append("}");
/* 358:    */       }
/* 359:    */     }
/* 360:371 */     return buf;
/* 361:    */   }
/* 362:    */   
/* 363:    */   private static String getQualifiedNewInstance(String classname, List<Exprent> lstParams, int indent, BytecodeMappingTracer tracer)
/* 364:    */   {
/* 365:375 */     ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(classname);
/* 366:377 */     if ((node != null) && (node.type != 0) && (node.type != 4) && ((node.access & 0x8) == 0)) {
/* 367:379 */       if (!lstParams.isEmpty())
/* 368:    */       {
/* 369:380 */         Exprent enclosing = (Exprent)lstParams.get(0);
/* 370:    */         
/* 371:382 */         boolean isQualifiedNew = false;
/* 372:384 */         if (enclosing.type == 12)
/* 373:    */         {
/* 374:385 */           VarExprent varEnclosing = (VarExprent)enclosing;
/* 375:    */           
/* 376:387 */           StructClass current_class = ((ClassesProcessor.ClassNode)DecompilerContext.getProperty("CURRENT_CLASS_NODE")).classStruct;
/* 377:388 */           String this_classname = (String)varEnclosing.getProcessor().getThisVars().get(new VarVersionPair(varEnclosing));
/* 378:390 */           if (!current_class.qualifiedName.equals(this_classname)) {
/* 379:391 */             isQualifiedNew = true;
/* 380:    */           }
/* 381:    */         }
/* 382:    */         else
/* 383:    */         {
/* 384:395 */           isQualifiedNew = true;
/* 385:    */         }
/* 386:398 */         if (isQualifiedNew) {
/* 387:399 */           return enclosing.toJava(indent, tracer).toString();
/* 388:    */         }
/* 389:    */       }
/* 390:    */     }
/* 391:404 */     return null;
/* 392:    */   }
/* 393:    */   
/* 394:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/* 395:    */   {
/* 396:409 */     if (oldExpr == this.constructor) {
/* 397:410 */       this.constructor = ((InvocationExprent)newExpr);
/* 398:    */     }
/* 399:413 */     if (this.constructor != null) {
/* 400:414 */       this.constructor.replaceExprent(oldExpr, newExpr);
/* 401:    */     }
/* 402:417 */     for (int i = 0; i < this.lstDims.size(); i++) {
/* 403:418 */       if (oldExpr == this.lstDims.get(i)) {
/* 404:419 */         this.lstDims.set(i, newExpr);
/* 405:    */       }
/* 406:    */     }
/* 407:423 */     for (int i = 0; i < this.lstArrayElements.size(); i++) {
/* 408:424 */       if (oldExpr == this.lstArrayElements.get(i)) {
/* 409:425 */         this.lstArrayElements.set(i, newExpr);
/* 410:    */       }
/* 411:    */     }
/* 412:    */   }
/* 413:    */   
/* 414:    */   public boolean equals(Object o)
/* 415:    */   {
/* 416:432 */     if (o == this) {
/* 417:432 */       return true;
/* 418:    */     }
/* 419:433 */     if ((o == null) || (!(o instanceof NewExprent))) {
/* 420:433 */       return false;
/* 421:    */     }
/* 422:435 */     NewExprent ne = (NewExprent)o;
/* 423:436 */     return (InterpreterUtil.equalObjects(this.newType, ne.getNewType())) && (InterpreterUtil.equalLists(this.lstDims, ne.getLstDims())) && (InterpreterUtil.equalObjects(this.constructor, ne.getConstructor())) && (this.directArrayInit == ne.directArrayInit) && (InterpreterUtil.equalLists(this.lstArrayElements, ne.getLstArrayElements()));
/* 424:    */   }
/* 425:    */   
/* 426:    */   public InvocationExprent getConstructor()
/* 427:    */   {
/* 428:444 */     return this.constructor;
/* 429:    */   }
/* 430:    */   
/* 431:    */   public void setConstructor(InvocationExprent constructor)
/* 432:    */   {
/* 433:448 */     this.constructor = constructor;
/* 434:    */   }
/* 435:    */   
/* 436:    */   public List<Exprent> getLstDims()
/* 437:    */   {
/* 438:452 */     return this.lstDims;
/* 439:    */   }
/* 440:    */   
/* 441:    */   public VarType getNewType()
/* 442:    */   {
/* 443:456 */     return this.newType;
/* 444:    */   }
/* 445:    */   
/* 446:    */   public List<Exprent> getLstArrayElements()
/* 447:    */   {
/* 448:460 */     return this.lstArrayElements;
/* 449:    */   }
/* 450:    */   
/* 451:    */   public void setLstArrayElements(List<Exprent> lstArrayElements)
/* 452:    */   {
/* 453:464 */     this.lstArrayElements = lstArrayElements;
/* 454:    */   }
/* 455:    */   
/* 456:    */   public void setDirectArrayInit(boolean directArrayInit)
/* 457:    */   {
/* 458:468 */     this.directArrayInit = directArrayInit;
/* 459:    */   }
/* 460:    */   
/* 461:    */   public boolean isLambda()
/* 462:    */   {
/* 463:472 */     return this.lambda;
/* 464:    */   }
/* 465:    */   
/* 466:    */   public boolean isAnonymous()
/* 467:    */   {
/* 468:476 */     return this.anonymous;
/* 469:    */   }
/* 470:    */   
/* 471:    */   public void setAnonymous(boolean anonymous)
/* 472:    */   {
/* 473:480 */     this.anonymous = anonymous;
/* 474:    */   }
/* 475:    */   
/* 476:    */   public void setEnumConst(boolean enumConst)
/* 477:    */   {
/* 478:484 */     this.enumConst = enumConst;
/* 479:    */   }
/* 480:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent
 * JD-Core Version:    0.7.0.1
 */