/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*   9:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  10:    */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.CheckTypesResult;
/*  13:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  14:    */ import org.jetbrains.java.decompiler.struct.StructField;
/*  15:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  16:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  17:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  18:    */ 
/*  19:    */ public class AssignmentExprent
/*  20:    */   extends Exprent
/*  21:    */ {
/*  22:    */   public static final int CONDITION_NONE = -1;
/*  23: 37 */   private static final String[] OPERATORS = { " += ", " -= ", " *= ", " /= ", " &= ", " |= ", " ^= ", " %= ", " <<= ", " >>= ", " >>>= " };
/*  24:    */   private Exprent left;
/*  25:    */   private Exprent right;
/*  26: 53 */   private int condType = -1;
/*  27:    */   
/*  28:    */   public AssignmentExprent(Exprent left, Exprent right, Set<Integer> bytecodeOffsets)
/*  29:    */   {
/*  30: 56 */     super(2);
/*  31: 57 */     this.left = left;
/*  32: 58 */     this.right = right;
/*  33:    */     
/*  34: 60 */     addBytecodeOffsets(bytecodeOffsets);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public VarType getExprType()
/*  38:    */   {
/*  39: 65 */     return this.left.getExprType();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public CheckTypesResult checkExprTypeBounds()
/*  43:    */   {
/*  44: 70 */     CheckTypesResult result = new CheckTypesResult();
/*  45:    */     
/*  46: 72 */     VarType typeLeft = this.left.getExprType();
/*  47: 73 */     VarType typeRight = this.right.getExprType();
/*  48: 75 */     if (typeLeft.typeFamily > typeRight.typeFamily) {
/*  49: 76 */       result.addMinTypeExprent(this.right, VarType.getMinTypeInFamily(typeLeft.typeFamily));
/*  50: 78 */     } else if (typeLeft.typeFamily < typeRight.typeFamily) {
/*  51: 79 */       result.addMinTypeExprent(this.left, typeRight);
/*  52:    */     } else {
/*  53: 82 */       result.addMinTypeExprent(this.left, VarType.getCommonSupertype(typeLeft, typeRight));
/*  54:    */     }
/*  55: 85 */     return result;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public List<Exprent> getAllExprents()
/*  59:    */   {
/*  60: 90 */     List<Exprent> lst = new ArrayList();
/*  61: 91 */     lst.add(this.left);
/*  62: 92 */     lst.add(this.right);
/*  63: 93 */     return lst;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public Exprent copy()
/*  67:    */   {
/*  68: 98 */     return new AssignmentExprent(this.left.copy(), this.right.copy(), this.bytecode);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public int getPrecedence()
/*  72:    */   {
/*  73:103 */     return 13;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  77:    */   {
/*  78:108 */     VarType leftType = this.left.getExprType();
/*  79:109 */     VarType rightType = this.right.getExprType();
/*  80:    */     
/*  81:111 */     boolean fieldInClassInit = false;boolean hiddenField = false;
/*  82:112 */     if (this.left.type == 5)
/*  83:    */     {
/*  84:113 */       FieldExprent field = (FieldExprent)this.left;
/*  85:114 */       ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)DecompilerContext.getProperty("CURRENT_CLASS_NODE");
/*  86:115 */       if (node != null)
/*  87:    */       {
/*  88:116 */         StructField fd = node.classStruct.getField(field.getName(), field.getDescriptor().descriptorString);
/*  89:117 */         if (fd != null)
/*  90:    */         {
/*  91:118 */           if ((field.isStatic()) && (fd.hasModifier(16))) {
/*  92:119 */             fieldInClassInit = true;
/*  93:    */           }
/*  94:121 */           if ((node.getWrapper() != null) && (node.getWrapper().getHiddenMembers().contains(InterpreterUtil.makeUniqueKey(fd.getName(), fd.getDescriptor())))) {
/*  95:122 */             hiddenField = true;
/*  96:    */           }
/*  97:    */         }
/*  98:    */       }
/*  99:    */     }
/* 100:128 */     if (hiddenField) {
/* 101:129 */       return new TextBuffer();
/* 102:    */     }
/* 103:132 */     TextBuffer buffer = new TextBuffer();
/* 104:134 */     if (fieldInClassInit) {
/* 105:135 */       buffer.append(((FieldExprent)this.left).getName());
/* 106:    */     } else {
/* 107:138 */       buffer.append(this.left.toJava(indent, tracer));
/* 108:    */     }
/* 109:141 */     TextBuffer res = this.right.toJava(indent, tracer);
/* 110:143 */     if ((this.condType == -1) && (!leftType.isSuperset(rightType)) && ((rightType.equals(VarType.VARTYPE_OBJECT)) || (leftType.type != 8)))
/* 111:    */     {
/* 112:146 */       if (this.right.getPrecedence() >= FunctionExprent.getPrecedence(29)) {
/* 113:147 */         res.enclose("(", ")");
/* 114:    */       }
/* 115:150 */       res.prepend("(" + ExprProcessor.getCastTypeName(leftType) + ")");
/* 116:    */     }
/* 117:153 */     buffer.append(this.condType == -1 ? " = " : OPERATORS[this.condType]).append(res);
/* 118:    */     
/* 119:155 */     tracer.addMapping(this.bytecode);
/* 120:    */     
/* 121:157 */     return buffer;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/* 125:    */   {
/* 126:162 */     if (oldExpr == this.left) {
/* 127:163 */       this.left = newExpr;
/* 128:    */     }
/* 129:165 */     if (oldExpr == this.right) {
/* 130:166 */       this.right = newExpr;
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean equals(Object o)
/* 135:    */   {
/* 136:172 */     if (o == this) {
/* 137:172 */       return true;
/* 138:    */     }
/* 139:173 */     if ((o == null) || (!(o instanceof AssignmentExprent))) {
/* 140:173 */       return false;
/* 141:    */     }
/* 142:175 */     AssignmentExprent as = (AssignmentExprent)o;
/* 143:176 */     return (InterpreterUtil.equalObjects(this.left, as.getLeft())) && (InterpreterUtil.equalObjects(this.right, as.getRight())) && (this.condType == as.getCondType());
/* 144:    */   }
/* 145:    */   
/* 146:    */   public Exprent getLeft()
/* 147:    */   {
/* 148:186 */     return this.left;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void setLeft(Exprent left)
/* 152:    */   {
/* 153:190 */     this.left = left;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public Exprent getRight()
/* 157:    */   {
/* 158:194 */     return this.right;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void setRight(Exprent right)
/* 162:    */   {
/* 163:198 */     this.right = right;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public int getCondType()
/* 167:    */   {
/* 168:202 */     return this.condType;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public void setCondType(int condType)
/* 172:    */   {
/* 173:206 */     this.condType = condType;
/* 174:    */   }
/* 175:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent
 * JD-Core Version:    0.7.0.1
 */