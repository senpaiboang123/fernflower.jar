/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ import java.util.Set;
/*  6:   */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  7:   */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  8:   */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  9:   */ 
/* 10:   */ public class MonitorExprent
/* 11:   */   extends Exprent
/* 12:   */ {
/* 13:   */   public static final int MONITOR_ENTER = 0;
/* 14:   */   public static final int MONITOR_EXIT = 1;
/* 15:   */   private final int monType;
/* 16:   */   private Exprent value;
/* 17:   */   
/* 18:   */   public MonitorExprent(int monType, Exprent value, Set<Integer> bytecodeOffsets)
/* 19:   */   {
/* 20:35 */     super(9);
/* 21:36 */     this.monType = monType;
/* 22:37 */     this.value = value;
/* 23:   */     
/* 24:39 */     addBytecodeOffsets(bytecodeOffsets);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Exprent copy()
/* 28:   */   {
/* 29:44 */     return new MonitorExprent(this.monType, this.value.copy(), this.bytecode);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public List<Exprent> getAllExprents()
/* 33:   */   {
/* 34:49 */     List<Exprent> lst = new ArrayList();
/* 35:50 */     lst.add(this.value);
/* 36:51 */     return lst;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 40:   */   {
/* 41:56 */     tracer.addMapping(this.bytecode);
/* 42:58 */     if (this.monType == 0) {
/* 43:59 */       return this.value.toJava(indent, tracer).enclose("synchronized(", ")");
/* 44:   */     }
/* 45:62 */     return new TextBuffer();
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void replaceExprent(Exprent oldExpr, Exprent newExpr)
/* 49:   */   {
/* 50:68 */     if (oldExpr == this.value) {
/* 51:69 */       this.value = newExpr;
/* 52:   */     }
/* 53:   */   }
/* 54:   */   
/* 55:   */   public boolean equals(Object o)
/* 56:   */   {
/* 57:75 */     if (o == this) {
/* 58:75 */       return true;
/* 59:   */     }
/* 60:76 */     if ((o == null) || (!(o instanceof MonitorExprent))) {
/* 61:76 */       return false;
/* 62:   */     }
/* 63:78 */     MonitorExprent me = (MonitorExprent)o;
/* 64:79 */     return (this.monType == me.getMonType()) && (InterpreterUtil.equalObjects(this.value, me.getValue()));
/* 65:   */   }
/* 66:   */   
/* 67:   */   public int getMonType()
/* 68:   */   {
/* 69:84 */     return this.monType;
/* 70:   */   }
/* 71:   */   
/* 72:   */   public Exprent getValue()
/* 73:   */   {
/* 74:88 */     return this.value;
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.MonitorExprent
 * JD-Core Version:    0.7.0.1
 */