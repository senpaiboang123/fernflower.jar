/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  5:   */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  6:   */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  7:   */ import org.jetbrains.java.decompiler.main.collectors.ImportCollector;
/*  8:   */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  9:   */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/* 10:   */ 
/* 11:   */ public class AnnotationExprent
/* 12:   */   extends Exprent
/* 13:   */ {
/* 14:   */   public static final int ANNOTATION_NORMAL = 1;
/* 15:   */   public static final int ANNOTATION_MARKER = 2;
/* 16:   */   public static final int ANNOTATION_SINGLE_ELEMENT = 3;
/* 17:   */   private final String className;
/* 18:   */   private final List<String> parNames;
/* 19:   */   private final List<Exprent> parValues;
/* 20:   */   
/* 21:   */   public AnnotationExprent(String className, List<String> parNames, List<Exprent> parValues)
/* 22:   */   {
/* 23:37 */     super(13);
/* 24:38 */     this.className = className;
/* 25:39 */     this.parNames = parNames;
/* 26:40 */     this.parValues = parValues;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/* 30:   */   {
/* 31:45 */     TextBuffer buffer = new TextBuffer();
/* 32:   */     
/* 33:47 */     buffer.appendIndent(indent);
/* 34:48 */     buffer.append("@");
/* 35:49 */     buffer.append(DecompilerContext.getImportCollector().getShortName(ExprProcessor.buildJavaClassName(this.className)));
/* 36:51 */     if (!this.parNames.isEmpty())
/* 37:   */     {
/* 38:52 */       buffer.append("(");
/* 39:53 */       if ((this.parNames.size() == 1) && ("value".equals(this.parNames.get(0))))
/* 40:   */       {
/* 41:54 */         buffer.append(((Exprent)this.parValues.get(0)).toJava(indent + 1, tracer));
/* 42:   */       }
/* 43:   */       else
/* 44:   */       {
/* 45:57 */         for (int i = 0; i < this.parNames.size(); i++)
/* 46:   */         {
/* 47:58 */           buffer.appendLineSeparator().appendIndent(indent + 1);
/* 48:59 */           buffer.append((String)this.parNames.get(i));
/* 49:60 */           buffer.append(" = ");
/* 50:61 */           buffer.append(((Exprent)this.parValues.get(i)).toJava(indent + 2, tracer));
/* 51:63 */           if (i < this.parNames.size() - 1) {
/* 52:64 */             buffer.append(",");
/* 53:   */           }
/* 54:   */         }
/* 55:67 */         buffer.appendLineSeparator().appendIndent(indent);
/* 56:   */       }
/* 57:70 */       buffer.append(")");
/* 58:   */     }
/* 59:73 */     return buffer;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public String getClassName()
/* 63:   */   {
/* 64:77 */     return this.className;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public int getAnnotationType()
/* 68:   */   {
/* 69:81 */     if (this.parNames.isEmpty()) {
/* 70:82 */       return 2;
/* 71:   */     }
/* 72:84 */     if ((this.parNames.size() == 1) && ("value".equals(this.parNames.get(0)))) {
/* 73:85 */       return 3;
/* 74:   */     }
/* 75:88 */     return 1;
/* 76:   */   }
/* 77:   */   
/* 78:   */   public boolean equals(Object o)
/* 79:   */   {
/* 80:94 */     if (o == this) {
/* 81:94 */       return true;
/* 82:   */     }
/* 83:95 */     if ((o == null) || (!(o instanceof AnnotationExprent))) {
/* 84:95 */       return false;
/* 85:   */     }
/* 86:97 */     AnnotationExprent ann = (AnnotationExprent)o;
/* 87:98 */     return (this.className.equals(ann.className)) && (InterpreterUtil.equalLists(this.parNames, ann.parNames)) && (InterpreterUtil.equalLists(this.parValues, ann.parValues));
/* 88:   */   }
/* 89:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.AnnotationExprent
 * JD-Core Version:    0.7.0.1
 */