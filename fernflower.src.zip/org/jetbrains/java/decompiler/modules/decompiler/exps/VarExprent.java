/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.exps;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Map;
/*   6:    */ import org.jetbrains.java.decompiler.main.ClassWriter;
/*   7:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor;
/*   8:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*   9:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  10:    */ import org.jetbrains.java.decompiler.main.TextBuffer;
/*  11:    */ import org.jetbrains.java.decompiler.main.collectors.BytecodeMappingTracer;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  15:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  16:    */ import org.jetbrains.java.decompiler.struct.match.IMatchable.MatchProperties;
/*  17:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  18:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode;
/*  19:    */ import org.jetbrains.java.decompiler.struct.match.MatchNode.RuleValue;
/*  20:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  21:    */ 
/*  22:    */ public class VarExprent
/*  23:    */   extends Exprent
/*  24:    */ {
/*  25:    */   public static final int STACK_BASE = 10000;
/*  26:    */   public static final String VAR_NAMELESS_ENCLOSURE = "<VAR_NAMELESS_ENCLOSURE>";
/*  27:    */   private int index;
/*  28:    */   private VarType varType;
/*  29: 45 */   private boolean definition = false;
/*  30:    */   private VarProcessor processor;
/*  31: 47 */   private int version = 0;
/*  32: 48 */   private boolean classDef = false;
/*  33: 49 */   private boolean stack = false;
/*  34:    */   
/*  35:    */   public VarExprent(int index, VarType varType, VarProcessor processor)
/*  36:    */   {
/*  37: 52 */     super(12);
/*  38: 53 */     this.index = index;
/*  39: 54 */     this.varType = varType;
/*  40: 55 */     this.processor = processor;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public VarType getExprType()
/*  44:    */   {
/*  45: 60 */     return getVarType();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public int getExprentUse()
/*  49:    */   {
/*  50: 65 */     return 3;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public List<Exprent> getAllExprents()
/*  54:    */   {
/*  55: 70 */     return new ArrayList();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public Exprent copy()
/*  59:    */   {
/*  60: 75 */     VarExprent var = new VarExprent(this.index, getVarType(), this.processor);
/*  61: 76 */     var.setDefinition(this.definition);
/*  62: 77 */     var.setVersion(this.version);
/*  63: 78 */     var.setClassDef(this.classDef);
/*  64: 79 */     var.setStack(this.stack);
/*  65: 80 */     return var;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public TextBuffer toJava(int indent, BytecodeMappingTracer tracer)
/*  69:    */   {
/*  70: 85 */     TextBuffer buffer = new TextBuffer();
/*  71:    */     
/*  72: 87 */     tracer.addMapping(this.bytecode);
/*  73: 89 */     if (this.classDef)
/*  74:    */     {
/*  75: 90 */       ClassesProcessor.ClassNode child = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(this.varType.value);
/*  76: 91 */       new ClassWriter().classToJava(child, buffer, indent, tracer);
/*  77: 92 */       tracer.incrementCurrentSourceLine(buffer.countLines());
/*  78:    */     }
/*  79:    */     else
/*  80:    */     {
/*  81: 95 */       String name = null;
/*  82: 96 */       if (this.processor != null) {
/*  83: 97 */         name = this.processor.getVarName(new VarVersionPair(this.index, this.version));
/*  84:    */       }
/*  85:100 */       if (this.definition)
/*  86:    */       {
/*  87:101 */         if ((this.processor != null) && (this.processor.getVarFinal(new VarVersionPair(this.index, this.version)) == 2)) {
/*  88:102 */           buffer.append("final ");
/*  89:    */         }
/*  90:104 */         buffer.append(ExprProcessor.getCastTypeName(getVarType())).append(" ");
/*  91:    */       }
/*  92:106 */       buffer.append(name == null ? "var" + this.index + (this.version == 0 ? "" : new StringBuilder().append("_").append(this.version).toString()) : name);
/*  93:    */     }
/*  94:109 */     return buffer;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean equals(Object o)
/*  98:    */   {
/*  99:114 */     if (o == this) {
/* 100:114 */       return true;
/* 101:    */     }
/* 102:115 */     if ((o == null) || (!(o instanceof VarExprent))) {
/* 103:115 */       return false;
/* 104:    */     }
/* 105:117 */     VarExprent ve = (VarExprent)o;
/* 106:118 */     return (this.index == ve.getIndex()) && (this.version == ve.getVersion()) && (InterpreterUtil.equalObjects(getVarType(), ve.getVarType()));
/* 107:    */   }
/* 108:    */   
/* 109:    */   public int getIndex()
/* 110:    */   {
/* 111:124 */     return this.index;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setIndex(int index)
/* 115:    */   {
/* 116:128 */     this.index = index;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public VarType getVarType()
/* 120:    */   {
/* 121:132 */     VarType vt = null;
/* 122:133 */     if (this.processor != null) {
/* 123:134 */       vt = this.processor.getVarType(new VarVersionPair(this.index, this.version));
/* 124:    */     }
/* 125:137 */     if ((vt == null) || ((this.varType != null) && (this.varType.type != 17))) {
/* 126:138 */       vt = this.varType;
/* 127:    */     }
/* 128:141 */     return vt == null ? VarType.VARTYPE_UNKNOWN : vt;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void setVarType(VarType varType)
/* 132:    */   {
/* 133:145 */     this.varType = varType;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public boolean isDefinition()
/* 137:    */   {
/* 138:149 */     return this.definition;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void setDefinition(boolean definition)
/* 142:    */   {
/* 143:153 */     this.definition = definition;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public VarProcessor getProcessor()
/* 147:    */   {
/* 148:157 */     return this.processor;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void setProcessor(VarProcessor processor)
/* 152:    */   {
/* 153:161 */     this.processor = processor;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public int getVersion()
/* 157:    */   {
/* 158:165 */     return this.version;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void setVersion(int version)
/* 162:    */   {
/* 163:169 */     this.version = version;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public boolean isClassDef()
/* 167:    */   {
/* 168:173 */     return this.classDef;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public void setClassDef(boolean classDef)
/* 172:    */   {
/* 173:177 */     this.classDef = classDef;
/* 174:    */   }
/* 175:    */   
/* 176:    */   public boolean isStack()
/* 177:    */   {
/* 178:181 */     return this.stack;
/* 179:    */   }
/* 180:    */   
/* 181:    */   public void setStack(boolean stack)
/* 182:    */   {
/* 183:185 */     this.stack = stack;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public boolean match(MatchNode matchNode, MatchEngine engine)
/* 187:    */   {
/* 188:194 */     if (!super.match(matchNode, engine)) {
/* 189:195 */       return false;
/* 190:    */     }
/* 191:198 */     MatchNode.RuleValue rule = (MatchNode.RuleValue)matchNode.getRules().get(IMatchable.MatchProperties.EXPRENT_VAR_INDEX);
/* 192:199 */     if (rule != null) {
/* 193:200 */       if (rule.isVariable())
/* 194:    */       {
/* 195:201 */         if (!engine.checkAndSetVariableValue((String)rule.value, Integer.valueOf(this.index))) {
/* 196:202 */           return false;
/* 197:    */         }
/* 198:    */       }
/* 199:205 */       else if (this.index != Integer.valueOf((String)rule.value).intValue()) {
/* 200:206 */         return false;
/* 201:    */       }
/* 202:    */     }
/* 203:211 */     return true;
/* 204:    */   }
/* 205:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent
 * JD-Core Version:    0.7.0.1
 */