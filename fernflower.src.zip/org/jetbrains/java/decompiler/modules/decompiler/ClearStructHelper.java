/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler;
/*  2:   */ 
/*  3:   */ import java.util.LinkedList;
/*  4:   */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  5:   */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  6:   */ 
/*  7:   */ public class ClearStructHelper
/*  8:   */ {
/*  9:   */   public static void clearStatements(RootStatement root)
/* 10:   */   {
/* 11:28 */     LinkedList<Statement> stack = new LinkedList();
/* 12:29 */     stack.add(root);
/* 13:31 */     while (!stack.isEmpty())
/* 14:   */     {
/* 15:33 */       Statement stat = (Statement)stack.removeFirst();
/* 16:   */       
/* 17:35 */       stat.clearTempInformation();
/* 18:   */       
/* 19:37 */       stack.addAll(stat.getStats());
/* 20:   */     }
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.ClearStructHelper
 * JD-Core Version:    0.7.0.1
 */