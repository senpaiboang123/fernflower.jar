/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  10:    */ 
/*  11:    */ public class DecHelper
/*  12:    */ {
/*  13:    */   public static boolean checkStatementExceptions(List<Statement> lst)
/*  14:    */   {
/*  15: 28 */     Set<Statement> all = new HashSet(lst);
/*  16:    */     
/*  17: 30 */     Set<Statement> handlers = new HashSet();
/*  18: 31 */     Set<Statement> intersection = null;
/*  19: 33 */     for (Statement stat : lst)
/*  20:    */     {
/*  21: 34 */       Set<Statement> setNew = stat.getNeighboursSet(2, 1);
/*  22: 36 */       if (intersection == null)
/*  23:    */       {
/*  24: 37 */         intersection = setNew;
/*  25:    */       }
/*  26:    */       else
/*  27:    */       {
/*  28: 40 */         HashSet<Statement> interclone = new HashSet(intersection);
/*  29: 41 */         interclone.removeAll(setNew);
/*  30:    */         
/*  31: 43 */         intersection.retainAll(setNew);
/*  32:    */         
/*  33: 45 */         setNew.removeAll(intersection);
/*  34:    */         
/*  35: 47 */         handlers.addAll(interclone);
/*  36: 48 */         handlers.addAll(setNew);
/*  37:    */       }
/*  38:    */     }
/*  39: 52 */     for (Statement stat : handlers) {
/*  40: 53 */       if ((!all.contains(stat)) || (!all.containsAll(stat.getNeighbours(2, 0)))) {
/*  41: 54 */         return false;
/*  42:    */       }
/*  43:    */     }
/*  44: 59 */     for (int i = 1; i < lst.size(); i++)
/*  45:    */     {
/*  46: 60 */       Statement stat = (Statement)lst.get(i);
/*  47: 61 */       if ((!stat.getPredecessorEdges(2).isEmpty()) && (!handlers.contains(stat))) {
/*  48: 62 */         return false;
/*  49:    */       }
/*  50:    */     }
/*  51: 66 */     return true;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static boolean isChoiceStatement(Statement head, List<Statement> lst)
/*  55:    */   {
/*  56: 71 */     Statement post = null;
/*  57:    */     
/*  58: 73 */     Set<Statement> setDest = head.getNeighboursSet(1, 1);
/*  59: 75 */     if (setDest.contains(head)) {
/*  60: 76 */       return false;
/*  61:    */     }
/*  62:    */     for (;;)
/*  63:    */     {
/*  64: 81 */       lst.clear();
/*  65:    */       
/*  66: 83 */       boolean repeat = false;
/*  67:    */       
/*  68: 85 */       setDest.remove(post);
/*  69: 87 */       for (Statement stat : setDest)
/*  70:    */       {
/*  71: 88 */         if (stat.getLastBasicType() != 2)
/*  72:    */         {
/*  73: 89 */           if (post == null)
/*  74:    */           {
/*  75: 90 */             post = stat;
/*  76: 91 */             repeat = true;
/*  77: 92 */             break;
/*  78:    */           }
/*  79: 95 */           return false;
/*  80:    */         }
/*  81:100 */         Set<Statement> setPred = stat.getNeighboursSet(1, 0);
/*  82:101 */         setPred.remove(head);
/*  83:102 */         if (setPred.contains(stat)) {
/*  84:103 */           return false;
/*  85:    */         }
/*  86:106 */         if ((!setDest.containsAll(setPred)) || (setPred.size() > 1))
/*  87:    */         {
/*  88:107 */           if (post == null)
/*  89:    */           {
/*  90:108 */             post = stat;
/*  91:109 */             repeat = true;
/*  92:110 */             break;
/*  93:    */           }
/*  94:113 */           return false;
/*  95:    */         }
/*  96:116 */         if (setPred.size() == 1)
/*  97:    */         {
/*  98:117 */           Statement pred = (Statement)setPred.iterator().next();
/*  99:118 */           while (lst.contains(pred))
/* 100:    */           {
/* 101:119 */             Set<Statement> setPredTemp = pred.getNeighboursSet(1, 0);
/* 102:120 */             setPredTemp.remove(head);
/* 103:122 */             if (setPredTemp.isEmpty()) {
/* 104:    */               break;
/* 105:    */             }
/* 106:123 */             pred = (Statement)setPredTemp.iterator().next();
/* 107:124 */             if (pred == stat) {
/* 108:125 */               return false;
/* 109:    */             }
/* 110:    */           }
/* 111:    */         }
/* 112:135 */         List<StatEdge> lstEdges = stat.getSuccessorEdges(1073741824);
/* 113:136 */         if (lstEdges.size() > 1)
/* 114:    */         {
/* 115:137 */           Set<Statement> setSucc = stat.getNeighboursSet(1073741824, 1);
/* 116:138 */           setSucc.retainAll(setDest);
/* 117:140 */           if (setSucc.size() > 0) {
/* 118:141 */             return false;
/* 119:    */           }
/* 120:144 */           if (post == null)
/* 121:    */           {
/* 122:145 */             post = stat;
/* 123:146 */             repeat = true;
/* 124:147 */             break;
/* 125:    */           }
/* 126:150 */           return false;
/* 127:    */         }
/* 128:154 */         if (lstEdges.size() == 1)
/* 129:    */         {
/* 130:156 */           StatEdge edge = (StatEdge)lstEdges.get(0);
/* 131:157 */           if (edge.getType() == 1)
/* 132:    */           {
/* 133:158 */             Statement statd = edge.getDestination();
/* 134:159 */             if (head == statd) {
/* 135:160 */               return false;
/* 136:    */             }
/* 137:162 */             if ((!setDest.contains(statd)) && (post != statd))
/* 138:    */             {
/* 139:163 */               if (post != null) {
/* 140:164 */                 return false;
/* 141:    */               }
/* 142:167 */               Set<Statement> set = statd.getNeighboursSet(1, 0);
/* 143:168 */               if (set.size() > 1)
/* 144:    */               {
/* 145:169 */                 post = statd;
/* 146:170 */                 repeat = true;
/* 147:171 */                 break;
/* 148:    */               }
/* 149:174 */               return false;
/* 150:    */             }
/* 151:    */           }
/* 152:    */         }
/* 153:181 */         lst.add(stat);
/* 154:    */       }
/* 155:184 */       if (!repeat) {
/* 156:    */         break;
/* 157:    */       }
/* 158:    */     }
/* 159:189 */     lst.add(head);
/* 160:190 */     lst.remove(post);
/* 161:    */     
/* 162:192 */     lst.add(0, post);
/* 163:    */     
/* 164:194 */     return true;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public static HashSet<Statement> getUniquePredExceptions(Statement head)
/* 168:    */   {
/* 169:200 */     HashSet<Statement> setHandlers = new HashSet(head.getNeighbours(2, 1));
/* 170:    */     
/* 171:202 */     Iterator<Statement> it = setHandlers.iterator();
/* 172:203 */     while (it.hasNext()) {
/* 173:204 */       if (((Statement)it.next()).getPredecessorEdges(2).size() > 1) {
/* 174:205 */         it.remove();
/* 175:    */       }
/* 176:    */     }
/* 177:208 */     return setHandlers;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static List<Exprent> copyExprentList(List<Exprent> lst)
/* 181:    */   {
/* 182:212 */     List<Exprent> ret = new ArrayList();
/* 183:213 */     for (Exprent expr : lst) {
/* 184:214 */       ret.add(expr.copy());
/* 185:    */     }
/* 186:216 */     return ret;
/* 187:    */   }
/* 188:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.DecHelper
 * JD-Core Version:    0.7.0.1
 */