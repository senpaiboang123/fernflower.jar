/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.decompose;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Set;
/*   5:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*   6:    */ 
/*   7:    */ public class GenericDominatorEngine
/*   8:    */ {
/*   9:    */   private final IGraph graph;
/*  10: 27 */   private final VBStyleCollection<IGraphNode, IGraphNode> colOrderedIDoms = new VBStyleCollection();
/*  11:    */   private Set<? extends IGraphNode> setRoots;
/*  12:    */   
/*  13:    */   public GenericDominatorEngine(IGraph graph)
/*  14:    */   {
/*  15: 32 */     this.graph = graph;
/*  16:    */   }
/*  17:    */   
/*  18:    */   public void initialize()
/*  19:    */   {
/*  20: 36 */     calcIDoms();
/*  21:    */   }
/*  22:    */   
/*  23:    */   private void orderNodes()
/*  24:    */   {
/*  25: 41 */     this.setRoots = this.graph.getRoots();
/*  26: 43 */     for (IGraphNode node : this.graph.getReversePostOrderList()) {
/*  27: 44 */       this.colOrderedIDoms.addWithKey(null, node);
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31:    */   private static IGraphNode getCommonIDom(IGraphNode node1, IGraphNode node2, VBStyleCollection<IGraphNode, IGraphNode> orderedIDoms)
/*  32:    */   {
/*  33: 52 */     if (node1 == null) {
/*  34: 53 */       return node2;
/*  35:    */     }
/*  36: 55 */     if (node2 == null) {
/*  37: 56 */       return node1;
/*  38:    */     }
/*  39: 59 */     int index1 = orderedIDoms.getIndexByKey(node1);
/*  40: 60 */     int index2 = orderedIDoms.getIndexByKey(node2);
/*  41: 62 */     while (index1 != index2) {
/*  42: 63 */       if (index1 > index2)
/*  43:    */       {
/*  44: 64 */         IGraphNode nodeOld = node1;
/*  45: 65 */         node1 = (IGraphNode)orderedIDoms.getWithKey(node1);
/*  46: 67 */         if (nodeOld == node1) {
/*  47: 68 */           return null;
/*  48:    */         }
/*  49: 71 */         index1 = orderedIDoms.getIndexByKey(node1);
/*  50:    */       }
/*  51:    */       else
/*  52:    */       {
/*  53: 74 */         IGraphNode nodeOld = node2;
/*  54: 75 */         node2 = (IGraphNode)orderedIDoms.getWithKey(node2);
/*  55: 77 */         if (nodeOld == node2) {
/*  56: 78 */           return null;
/*  57:    */         }
/*  58: 81 */         index2 = orderedIDoms.getIndexByKey(node2);
/*  59:    */       }
/*  60:    */     }
/*  61: 85 */     return node1;
/*  62:    */   }
/*  63:    */   
/*  64:    */   private void calcIDoms()
/*  65:    */   {
/*  66: 90 */     orderNodes();
/*  67:    */     
/*  68: 92 */     List<IGraphNode> lstNodes = this.colOrderedIDoms.getLstKeys();
/*  69:    */     for (;;)
/*  70:    */     {
/*  71: 96 */       boolean changed = false;
/*  72: 98 */       for (IGraphNode node : lstNodes)
/*  73:    */       {
/*  74:100 */         IGraphNode idom = null;
/*  75:102 */         if (!this.setRoots.contains(node)) {
/*  76:103 */           for (IGraphNode pred : node.getPredecessors()) {
/*  77:104 */             if (this.colOrderedIDoms.getWithKey(pred) != null)
/*  78:    */             {
/*  79:105 */               idom = getCommonIDom(idom, pred, this.colOrderedIDoms);
/*  80:106 */               if (idom == null) {
/*  81:    */                 break;
/*  82:    */               }
/*  83:    */             }
/*  84:    */           }
/*  85:    */         }
/*  86:113 */         if (idom == null) {
/*  87:114 */           idom = node;
/*  88:    */         }
/*  89:117 */         IGraphNode oldidom = (IGraphNode)this.colOrderedIDoms.putWithKey(idom, node);
/*  90:118 */         if (!idom.equals(oldidom)) {
/*  91:119 */           changed = true;
/*  92:    */         }
/*  93:    */       }
/*  94:123 */       if (!changed) {
/*  95:    */         break;
/*  96:    */       }
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   public VBStyleCollection<IGraphNode, IGraphNode> getOrderedIDoms()
/* 101:    */   {
/* 102:130 */     return this.colOrderedIDoms;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public boolean isDominator(IGraphNode node, IGraphNode dom)
/* 106:    */   {
/* 107:135 */     while (!node.equals(dom))
/* 108:    */     {
/* 109:137 */       IGraphNode idom = (IGraphNode)this.colOrderedIDoms.getWithKey(node);
/* 110:139 */       if (idom == node) {
/* 111:140 */         return false;
/* 112:    */       }
/* 113:142 */       if (idom == null) {
/* 114:143 */         throw new RuntimeException("Inconsistent idom sequence discovered!");
/* 115:    */       }
/* 116:146 */       node = idom;
/* 117:    */     }
/* 118:150 */     return true;
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.decompose.GenericDominatorEngine
 * JD-Core Version:    0.7.0.1
 */