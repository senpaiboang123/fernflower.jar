/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.decompose;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*   6:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*   7:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*   8:    */ 
/*   9:    */ public class DominatorEngine
/*  10:    */ {
/*  11:    */   private final Statement statement;
/*  12: 28 */   private final VBStyleCollection<Integer, Integer> colOrderedIDoms = new VBStyleCollection();
/*  13:    */   
/*  14:    */   public DominatorEngine(Statement statement)
/*  15:    */   {
/*  16: 32 */     this.statement = statement;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public void initialize()
/*  20:    */   {
/*  21: 36 */     calcIDoms();
/*  22:    */   }
/*  23:    */   
/*  24:    */   private void orderStatements()
/*  25:    */   {
/*  26: 41 */     for (Statement stat : this.statement.getReversePostOrderList()) {
/*  27: 42 */       this.colOrderedIDoms.addWithKey(null, stat.id);
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31:    */   private static Integer getCommonIDom(Integer key1, Integer key2, VBStyleCollection<Integer, Integer> orderedIDoms)
/*  32:    */   {
/*  33: 48 */     if (key1 == null) {
/*  34: 49 */       return key2;
/*  35:    */     }
/*  36: 51 */     if (key2 == null) {
/*  37: 52 */       return key1;
/*  38:    */     }
/*  39: 55 */     int index1 = orderedIDoms.getIndexByKey(key1);
/*  40: 56 */     int index2 = orderedIDoms.getIndexByKey(key2);
/*  41: 58 */     while (index1 != index2) {
/*  42: 59 */       if (index1 > index2)
/*  43:    */       {
/*  44: 60 */         key1 = (Integer)orderedIDoms.getWithKey(key1);
/*  45: 61 */         index1 = orderedIDoms.getIndexByKey(key1);
/*  46:    */       }
/*  47:    */       else
/*  48:    */       {
/*  49: 64 */         key2 = (Integer)orderedIDoms.getWithKey(key2);
/*  50: 65 */         index2 = orderedIDoms.getIndexByKey(key2);
/*  51:    */       }
/*  52:    */     }
/*  53: 69 */     return key1;
/*  54:    */   }
/*  55:    */   
/*  56:    */   private void calcIDoms()
/*  57:    */   {
/*  58: 74 */     orderStatements();
/*  59:    */     
/*  60: 76 */     this.colOrderedIDoms.putWithKey(this.statement.getFirst().id, this.statement.getFirst().id);
/*  61:    */     
/*  62:    */ 
/*  63: 79 */     List<Integer> lstIds = this.colOrderedIDoms.getLstKeys().subList(1, this.colOrderedIDoms.getLstKeys().size());
/*  64:    */     for (;;)
/*  65:    */     {
/*  66: 83 */       boolean changed = false;
/*  67: 85 */       for (Integer id : lstIds)
/*  68:    */       {
/*  69: 87 */         Statement stat = (Statement)this.statement.getStats().getWithKey(id);
/*  70: 88 */         Integer idom = null;
/*  71: 90 */         for (StatEdge edge : stat.getAllPredecessorEdges()) {
/*  72: 91 */           if (this.colOrderedIDoms.getWithKey(edge.getSource().id) != null) {
/*  73: 92 */             idom = getCommonIDom(idom, edge.getSource().id, this.colOrderedIDoms);
/*  74:    */           }
/*  75:    */         }
/*  76: 96 */         Integer oldidom = (Integer)this.colOrderedIDoms.putWithKey(idom, id);
/*  77: 97 */         if (!idom.equals(oldidom)) {
/*  78: 98 */           changed = true;
/*  79:    */         }
/*  80:    */       }
/*  81:102 */       if (!changed) {
/*  82:    */         break;
/*  83:    */       }
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public VBStyleCollection<Integer, Integer> getOrderedIDoms()
/*  88:    */   {
/*  89:109 */     return this.colOrderedIDoms;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean isDominator(Integer node, Integer dom)
/*  93:    */   {
/*  94:114 */     while (!node.equals(dom))
/*  95:    */     {
/*  96:116 */       Integer idom = (Integer)this.colOrderedIDoms.getWithKey(node);
/*  97:118 */       if (idom.equals(node)) {
/*  98:119 */         return false;
/*  99:    */       }
/* 100:122 */       node = idom;
/* 101:    */     }
/* 102:126 */     return true;
/* 103:    */   }
/* 104:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.decompose.DominatorEngine
 * JD-Core Version:    0.7.0.1
 */