package org.jetbrains.java.decompiler.modules.decompiler.decompose;

import java.util.List;

public abstract interface IGraphNode
{
  public abstract List<? extends IGraphNode> getPredecessors();
}


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.decompose.IGraphNode
 * JD-Core Version:    0.7.0.1
 */