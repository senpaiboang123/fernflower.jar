package org.jetbrains.java.decompiler.modules.decompiler.decompose;

import java.util.List;
import java.util.Set;

public abstract interface IGraph
{
  public abstract List<? extends IGraphNode> getReversePostOrderList();
  
  public abstract Set<? extends IGraphNode> getRoots();
}


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.decompose.IGraph
 * JD-Core Version:    0.7.0.1
 */