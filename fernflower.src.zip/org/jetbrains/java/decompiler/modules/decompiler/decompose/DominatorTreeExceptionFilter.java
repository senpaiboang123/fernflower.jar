/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.decompose;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import java.util.Set;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  11:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  12:    */ 
/*  13:    */ public class DominatorTreeExceptionFilter
/*  14:    */ {
/*  15:    */   private final Statement statement;
/*  16: 30 */   private final Map<Integer, Set<Integer>> mapTreeBranches = new HashMap();
/*  17: 33 */   private final Map<Integer, Set<Integer>> mapExceptionRanges = new HashMap();
/*  18: 36 */   private Map<Integer, Integer> mapExceptionDoms = new HashMap();
/*  19: 39 */   private final Map<Integer, Map<Integer, Integer>> mapExceptionRangeUniqueExit = new HashMap();
/*  20:    */   private DominatorEngine domEngine;
/*  21:    */   
/*  22:    */   public DominatorTreeExceptionFilter(Statement statement)
/*  23:    */   {
/*  24: 44 */     this.statement = statement;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void initialize()
/*  28:    */   {
/*  29: 49 */     this.domEngine = new DominatorEngine(this.statement);
/*  30: 50 */     this.domEngine.initialize();
/*  31:    */     
/*  32: 52 */     buildDominatorTree();
/*  33:    */     
/*  34: 54 */     buildExceptionRanges();
/*  35:    */     
/*  36: 56 */     buildFilter(this.statement.getFirst().id);
/*  37:    */     
/*  38:    */ 
/*  39: 59 */     this.mapTreeBranches.clear();
/*  40: 60 */     this.mapExceptionRanges.clear();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public boolean acceptStatementPair(Integer head, Integer exit)
/*  44:    */   {
/*  45: 65 */     Map<Integer, Integer> filter = (Map)this.mapExceptionRangeUniqueExit.get(head);
/*  46: 66 */     for (Map.Entry<Integer, Integer> entry : filter.entrySet()) {
/*  47: 67 */       if (!head.equals(this.mapExceptionDoms.get(entry.getKey())))
/*  48:    */       {
/*  49: 68 */         Integer filterExit = (Integer)entry.getValue();
/*  50: 69 */         if ((filterExit.intValue() == -1) || (!filterExit.equals(exit))) {
/*  51: 70 */           return false;
/*  52:    */         }
/*  53:    */       }
/*  54:    */     }
/*  55: 75 */     return true;
/*  56:    */   }
/*  57:    */   
/*  58:    */   private void buildDominatorTree()
/*  59:    */   {
/*  60: 80 */     VBStyleCollection<Integer, Integer> orderedIDoms = this.domEngine.getOrderedIDoms();
/*  61:    */     
/*  62: 82 */     List<Integer> lstKeys = orderedIDoms.getLstKeys();
/*  63: 83 */     for (int index = lstKeys.size() - 1; index >= 0; index--)
/*  64:    */     {
/*  65: 84 */       Integer key = (Integer)lstKeys.get(index);
/*  66: 85 */       Integer idom = (Integer)orderedIDoms.get(index);
/*  67:    */       
/*  68: 87 */       Set<Integer> set = (Set)this.mapTreeBranches.get(idom);
/*  69: 88 */       if (set == null) {
/*  70: 89 */         this.mapTreeBranches.put(idom, set = new HashSet());
/*  71:    */       }
/*  72: 91 */       set.add(key);
/*  73:    */     }
/*  74: 94 */     Integer firstid = this.statement.getFirst().id;
/*  75: 95 */     ((Set)this.mapTreeBranches.get(firstid)).remove(firstid);
/*  76:    */   }
/*  77:    */   
/*  78:    */   private void buildExceptionRanges()
/*  79:    */   {
/*  80:100 */     for (Statement stat : this.statement.getStats())
/*  81:    */     {
/*  82:101 */       List<Statement> lstPreds = stat.getNeighbours(2, 0);
/*  83:102 */       if (!lstPreds.isEmpty())
/*  84:    */       {
/*  85:104 */         Set<Integer> set = new HashSet();
/*  86:106 */         for (Statement st : lstPreds) {
/*  87:107 */           set.add(st.id);
/*  88:    */         }
/*  89:110 */         this.mapExceptionRanges.put(stat.id, set);
/*  90:    */       }
/*  91:    */     }
/*  92:114 */     this.mapExceptionDoms = buildExceptionDoms(this.statement.getFirst().id);
/*  93:    */   }
/*  94:    */   
/*  95:    */   private Map<Integer, Integer> buildExceptionDoms(Integer id)
/*  96:    */   {
/*  97:119 */     Map<Integer, Integer> map = new HashMap();
/*  98:    */     
/*  99:121 */     Set<Integer> children = (Set)this.mapTreeBranches.get(id);
/* 100:122 */     if (children != null) {
/* 101:123 */       for (Integer childid : children)
/* 102:    */       {
/* 103:124 */         mapChild = buildExceptionDoms(childid);
/* 104:125 */         for (Integer handler : mapChild.keySet()) {
/* 105:126 */           map.put(handler, map.containsKey(handler) ? id : (Integer)mapChild.get(handler));
/* 106:    */         }
/* 107:    */       }
/* 108:    */     }
/* 109:    */     Map<Integer, Integer> mapChild;
/* 110:131 */     for (Map.Entry<Integer, Set<Integer>> entry : this.mapExceptionRanges.entrySet()) {
/* 111:132 */       if (((Set)entry.getValue()).contains(id)) {
/* 112:133 */         map.put(entry.getKey(), id);
/* 113:    */       }
/* 114:    */     }
/* 115:137 */     return map;
/* 116:    */   }
/* 117:    */   
/* 118:    */   private void buildFilter(Integer id)
/* 119:    */   {
/* 120:143 */     Map<Integer, Integer> map = new HashMap();
/* 121:    */     
/* 122:145 */     Set<Integer> children = (Set)this.mapTreeBranches.get(id);
/* 123:    */     Iterator i$;
/* 124:146 */     if (children != null) {
/* 125:147 */       for (i$ = children.iterator(); i$.hasNext();)
/* 126:    */       {
/* 127:147 */         childid = (Integer)i$.next();
/* 128:    */         
/* 129:149 */         buildFilter(childid);
/* 130:    */         
/* 131:151 */         mapChild = (Map)this.mapExceptionRangeUniqueExit.get(childid);
/* 132:153 */         for (Map.Entry<Integer, Set<Integer>> entry : this.mapExceptionRanges.entrySet())
/* 133:    */         {
/* 134:155 */           Integer handler = (Integer)entry.getKey();
/* 135:156 */           Set<Integer> range = (Set)entry.getValue();
/* 136:158 */           if (range.contains(id))
/* 137:    */           {
/* 138:160 */             Integer exit = null;
/* 139:162 */             if (!range.contains(childid)) {
/* 140:163 */               exit = childid;
/* 141:    */             } else {
/* 142:167 */               exit = map.containsKey(handler) ? new Integer(-1) : (Integer)mapChild.get(handler);
/* 143:    */             }
/* 144:170 */             if (exit != null) {
/* 145:171 */               map.put(handler, exit);
/* 146:    */             }
/* 147:    */           }
/* 148:    */         }
/* 149:    */       }
/* 150:    */     }
/* 151:    */     Integer childid;
/* 152:    */     Map<Integer, Integer> mapChild;
/* 153:178 */     this.mapExceptionRangeUniqueExit.put(id, map);
/* 154:    */   }
/* 155:    */   
/* 156:    */   public DominatorEngine getDomEngine()
/* 157:    */   {
/* 158:182 */     return this.domEngine;
/* 159:    */   }
/* 160:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.decompose.DominatorTreeExceptionFilter
 * JD-Core Version:    0.7.0.1
 */