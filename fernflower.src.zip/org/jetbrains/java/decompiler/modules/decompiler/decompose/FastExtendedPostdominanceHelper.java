/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.decompose;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.LinkedList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  13:    */ import org.jetbrains.java.decompiler.util.FastFixedSetFactory;
/*  14:    */ import org.jetbrains.java.decompiler.util.FastFixedSetFactory.FastFixedSet;
/*  15:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  16:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  17:    */ 
/*  18:    */ public class FastExtendedPostdominanceHelper
/*  19:    */ {
/*  20:    */   private List<Statement> lstReversePostOrderList;
/*  21:    */   private HashMap<Integer, FastFixedSetFactory.FastFixedSet<Integer>> mapSupportPoints;
/*  22:    */   private final HashMap<Integer, FastFixedSetFactory.FastFixedSet<Integer>> mapExtPostdominators;
/*  23:    */   private Statement statement;
/*  24:    */   private FastFixedSetFactory<Integer> factory;
/*  25:    */   
/*  26:    */   public FastExtendedPostdominanceHelper()
/*  27:    */   {
/*  28: 31 */     this.mapSupportPoints = new HashMap();
/*  29:    */     
/*  30: 33 */     this.mapExtPostdominators = new HashMap();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public HashMap<Integer, Set<Integer>> getExtendedPostdominators(Statement statement)
/*  34:    */   {
/*  35: 41 */     this.statement = statement;
/*  36:    */     
/*  37: 43 */     HashSet<Integer> set = new HashSet();
/*  38: 44 */     for (Statement st : statement.getStats()) {
/*  39: 45 */       set.add(st.id);
/*  40:    */     }
/*  41: 47 */     this.factory = new FastFixedSetFactory(set);
/*  42:    */     
/*  43: 49 */     this.lstReversePostOrderList = statement.getReversePostOrderList();
/*  44:    */     
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51: 57 */     calcDefaultReachableSets();
/*  52:    */     
/*  53: 59 */     removeErroneousNodes();
/*  54:    */     
/*  55: 61 */     DominatorTreeExceptionFilter filter = new DominatorTreeExceptionFilter(statement);
/*  56: 62 */     filter.initialize();
/*  57:    */     
/*  58: 64 */     filterOnExceptionRanges(filter);
/*  59:    */     
/*  60: 66 */     filterOnDominance(filter);
/*  61:    */     
/*  62: 68 */     HashMap<Integer, Set<Integer>> res = new HashMap();
/*  63: 69 */     for (Map.Entry<Integer, FastFixedSetFactory.FastFixedSet<Integer>> entry : this.mapExtPostdominators.entrySet()) {
/*  64: 70 */       res.put(entry.getKey(), ((FastFixedSetFactory.FastFixedSet)entry.getValue()).toPlainSet());
/*  65:    */     }
/*  66: 73 */     return res;
/*  67:    */   }
/*  68:    */   
/*  69:    */   private void filterOnDominance(DominatorTreeExceptionFilter filter)
/*  70:    */   {
/*  71: 79 */     DominatorEngine engine = filter.getDomEngine();
/*  72: 81 */     for (Integer head : new HashSet(this.mapExtPostdominators.keySet()))
/*  73:    */     {
/*  74: 83 */       FastFixedSetFactory.FastFixedSet<Integer> setPostdoms = (FastFixedSetFactory.FastFixedSet)this.mapExtPostdominators.get(head);
/*  75:    */       
/*  76: 85 */       LinkedList<Statement> stack = new LinkedList();
/*  77: 86 */       LinkedList<FastFixedSetFactory.FastFixedSet<Integer>> stackPath = new LinkedList();
/*  78:    */       
/*  79: 88 */       stack.add(this.statement.getStats().getWithKey(head));
/*  80: 89 */       stackPath.add(this.factory.spawnEmptySet());
/*  81:    */       
/*  82: 91 */       Set<Statement> setVisited = new HashSet();
/*  83:    */       
/*  84: 93 */       setVisited.add(stack.getFirst());
/*  85:    */       FastFixedSetFactory.FastFixedSet<Integer> path;
/*  86: 95 */       while (!stack.isEmpty())
/*  87:    */       {
/*  88: 97 */         Statement stat = (Statement)stack.removeFirst();
/*  89: 98 */         path = (FastFixedSetFactory.FastFixedSet)stackPath.removeFirst();
/*  90:100 */         if (setPostdoms.contains(stat.id)) {
/*  91:101 */           path.add(stat.id);
/*  92:    */         }
/*  93:104 */         if (!path.contains(setPostdoms)) {
/*  94:108 */           if (!engine.isDominator(stat.id, head)) {
/*  95:109 */             setPostdoms.complement(path);
/*  96:    */           } else {
/*  97:113 */             for (StatEdge edge : stat.getSuccessorEdges(1))
/*  98:    */             {
/*  99:115 */               Statement edge_destination = edge.getDestination();
/* 100:117 */               if (!setVisited.contains(edge_destination))
/* 101:    */               {
/* 102:119 */                 stack.add(edge_destination);
/* 103:120 */                 stackPath.add(path.getCopy());
/* 104:    */                 
/* 105:122 */                 setVisited.add(edge_destination);
/* 106:    */               }
/* 107:    */             }
/* 108:    */           }
/* 109:    */         }
/* 110:    */       }
/* 111:127 */       if (setPostdoms.isEmpty()) {
/* 112:128 */         this.mapExtPostdominators.remove(head);
/* 113:    */       }
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   private void filterOnExceptionRanges(DominatorTreeExceptionFilter filter)
/* 118:    */   {
/* 119:137 */     for (Integer head : new HashSet(this.mapExtPostdominators.keySet()))
/* 120:    */     {
/* 121:139 */       FastFixedSetFactory.FastFixedSet<Integer> set = (FastFixedSetFactory.FastFixedSet)this.mapExtPostdominators.get(head);
/* 122:140 */       for (Iterator<Integer> it = set.iterator(); it.hasNext();) {
/* 123:141 */         if (!filter.acceptStatementPair(head, (Integer)it.next())) {
/* 124:142 */           it.remove();
/* 125:    */         }
/* 126:    */       }
/* 127:145 */       if (set.isEmpty()) {
/* 128:146 */         this.mapExtPostdominators.remove(head);
/* 129:    */       }
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   private void removeErroneousNodes()
/* 134:    */   {
/* 135:154 */     this.mapSupportPoints = new HashMap();
/* 136:    */     
/* 137:156 */     calcReachabilitySuppPoints(1);
/* 138:    */     
/* 139:158 */     iterateReachability(new IReachabilityAction()
/* 140:    */     {
/* 141:    */       public boolean action(Statement node, HashMap<Integer, FastFixedSetFactory.FastFixedSet<Integer>> mapSets)
/* 142:    */       {
/* 143:161 */         Integer nodeid = node.id;
/* 144:    */         
/* 145:163 */         FastFixedSetFactory.FastFixedSet<Integer> setReachability = (FastFixedSetFactory.FastFixedSet)mapSets.get(nodeid);
/* 146:164 */         List<FastFixedSetFactory.FastFixedSet<Integer>> lstPredSets = new ArrayList();
/* 147:166 */         for (StatEdge prededge : node.getPredecessorEdges(1))
/* 148:    */         {
/* 149:167 */           FastFixedSetFactory.FastFixedSet<Integer> setPred = (FastFixedSetFactory.FastFixedSet)mapSets.get(prededge.getSource().id);
/* 150:168 */           if (setPred == null) {
/* 151:169 */             setPred = (FastFixedSetFactory.FastFixedSet)FastExtendedPostdominanceHelper.this.mapSupportPoints.get(prededge.getSource().id);
/* 152:    */           }
/* 153:173 */           lstPredSets.add(setPred);
/* 154:    */         }
/* 155:176 */         for (Integer id : setReachability.toPlainSet())
/* 156:    */         {
/* 157:178 */           FastFixedSetFactory.FastFixedSet<Integer> setReachabilityCopy = setReachability.getCopy();
/* 158:    */           
/* 159:180 */           FastFixedSetFactory.FastFixedSet<Integer> setIntersection = FastExtendedPostdominanceHelper.this.factory.spawnEmptySet();
/* 160:181 */           boolean isIntersectionInitialized = false;
/* 161:183 */           for (FastFixedSetFactory.FastFixedSet<Integer> predset : lstPredSets) {
/* 162:184 */             if (predset.contains(id)) {
/* 163:185 */               if (!isIntersectionInitialized)
/* 164:    */               {
/* 165:186 */                 setIntersection.union(predset);
/* 166:187 */                 isIntersectionInitialized = true;
/* 167:    */               }
/* 168:    */               else
/* 169:    */               {
/* 170:190 */                 setIntersection.intersection(predset);
/* 171:    */               }
/* 172:    */             }
/* 173:    */           }
/* 174:195 */           if (nodeid.intValue() != id.intValue()) {
/* 175:196 */             setIntersection.add(nodeid);
/* 176:    */           } else {
/* 177:199 */             setIntersection.remove(nodeid);
/* 178:    */           }
/* 179:202 */           setReachabilityCopy.complement(setIntersection);
/* 180:    */           
/* 181:204 */           ((FastFixedSetFactory.FastFixedSet)FastExtendedPostdominanceHelper.this.mapExtPostdominators.get(id)).complement(setReachabilityCopy);
/* 182:    */         }
/* 183:207 */         return false;
/* 184:    */       }
/* 185:207 */     }, 1);
/* 186:    */     
/* 187:    */ 
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:213 */     FastFixedSetFactory.FastFixedSet<Integer> setHandlers = this.factory.spawnEmptySet();
/* 192:214 */     boolean handlerfound = false;
/* 193:216 */     for (Statement stat : this.statement.getStats()) {
/* 194:217 */       if ((stat.getPredecessorEdges(1073741824).isEmpty()) && (!stat.getPredecessorEdges(2).isEmpty()))
/* 195:    */       {
/* 196:219 */         setHandlers.add(stat.id);
/* 197:220 */         handlerfound = true;
/* 198:    */       }
/* 199:    */     }
/* 200:224 */     if (handlerfound) {
/* 201:225 */       for (FastFixedSetFactory.FastFixedSet<Integer> set : this.mapExtPostdominators.values()) {
/* 202:226 */         set.complement(setHandlers);
/* 203:    */       }
/* 204:    */     }
/* 205:    */   }
/* 206:    */   
/* 207:    */   private void calcDefaultReachableSets()
/* 208:    */   {
/* 209:234 */     int edgetype = 3;
/* 210:    */     
/* 211:236 */     calcReachabilitySuppPoints(edgetype);
/* 212:238 */     for (Statement stat : this.statement.getStats()) {
/* 213:239 */       this.mapExtPostdominators.put(stat.id, this.factory.spawnEmptySet());
/* 214:    */     }
/* 215:242 */     iterateReachability(new IReachabilityAction()
/* 216:    */     {
/* 217:    */       public boolean action(Statement node, HashMap<Integer, FastFixedSetFactory.FastFixedSet<Integer>> mapSets)
/* 218:    */       {
/* 219:245 */         Integer nodeid = node.id;
/* 220:246 */         FastFixedSetFactory.FastFixedSet<Integer> setReachability = (FastFixedSetFactory.FastFixedSet)mapSets.get(nodeid);
/* 221:248 */         for (Integer id : setReachability.toPlainSet()) {
/* 222:249 */           ((FastFixedSetFactory.FastFixedSet)FastExtendedPostdominanceHelper.this.mapExtPostdominators.get(id)).add(nodeid);
/* 223:    */         }
/* 224:252 */         return false;
/* 225:    */       }
/* 226:252 */     }, edgetype);
/* 227:    */   }
/* 228:    */   
/* 229:    */   private void calcReachabilitySuppPoints(final int edgetype)
/* 230:    */   {
/* 231:260 */     iterateReachability(new IReachabilityAction()
/* 232:    */     {
/* 233:    */       public boolean action(Statement node, HashMap<Integer, FastFixedSetFactory.FastFixedSet<Integer>> mapSets)
/* 234:    */       {
/* 235:264 */         for (StatEdge sucedge : node.getAllSuccessorEdges()) {
/* 236:265 */           if (((sucedge.getType() & edgetype) != 0) && 
/* 237:266 */             (mapSets.containsKey(sucedge.getDestination().id)))
/* 238:    */           {
/* 239:267 */             FastFixedSetFactory.FastFixedSet<Integer> setReachability = (FastFixedSetFactory.FastFixedSet)mapSets.get(node.id);
/* 240:269 */             if (!InterpreterUtil.equalObjects(setReachability, FastExtendedPostdominanceHelper.this.mapSupportPoints.get(node.id)))
/* 241:    */             {
/* 242:270 */               FastExtendedPostdominanceHelper.this.mapSupportPoints.put(node.id, setReachability);
/* 243:271 */               return true;
/* 244:    */             }
/* 245:    */           }
/* 246:    */         }
/* 247:277 */         return false;
/* 248:    */       }
/* 249:277 */     }, edgetype);
/* 250:    */   }
/* 251:    */   
/* 252:    */   private void iterateReachability(IReachabilityAction action, int edgetype)
/* 253:    */   {
/* 254:    */     for (;;)
/* 255:    */     {
/* 256:286 */       boolean iterate = false;
/* 257:    */       
/* 258:288 */       HashMap<Integer, FastFixedSetFactory.FastFixedSet<Integer>> mapSets = new HashMap();
/* 259:290 */       for (Statement stat : this.lstReversePostOrderList)
/* 260:    */       {
/* 261:292 */         FastFixedSetFactory.FastFixedSet<Integer> set = this.factory.spawnEmptySet();
/* 262:293 */         set.add(stat.id);
/* 263:295 */         for (StatEdge prededge : stat.getAllPredecessorEdges()) {
/* 264:296 */           if ((prededge.getType() & edgetype) != 0)
/* 265:    */           {
/* 266:297 */             Statement pred = prededge.getSource();
/* 267:    */             
/* 268:299 */             FastFixedSetFactory.FastFixedSet<Integer> setPred = (FastFixedSetFactory.FastFixedSet)mapSets.get(pred.id);
/* 269:300 */             if (setPred == null) {
/* 270:301 */               setPred = (FastFixedSetFactory.FastFixedSet)this.mapSupportPoints.get(pred.id);
/* 271:    */             }
/* 272:304 */             if (setPred != null) {
/* 273:305 */               set.union(setPred);
/* 274:    */             }
/* 275:    */           }
/* 276:    */         }
/* 277:310 */         mapSets.put(stat.id, set);
/* 278:312 */         if (action != null) {
/* 279:313 */           iterate |= action.action(stat, mapSets);
/* 280:    */         }
/* 281:317 */         for (StatEdge prededge : stat.getAllPredecessorEdges()) {
/* 282:318 */           if ((prededge.getType() & edgetype) != 0)
/* 283:    */           {
/* 284:319 */             Statement pred = prededge.getSource();
/* 285:321 */             if (mapSets.containsKey(pred.id))
/* 286:    */             {
/* 287:322 */               boolean remstat = true;
/* 288:323 */               for (StatEdge sucedge : pred.getAllSuccessorEdges()) {
/* 289:324 */                 if (((sucedge.getType() & edgetype) != 0) && 
/* 290:325 */                   (!mapSets.containsKey(sucedge.getDestination().id)))
/* 291:    */                 {
/* 292:326 */                   remstat = false;
/* 293:327 */                   break;
/* 294:    */                 }
/* 295:    */               }
/* 296:332 */               if (remstat) {
/* 297:333 */                 mapSets.put(pred.id, null);
/* 298:    */               }
/* 299:    */             }
/* 300:    */           }
/* 301:    */         }
/* 302:    */       }
/* 303:340 */       if (!iterate) {
/* 304:    */         break;
/* 305:    */       }
/* 306:    */     }
/* 307:    */   }
/* 308:    */   
/* 309:    */   private static abstract interface IReachabilityAction
/* 310:    */   {
/* 311:    */     public abstract boolean action(Statement paramStatement, HashMap<Integer, FastFixedSetFactory.FastFixedSet<Integer>> paramHashMap);
/* 312:    */   }
/* 313:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.decompose.FastExtendedPostdominanceHelper
 * JD-Core Version:    0.7.0.1
 */