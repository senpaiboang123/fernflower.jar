/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.HashSet;
/*   4:    */ import java.util.LinkedList;
/*   5:    */ import java.util.List;
/*   6:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectNode;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.FlattenStatementsHelper;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  14:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  15:    */ 
/*  16:    */ public class PPandMMHelper
/*  17:    */ {
/*  18:    */   private boolean exprentReplaced;
/*  19:    */   
/*  20:    */   public boolean findPPandMM(RootStatement root)
/*  21:    */   {
/*  22: 38 */     FlattenStatementsHelper flatthelper = new FlattenStatementsHelper();
/*  23: 39 */     DirectGraph dgraph = flatthelper.buildDirectGraph(root);
/*  24:    */     
/*  25: 41 */     LinkedList<DirectNode> stack = new LinkedList();
/*  26: 42 */     stack.add(dgraph.first);
/*  27:    */     
/*  28: 44 */     HashSet<DirectNode> setVisited = new HashSet();
/*  29:    */     
/*  30: 46 */     boolean res = false;
/*  31: 48 */     while (!stack.isEmpty())
/*  32:    */     {
/*  33: 50 */       DirectNode node = (DirectNode)stack.removeFirst();
/*  34: 52 */       if (!setVisited.contains(node))
/*  35:    */       {
/*  36: 55 */         setVisited.add(node);
/*  37:    */         
/*  38: 57 */         res |= processExprentList(node.exprents);
/*  39:    */         
/*  40: 59 */         stack.addAll(node.succs);
/*  41:    */       }
/*  42:    */     }
/*  43: 62 */     return res;
/*  44:    */   }
/*  45:    */   
/*  46:    */   private boolean processExprentList(List<Exprent> lst)
/*  47:    */   {
/*  48: 67 */     boolean result = false;
/*  49: 69 */     for (int i = 0; i < lst.size(); i++)
/*  50:    */     {
/*  51: 70 */       Exprent exprent = (Exprent)lst.get(i);
/*  52: 71 */       this.exprentReplaced = false;
/*  53:    */       
/*  54: 73 */       Exprent retexpr = processExprentRecursive(exprent);
/*  55: 74 */       if (retexpr != null)
/*  56:    */       {
/*  57: 75 */         lst.set(i, retexpr);
/*  58:    */         
/*  59: 77 */         result = true;
/*  60: 78 */         i--;
/*  61:    */       }
/*  62: 81 */       result |= this.exprentReplaced;
/*  63:    */     }
/*  64: 84 */     return result;
/*  65:    */   }
/*  66:    */   
/*  67:    */   private Exprent processExprentRecursive(Exprent exprent)
/*  68:    */   {
/*  69: 89 */     boolean replaced = true;
/*  70: 90 */     while (replaced)
/*  71:    */     {
/*  72: 91 */       replaced = false;
/*  73: 93 */       for (Exprent expr : exprent.getAllExprents())
/*  74:    */       {
/*  75: 94 */         Exprent retexpr = processExprentRecursive(expr);
/*  76: 95 */         if (retexpr != null)
/*  77:    */         {
/*  78: 96 */           exprent.replaceExprent(expr, retexpr);
/*  79: 97 */           replaced = true;
/*  80: 98 */           this.exprentReplaced = true;
/*  81: 99 */           break;
/*  82:    */         }
/*  83:    */       }
/*  84:    */     }
/*  85:104 */     if (exprent.type == 2)
/*  86:    */     {
/*  87:105 */       AssignmentExprent as = (AssignmentExprent)exprent;
/*  88:107 */       if (as.getRight().type == 6)
/*  89:    */       {
/*  90:108 */         FunctionExprent func = (FunctionExprent)as.getRight();
/*  91:    */         
/*  92:110 */         VarType midlayer = null;
/*  93:111 */         if ((func.getFuncType() >= 14) && (func.getFuncType() <= 28))
/*  94:    */         {
/*  95:113 */           midlayer = func.getSimpleCastType();
/*  96:114 */           if (((Exprent)func.getLstOperands().get(0)).type == 6) {
/*  97:115 */             func = (FunctionExprent)func.getLstOperands().get(0);
/*  98:    */           } else {
/*  99:118 */             return null;
/* 100:    */           }
/* 101:    */         }
/* 102:122 */         if ((func.getFuncType() == 0) || (func.getFuncType() == 1))
/* 103:    */         {
/* 104:124 */           Exprent econd = (Exprent)func.getLstOperands().get(0);
/* 105:125 */           Exprent econst = (Exprent)func.getLstOperands().get(1);
/* 106:127 */           if ((econst.type != 3) && (econd.type == 3) && (func.getFuncType() == 0))
/* 107:    */           {
/* 108:129 */             econd = econst;
/* 109:130 */             econst = (Exprent)func.getLstOperands().get(0);
/* 110:    */           }
/* 111:133 */           if ((econst.type == 3) && (((ConstExprent)econst).hasValueOne()))
/* 112:    */           {
/* 113:134 */             Exprent left = as.getLeft();
/* 114:    */             
/* 115:136 */             VarType condtype = econd.getExprType();
/* 116:137 */             if ((left.equals(econd)) && ((midlayer == null) || (midlayer.equals(condtype))))
/* 117:    */             {
/* 118:138 */               FunctionExprent ret = new FunctionExprent(func.getFuncType() == 0 ? 35 : 33, econd, func.bytecode);
/* 119:    */               
/* 120:    */ 
/* 121:141 */               ret.setImplicitType(condtype);
/* 122:    */               
/* 123:143 */               this.exprentReplaced = true;
/* 124:144 */               return ret;
/* 125:    */             }
/* 126:    */           }
/* 127:    */         }
/* 128:    */       }
/* 129:    */     }
/* 130:151 */     return null;
/* 131:    */   }
/* 132:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.PPandMMHelper
 * JD-Core Version:    0.7.0.1
 */