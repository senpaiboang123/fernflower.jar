/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SwitchStatement;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SynchronizedStatement;
/*  19:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  20:    */ 
/*  21:    */ public class LabelHelper
/*  22:    */ {
/*  23:    */   public static void cleanUpEdges(RootStatement root)
/*  24:    */   {
/*  25: 30 */     resetAllEdges(root);
/*  26:    */     
/*  27: 32 */     removeNonImmediateEdges(root);
/*  28:    */     
/*  29: 34 */     liftClosures(root);
/*  30:    */     
/*  31: 36 */     lowContinueLabels(root, new HashSet());
/*  32:    */     
/*  33: 38 */     lowClosures(root);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static void identifyLabels(RootStatement root)
/*  37:    */   {
/*  38: 43 */     setExplicitEdges(root);
/*  39:    */     
/*  40: 45 */     hideDefaultSwitchEdges(root);
/*  41:    */     
/*  42: 47 */     processStatementLabel(root);
/*  43:    */     
/*  44: 49 */     setRetEdgesUnlabeled(root);
/*  45:    */   }
/*  46:    */   
/*  47:    */   private static void liftClosures(Statement stat)
/*  48:    */   {
/*  49: 54 */     for (StatEdge edge : stat.getAllSuccessorEdges()) {
/*  50: 55 */       switch (edge.getType())
/*  51:    */       {
/*  52:    */       case 8: 
/*  53: 57 */         if (edge.getDestination() != edge.closure) {
/*  54: 58 */           edge.getDestination().addLabeledEdge(edge);
/*  55:    */         }
/*  56:    */         break;
/*  57:    */       case 4: 
/*  58: 62 */         Statement dest = edge.getDestination();
/*  59: 63 */         if (dest.type != 14)
/*  60:    */         {
/*  61: 64 */           Statement parent = dest.getParent();
/*  62:    */           
/*  63: 66 */           List<Statement> lst = new ArrayList();
/*  64: 67 */           if (parent.type == 15) {
/*  65: 68 */             lst.addAll(parent.getStats());
/*  66: 70 */           } else if (parent.type == 6) {
/*  67: 71 */             lst.addAll(((SwitchStatement)parent).getCaseStatements());
/*  68:    */           }
/*  69: 74 */           for (int i = 0; i < lst.size(); i++) {
/*  70: 75 */             if (lst.get(i) == dest)
/*  71:    */             {
/*  72: 76 */               ((Statement)lst.get(i - 1)).addLabeledEdge(edge);
/*  73: 77 */               break;
/*  74:    */             }
/*  75:    */           }
/*  76:    */         }
/*  77:    */         break;
/*  78:    */       }
/*  79:    */     }
/*  80: 84 */     for (Statement st : stat.getStats()) {
/*  81: 85 */       liftClosures(st);
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   private static void removeNonImmediateEdges(Statement stat)
/*  86:    */   {
/*  87: 91 */     for (Statement st : stat.getStats()) {
/*  88: 92 */       removeNonImmediateEdges(st);
/*  89:    */     }
/*  90: 95 */     if (!stat.hasBasicSuccEdge()) {
/*  91: 96 */       for (StatEdge edge : stat.getSuccessorEdges(12)) {
/*  92: 97 */         stat.removeSuccessor(edge);
/*  93:    */       }
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void lowContinueLabels(Statement stat, HashSet<StatEdge> edges)
/*  98:    */   {
/*  99:104 */     boolean ok = stat.type != 5;
/* 100:105 */     if (!ok)
/* 101:    */     {
/* 102:106 */       DoStatement dostat = (DoStatement)stat;
/* 103:107 */       ok = (dostat.getLooptype() == 0) || (dostat.getLooptype() == 2) || ((dostat.getLooptype() == 3) && (dostat.getIncExprent() == null));
/* 104:    */     }
/* 105:112 */     if (ok) {
/* 106:113 */       edges.addAll(stat.getPredecessorEdges(8));
/* 107:    */     }
/* 108:116 */     if ((ok) && (stat.type == 5)) {
/* 109:117 */       for (StatEdge edge : edges) {
/* 110:118 */         if (stat.containsStatementStrict(edge.getSource()))
/* 111:    */         {
/* 112:120 */           edge.getDestination().removePredecessor(edge);
/* 113:121 */           edge.getSource().changeEdgeNode(1, edge, stat);
/* 114:122 */           stat.addPredecessor(edge);
/* 115:    */           
/* 116:124 */           stat.addLabeledEdge(edge);
/* 117:    */         }
/* 118:    */       }
/* 119:    */     }
/* 120:129 */     for (Statement st : stat.getStats()) {
/* 121:130 */       if (st == stat.getFirst()) {
/* 122:131 */         lowContinueLabels(st, edges);
/* 123:    */       } else {
/* 124:134 */         lowContinueLabels(st, new HashSet());
/* 125:    */       }
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   public static void lowClosures(Statement stat)
/* 130:    */   {
/* 131:141 */     for (Iterator i$ = new ArrayList(stat.getLabelEdges()).iterator(); i$.hasNext();)
/* 132:    */     {
/* 133:141 */       edge = (StatEdge)i$.next();
/* 134:143 */       if (edge.getType() == 4) {
/* 135:144 */         for (Statement st : stat.getStats()) {
/* 136:145 */           if ((st.containsStatementStrict(edge.getSource())) && 
/* 137:146 */             (MergeHelper.isDirectPath(st, edge.getDestination()))) {
/* 138:147 */             st.addLabeledEdge(edge);
/* 139:    */           }
/* 140:    */         }
/* 141:    */       }
/* 142:    */     }
/* 143:    */     StatEdge edge;
/* 144:154 */     for (Statement st : stat.getStats()) {
/* 145:155 */       lowClosures(st);
/* 146:    */     }
/* 147:    */   }
/* 148:    */   
/* 149:    */   private static void resetAllEdges(Statement stat)
/* 150:    */   {
/* 151:161 */     for (Statement st : stat.getStats()) {
/* 152:162 */       resetAllEdges(st);
/* 153:    */     }
/* 154:165 */     for (StatEdge edge : stat.getAllSuccessorEdges())
/* 155:    */     {
/* 156:166 */       edge.explicit = true;
/* 157:167 */       edge.labeled = true;
/* 158:    */     }
/* 159:    */   }
/* 160:    */   
/* 161:    */   private static void setRetEdgesUnlabeled(RootStatement root)
/* 162:    */   {
/* 163:172 */     Statement exit = root.getDummyExit();
/* 164:173 */     for (StatEdge edge : exit.getAllPredecessorEdges())
/* 165:    */     {
/* 166:174 */       List<Exprent> lst = edge.getSource().getExprents();
/* 167:175 */       if ((edge.getType() == 32) || ((lst != null) && (!lst.isEmpty()) && (((Exprent)lst.get(lst.size() - 1)).type == 4))) {
/* 168:177 */         edge.labeled = false;
/* 169:    */       }
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   private static HashMap<Statement, List<StatEdge>> setExplicitEdges(Statement stat)
/* 174:    */   {
/* 175:184 */     HashMap<Statement, List<StatEdge>> mapEdges = new HashMap();
/* 176:186 */     if (stat.getExprents() != null) {
/* 177:187 */       return mapEdges;
/* 178:    */     }
/* 179:191 */     switch (stat.type)
/* 180:    */     {
/* 181:    */     case 7: 
/* 182:    */     case 12: 
/* 183:195 */       for (Statement st : stat.getStats())
/* 184:    */       {
/* 185:196 */         HashMap<Statement, List<StatEdge>> mapEdges1 = setExplicitEdges(st);
/* 186:197 */         processEdgesWithNext(st, mapEdges1, null);
/* 187:199 */         if ((stat.type == 7) || (st == stat.getFirst())) {
/* 188:201 */           if (mapEdges1 != null) {
/* 189:202 */             for (Map.Entry<Statement, List<StatEdge>> entr : mapEdges1.entrySet()) {
/* 190:203 */               if (mapEdges.containsKey(entr.getKey())) {
/* 191:204 */                 ((List)mapEdges.get(entr.getKey())).addAll((Collection)entr.getValue());
/* 192:    */               } else {
/* 193:207 */                 mapEdges.put(entr.getKey(), entr.getValue());
/* 194:    */               }
/* 195:    */             }
/* 196:    */           }
/* 197:    */         }
/* 198:    */       }
/* 199:214 */       break;
/* 200:    */     case 5: 
/* 201:216 */       mapEdges = setExplicitEdges(stat.getFirst());
/* 202:217 */       processEdgesWithNext(stat.getFirst(), mapEdges, stat);
/* 203:218 */       break;
/* 204:    */     case 2: 
/* 205:220 */       IfStatement ifstat = (IfStatement)stat;
/* 206:222 */       if (ifstat.getIfstat() == null)
/* 207:    */       {
/* 208:223 */         processEdgesWithNext(ifstat.getFirst(), mapEdges, null);
/* 209:    */       }
/* 210:    */       else
/* 211:    */       {
/* 212:226 */         mapEdges = setExplicitEdges(ifstat.getIfstat());
/* 213:227 */         processEdgesWithNext(ifstat.getIfstat(), mapEdges, null);
/* 214:    */         
/* 215:229 */         HashMap<Statement, List<StatEdge>> mapEdges1 = null;
/* 216:230 */         if (ifstat.getElsestat() != null)
/* 217:    */         {
/* 218:231 */           mapEdges1 = setExplicitEdges(ifstat.getElsestat());
/* 219:232 */           processEdgesWithNext(ifstat.getElsestat(), mapEdges1, null);
/* 220:    */         }
/* 221:236 */         if (mapEdges1 != null) {
/* 222:237 */           for (Map.Entry<Statement, List<StatEdge>> entr : mapEdges1.entrySet()) {
/* 223:238 */             if (mapEdges.containsKey(entr.getKey())) {
/* 224:239 */               ((List)mapEdges.get(entr.getKey())).addAll((Collection)entr.getValue());
/* 225:    */             } else {
/* 226:242 */               mapEdges.put(entr.getKey(), entr.getValue());
/* 227:    */             }
/* 228:    */           }
/* 229:    */         }
/* 230:    */       }
/* 231:247 */       break;
/* 232:    */     case 13: 
/* 233:249 */       mapEdges = setExplicitEdges(stat.getFirst());
/* 234:250 */       processEdgesWithNext(stat.getFirst(), mapEdges, ((RootStatement)stat).getDummyExit());
/* 235:251 */       break;
/* 236:    */     case 15: 
/* 237:253 */       int index = 0;
/* 238:254 */       while (index < stat.getStats().size() - 1)
/* 239:    */       {
/* 240:255 */         Statement st = (Statement)stat.getStats().get(index);
/* 241:256 */         processEdgesWithNext(st, setExplicitEdges(st), (Statement)stat.getStats().get(index + 1));
/* 242:257 */         index++;
/* 243:    */       }
/* 244:260 */       Statement st = (Statement)stat.getStats().get(index);
/* 245:261 */       mapEdges = setExplicitEdges(st);
/* 246:262 */       processEdgesWithNext(st, mapEdges, null);
/* 247:263 */       break;
/* 248:    */     case 6: 
/* 249:265 */       SwitchStatement swst = (SwitchStatement)stat;
/* 250:267 */       for (int i = 0; i < swst.getCaseStatements().size() - 1; i++)
/* 251:    */       {
/* 252:268 */         Statement stt = (Statement)swst.getCaseStatements().get(i);
/* 253:269 */         Statement stnext = (Statement)swst.getCaseStatements().get(i + 1);
/* 254:271 */         if ((stnext.getExprents() != null) && (stnext.getExprents().isEmpty())) {
/* 255:272 */           stnext = ((StatEdge)stnext.getAllSuccessorEdges().get(0)).getDestination();
/* 256:    */         }
/* 257:274 */         processEdgesWithNext(stt, setExplicitEdges(stt), stnext);
/* 258:    */       }
/* 259:277 */       int last = swst.getCaseStatements().size() - 1;
/* 260:278 */       if (last >= 0)
/* 261:    */       {
/* 262:279 */         Statement stlast = (Statement)swst.getCaseStatements().get(last);
/* 263:280 */         if ((stlast.getExprents() != null) && (stlast.getExprents().isEmpty()))
/* 264:    */         {
/* 265:281 */           StatEdge edge = (StatEdge)stlast.getAllSuccessorEdges().get(0);
/* 266:282 */           mapEdges.put(edge.getDestination(), new ArrayList(Arrays.asList(new StatEdge[] { edge })));
/* 267:    */         }
/* 268:    */         else
/* 269:    */         {
/* 270:285 */           mapEdges = setExplicitEdges(stlast);
/* 271:286 */           processEdgesWithNext(stlast, mapEdges, null);
/* 272:    */         }
/* 273:    */       }
/* 274:288 */       break;
/* 275:    */     case 10: 
/* 276:292 */       SynchronizedStatement synstat = (SynchronizedStatement)stat;
/* 277:    */       
/* 278:294 */       processEdgesWithNext(synstat.getFirst(), setExplicitEdges(stat.getFirst()), synstat.getBody());
/* 279:295 */       mapEdges = setExplicitEdges(synstat.getBody());
/* 280:296 */       processEdgesWithNext(synstat.getBody(), mapEdges, null);
/* 281:    */     }
/* 282:300 */     return mapEdges;
/* 283:    */   }
/* 284:    */   
/* 285:    */   private static void processEdgesWithNext(Statement stat, HashMap<Statement, List<StatEdge>> mapEdges, Statement next)
/* 286:    */   {
/* 287:305 */     StatEdge statedge = null;
/* 288:    */     
/* 289:307 */     List<StatEdge> lstSuccs = stat.getAllSuccessorEdges();
/* 290:308 */     if (!lstSuccs.isEmpty())
/* 291:    */     {
/* 292:309 */       statedge = (StatEdge)lstSuccs.get(0);
/* 293:311 */       if (statedge.getDestination() == next)
/* 294:    */       {
/* 295:312 */         statedge.explicit = false;
/* 296:313 */         statedge = null;
/* 297:    */       }
/* 298:    */       else
/* 299:    */       {
/* 300:316 */         next = statedge.getDestination();
/* 301:    */       }
/* 302:    */     }
/* 303:321 */     if ((stat.type == 5) && (((DoStatement)stat).getLooptype() == 0)) {
/* 304:322 */       next = null;
/* 305:    */     }
/* 306:325 */     if (next == null)
/* 307:    */     {
/* 308:326 */       if (mapEdges.size() == 1)
/* 309:    */       {
/* 310:327 */         List<StatEdge> lstEdges = (List)mapEdges.values().iterator().next();
/* 311:328 */         if ((lstEdges.size() > 1) && (((Statement)mapEdges.keySet().iterator().next()).type != 14))
/* 312:    */         {
/* 313:329 */           StatEdge edge_example = (StatEdge)lstEdges.get(0);
/* 314:    */           
/* 315:331 */           Statement closure = stat.getParent();
/* 316:332 */           if (!closure.containsStatementStrict(edge_example.closure)) {
/* 317:333 */             closure = edge_example.closure;
/* 318:    */           }
/* 319:336 */           StatEdge newedge = new StatEdge(edge_example.getType(), stat, edge_example.getDestination(), closure);
/* 320:337 */           stat.addSuccessor(newedge);
/* 321:339 */           for (StatEdge edge : lstEdges) {
/* 322:340 */             edge.explicit = false;
/* 323:    */           }
/* 324:343 */           mapEdges.put(newedge.getDestination(), new ArrayList(Arrays.asList(new StatEdge[] { newedge })));
/* 325:    */         }
/* 326:    */       }
/* 327:    */     }
/* 328:    */     else
/* 329:    */     {
/* 330:349 */       boolean implfound = false;
/* 331:351 */       for (Map.Entry<Statement, List<StatEdge>> entr : mapEdges.entrySet()) {
/* 332:352 */         if (entr.getKey() == next)
/* 333:    */         {
/* 334:353 */           for (StatEdge edge : (List)entr.getValue()) {
/* 335:354 */             edge.explicit = false;
/* 336:    */           }
/* 337:356 */           implfound = true;
/* 338:357 */           break;
/* 339:    */         }
/* 340:    */       }
/* 341:361 */       if ((stat.getAllSuccessorEdges().isEmpty()) && (!implfound))
/* 342:    */       {
/* 343:362 */         List<StatEdge> lstEdges = null;
/* 344:363 */         for (Map.Entry<Statement, List<StatEdge>> entr : mapEdges.entrySet()) {
/* 345:364 */           if ((((Statement)entr.getKey()).type != 14) && ((lstEdges == null) || (((List)entr.getValue()).size() > lstEdges.size()))) {
/* 346:366 */             lstEdges = (List)entr.getValue();
/* 347:    */           }
/* 348:    */         }
/* 349:370 */         if ((lstEdges != null) && (lstEdges.size() > 1))
/* 350:    */         {
/* 351:371 */           StatEdge edge_example = (StatEdge)lstEdges.get(0);
/* 352:    */           
/* 353:373 */           Statement closure = stat.getParent();
/* 354:374 */           if (!closure.containsStatementStrict(edge_example.closure)) {
/* 355:375 */             closure = edge_example.closure;
/* 356:    */           }
/* 357:378 */           StatEdge newedge = new StatEdge(edge_example.getType(), stat, edge_example.getDestination(), closure);
/* 358:379 */           stat.addSuccessor(newedge);
/* 359:381 */           for (StatEdge edge : lstEdges) {
/* 360:382 */             edge.explicit = false;
/* 361:    */           }
/* 362:    */         }
/* 363:    */       }
/* 364:387 */       mapEdges.clear();
/* 365:    */     }
/* 366:390 */     if (statedge != null) {
/* 367:391 */       mapEdges.put(statedge.getDestination(), new ArrayList(Arrays.asList(new StatEdge[] { statedge })));
/* 368:    */     }
/* 369:    */   }
/* 370:    */   
/* 371:    */   private static void hideDefaultSwitchEdges(Statement stat)
/* 372:    */   {
/* 373:397 */     if (stat.type == 6)
/* 374:    */     {
/* 375:398 */       SwitchStatement swst = (SwitchStatement)stat;
/* 376:    */       
/* 377:400 */       int last = swst.getCaseStatements().size() - 1;
/* 378:401 */       if (last >= 0)
/* 379:    */       {
/* 380:402 */         Statement stlast = (Statement)swst.getCaseStatements().get(last);
/* 381:404 */         if ((stlast.getExprents() != null) && (stlast.getExprents().isEmpty()) && 
/* 382:405 */           (!((StatEdge)stlast.getAllSuccessorEdges().get(0)).explicit))
/* 383:    */         {
/* 384:406 */           List<StatEdge> lstEdges = (List)swst.getCaseEdges().get(last);
/* 385:407 */           lstEdges.remove(swst.getDefault_edge());
/* 386:409 */           if (lstEdges.isEmpty())
/* 387:    */           {
/* 388:410 */             swst.getCaseStatements().remove(last);
/* 389:411 */             swst.getCaseEdges().remove(last);
/* 390:    */           }
/* 391:    */         }
/* 392:    */       }
/* 393:    */     }
/* 394:418 */     for (Statement st : stat.getStats()) {
/* 395:419 */       hideDefaultSwitchEdges(st);
/* 396:    */     }
/* 397:    */   }
/* 398:    */   
/* 399:    */   private static HashSet<Statement>[] processStatementLabel(Statement stat)
/* 400:    */   {
/* 401:425 */     HashSet<Statement> setBreak = new HashSet();
/* 402:426 */     HashSet<Statement> setContinue = new HashSet();
/* 403:428 */     if (stat.getExprents() == null)
/* 404:    */     {
/* 405:429 */       for (Statement st : stat.getStats())
/* 406:    */       {
/* 407:430 */         HashSet<Statement>[] arr = processStatementLabel(st);
/* 408:    */         
/* 409:432 */         setBreak.addAll(arr[0]);
/* 410:433 */         setContinue.addAll(arr[1]);
/* 411:    */       }
/* 412:436 */       boolean shieldType = (stat.type == 5) || (stat.type == 6);
/* 413:437 */       if (shieldType) {
/* 414:438 */         for (StatEdge edge : stat.getLabelEdges()) {
/* 415:439 */           if ((edge.explicit) && (((edge.getType() == 4) && (setBreak.contains(edge.getSource()))) || ((edge.getType() == 8) && (setContinue.contains(edge.getSource()))))) {
/* 416:441 */             edge.labeled = false;
/* 417:    */           }
/* 418:    */         }
/* 419:    */       }
/* 420:446 */       switch (stat.type)
/* 421:    */       {
/* 422:    */       case 5: 
/* 423:448 */         setContinue.clear();
/* 424:    */       case 6: 
/* 425:450 */         setBreak.clear();
/* 426:    */       }
/* 427:    */     }
/* 428:454 */     setBreak.add(stat);
/* 429:455 */     setContinue.add(stat);
/* 430:    */     
/* 431:457 */     return new HashSet[] { setBreak, setContinue };
/* 432:    */   }
/* 433:    */   
/* 434:    */   public static void replaceContinueWithBreak(Statement stat)
/* 435:    */   {
/* 436:462 */     if (stat.type == 5)
/* 437:    */     {
/* 438:464 */       List<StatEdge> lst = stat.getPredecessorEdges(8);
/* 439:466 */       for (StatEdge edge : lst) {
/* 440:468 */         if (edge.explicit)
/* 441:    */         {
/* 442:469 */           Statement minclosure = getMinContinueClosure(edge);
/* 443:471 */           if ((minclosure != edge.closure) && (!InlineSingleBlockHelper.isBreakEdgeLabeled(edge.getSource(), minclosure)))
/* 444:    */           {
/* 445:473 */             edge.getSource().changeEdgeType(1, edge, 4);
/* 446:474 */             edge.labeled = false;
/* 447:475 */             minclosure.addLabeledEdge(edge);
/* 448:    */           }
/* 449:    */         }
/* 450:    */       }
/* 451:    */     }
/* 452:481 */     for (Statement st : stat.getStats()) {
/* 453:482 */       replaceContinueWithBreak(st);
/* 454:    */     }
/* 455:    */   }
/* 456:    */   
/* 457:    */   private static Statement getMinContinueClosure(StatEdge edge)
/* 458:    */   {
/* 459:488 */     Statement closure = edge.closure;
/* 460:    */     for (;;)
/* 461:    */     {
/* 462:491 */       boolean found = false;
/* 463:493 */       for (Statement st : closure.getStats()) {
/* 464:494 */         if ((st.containsStatementStrict(edge.getSource())) && 
/* 465:495 */           (MergeHelper.isDirectPath(st, edge.getDestination())))
/* 466:    */         {
/* 467:496 */           closure = st;
/* 468:497 */           found = true;
/* 469:498 */           break;
/* 470:    */         }
/* 471:    */       }
/* 472:503 */       if (!found) {
/* 473:    */         break;
/* 474:    */       }
/* 475:    */     }
/* 476:508 */     return closure;
/* 477:    */   }
/* 478:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.LabelHelper
 * JD-Core Version:    0.7.0.1
 */