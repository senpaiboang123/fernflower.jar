/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.List;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*   8:    */ import org.jetbrains.java.decompiler.util.ListStack;
/*   9:    */ 
/*  10:    */ public class StrongConnectivityHelper
/*  11:    */ {
/*  12:    */   private ListStack<Statement> lstack;
/*  13:    */   private int ncounter;
/*  14:    */   private HashSet<Statement> tset;
/*  15:    */   private HashMap<Statement, Integer> dfsnummap;
/*  16:    */   private HashMap<Statement, Integer> lowmap;
/*  17:    */   private List<List<Statement>> components;
/*  18:    */   private HashSet<Statement> setProcessed;
/*  19:    */   
/*  20:    */   public StrongConnectivityHelper() {}
/*  21:    */   
/*  22:    */   public StrongConnectivityHelper(Statement stat)
/*  23:    */   {
/*  24: 86 */     findComponents(stat);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public List<List<Statement>> findComponents(Statement stat)
/*  28:    */   {
/*  29: 95 */     this.components = new ArrayList();
/*  30: 96 */     this.setProcessed = new HashSet();
/*  31:    */     
/*  32: 98 */     visitTree(stat.getFirst());
/*  33:100 */     for (Statement st : stat.getStats()) {
/*  34:101 */       if ((!this.setProcessed.contains(st)) && (st.getPredecessorEdges(1073741824).isEmpty())) {
/*  35:102 */         visitTree(st);
/*  36:    */       }
/*  37:    */     }
/*  38:107 */     for (Statement st : stat.getStats()) {
/*  39:108 */       if (!this.setProcessed.contains(st)) {
/*  40:109 */         visitTree(st);
/*  41:    */       }
/*  42:    */     }
/*  43:113 */     return this.components;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static boolean isExitComponent(List<Statement> lst)
/*  47:    */   {
/*  48:118 */     HashSet<Statement> set = new HashSet();
/*  49:119 */     for (Statement stat : lst) {
/*  50:120 */       set.addAll(stat.getNeighbours(1, 1));
/*  51:    */     }
/*  52:122 */     set.removeAll(lst);
/*  53:    */     
/*  54:124 */     return set.size() == 0;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static List<Statement> getExitReps(List<List<Statement>> lst)
/*  58:    */   {
/*  59:129 */     List<Statement> res = new ArrayList();
/*  60:131 */     for (List<Statement> comp : lst) {
/*  61:132 */       if (isExitComponent(comp)) {
/*  62:133 */         res.add(comp.get(0));
/*  63:    */       }
/*  64:    */     }
/*  65:137 */     return res;
/*  66:    */   }
/*  67:    */   
/*  68:    */   private void visitTree(Statement stat)
/*  69:    */   {
/*  70:145 */     this.lstack = new ListStack();
/*  71:146 */     this.ncounter = 0;
/*  72:147 */     this.tset = new HashSet();
/*  73:148 */     this.dfsnummap = new HashMap();
/*  74:149 */     this.lowmap = new HashMap();
/*  75:    */     
/*  76:151 */     visit(stat);
/*  77:    */     
/*  78:153 */     this.setProcessed.addAll(this.tset);
/*  79:154 */     this.setProcessed.add(stat);
/*  80:    */   }
/*  81:    */   
/*  82:    */   private void visit(Statement stat)
/*  83:    */   {
/*  84:159 */     this.lstack.push(stat);
/*  85:160 */     this.dfsnummap.put(stat, Integer.valueOf(this.ncounter));
/*  86:161 */     this.lowmap.put(stat, Integer.valueOf(this.ncounter));
/*  87:162 */     this.ncounter += 1;
/*  88:    */     
/*  89:164 */     List<Statement> lstSuccs = stat.getNeighbours(1, 1);
/*  90:165 */     lstSuccs.removeAll(this.setProcessed);
/*  91:167 */     for (int i = 0; i < lstSuccs.size(); i++)
/*  92:    */     {
/*  93:168 */       Statement succ = (Statement)lstSuccs.get(i);
/*  94:    */       int secvalue;
/*  95:    */       int secvalue;
/*  96:171 */       if (this.tset.contains(succ))
/*  97:    */       {
/*  98:172 */         secvalue = ((Integer)this.dfsnummap.get(succ)).intValue();
/*  99:    */       }
/* 100:    */       else
/* 101:    */       {
/* 102:175 */         this.tset.add(succ);
/* 103:176 */         visit(succ);
/* 104:177 */         secvalue = ((Integer)this.lowmap.get(succ)).intValue();
/* 105:    */       }
/* 106:179 */       this.lowmap.put(stat, Integer.valueOf(Math.min(((Integer)this.lowmap.get(stat)).intValue(), secvalue)));
/* 107:    */     }
/* 108:183 */     if (((Integer)this.lowmap.get(stat)).intValue() == ((Integer)this.dfsnummap.get(stat)).intValue())
/* 109:    */     {
/* 110:184 */       List<Statement> lst = new ArrayList();
/* 111:    */       Statement v;
/* 112:    */       do
/* 113:    */       {
/* 114:187 */         v = (Statement)this.lstack.pop();
/* 115:188 */         lst.add(v);
/* 116:190 */       } while (v != stat);
/* 117:191 */       this.components.add(lst);
/* 118:    */     }
/* 119:    */   }
/* 120:    */   
/* 121:    */   public List<List<Statement>> getComponents()
/* 122:    */   {
/* 123:201 */     return this.components;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void setComponents(List<List<Statement>> components)
/* 127:    */   {
/* 128:205 */     this.components = components;
/* 129:    */   }
/* 130:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.StrongConnectivityHelper
 * JD-Core Version:    0.7.0.1
 */