/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.List;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.IfExprent;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  14:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  15:    */ 
/*  16:    */ public class IfHelper
/*  17:    */ {
/*  18:    */   public static boolean mergeAllIfs(RootStatement root)
/*  19:    */   {
/*  20: 37 */     boolean res = mergeAllIfsRec(root, new HashSet());
/*  21: 39 */     if (res) {
/*  22: 40 */       SequenceHelper.condenseSequences(root);
/*  23:    */     }
/*  24: 43 */     return res;
/*  25:    */   }
/*  26:    */   
/*  27:    */   private static boolean mergeAllIfsRec(Statement stat, HashSet<Integer> setReorderedIfs)
/*  28:    */   {
/*  29: 49 */     boolean res = false;
/*  30: 51 */     if (stat.getExprents() == null) {
/*  31:    */       for (;;)
/*  32:    */       {
/*  33: 55 */         boolean changed = false;
/*  34: 57 */         for (Statement st : stat.getStats())
/*  35:    */         {
/*  36: 59 */           res |= mergeAllIfsRec(st, setReorderedIfs);
/*  37: 62 */           if ((changed = mergeIfs(st, setReorderedIfs))) {
/*  38:    */             break;
/*  39:    */           }
/*  40:    */         }
/*  41: 67 */         res |= changed;
/*  42: 69 */         if (!changed) {
/*  43:    */           break;
/*  44:    */         }
/*  45:    */       }
/*  46:    */     }
/*  47: 75 */     return res;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static boolean mergeIfs(Statement statement, HashSet<Integer> setReorderedIfs)
/*  51:    */   {
/*  52: 81 */     if ((statement.type != 2) && (statement.type != 15)) {
/*  53: 82 */       return false;
/*  54:    */     }
/*  55: 85 */     boolean res = false;
/*  56:    */     for (;;)
/*  57:    */     {
/*  58: 89 */       boolean updated = false;
/*  59:    */       
/*  60: 91 */       List<Statement> lst = new ArrayList();
/*  61: 92 */       if (statement.type == 2) {
/*  62: 93 */         lst.add(statement);
/*  63:    */       } else {
/*  64: 96 */         lst.addAll(statement.getStats());
/*  65:    */       }
/*  66: 99 */       boolean stsingle = lst.size() == 1;
/*  67:101 */       for (Statement stat : lst) {
/*  68:103 */         if (stat.type == 2)
/*  69:    */         {
/*  70:104 */           IfNode rtnode = buildGraph((IfStatement)stat, stsingle);
/*  71:106 */           if (rtnode != null)
/*  72:    */           {
/*  73:110 */             if ((updated = collapseIfIf(rtnode))) {
/*  74:    */               break;
/*  75:    */             }
/*  76:114 */             if (!setReorderedIfs.contains(stat.id))
/*  77:    */             {
/*  78:116 */               if ((updated = collapseIfElse(rtnode))) {
/*  79:    */                 break;
/*  80:    */               }
/*  81:120 */               if ((updated = collapseElse(rtnode))) {
/*  82:    */                 break;
/*  83:    */               }
/*  84:    */             }
/*  85:125 */             if ((updated = reorderIf((IfStatement)stat)))
/*  86:    */             {
/*  87:126 */               setReorderedIfs.add(stat.id);
/*  88:127 */               break;
/*  89:    */             }
/*  90:    */           }
/*  91:    */         }
/*  92:    */       }
/*  93:132 */       if (!updated) {
/*  94:    */         break;
/*  95:    */       }
/*  96:136 */       res |= updated;
/*  97:    */     }
/*  98:139 */     return res;
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static boolean collapseIfIf(IfNode rtnode)
/* 102:    */   {
/* 103:144 */     if (((Integer)rtnode.edgetypes.get(0)).intValue() == 0)
/* 104:    */     {
/* 105:145 */       IfNode ifbranch = (IfNode)rtnode.succs.get(0);
/* 106:146 */       if (ifbranch.succs.size() == 2) {
/* 107:149 */         if (((IfNode)ifbranch.succs.get(1)).value == ((IfNode)rtnode.succs.get(1)).value)
/* 108:    */         {
/* 109:151 */           IfStatement ifparent = (IfStatement)rtnode.value;
/* 110:152 */           IfStatement ifchild = (IfStatement)ifbranch.value;
/* 111:153 */           Statement ifinner = ((IfNode)ifbranch.succs.get(0)).value;
/* 112:155 */           if (ifchild.getFirst().getExprents().isEmpty())
/* 113:    */           {
/* 114:157 */             ifparent.getFirst().removeSuccessor(ifparent.getIfEdge());
/* 115:158 */             ifchild.removeSuccessor((StatEdge)ifchild.getAllSuccessorEdges().get(0));
/* 116:159 */             ifparent.getStats().removeWithKey(ifchild.id);
/* 117:161 */             if (((Integer)ifbranch.edgetypes.get(0)).intValue() == 1)
/* 118:    */             {
/* 119:163 */               ifparent.setIfstat(null);
/* 120:    */               
/* 121:165 */               StatEdge ifedge = ifchild.getIfEdge();
/* 122:    */               
/* 123:167 */               ifchild.getFirst().removeSuccessor(ifedge);
/* 124:168 */               ifedge.setSource(ifparent.getFirst());
/* 125:170 */               if (ifedge.closure == ifchild) {
/* 126:171 */                 ifedge.closure = null;
/* 127:    */               }
/* 128:173 */               ifparent.getFirst().addSuccessor(ifedge);
/* 129:    */               
/* 130:175 */               ifparent.setIfEdge(ifedge);
/* 131:    */             }
/* 132:    */             else
/* 133:    */             {
/* 134:178 */               ifchild.getFirst().removeSuccessor(ifchild.getIfEdge());
/* 135:    */               
/* 136:180 */               StatEdge ifedge = new StatEdge(1, ifparent.getFirst(), ifinner);
/* 137:181 */               ifparent.getFirst().addSuccessor(ifedge);
/* 138:182 */               ifparent.setIfEdge(ifedge);
/* 139:183 */               ifparent.setIfstat(ifinner);
/* 140:    */               
/* 141:185 */               ifparent.getStats().addWithKey(ifinner, ifinner.id);
/* 142:186 */               ifinner.setParent(ifparent);
/* 143:188 */               if (!ifinner.getAllSuccessorEdges().isEmpty())
/* 144:    */               {
/* 145:189 */                 StatEdge edge = (StatEdge)ifinner.getAllSuccessorEdges().get(0);
/* 146:190 */                 if (edge.closure == ifchild) {
/* 147:191 */                   edge.closure = null;
/* 148:    */                 }
/* 149:    */               }
/* 150:    */             }
/* 151:197 */             IfExprent statexpr = ifparent.getHeadexprent();
/* 152:    */             
/* 153:199 */             List<Exprent> lstOperands = new ArrayList();
/* 154:200 */             lstOperands.add(statexpr.getCondition());
/* 155:201 */             lstOperands.add(ifchild.getHeadexprent().getCondition());
/* 156:    */             
/* 157:203 */             statexpr.setCondition(new FunctionExprent(48, lstOperands, null));
/* 158:204 */             statexpr.addBytecodeOffsets(ifchild.getHeadexprent().bytecode);
/* 159:    */             
/* 160:206 */             return true;
/* 161:    */           }
/* 162:    */         }
/* 163:    */       }
/* 164:    */     }
/* 165:212 */     return false;
/* 166:    */   }
/* 167:    */   
/* 168:    */   private static boolean collapseIfElse(IfNode rtnode)
/* 169:    */   {
/* 170:217 */     if (((Integer)rtnode.edgetypes.get(0)).intValue() == 0)
/* 171:    */     {
/* 172:218 */       IfNode ifbranch = (IfNode)rtnode.succs.get(0);
/* 173:219 */       if (ifbranch.succs.size() == 2) {
/* 174:222 */         if (((IfNode)ifbranch.succs.get(0)).value == ((IfNode)rtnode.succs.get(1)).value)
/* 175:    */         {
/* 176:224 */           IfStatement ifparent = (IfStatement)rtnode.value;
/* 177:225 */           IfStatement ifchild = (IfStatement)ifbranch.value;
/* 178:227 */           if (ifchild.getFirst().getExprents().isEmpty())
/* 179:    */           {
/* 180:229 */             ifparent.getFirst().removeSuccessor(ifparent.getIfEdge());
/* 181:230 */             ifchild.getFirst().removeSuccessor(ifchild.getIfEdge());
/* 182:231 */             ifparent.getStats().removeWithKey(ifchild.id);
/* 183:233 */             if ((((Integer)ifbranch.edgetypes.get(1)).intValue() == 1) && (((Integer)ifbranch.edgetypes.get(0)).intValue() == 1))
/* 184:    */             {
/* 185:236 */               ifparent.setIfstat(null);
/* 186:    */               
/* 187:238 */               StatEdge ifedge = (StatEdge)ifchild.getAllSuccessorEdges().get(0);
/* 188:    */               
/* 189:240 */               ifchild.removeSuccessor(ifedge);
/* 190:241 */               ifedge.setSource(ifparent.getFirst());
/* 191:242 */               ifparent.getFirst().addSuccessor(ifedge);
/* 192:    */               
/* 193:244 */               ifparent.setIfEdge(ifedge);
/* 194:    */             }
/* 195:    */             else
/* 196:    */             {
/* 197:247 */               throw new RuntimeException("inconsistent if structure!");
/* 198:    */             }
/* 199:251 */             IfExprent statexpr = ifparent.getHeadexprent();
/* 200:    */             
/* 201:253 */             List<Exprent> lstOperands = new ArrayList();
/* 202:254 */             lstOperands.add(statexpr.getCondition());
/* 203:255 */             lstOperands.add(new FunctionExprent(12, ifchild.getHeadexprent().getCondition(), null));
/* 204:256 */             statexpr.setCondition(new FunctionExprent(48, lstOperands, null));
/* 205:257 */             statexpr.addBytecodeOffsets(ifchild.getHeadexprent().bytecode);
/* 206:    */             
/* 207:259 */             return true;
/* 208:    */           }
/* 209:    */         }
/* 210:    */       }
/* 211:    */     }
/* 212:265 */     return false;
/* 213:    */   }
/* 214:    */   
/* 215:    */   private static boolean collapseElse(IfNode rtnode)
/* 216:    */   {
/* 217:271 */     if (((Integer)rtnode.edgetypes.get(1)).intValue() == 0)
/* 218:    */     {
/* 219:272 */       IfNode elsebranch = (IfNode)rtnode.succs.get(1);
/* 220:273 */       if (elsebranch.succs.size() == 2)
/* 221:    */       {
/* 222:276 */         int path = ((IfNode)elsebranch.succs.get(0)).value == ((IfNode)rtnode.succs.get(0)).value ? 1 : ((IfNode)elsebranch.succs.get(1)).value == ((IfNode)rtnode.succs.get(0)).value ? 2 : 0;
/* 223:279 */         if (path > 0)
/* 224:    */         {
/* 225:281 */           IfStatement firstif = (IfStatement)rtnode.value;
/* 226:282 */           IfStatement secondif = (IfStatement)elsebranch.value;
/* 227:283 */           Statement parent = firstif.getParent();
/* 228:285 */           if (secondif.getFirst().getExprents().isEmpty())
/* 229:    */           {
/* 230:287 */             firstif.getFirst().removeSuccessor(firstif.getIfEdge());
/* 231:    */             
/* 232:    */ 
/* 233:290 */             firstif.removeAllSuccessors(secondif);
/* 234:292 */             for (StatEdge edge : firstif.getAllPredecessorEdges()) {
/* 235:293 */               if (!firstif.containsStatementStrict(edge.getSource()))
/* 236:    */               {
/* 237:294 */                 firstif.removePredecessor(edge);
/* 238:295 */                 edge.getSource().changeEdgeNode(1, edge, secondif);
/* 239:296 */                 secondif.addPredecessor(edge);
/* 240:    */               }
/* 241:    */             }
/* 242:300 */             parent.getStats().removeWithKey(firstif.id);
/* 243:301 */             if (parent.getFirst() == firstif) {
/* 244:302 */               parent.setFirst(secondif);
/* 245:    */             }
/* 246:306 */             IfExprent statexpr = secondif.getHeadexprent();
/* 247:    */             
/* 248:308 */             List<Exprent> lstOperands = new ArrayList();
/* 249:309 */             lstOperands.add(firstif.getHeadexprent().getCondition());
/* 250:311 */             if (path == 2) {
/* 251:312 */               lstOperands.set(0, new FunctionExprent(12, (Exprent)lstOperands.get(0), null));
/* 252:    */             }
/* 253:315 */             lstOperands.add(statexpr.getCondition());
/* 254:    */             
/* 255:317 */             statexpr.setCondition(new FunctionExprent(path == 1 ? 49 : 48, lstOperands, null));
/* 256:320 */             if ((secondif.getFirst().getExprents().isEmpty()) && (!firstif.getFirst().getExprents().isEmpty())) {
/* 257:323 */               secondif.replaceStatement(secondif.getFirst(), firstif.getFirst());
/* 258:    */             }
/* 259:326 */             return true;
/* 260:    */           }
/* 261:    */         }
/* 262:    */       }
/* 263:330 */       else if (elsebranch.succs.size() == 1)
/* 264:    */       {
/* 265:332 */         if (((IfNode)elsebranch.succs.get(0)).value == ((IfNode)rtnode.succs.get(0)).value)
/* 266:    */         {
/* 267:334 */           IfStatement firstif = (IfStatement)rtnode.value;
/* 268:335 */           Statement second = elsebranch.value;
/* 269:    */           
/* 270:337 */           firstif.removeAllSuccessors(second);
/* 271:339 */           for (StatEdge edge : second.getAllSuccessorEdges())
/* 272:    */           {
/* 273:340 */             second.removeSuccessor(edge);
/* 274:341 */             edge.setSource(firstif);
/* 275:342 */             firstif.addSuccessor(edge);
/* 276:    */           }
/* 277:345 */           StatEdge ifedge = firstif.getIfEdge();
/* 278:346 */           firstif.getFirst().removeSuccessor(ifedge);
/* 279:    */           
/* 280:348 */           second.addSuccessor(new StatEdge(ifedge.getType(), second, ifedge.getDestination(), ifedge.closure));
/* 281:    */           
/* 282:350 */           StatEdge newifedge = new StatEdge(1, firstif.getFirst(), second);
/* 283:351 */           firstif.getFirst().addSuccessor(newifedge);
/* 284:352 */           firstif.setIfstat(second);
/* 285:    */           
/* 286:354 */           firstif.getStats().addWithKey(second, second.id);
/* 287:355 */           second.setParent(firstif);
/* 288:    */           
/* 289:357 */           firstif.getParent().getStats().removeWithKey(second.id);
/* 290:    */           
/* 291:    */ 
/* 292:360 */           IfExprent statexpr = firstif.getHeadexprent();
/* 293:361 */           statexpr.setCondition(new FunctionExprent(12, statexpr.getCondition(), null));
/* 294:    */           
/* 295:    */ 
/* 296:364 */           return true;
/* 297:    */         }
/* 298:    */       }
/* 299:    */     }
/* 300:369 */     return false;
/* 301:    */   }
/* 302:    */   
/* 303:    */   private static IfNode buildGraph(IfStatement stat, boolean stsingle)
/* 304:    */   {
/* 305:375 */     if (stat.iftype == 1) {
/* 306:376 */       return null;
/* 307:    */     }
/* 308:379 */     IfNode res = new IfNode(stat);
/* 309:    */     
/* 310:    */ 
/* 311:382 */     Statement ifchild = stat.getIfstat();
/* 312:383 */     if (ifchild == null)
/* 313:    */     {
/* 314:384 */       StatEdge edge = stat.getIfEdge();
/* 315:385 */       res.addChild(new IfNode(edge.getDestination()), 1);
/* 316:    */     }
/* 317:    */     else
/* 318:    */     {
/* 319:388 */       IfNode ifnode = new IfNode(ifchild);
/* 320:389 */       res.addChild(ifnode, 0);
/* 321:390 */       if ((ifchild.type == 2) && (((IfStatement)ifchild).iftype == 0))
/* 322:    */       {
/* 323:391 */         IfStatement stat2 = (IfStatement)ifchild;
/* 324:392 */         Statement ifchild2 = stat2.getIfstat();
/* 325:393 */         if (ifchild2 == null)
/* 326:    */         {
/* 327:394 */           StatEdge edge = stat2.getIfEdge();
/* 328:395 */           ifnode.addChild(new IfNode(edge.getDestination()), 1);
/* 329:    */         }
/* 330:    */         else
/* 331:    */         {
/* 332:398 */           ifnode.addChild(new IfNode(ifchild2), 0);
/* 333:    */         }
/* 334:    */       }
/* 335:402 */       if (!ifchild.getAllSuccessorEdges().isEmpty()) {
/* 336:403 */         ifnode.addChild(new IfNode(((StatEdge)ifchild.getAllSuccessorEdges().get(0)).getDestination()), 1);
/* 337:    */       }
/* 338:    */     }
/* 339:408 */     StatEdge edge = (StatEdge)stat.getAllSuccessorEdges().get(0);
/* 340:409 */     Statement elsechild = edge.getDestination();
/* 341:410 */     IfNode elsenode = new IfNode(elsechild);
/* 342:412 */     if ((stsingle) || (edge.getType() != 1))
/* 343:    */     {
/* 344:413 */       res.addChild(elsenode, 1);
/* 345:    */     }
/* 346:    */     else
/* 347:    */     {
/* 348:416 */       res.addChild(elsenode, 0);
/* 349:417 */       if ((elsechild.type == 2) && (((IfStatement)elsechild).iftype == 0))
/* 350:    */       {
/* 351:418 */         IfStatement stat2 = (IfStatement)elsechild;
/* 352:419 */         Statement ifchild2 = stat2.getIfstat();
/* 353:420 */         if (ifchild2 == null) {
/* 354:421 */           elsenode.addChild(new IfNode(stat2.getIfEdge().getDestination()), 1);
/* 355:    */         } else {
/* 356:424 */           elsenode.addChild(new IfNode(ifchild2), 0);
/* 357:    */         }
/* 358:    */       }
/* 359:428 */       if (!elsechild.getAllSuccessorEdges().isEmpty()) {
/* 360:429 */         elsenode.addChild(new IfNode(((StatEdge)elsechild.getAllSuccessorEdges().get(0)).getDestination()), 1);
/* 361:    */       }
/* 362:    */     }
/* 363:433 */     return res;
/* 364:    */   }
/* 365:    */   
/* 366:    */   private static boolean reorderIf(IfStatement ifstat)
/* 367:    */   {
/* 368:440 */     if (ifstat.iftype == 1) {
/* 369:441 */       return false;
/* 370:    */     }
/* 371:444 */     boolean ifdirect = false;boolean elsedirect = false;
/* 372:445 */     boolean noifstat = false;boolean noelsestat = false;
/* 373:446 */     boolean ifdirectpath = false;boolean elsedirectpath = false;
/* 374:    */     
/* 375:448 */     Statement parent = ifstat.getParent();
/* 376:449 */     Statement from = parent.type == 15 ? parent : ifstat;
/* 377:    */     
/* 378:451 */     Statement next = getNextStatement(from);
/* 379:453 */     if (ifstat.getIfstat() == null)
/* 380:    */     {
/* 381:454 */       noifstat = true;
/* 382:456 */       if (ifstat.getIfEdge().getType() == 32) {
/* 383:457 */         ifdirect = true;
/* 384:    */       } else {
/* 385:460 */         ifdirect = MergeHelper.isDirectPath(from, ifstat.getIfEdge().getDestination());
/* 386:    */       }
/* 387:    */     }
/* 388:    */     else
/* 389:    */     {
/* 390:464 */       List<StatEdge> lstSuccs = ifstat.getIfstat().getAllSuccessorEdges();
/* 391:465 */       if ((!lstSuccs.isEmpty()) && (((StatEdge)lstSuccs.get(0)).getType() == 32)) {
/* 392:466 */         ifdirect = true;
/* 393:    */       } else {
/* 394:469 */         ifdirect = hasDirectEndEdge(ifstat.getIfstat(), from);
/* 395:    */       }
/* 396:    */     }
/* 397:473 */     Statement last = parent.type == 15 ? (Statement)parent.getStats().getLast() : ifstat;
/* 398:474 */     noelsestat = last == ifstat;
/* 399:476 */     if ((!last.getAllSuccessorEdges().isEmpty()) && (((StatEdge)last.getAllSuccessorEdges().get(0)).getType() == 32)) {
/* 400:477 */       elsedirect = true;
/* 401:    */     } else {
/* 402:480 */       elsedirect = hasDirectEndEdge(last, from);
/* 403:    */     }
/* 404:483 */     if ((!noelsestat) && (existsPath(ifstat, ((StatEdge)ifstat.getAllSuccessorEdges().get(0)).getDestination()))) {
/* 405:484 */       return false;
/* 406:    */     }
/* 407:487 */     if ((!ifdirect) && (!noifstat)) {
/* 408:488 */       ifdirectpath = existsPath(ifstat, next);
/* 409:    */     }
/* 410:491 */     if ((!elsedirect) && (!noelsestat))
/* 411:    */     {
/* 412:492 */       SequenceStatement sequence = (SequenceStatement)parent;
/* 413:494 */       for (int i = sequence.getStats().size() - 1; i >= 0; i--)
/* 414:    */       {
/* 415:495 */         Statement sttemp = (Statement)sequence.getStats().get(i);
/* 416:496 */         if (sttemp == ifstat) {
/* 417:    */           break;
/* 418:    */         }
/* 419:500 */         if ((elsedirectpath = existsPath(sttemp, next))) {
/* 420:    */           break;
/* 421:    */         }
/* 422:    */       }
/* 423:    */     }
/* 424:507 */     if (((ifdirect) || (ifdirectpath)) && ((elsedirect) || (elsedirectpath)) && (!noifstat) && (!noelsestat))
/* 425:    */     {
/* 426:509 */       SequenceStatement sequence = (SequenceStatement)parent;
/* 427:    */       
/* 428:    */ 
/* 429:512 */       List<Statement> lst = new ArrayList();
/* 430:513 */       for (int i = sequence.getStats().size() - 1; i >= 0; i--)
/* 431:    */       {
/* 432:514 */         Statement sttemp = (Statement)sequence.getStats().get(i);
/* 433:515 */         if (sttemp == ifstat) {
/* 434:    */           break;
/* 435:    */         }
/* 436:519 */         lst.add(0, sttemp);
/* 437:    */       }
/* 438:    */       Statement stelse;
/* 439:    */       Statement stelse;
/* 440:524 */       if (lst.size() == 1)
/* 441:    */       {
/* 442:525 */         stelse = (Statement)lst.get(0);
/* 443:    */       }
/* 444:    */       else
/* 445:    */       {
/* 446:528 */         stelse = new SequenceStatement(lst);
/* 447:529 */         stelse.setAllParent();
/* 448:    */       }
/* 449:532 */       ifstat.removeSuccessor((StatEdge)ifstat.getAllSuccessorEdges().get(0));
/* 450:533 */       for (Statement st : lst) {
/* 451:534 */         sequence.getStats().removeWithKey(st.id);
/* 452:    */       }
/* 453:537 */       StatEdge elseedge = new StatEdge(1, ifstat.getFirst(), stelse);
/* 454:538 */       ifstat.getFirst().addSuccessor(elseedge);
/* 455:539 */       ifstat.setElsestat(stelse);
/* 456:540 */       ifstat.setElseEdge(elseedge);
/* 457:    */       
/* 458:542 */       ifstat.getStats().addWithKey(stelse, stelse.id);
/* 459:543 */       stelse.setParent(ifstat);
/* 460:    */       
/* 461:    */ 
/* 462:    */ 
/* 463:    */ 
/* 464:    */ 
/* 465:    */ 
/* 466:    */ 
/* 467:551 */       ifstat.iftype = 1;
/* 468:    */     }
/* 469:553 */     else if ((ifdirect) && ((!elsedirect) || ((noifstat) && (!noelsestat))))
/* 470:    */     {
/* 471:556 */       IfExprent statexpr = ifstat.getHeadexprent();
/* 472:557 */       statexpr.setCondition(new FunctionExprent(12, statexpr.getCondition(), null));
/* 473:559 */       if (noelsestat)
/* 474:    */       {
/* 475:560 */         StatEdge ifedge = ifstat.getIfEdge();
/* 476:561 */         StatEdge elseedge = (StatEdge)ifstat.getAllSuccessorEdges().get(0);
/* 477:563 */         if (noifstat)
/* 478:    */         {
/* 479:564 */           ifstat.getFirst().removeSuccessor(ifedge);
/* 480:565 */           ifstat.removeSuccessor(elseedge);
/* 481:    */           
/* 482:567 */           ifedge.setSource(ifstat);
/* 483:568 */           elseedge.setSource(ifstat.getFirst());
/* 484:    */           
/* 485:570 */           ifstat.addSuccessor(ifedge);
/* 486:571 */           ifstat.getFirst().addSuccessor(elseedge);
/* 487:    */           
/* 488:573 */           ifstat.setIfEdge(elseedge);
/* 489:    */         }
/* 490:    */         else
/* 491:    */         {
/* 492:576 */           Statement ifbranch = ifstat.getIfstat();
/* 493:577 */           SequenceStatement newseq = new SequenceStatement(Arrays.asList(new Statement[] { ifstat, ifbranch }));
/* 494:    */           
/* 495:579 */           ifstat.getFirst().removeSuccessor(ifedge);
/* 496:580 */           ifstat.getStats().removeWithKey(ifbranch.id);
/* 497:581 */           ifstat.setIfstat(null);
/* 498:    */           
/* 499:583 */           ifstat.removeSuccessor(elseedge);
/* 500:584 */           elseedge.setSource(ifstat.getFirst());
/* 501:585 */           ifstat.getFirst().addSuccessor(elseedge);
/* 502:    */           
/* 503:587 */           ifstat.setIfEdge(elseedge);
/* 504:    */           
/* 505:589 */           ifstat.getParent().replaceStatement(ifstat, newseq);
/* 506:590 */           newseq.setAllParent();
/* 507:    */           
/* 508:592 */           ifstat.addSuccessor(new StatEdge(1, ifstat, ifbranch));
/* 509:    */         }
/* 510:    */       }
/* 511:    */       else
/* 512:    */       {
/* 513:597 */         SequenceStatement sequence = (SequenceStatement)parent;
/* 514:    */         
/* 515:    */ 
/* 516:600 */         List<Statement> lst = new ArrayList();
/* 517:601 */         for (int i = sequence.getStats().size() - 1; i >= 0; i--)
/* 518:    */         {
/* 519:602 */           Statement sttemp = (Statement)sequence.getStats().get(i);
/* 520:603 */           if (sttemp == ifstat) {
/* 521:    */             break;
/* 522:    */           }
/* 523:607 */           lst.add(0, sttemp);
/* 524:    */         }
/* 525:    */         Statement stelse;
/* 526:    */         Statement stelse;
/* 527:612 */         if (lst.size() == 1)
/* 528:    */         {
/* 529:613 */           stelse = (Statement)lst.get(0);
/* 530:    */         }
/* 531:    */         else
/* 532:    */         {
/* 533:616 */           stelse = new SequenceStatement(lst);
/* 534:617 */           stelse.setAllParent();
/* 535:    */         }
/* 536:620 */         ifstat.removeSuccessor((StatEdge)ifstat.getAllSuccessorEdges().get(0));
/* 537:621 */         for (Statement st : lst) {
/* 538:622 */           sequence.getStats().removeWithKey(st.id);
/* 539:    */         }
/* 540:625 */         if (noifstat)
/* 541:    */         {
/* 542:626 */           StatEdge ifedge = ifstat.getIfEdge();
/* 543:    */           
/* 544:628 */           ifstat.getFirst().removeSuccessor(ifedge);
/* 545:629 */           ifedge.setSource(ifstat);
/* 546:630 */           ifstat.addSuccessor(ifedge);
/* 547:    */         }
/* 548:    */         else
/* 549:    */         {
/* 550:633 */           Statement ifbranch = ifstat.getIfstat();
/* 551:    */           
/* 552:635 */           ifstat.getFirst().removeSuccessor(ifstat.getIfEdge());
/* 553:636 */           ifstat.getStats().removeWithKey(ifbranch.id);
/* 554:    */           
/* 555:638 */           ifstat.addSuccessor(new StatEdge(1, ifstat, ifbranch));
/* 556:    */           
/* 557:640 */           sequence.getStats().addWithKey(ifbranch, ifbranch.id);
/* 558:641 */           ifbranch.setParent(sequence);
/* 559:    */         }
/* 560:644 */         StatEdge newifedge = new StatEdge(1, ifstat.getFirst(), stelse);
/* 561:645 */         ifstat.getFirst().addSuccessor(newifedge);
/* 562:646 */         ifstat.setIfstat(stelse);
/* 563:647 */         ifstat.setIfEdge(newifedge);
/* 564:    */         
/* 565:649 */         ifstat.getStats().addWithKey(stelse, stelse.id);
/* 566:650 */         stelse.setParent(ifstat);
/* 567:    */       }
/* 568:    */     }
/* 569:    */     else
/* 570:    */     {
/* 571:654 */       return false;
/* 572:    */     }
/* 573:657 */     return true;
/* 574:    */   }
/* 575:    */   
/* 576:    */   private static boolean hasDirectEndEdge(Statement stat, Statement from)
/* 577:    */   {
/* 578:662 */     for (StatEdge edge : stat.getAllSuccessorEdges()) {
/* 579:663 */       if (MergeHelper.isDirectPath(from, edge.getDestination())) {
/* 580:664 */         return true;
/* 581:    */       }
/* 582:    */     }
/* 583:668 */     if (stat.getExprents() == null) {
/* 584:669 */       switch (stat.type)
/* 585:    */       {
/* 586:    */       case 15: 
/* 587:671 */         return hasDirectEndEdge((Statement)stat.getStats().getLast(), from);
/* 588:    */       case 7: 
/* 589:    */       case 12: 
/* 590:674 */         for (Statement st : stat.getStats()) {
/* 591:675 */           if (hasDirectEndEdge(st, from)) {
/* 592:676 */             return true;
/* 593:    */           }
/* 594:    */         }
/* 595:679 */         break;
/* 596:    */       case 2: 
/* 597:681 */         IfStatement ifstat = (IfStatement)stat;
/* 598:682 */         if (ifstat.iftype == 1) {
/* 599:683 */           return (hasDirectEndEdge(ifstat.getIfstat(), from)) || (hasDirectEndEdge(ifstat.getElsestat(), from));
/* 600:    */         }
/* 601:    */         break;
/* 602:    */       case 10: 
/* 603:688 */         return hasDirectEndEdge((Statement)stat.getStats().get(1), from);
/* 604:    */       case 6: 
/* 605:690 */         for (Statement st : stat.getStats()) {
/* 606:691 */           if (hasDirectEndEdge(st, from)) {
/* 607:692 */             return true;
/* 608:    */           }
/* 609:    */         }
/* 610:    */       }
/* 611:    */     }
/* 612:698 */     return false;
/* 613:    */   }
/* 614:    */   
/* 615:    */   private static Statement getNextStatement(Statement stat)
/* 616:    */   {
/* 617:704 */     Statement parent = stat.getParent();
/* 618:705 */     switch (parent.type)
/* 619:    */     {
/* 620:    */     case 13: 
/* 621:707 */       return ((RootStatement)parent).getDummyExit();
/* 622:    */     case 5: 
/* 623:709 */       return parent;
/* 624:    */     case 15: 
/* 625:711 */       SequenceStatement sequence = (SequenceStatement)parent;
/* 626:712 */       if (sequence.getStats().getLast() != stat) {
/* 627:713 */         for (int i = sequence.getStats().size() - 1; i >= 0; i--) {
/* 628:714 */           if (sequence.getStats().get(i) == stat) {
/* 629:715 */             return (Statement)sequence.getStats().get(i + 1);
/* 630:    */           }
/* 631:    */         }
/* 632:    */       }
/* 633:    */       break;
/* 634:    */     }
/* 635:721 */     return getNextStatement(parent);
/* 636:    */   }
/* 637:    */   
/* 638:    */   private static boolean existsPath(Statement from, Statement to)
/* 639:    */   {
/* 640:726 */     for (StatEdge edge : to.getAllPredecessorEdges()) {
/* 641:727 */       if (from.containsStatementStrict(edge.getSource())) {
/* 642:728 */         return true;
/* 643:    */       }
/* 644:    */     }
/* 645:732 */     return false;
/* 646:    */   }
/* 647:    */   
/* 648:    */   private static class IfNode
/* 649:    */   {
/* 650:    */     public final Statement value;
/* 651:738 */     public final List<IfNode> succs = new ArrayList();
/* 652:739 */     public final List<Integer> edgetypes = new ArrayList();
/* 653:    */     
/* 654:    */     public IfNode(Statement value)
/* 655:    */     {
/* 656:742 */       this.value = value;
/* 657:    */     }
/* 658:    */     
/* 659:    */     public void addChild(IfNode child, int type)
/* 660:    */     {
/* 661:746 */       this.succs.add(child);
/* 662:747 */       this.edgetypes.add(new Integer(type));
/* 663:    */     }
/* 664:    */   }
/* 665:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.IfHelper
 * JD-Core Version:    0.7.0.1
 */