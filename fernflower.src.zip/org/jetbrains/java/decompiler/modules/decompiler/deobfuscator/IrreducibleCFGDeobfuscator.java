/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.deobfuscator;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*   9:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  13:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  14:    */ 
/*  15:    */ public class IrreducibleCFGDeobfuscator
/*  16:    */ {
/*  17:    */   public static boolean isStatementIrreducible(Statement statement)
/*  18:    */   {
/*  19: 42 */     HashMap<Integer, 1Node> mapNodes = new HashMap();
/*  20: 45 */     for (Statement stat : statement.getStats())
/*  21:    */     {
/*  22: 46 */       if (!stat.getSuccessorEdges(2).isEmpty()) {
/*  23: 47 */         return false;
/*  24:    */       }
/*  25: 50 */       mapNodes.put(stat.id, new Object()
/*  26:    */       {
/*  27: 34 */         public final Set<1Node> preds = new HashSet();
/*  28: 35 */         public final Set<1Node> succs = new HashSet();
/*  29:    */       });
/*  30:    */     }
/*  31: 54 */     for (Statement stat : statement.getStats())
/*  32:    */     {
/*  33: 55 */       node = (1Node)mapNodes.get(stat.id);
/*  34: 57 */       for (Statement succ : stat.getNeighbours(1, 1))
/*  35:    */       {
/*  36: 58 */         Object nodeSucc = (1Node)mapNodes.get(succ.id);
/*  37:    */         
/*  38: 60 */         node.succs.add(nodeSucc);
/*  39: 61 */         nodeSucc.preds.add(node);
/*  40:    */       }
/*  41:    */     }
/*  42:    */     Object node;
/*  43:    */     for (;;)
/*  44:    */     {
/*  45: 67 */       int ttype = 0;
/*  46: 68 */       Object node = null;
/*  47: 70 */       for (Object nd : mapNodes.values())
/*  48:    */       {
/*  49: 71 */         if (nd.succs.contains(nd)) {
/*  50: 72 */           ttype = 1;
/*  51: 74 */         } else if (nd.preds.size() == 1) {
/*  52: 75 */           ttype = 2;
/*  53:    */         }
/*  54: 78 */         if (ttype != 0)
/*  55:    */         {
/*  56: 79 */           node = nd;
/*  57: 80 */           break;
/*  58:    */         }
/*  59:    */       }
/*  60: 84 */       if (node != null)
/*  61:    */       {
/*  62: 85 */         if (ttype == 1)
/*  63:    */         {
/*  64: 86 */           node.succs.remove(node);
/*  65: 87 */           node.preds.remove(node);
/*  66:    */         }
/*  67:    */         else
/*  68:    */         {
/*  69: 90 */           Object pred = (1Node)node.preds.iterator().next();
/*  70:    */           
/*  71: 92 */           pred.succs.addAll(node.succs);
/*  72: 93 */           pred.succs.remove(node);
/*  73: 95 */           for (Object succ : node.succs)
/*  74:    */           {
/*  75: 96 */             succ.preds.remove(node);
/*  76: 97 */             succ.preds.add(pred);
/*  77:    */           }
/*  78:100 */           mapNodes.remove(node.id);
/*  79:    */         }
/*  80:    */       }
/*  81:    */       else {
/*  82:104 */         return mapNodes.size() > 1;
/*  83:    */       }
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static Statement getCandidateForSplitting(Statement statement)
/*  88:    */   {
/*  89:112 */     Statement candidateForSplitting = null;
/*  90:113 */     int sizeCandidateForSplitting = 2147483647;
/*  91:114 */     int succsCandidateForSplitting = 2147483647;
/*  92:116 */     for (Statement stat : statement.getStats())
/*  93:    */     {
/*  94:118 */       Set<Statement> setPreds = stat.getNeighboursSet(1, 0);
/*  95:120 */       if (setPreds.size() > 1)
/*  96:    */       {
/*  97:121 */         int succCount = stat.getNeighboursSet(1, 1).size();
/*  98:122 */         if (succCount <= succsCandidateForSplitting)
/*  99:    */         {
/* 100:123 */           int size = getStatementSize(stat) * (setPreds.size() - 1);
/* 101:125 */           if ((succCount < succsCandidateForSplitting) || (size < sizeCandidateForSplitting))
/* 102:    */           {
/* 103:127 */             candidateForSplitting = stat;
/* 104:128 */             sizeCandidateForSplitting = size;
/* 105:129 */             succsCandidateForSplitting = succCount;
/* 106:    */           }
/* 107:    */         }
/* 108:    */       }
/* 109:    */     }
/* 110:135 */     return candidateForSplitting;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static boolean splitIrreducibleNode(Statement statement)
/* 114:    */   {
/* 115:140 */     Statement splitnode = getCandidateForSplitting(statement);
/* 116:141 */     if (splitnode == null) {
/* 117:142 */       return false;
/* 118:    */     }
/* 119:145 */     StatEdge enteredge = (StatEdge)splitnode.getPredecessorEdges(1).iterator().next();
/* 120:    */     
/* 121:    */ 
/* 122:148 */     Statement splitcopy = copyStatement(splitnode, null, new HashMap());
/* 123:149 */     initCopiedStatement(splitcopy);
/* 124:    */     
/* 125:    */ 
/* 126:152 */     splitcopy.setParent(statement);
/* 127:153 */     statement.getStats().addWithKey(splitcopy, splitcopy.id);
/* 128:156 */     for (StatEdge prededge : splitnode.getPredecessorEdges(1073741824)) {
/* 129:157 */       if ((prededge.getSource() == enteredge.getSource()) || (prededge.closure == enteredge.getSource()))
/* 130:    */       {
/* 131:159 */         splitnode.removePredecessor(prededge);
/* 132:160 */         prededge.getSource().changeEdgeNode(1, prededge, splitcopy);
/* 133:161 */         splitcopy.addPredecessor(prededge);
/* 134:    */       }
/* 135:    */     }
/* 136:166 */     for (StatEdge succ : splitnode.getSuccessorEdges(1073741824)) {
/* 137:167 */       splitcopy.addSuccessor(new StatEdge(succ.getType(), splitcopy, succ.getDestination(), succ.closure));
/* 138:    */     }
/* 139:170 */     return true;
/* 140:    */   }
/* 141:    */   
/* 142:    */   private static int getStatementSize(Statement statement)
/* 143:    */   {
/* 144:175 */     int res = 0;
/* 145:177 */     if (statement.type == 8) {
/* 146:178 */       res = ((BasicBlockStatement)statement).getBlock().getSeq().length();
/* 147:    */     } else {
/* 148:181 */       for (Statement stat : statement.getStats()) {
/* 149:182 */         res += getStatementSize(stat);
/* 150:    */       }
/* 151:    */     }
/* 152:186 */     return res;
/* 153:    */   }
/* 154:    */   
/* 155:    */   private static Statement copyStatement(Statement from, Statement to, HashMap<Statement, Statement> mapAltToCopies)
/* 156:    */   {
/* 157:191 */     if (to == null)
/* 158:    */     {
/* 159:193 */       to = from.getSimpleCopy();
/* 160:194 */       mapAltToCopies.put(from, to);
/* 161:    */     }
/* 162:198 */     for (Statement st : from.getStats())
/* 163:    */     {
/* 164:199 */       Statement stcopy = st.getSimpleCopy();
/* 165:    */       
/* 166:201 */       to.getStats().addWithKey(stcopy, stcopy.id);
/* 167:202 */       mapAltToCopies.put(st, stcopy);
/* 168:    */     }
/* 169:    */     Statement stnew;
/* 170:206 */     for (int i = 0; i < from.getStats().size(); i++)
/* 171:    */     {
/* 172:207 */       Statement stold = (Statement)from.getStats().get(i);
/* 173:208 */       stnew = (Statement)to.getStats().get(i);
/* 174:210 */       for (StatEdge edgeold : stold.getSuccessorEdges(1073741824))
/* 175:    */       {
/* 176:212 */         StatEdge edgenew = new StatEdge(edgeold.getType(), stnew, mapAltToCopies.containsKey(edgeold.getDestination()) ? (Statement)mapAltToCopies.get(edgeold.getDestination()) : edgeold.getDestination(), mapAltToCopies.containsKey(edgeold.closure) ? (Statement)mapAltToCopies.get(edgeold.closure) : edgeold.closure);
/* 177:    */         
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:220 */         stnew.addSuccessor(edgenew);
/* 185:    */       }
/* 186:    */     }
/* 187:225 */     for (int i = 0; i < from.getStats().size(); i++)
/* 188:    */     {
/* 189:226 */       Statement stold = (Statement)from.getStats().get(i);
/* 190:227 */       Statement stnew = (Statement)to.getStats().get(i);
/* 191:    */       
/* 192:229 */       copyStatement(stold, stnew, mapAltToCopies);
/* 193:    */     }
/* 194:232 */     return to;
/* 195:    */   }
/* 196:    */   
/* 197:    */   private static void initCopiedStatement(Statement statement)
/* 198:    */   {
/* 199:237 */     statement.initSimpleCopy();
/* 200:238 */     statement.setCopied(true);
/* 201:240 */     for (Statement st : statement.getStats())
/* 202:    */     {
/* 203:241 */       st.setParent(statement);
/* 204:242 */       initCopiedStatement(st);
/* 205:    */     }
/* 206:    */   }
/* 207:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.deobfuscator.IrreducibleCFGDeobfuscator
 * JD-Core Version:    0.7.0.1
 */