/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.deobfuscator;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.LinkedList;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Map.Entry;
/*  13:    */ import java.util.Set;
/*  14:    */ import org.jetbrains.java.decompiler.code.Instruction;
/*  15:    */ import org.jetbrains.java.decompiler.code.InstructionSequence;
/*  16:    */ import org.jetbrains.java.decompiler.code.SimpleInstructionSequence;
/*  17:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*  18:    */ import org.jetbrains.java.decompiler.code.cfg.ControlFlowGraph;
/*  19:    */ import org.jetbrains.java.decompiler.code.cfg.ExceptionRangeCFG;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.decompose.GenericDominatorEngine;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.decompose.IGraph;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.decompose.IGraphNode;
/*  23:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  24:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  25:    */ 
/*  26:    */ public class ExceptionDeobfuscator
/*  27:    */ {
/*  28:    */   private static class Range
/*  29:    */   {
/*  30:    */     private final BasicBlock handler;
/*  31:    */     private final String uniqueStr;
/*  32:    */     private final Set<BasicBlock> protectedRange;
/*  33:    */     private final ExceptionRangeCFG rangeCFG;
/*  34:    */     
/*  35:    */     private Range(BasicBlock handler, String uniqueStr, Set<BasicBlock> protectedRange, ExceptionRangeCFG rangeCFG)
/*  36:    */     {
/*  37: 42 */       this.handler = handler;
/*  38: 43 */       this.uniqueStr = uniqueStr;
/*  39: 44 */       this.protectedRange = protectedRange;
/*  40: 45 */       this.rangeCFG = rangeCFG;
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static void restorePopRanges(ControlFlowGraph graph)
/*  45:    */   {
/*  46: 51 */     List<Range> lstRanges = new ArrayList();
/*  47: 54 */     for (ExceptionRangeCFG range : graph.getExceptions())
/*  48:    */     {
/*  49: 55 */       boolean found = false;
/*  50: 56 */       for (Range arr : lstRanges) {
/*  51: 57 */         if ((arr.handler == range.getHandler()) && (InterpreterUtil.equalObjects(range.getUniqueExceptionsString(), arr.uniqueStr)))
/*  52:    */         {
/*  53: 58 */           arr.protectedRange.addAll(range.getProtectedRange());
/*  54: 59 */           found = true;
/*  55: 60 */           break;
/*  56:    */         }
/*  57:    */       }
/*  58: 64 */       if (!found) {
/*  59: 66 */         lstRanges.add(new Range(range.getHandler(), range.getUniqueExceptionsString(), new HashSet(range.getProtectedRange()), range, null));
/*  60:    */       }
/*  61:    */     }
/*  62: 71 */     for (Iterator i$ = lstRanges.iterator(); i$.hasNext();)
/*  63:    */     {
/*  64: 71 */       range = (Range)i$.next();
/*  65: 73 */       if (range.uniqueStr != null)
/*  66:    */       {
/*  67: 75 */         handler = range.handler;
/*  68: 76 */         seq = handler.getSeq();
/*  69: 79 */         if (seq.length() > 0)
/*  70:    */         {
/*  71: 80 */           firstinstr = seq.getInstr(0);
/*  72: 82 */           if ((firstinstr.opcode == 87) || (firstinstr.opcode == 58))
/*  73:    */           {
/*  74: 84 */             setrange = new HashSet(range.protectedRange);
/*  75: 86 */             for (Range range_super : lstRanges) {
/*  76: 88 */               if (range != range_super)
/*  77:    */               {
/*  78: 90 */                 Set<BasicBlock> setrange_super = new HashSet(range_super.protectedRange);
/*  79: 92 */                 if ((!setrange.contains(range_super.handler)) && (!setrange_super.contains(handler)) && ((range_super.uniqueStr == null) || (setrange_super.containsAll(setrange))))
/*  80:    */                 {
/*  81: 95 */                   if (range_super.uniqueStr == null) {
/*  82: 96 */                     setrange_super.retainAll(setrange);
/*  83:    */                   } else {
/*  84: 99 */                     setrange_super.removeAll(setrange);
/*  85:    */                   }
/*  86:102 */                   if (!setrange_super.isEmpty())
/*  87:    */                   {
/*  88:104 */                     BasicBlock newblock = handler;
/*  89:107 */                     if (seq.length() > 1)
/*  90:    */                     {
/*  91:108 */                       newblock = new BasicBlock(++graph.last_id);
/*  92:109 */                       InstructionSequence newseq = new SimpleInstructionSequence();
/*  93:110 */                       newseq.addInstruction(firstinstr.clone(), -1);
/*  94:    */                       
/*  95:112 */                       newblock.setSeq(newseq);
/*  96:113 */                       graph.getBlocks().addWithKey(newblock, Integer.valueOf(newblock.id));
/*  97:    */                       
/*  98:    */ 
/*  99:116 */                       List<BasicBlock> lstTemp = new ArrayList();
/* 100:117 */                       lstTemp.addAll(handler.getPreds());
/* 101:118 */                       lstTemp.addAll(handler.getPredExceptions());
/* 102:121 */                       for (BasicBlock pred : lstTemp) {
/* 103:122 */                         pred.replaceSuccessor(handler, newblock);
/* 104:    */                       }
/* 105:126 */                       for (ExceptionRangeCFG range_ext : graph.getExceptions()) {
/* 106:127 */                         if (range_ext.getHandler() == handler)
/* 107:    */                         {
/* 108:128 */                           range_ext.setHandler(newblock);
/* 109:    */                         }
/* 110:130 */                         else if (range_ext.getProtectedRange().contains(handler))
/* 111:    */                         {
/* 112:131 */                           newblock.addSuccessorException(range_ext.getHandler());
/* 113:132 */                           range_ext.getProtectedRange().add(newblock);
/* 114:    */                         }
/* 115:    */                       }
/* 116:136 */                       newblock.addSuccessor(handler);
/* 117:137 */                       if (graph.getFirst() == handler) {
/* 118:138 */                         graph.setFirst(newblock);
/* 119:    */                       }
/* 120:142 */                       seq.removeInstruction(0);
/* 121:    */                     }
/* 122:145 */                     newblock.addSuccessorException(range_super.handler);
/* 123:146 */                     range_super.rangeCFG.getProtectedRange().add(newblock);
/* 124:    */                     
/* 125:148 */                     handler = range.rangeCFG.getHandler();
/* 126:149 */                     seq = handler.getSeq();
/* 127:    */                   }
/* 128:    */                 }
/* 129:    */               }
/* 130:    */             }
/* 131:    */           }
/* 132:    */         }
/* 133:    */       }
/* 134:    */     }
/* 135:    */     Range range;
/* 136:    */     BasicBlock handler;
/* 137:    */     InstructionSequence seq;
/* 138:    */     Instruction firstinstr;
/* 139:    */     Set<BasicBlock> setrange;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public static void insertEmptyExceptionHandlerBlocks(ControlFlowGraph graph)
/* 143:    */   {
/* 144:162 */     Set<BasicBlock> setVisited = new HashSet();
/* 145:164 */     for (ExceptionRangeCFG range : graph.getExceptions())
/* 146:    */     {
/* 147:165 */       BasicBlock handler = range.getHandler();
/* 148:167 */       if (!setVisited.contains(handler))
/* 149:    */       {
/* 150:170 */         setVisited.add(handler);
/* 151:    */         
/* 152:172 */         BasicBlock emptyblock = new BasicBlock(++graph.last_id);
/* 153:173 */         graph.getBlocks().addWithKey(emptyblock, Integer.valueOf(emptyblock.id));
/* 154:    */         
/* 155:175 */         List<BasicBlock> lstTemp = new ArrayList();
/* 156:    */         
/* 157:177 */         lstTemp.addAll(handler.getPredExceptions());
/* 158:180 */         for (BasicBlock pred : lstTemp) {
/* 159:181 */           pred.replaceSuccessor(handler, emptyblock);
/* 160:    */         }
/* 161:185 */         for (ExceptionRangeCFG range_ext : graph.getExceptions()) {
/* 162:186 */           if (range_ext.getHandler() == handler)
/* 163:    */           {
/* 164:187 */             range_ext.setHandler(emptyblock);
/* 165:    */           }
/* 166:189 */           else if (range_ext.getProtectedRange().contains(handler))
/* 167:    */           {
/* 168:190 */             emptyblock.addSuccessorException(range_ext.getHandler());
/* 169:191 */             range_ext.getProtectedRange().add(emptyblock);
/* 170:    */           }
/* 171:    */         }
/* 172:195 */         emptyblock.addSuccessor(handler);
/* 173:196 */         if (graph.getFirst() == handler) {
/* 174:197 */           graph.setFirst(emptyblock);
/* 175:    */         }
/* 176:    */       }
/* 177:    */     }
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static void removeEmptyRanges(ControlFlowGraph graph)
/* 181:    */   {
/* 182:204 */     List<ExceptionRangeCFG> lstRanges = graph.getExceptions();
/* 183:205 */     for (int i = lstRanges.size() - 1; i >= 0; i--)
/* 184:    */     {
/* 185:206 */       ExceptionRangeCFG range = (ExceptionRangeCFG)lstRanges.get(i);
/* 186:    */       
/* 187:208 */       boolean isEmpty = true;
/* 188:209 */       for (BasicBlock block : range.getProtectedRange()) {
/* 189:210 */         if (!block.getSeq().isEmpty())
/* 190:    */         {
/* 191:211 */           isEmpty = false;
/* 192:212 */           break;
/* 193:    */         }
/* 194:    */       }
/* 195:216 */       if (isEmpty)
/* 196:    */       {
/* 197:217 */         for (BasicBlock block : range.getProtectedRange()) {
/* 198:218 */           block.removeSuccessorException(range.getHandler());
/* 199:    */         }
/* 200:221 */         lstRanges.remove(i);
/* 201:    */       }
/* 202:    */     }
/* 203:    */   }
/* 204:    */   
/* 205:    */   public static void removeCircularRanges(ControlFlowGraph graph)
/* 206:    */   {
/* 207:228 */     GenericDominatorEngine engine = new GenericDominatorEngine(new IGraph()
/* 208:    */     {
/* 209:    */       public List<? extends IGraphNode> getReversePostOrderList()
/* 210:    */       {
/* 211:230 */         return this.val$graph.getReversePostOrder();
/* 212:    */       }
/* 213:    */       
/* 214:    */       public Set<? extends IGraphNode> getRoots()
/* 215:    */       {
/* 216:234 */         return new HashSet(Arrays.asList(new IGraphNode[] { this.val$graph.getFirst() }));
/* 217:    */       }
/* 218:237 */     });
/* 219:238 */     engine.initialize();
/* 220:    */     
/* 221:240 */     List<ExceptionRangeCFG> lstRanges = graph.getExceptions();
/* 222:241 */     for (int i = lstRanges.size() - 1; i >= 0; i--)
/* 223:    */     {
/* 224:242 */       ExceptionRangeCFG range = (ExceptionRangeCFG)lstRanges.get(i);
/* 225:    */       
/* 226:244 */       BasicBlock handler = range.getHandler();
/* 227:245 */       List<BasicBlock> rangeList = range.getProtectedRange();
/* 228:247 */       if (rangeList.contains(handler))
/* 229:    */       {
/* 230:249 */         List<BasicBlock> lstRemBlocks = getReachableBlocksRestricted(range, engine);
/* 231:251 */         if ((lstRemBlocks.size() < rangeList.size()) || (rangeList.size() == 1)) {
/* 232:252 */           for (BasicBlock block : lstRemBlocks)
/* 233:    */           {
/* 234:253 */             block.removeSuccessorException(handler);
/* 235:254 */             rangeList.remove(block);
/* 236:    */           }
/* 237:    */         }
/* 238:258 */         if (rangeList.isEmpty()) {
/* 239:259 */           lstRanges.remove(i);
/* 240:    */         }
/* 241:    */       }
/* 242:    */     }
/* 243:    */   }
/* 244:    */   
/* 245:    */   private static List<BasicBlock> getReachableBlocksRestricted(ExceptionRangeCFG range, GenericDominatorEngine engine)
/* 246:    */   {
/* 247:267 */     List<BasicBlock> lstRes = new ArrayList();
/* 248:    */     
/* 249:269 */     LinkedList<BasicBlock> stack = new LinkedList();
/* 250:270 */     Set<BasicBlock> setVisited = new HashSet();
/* 251:    */     
/* 252:272 */     BasicBlock handler = range.getHandler();
/* 253:273 */     stack.addFirst(handler);
/* 254:275 */     while (!stack.isEmpty())
/* 255:    */     {
/* 256:276 */       BasicBlock block = (BasicBlock)stack.removeFirst();
/* 257:    */       
/* 258:278 */       setVisited.add(block);
/* 259:280 */       if ((range.getProtectedRange().contains(block)) && (engine.isDominator(block, handler)))
/* 260:    */       {
/* 261:281 */         lstRes.add(block);
/* 262:    */         
/* 263:283 */         List<BasicBlock> lstSuccs = new ArrayList(block.getSuccs());
/* 264:284 */         lstSuccs.addAll(block.getSuccExceptions());
/* 265:286 */         for (BasicBlock succ : lstSuccs) {
/* 266:287 */           if (!setVisited.contains(succ)) {
/* 267:288 */             stack.add(succ);
/* 268:    */           }
/* 269:    */         }
/* 270:    */       }
/* 271:    */     }
/* 272:294 */     return lstRes;
/* 273:    */   }
/* 274:    */   
/* 275:    */   public static boolean hasObfuscatedExceptions(ControlFlowGraph graph)
/* 276:    */   {
/* 277:300 */     Map<BasicBlock, Set<BasicBlock>> mapRanges = new HashMap();
/* 278:301 */     for (ExceptionRangeCFG range : graph.getExceptions())
/* 279:    */     {
/* 280:302 */       Set<BasicBlock> set = (Set)mapRanges.get(range.getHandler());
/* 281:303 */       if (set == null) {
/* 282:304 */         mapRanges.put(range.getHandler(), set = new HashSet());
/* 283:    */       }
/* 284:306 */       set.addAll(range.getProtectedRange());
/* 285:    */     }
/* 286:309 */     for (Map.Entry<BasicBlock, Set<BasicBlock>> ent : mapRanges.entrySet())
/* 287:    */     {
/* 288:310 */       Set<BasicBlock> setEntries = new HashSet();
/* 289:312 */       for (BasicBlock block : (Set)ent.getValue())
/* 290:    */       {
/* 291:313 */         Set<BasicBlock> setTemp = new HashSet(block.getPreds());
/* 292:314 */         setTemp.removeAll((Collection)ent.getValue());
/* 293:316 */         if (!setTemp.isEmpty()) {
/* 294:317 */           setEntries.add(block);
/* 295:    */         }
/* 296:    */       }
/* 297:321 */       if ((!setEntries.isEmpty()) && 
/* 298:322 */         (setEntries.size() > 1)) {
/* 299:323 */         return true;
/* 300:    */       }
/* 301:    */     }
/* 302:328 */     return false;
/* 303:    */   }
/* 304:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.deobfuscator.ExceptionDeobfuscator
 * JD-Core Version:    0.7.0.1
 */