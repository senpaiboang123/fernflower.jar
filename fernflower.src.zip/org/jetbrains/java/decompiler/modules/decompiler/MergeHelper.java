/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import java.util.Set;
/*   6:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.IfExprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SwitchStatement;
/*  16:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  17:    */ 
/*  18:    */ public class MergeHelper
/*  19:    */ {
/*  20:    */   public static void enhanceLoops(Statement root)
/*  21:    */   {
/*  22: 33 */     while (enhanceLoopsRec(root)) {}
/*  23: 35 */     SequenceHelper.condenseSequences(root);
/*  24:    */   }
/*  25:    */   
/*  26:    */   private static boolean enhanceLoopsRec(Statement stat)
/*  27:    */   {
/*  28: 40 */     boolean res = false;
/*  29: 42 */     for (Statement st : stat.getStats()) {
/*  30: 43 */       if (st.getExprents() == null) {
/*  31: 44 */         res |= enhanceLoopsRec(st);
/*  32:    */       }
/*  33:    */     }
/*  34: 48 */     if (stat.type == 5) {
/*  35: 49 */       res |= enhanceLoop((DoStatement)stat);
/*  36:    */     }
/*  37: 52 */     return res;
/*  38:    */   }
/*  39:    */   
/*  40:    */   private static boolean enhanceLoop(DoStatement stat)
/*  41:    */   {
/*  42: 57 */     int oldloop = stat.getLooptype();
/*  43: 59 */     switch (oldloop)
/*  44:    */     {
/*  45:    */     case 0: 
/*  46: 63 */       if (matchWhile(stat)) {
/*  47: 65 */         matchFor(stat);
/*  48:    */       } else {
/*  49: 69 */         matchDoWhile(stat);
/*  50:    */       }
/*  51: 72 */       break;
/*  52:    */     case 2: 
/*  53: 74 */       matchFor(stat);
/*  54:    */     }
/*  55: 77 */     return stat.getLooptype() != oldloop;
/*  56:    */   }
/*  57:    */   
/*  58:    */   private static boolean matchDoWhile(DoStatement stat)
/*  59:    */   {
/*  60: 83 */     Statement last = stat.getFirst();
/*  61: 84 */     while (last.type == 15) {
/*  62: 85 */       last = (Statement)last.getStats().getLast();
/*  63:    */     }
/*  64: 88 */     if (last.type == 2)
/*  65:    */     {
/*  66: 89 */       IfStatement lastif = (IfStatement)last;
/*  67: 90 */       if ((lastif.iftype == 0) && (lastif.getIfstat() == null))
/*  68:    */       {
/*  69: 91 */         StatEdge ifedge = lastif.getIfEdge();
/*  70: 92 */         StatEdge elseedge = (StatEdge)lastif.getAllSuccessorEdges().get(0);
/*  71: 94 */         if (((ifedge.getType() == 4) && (elseedge.getType() == 8) && (elseedge.closure == stat) && (isDirectPath(stat, ifedge.getDestination()))) || ((ifedge.getType() == 8) && (elseedge.getType() == 4) && (ifedge.closure == stat) && (isDirectPath(stat, elseedge.getDestination()))))
/*  72:    */         {
/*  73: 99 */           Set<Statement> set = stat.getNeighboursSet(8, 0);
/*  74:100 */           set.remove(last);
/*  75:102 */           if (!set.isEmpty()) {
/*  76:103 */             return false;
/*  77:    */           }
/*  78:107 */           stat.setLooptype(1);
/*  79:    */           
/*  80:109 */           IfExprent ifexpr = (IfExprent)lastif.getHeadexprent().copy();
/*  81:110 */           if (ifedge.getType() == 4) {
/*  82:111 */             ifexpr.negateIf();
/*  83:    */           }
/*  84:113 */           stat.setConditionExprent(ifexpr.getCondition());
/*  85:114 */           lastif.getFirst().removeSuccessor(ifedge);
/*  86:115 */           lastif.removeSuccessor(elseedge);
/*  87:118 */           if (lastif.getFirst().getExprents().isEmpty())
/*  88:    */           {
/*  89:119 */             removeLastEmptyStatement(stat, lastif);
/*  90:    */           }
/*  91:    */           else
/*  92:    */           {
/*  93:122 */             lastif.setExprents(lastif.getFirst().getExprents());
/*  94:    */             
/*  95:124 */             StatEdge newedge = new StatEdge(8, lastif, stat);
/*  96:125 */             lastif.addSuccessor(newedge);
/*  97:126 */             stat.addLabeledEdge(newedge);
/*  98:    */           }
/*  99:129 */           if (stat.getAllSuccessorEdges().isEmpty())
/* 100:    */           {
/* 101:130 */             StatEdge edge = elseedge.getType() == 8 ? ifedge : elseedge;
/* 102:    */             
/* 103:132 */             edge.setSource(stat);
/* 104:133 */             if (edge.closure == stat) {
/* 105:134 */               edge.closure = stat.getParent();
/* 106:    */             }
/* 107:136 */             stat.addSuccessor(edge);
/* 108:    */           }
/* 109:139 */           return true;
/* 110:    */         }
/* 111:    */       }
/* 112:    */     }
/* 113:143 */     return false;
/* 114:    */   }
/* 115:    */   
/* 116:    */   private static boolean matchWhile(DoStatement stat)
/* 117:    */   {
/* 118:149 */     Statement first = stat.getFirst();
/* 119:150 */     while (first.type == 15) {
/* 120:151 */       first = first.getFirst();
/* 121:    */     }
/* 122:155 */     if (first.type == 2)
/* 123:    */     {
/* 124:156 */       IfStatement firstif = (IfStatement)first;
/* 125:158 */       if (firstif.getFirst().getExprents().isEmpty()) {
/* 126:160 */         if (firstif.iftype == 0) {
/* 127:161 */           if (firstif.getIfstat() == null)
/* 128:    */           {
/* 129:162 */             StatEdge ifedge = firstif.getIfEdge();
/* 130:163 */             if (isDirectPath(stat, ifedge.getDestination()))
/* 131:    */             {
/* 132:165 */               stat.setLooptype(2);
/* 133:    */               
/* 134:    */ 
/* 135:168 */               IfExprent ifexpr = (IfExprent)firstif.getHeadexprent().copy();
/* 136:169 */               ifexpr.negateIf();
/* 137:170 */               stat.setConditionExprent(ifexpr.getCondition());
/* 138:    */               
/* 139:    */ 
/* 140:173 */               firstif.getFirst().removeSuccessor(ifedge);
/* 141:174 */               firstif.removeSuccessor((StatEdge)firstif.getAllSuccessorEdges().get(0));
/* 142:176 */               if (stat.getAllSuccessorEdges().isEmpty())
/* 143:    */               {
/* 144:177 */                 ifedge.setSource(stat);
/* 145:178 */                 if (ifedge.closure == stat) {
/* 146:179 */                   ifedge.closure = stat.getParent();
/* 147:    */                 }
/* 148:181 */                 stat.addSuccessor(ifedge);
/* 149:    */               }
/* 150:185 */               if (firstif == stat.getFirst())
/* 151:    */               {
/* 152:186 */                 BasicBlockStatement bstat = new BasicBlockStatement(new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0)));
/* 153:    */                 
/* 154:188 */                 bstat.setExprents(new ArrayList());
/* 155:189 */                 stat.replaceStatement(firstif, bstat);
/* 156:    */               }
/* 157:    */               else
/* 158:    */               {
/* 159:193 */                 Statement sequence = firstif.getParent();
/* 160:194 */                 sequence.getStats().removeWithKey(firstif.id);
/* 161:195 */                 sequence.setFirst((Statement)sequence.getStats().get(0));
/* 162:    */               }
/* 163:198 */               return true;
/* 164:    */             }
/* 165:    */           }
/* 166:    */           else
/* 167:    */           {
/* 168:202 */             StatEdge elseedge = (StatEdge)firstif.getAllSuccessorEdges().get(0);
/* 169:203 */             if (isDirectPath(stat, elseedge.getDestination()))
/* 170:    */             {
/* 171:205 */               stat.setLooptype(2);
/* 172:    */               
/* 173:    */ 
/* 174:208 */               stat.setConditionExprent(((IfExprent)firstif.getHeadexprent().copy()).getCondition());
/* 175:    */               
/* 176:    */ 
/* 177:211 */               StatEdge ifedge = firstif.getIfEdge();
/* 178:212 */               firstif.getFirst().removeSuccessor(ifedge);
/* 179:213 */               firstif.removeSuccessor(elseedge);
/* 180:215 */               if (stat.getAllSuccessorEdges().isEmpty())
/* 181:    */               {
/* 182:217 */                 elseedge.setSource(stat);
/* 183:218 */                 if (elseedge.closure == stat) {
/* 184:219 */                   elseedge.closure = stat.getParent();
/* 185:    */                 }
/* 186:221 */                 stat.addSuccessor(elseedge);
/* 187:    */               }
/* 188:224 */               if (firstif.getIfstat() == null)
/* 189:    */               {
/* 190:225 */                 BasicBlockStatement bstat = new BasicBlockStatement(new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0)));
/* 191:    */                 
/* 192:227 */                 bstat.setExprents(new ArrayList());
/* 193:    */                 
/* 194:229 */                 ifedge.setSource(bstat);
/* 195:230 */                 bstat.addSuccessor(ifedge);
/* 196:    */                 
/* 197:232 */                 stat.replaceStatement(firstif, bstat);
/* 198:    */               }
/* 199:    */               else
/* 200:    */               {
/* 201:236 */                 first.getParent().replaceStatement(first, firstif.getIfstat());
/* 202:239 */                 for (StatEdge prededge : elseedge.getDestination().getPredecessorEdges(4)) {
/* 203:240 */                   if (stat.containsStatementStrict(prededge.closure)) {
/* 204:241 */                     stat.addLabeledEdge(prededge);
/* 205:    */                   }
/* 206:    */                 }
/* 207:245 */                 LabelHelper.lowClosures(stat);
/* 208:    */               }
/* 209:248 */               return true;
/* 210:    */             }
/* 211:    */           }
/* 212:    */         }
/* 213:    */       }
/* 214:    */     }
/* 215:254 */     return false;
/* 216:    */   }
/* 217:    */   
/* 218:    */   public static boolean isDirectPath(Statement stat, Statement endstat)
/* 219:    */   {
/* 220:259 */     Set<Statement> setStat = stat.getNeighboursSet(1073741824, 1);
/* 221:260 */     if (setStat.isEmpty())
/* 222:    */     {
/* 223:261 */       Statement parent = stat.getParent();
/* 224:262 */       if (parent == null) {
/* 225:263 */         return false;
/* 226:    */       }
/* 227:266 */       switch (parent.type)
/* 228:    */       {
/* 229:    */       case 13: 
/* 230:268 */         return endstat.type == 14;
/* 231:    */       case 5: 
/* 232:270 */         return endstat == parent;
/* 233:    */       case 6: 
/* 234:272 */         SwitchStatement swst = (SwitchStatement)parent;
/* 235:273 */         for (int i = 0; i < swst.getCaseStatements().size() - 1; i++)
/* 236:    */         {
/* 237:274 */           Statement stt = (Statement)swst.getCaseStatements().get(i);
/* 238:275 */           if (stt == stat)
/* 239:    */           {
/* 240:276 */             Statement stnext = (Statement)swst.getCaseStatements().get(i + 1);
/* 241:278 */             if ((stnext.getExprents() != null) && (stnext.getExprents().isEmpty())) {
/* 242:279 */               stnext = ((StatEdge)stnext.getAllSuccessorEdges().get(0)).getDestination();
/* 243:    */             }
/* 244:281 */             return endstat == stnext;
/* 245:    */           }
/* 246:    */         }
/* 247:    */       }
/* 248:285 */       return isDirectPath(parent, endstat);
/* 249:    */     }
/* 250:290 */     return setStat.contains(endstat);
/* 251:    */   }
/* 252:    */   
/* 253:    */   private static boolean matchFor(DoStatement stat)
/* 254:    */   {
/* 255:296 */     Exprent lastDoExprent = null;Exprent initDoExprent = null;
/* 256:297 */     Statement lastData = null;Statement preData = null;
/* 257:    */     
/* 258:    */ 
/* 259:300 */     lastData = getLastDirectData(stat.getFirst());
/* 260:301 */     if ((lastData == null) || (lastData.getExprents().isEmpty())) {
/* 261:302 */       return false;
/* 262:    */     }
/* 263:305 */     List<Exprent> lstExpr = lastData.getExprents();
/* 264:306 */     lastDoExprent = (Exprent)lstExpr.get(lstExpr.size() - 1);
/* 265:    */     
/* 266:308 */     boolean issingle = false;
/* 267:309 */     if ((lstExpr.size() == 1) && 
/* 268:310 */       (lastData.getAllPredecessorEdges().size() > 1)) {
/* 269:311 */       issingle = true;
/* 270:    */     }
/* 271:315 */     boolean haslast = (issingle) || (lastDoExprent.type == 2) || (lastDoExprent.type == 6);
/* 272:318 */     if (!haslast) {
/* 273:319 */       return false;
/* 274:    */     }
/* 275:322 */     boolean hasinit = false;
/* 276:    */     
/* 277:    */ 
/* 278:325 */     Statement current = stat;
/* 279:    */     for (;;)
/* 280:    */     {
/* 281:327 */       Statement parent = current.getParent();
/* 282:328 */       if (parent == null) {
/* 283:    */         break;
/* 284:    */       }
/* 285:332 */       if (parent.type != 15) {
/* 286:    */         break;
/* 287:    */       }
/* 288:333 */       if (current == parent.getFirst())
/* 289:    */       {
/* 290:334 */         current = parent;
/* 291:    */       }
/* 292:    */       else
/* 293:    */       {
/* 294:337 */         preData = (Statement)current.getNeighbours(1, 0).get(0);
/* 295:338 */         preData = getLastDirectData(preData);
/* 296:339 */         if ((preData == null) || (preData.getExprents().isEmpty())) {
/* 297:    */           break;
/* 298:    */         }
/* 299:340 */         initDoExprent = (Exprent)preData.getExprents().get(preData.getExprents().size() - 1);
/* 300:341 */         if (initDoExprent.type != 2) {
/* 301:    */           break;
/* 302:    */         }
/* 303:342 */         hasinit = true; break;
/* 304:    */       }
/* 305:    */     }
/* 306:353 */     if (((hasinit) && (haslast)) || (issingle))
/* 307:    */     {
/* 308:355 */       Set<Statement> set = stat.getNeighboursSet(8, 0);
/* 309:356 */       set.remove(lastData);
/* 310:358 */       if (!set.isEmpty()) {
/* 311:359 */         return false;
/* 312:    */       }
/* 313:362 */       stat.setLooptype(3);
/* 314:363 */       if (hasinit) {
/* 315:364 */         stat.setInitExprent((Exprent)preData.getExprents().remove(preData.getExprents().size() - 1));
/* 316:    */       }
/* 317:366 */       stat.setIncExprent((Exprent)lastData.getExprents().remove(lastData.getExprents().size() - 1));
/* 318:    */     }
/* 319:369 */     if (lastData.getExprents().isEmpty())
/* 320:    */     {
/* 321:370 */       List<StatEdge> lst = lastData.getAllSuccessorEdges();
/* 322:371 */       if (!lst.isEmpty()) {
/* 323:372 */         lastData.removeSuccessor((StatEdge)lst.get(0));
/* 324:    */       }
/* 325:374 */       removeLastEmptyStatement(stat, lastData);
/* 326:    */     }
/* 327:377 */     return true;
/* 328:    */   }
/* 329:    */   
/* 330:    */   private static void removeLastEmptyStatement(DoStatement dostat, Statement stat)
/* 331:    */   {
/* 332:382 */     if (stat == dostat.getFirst())
/* 333:    */     {
/* 334:383 */       BasicBlockStatement bstat = new BasicBlockStatement(new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0)));
/* 335:    */       
/* 336:385 */       bstat.setExprents(new ArrayList());
/* 337:386 */       dostat.replaceStatement(stat, bstat);
/* 338:    */     }
/* 339:    */     else
/* 340:    */     {
/* 341:389 */       for (StatEdge edge : stat.getAllPredecessorEdges())
/* 342:    */       {
/* 343:390 */         edge.getSource().changeEdgeType(1, edge, 8);
/* 344:    */         
/* 345:392 */         stat.removePredecessor(edge);
/* 346:393 */         edge.getSource().changeEdgeNode(1, edge, dostat);
/* 347:394 */         dostat.addPredecessor(edge);
/* 348:    */         
/* 349:396 */         dostat.addLabeledEdge(edge);
/* 350:    */       }
/* 351:400 */       stat.getParent().getStats().removeWithKey(stat.id);
/* 352:    */     }
/* 353:    */   }
/* 354:    */   
/* 355:    */   private static Statement getLastDirectData(Statement stat)
/* 356:    */   {
/* 357:406 */     if (stat.getExprents() != null) {
/* 358:407 */       return stat;
/* 359:    */     }
/* 360:410 */     switch (stat.type)
/* 361:    */     {
/* 362:    */     case 15: 
/* 363:412 */       for (int i = stat.getStats().size() - 1; i >= 0; i--)
/* 364:    */       {
/* 365:413 */         Statement tmp = getLastDirectData((Statement)stat.getStats().get(i));
/* 366:414 */         if ((tmp == null) || (!tmp.getExprents().isEmpty())) {
/* 367:415 */           return tmp;
/* 368:    */         }
/* 369:    */       }
/* 370:    */     }
/* 371:419 */     return null;
/* 372:    */   }
/* 373:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.MergeHelper
 * JD-Core Version:    0.7.0.1
 */