/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  6:   */ 
/*  7:   */ public class PrimitiveExprsList
/*  8:   */ {
/*  9:25 */   private final List<Exprent> lstExprents = new ArrayList();
/* 10:27 */   private ExprentStack stack = new ExprentStack();
/* 11:   */   
/* 12:   */   public PrimitiveExprsList copyStack()
/* 13:   */   {
/* 14:33 */     PrimitiveExprsList prlst = new PrimitiveExprsList();
/* 15:34 */     prlst.setStack(this.stack.clone());
/* 16:35 */     return prlst;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public List<Exprent> getLstExprents()
/* 20:   */   {
/* 21:39 */     return this.lstExprents;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public ExprentStack getStack()
/* 25:   */   {
/* 26:43 */     return this.stack;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setStack(ExprentStack stack)
/* 30:   */   {
/* 31:47 */     this.stack = stack;
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.PrimitiveExprsList
 * JD-Core Version:    0.7.0.1
 */