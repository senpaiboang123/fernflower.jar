/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*   6:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*  10:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  11:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  12:    */ 
/*  13:    */ public class ConcatenationHelper
/*  14:    */ {
/*  15:    */   private static final String builderClass = "java/lang/StringBuilder";
/*  16:    */   private static final String bufferClass = "java/lang/StringBuffer";
/*  17:    */   private static final String stringClass = "java/lang/String";
/*  18: 32 */   private static final VarType builderType = new VarType(8, 0, "java/lang/StringBuilder");
/*  19: 33 */   private static final VarType bufferType = new VarType(8, 0, "java/lang/StringBuffer");
/*  20:    */   
/*  21:    */   public static Exprent contractStringConcat(Exprent expr)
/*  22:    */   {
/*  23: 38 */     Exprent exprTmp = null;
/*  24: 39 */     VarType cltype = null;
/*  25: 42 */     if (expr.type == 8)
/*  26:    */     {
/*  27: 43 */       InvocationExprent iex = (InvocationExprent)expr;
/*  28: 44 */       if ("toString".equals(iex.getName()))
/*  29:    */       {
/*  30: 45 */         if ("java/lang/StringBuilder".equals(iex.getClassname())) {
/*  31: 46 */           cltype = builderType;
/*  32: 48 */         } else if ("java/lang/StringBuffer".equals(iex.getClassname())) {
/*  33: 49 */           cltype = bufferType;
/*  34:    */         }
/*  35: 51 */         if (cltype != null) {
/*  36: 52 */           exprTmp = iex.getInstance();
/*  37:    */         }
/*  38:    */       }
/*  39:    */     }
/*  40: 57 */     if (exprTmp == null) {
/*  41: 58 */       return expr;
/*  42:    */     }
/*  43: 63 */     List<Exprent> lstOperands = new ArrayList();
/*  44:    */     for (;;)
/*  45:    */     {
/*  46: 67 */       int found = 0;
/*  47: 69 */       switch (exprTmp.type)
/*  48:    */       {
/*  49:    */       case 8: 
/*  50: 71 */         InvocationExprent iex = (InvocationExprent)exprTmp;
/*  51: 72 */         if (isAppendConcat(iex, cltype))
/*  52:    */         {
/*  53: 73 */           lstOperands.add(0, iex.getLstParameters().get(0));
/*  54: 74 */           exprTmp = iex.getInstance();
/*  55: 75 */           found = 1;
/*  56:    */         }
/*  57:    */         break;
/*  58:    */       case 10: 
/*  59: 79 */         NewExprent nex = (NewExprent)exprTmp;
/*  60: 80 */         if (isNewConcat(nex, cltype))
/*  61:    */         {
/*  62: 81 */           VarType[] params = nex.getConstructor().getDescriptor().params;
/*  63: 82 */           if (params.length == 1) {
/*  64: 83 */             lstOperands.add(0, nex.getConstructor().getLstParameters().get(0));
/*  65:    */           }
/*  66: 85 */           found = 2;
/*  67:    */         }
/*  68:    */         break;
/*  69:    */       }
/*  70: 89 */       if (found == 0) {
/*  71: 90 */         return expr;
/*  72:    */       }
/*  73: 92 */       if (found == 2) {
/*  74:    */         break;
/*  75:    */       }
/*  76:    */     }
/*  77: 97 */     int first2str = 0;
/*  78: 98 */     int index = 0;
/*  79: 99 */     while ((index < lstOperands.size()) && (index < 2))
/*  80:    */     {
/*  81:100 */       if (((Exprent)lstOperands.get(index)).getExprType().equals(VarType.VARTYPE_STRING)) {
/*  82:101 */         first2str |= index + 1;
/*  83:    */       }
/*  84:103 */       index++;
/*  85:    */     }
/*  86:106 */     if (first2str == 0) {
/*  87:107 */       lstOperands.add(0, new ConstExprent(VarType.VARTYPE_STRING, "", expr.bytecode));
/*  88:    */     }
/*  89:111 */     for (int i = 0; i < lstOperands.size(); i++)
/*  90:    */     {
/*  91:112 */       Exprent rep = removeStringValueOf((Exprent)lstOperands.get(i));
/*  92:    */       
/*  93:114 */       boolean ok = i > 1;
/*  94:115 */       if (!ok)
/*  95:    */       {
/*  96:116 */         boolean isstr = rep.getExprType().equals(VarType.VARTYPE_STRING);
/*  97:117 */         ok = (isstr) || (first2str != i + 1);
/*  98:119 */         if (i == 0) {
/*  99:120 */           first2str &= 0x2;
/* 100:    */         }
/* 101:    */       }
/* 102:124 */       if (ok) {
/* 103:125 */         lstOperands.set(i, rep);
/* 104:    */       }
/* 105:    */     }
/* 106:130 */     Exprent func = (Exprent)lstOperands.get(0);
/* 107:132 */     for (int i = 1; i < lstOperands.size(); i++)
/* 108:    */     {
/* 109:133 */       List<Exprent> lstTmp = new ArrayList();
/* 110:134 */       lstTmp.add(func);
/* 111:135 */       lstTmp.add(lstOperands.get(i));
/* 112:136 */       func = new FunctionExprent(50, lstTmp, expr.bytecode);
/* 113:    */     }
/* 114:139 */     return func;
/* 115:    */   }
/* 116:    */   
/* 117:    */   private static boolean isAppendConcat(InvocationExprent expr, VarType cltype)
/* 118:    */   {
/* 119:144 */     if ("append".equals(expr.getName()))
/* 120:    */     {
/* 121:145 */       MethodDescriptor md = expr.getDescriptor();
/* 122:146 */       if ((md.ret.equals(cltype)) && (md.params.length == 1))
/* 123:    */       {
/* 124:147 */         VarType param = md.params[0];
/* 125:148 */         switch (param.type)
/* 126:    */         {
/* 127:    */         case 8: 
/* 128:150 */           if ((!param.equals(VarType.VARTYPE_STRING)) && (!param.equals(VarType.VARTYPE_OBJECT))) {
/* 129:    */             break;
/* 130:    */           }
/* 131:    */         case 1: 
/* 132:    */         case 2: 
/* 133:    */         case 3: 
/* 134:    */         case 4: 
/* 135:    */         case 5: 
/* 136:    */         case 7: 
/* 137:160 */           return true;
/* 138:    */         }
/* 139:    */       }
/* 140:    */     }
/* 141:166 */     return false;
/* 142:    */   }
/* 143:    */   
/* 144:    */   private static boolean isNewConcat(NewExprent expr, VarType cltype)
/* 145:    */   {
/* 146:171 */     if (expr.getNewType().equals(cltype))
/* 147:    */     {
/* 148:172 */       VarType[] params = expr.getConstructor().getDescriptor().params;
/* 149:173 */       if ((params.length == 0) || ((params.length == 1) && (params[0].equals(VarType.VARTYPE_STRING)))) {
/* 150:175 */         return true;
/* 151:    */       }
/* 152:    */     }
/* 153:179 */     return false;
/* 154:    */   }
/* 155:    */   
/* 156:    */   private static Exprent removeStringValueOf(Exprent exprent)
/* 157:    */   {
/* 158:184 */     if (exprent.type == 8)
/* 159:    */     {
/* 160:185 */       InvocationExprent iex = (InvocationExprent)exprent;
/* 161:186 */       if (("valueOf".equals(iex.getName())) && ("java/lang/String".equals(iex.getClassname())))
/* 162:    */       {
/* 163:187 */         MethodDescriptor md = iex.getDescriptor();
/* 164:188 */         if (md.params.length == 1)
/* 165:    */         {
/* 166:189 */           VarType param = md.params[0];
/* 167:190 */           switch (param.type)
/* 168:    */           {
/* 169:    */           case 8: 
/* 170:192 */             if (!param.equals(VarType.VARTYPE_OBJECT)) {
/* 171:    */               break;
/* 172:    */             }
/* 173:    */           case 1: 
/* 174:    */           case 2: 
/* 175:    */           case 3: 
/* 176:    */           case 4: 
/* 177:    */           case 5: 
/* 178:    */           case 7: 
/* 179:201 */             return (Exprent)iex.getLstParameters().get(0);
/* 180:    */           }
/* 181:    */         }
/* 182:    */       }
/* 183:    */     }
/* 184:207 */     return exprent;
/* 185:    */   }
/* 186:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.ConcatenationHelper
 * JD-Core Version:    0.7.0.1
 */