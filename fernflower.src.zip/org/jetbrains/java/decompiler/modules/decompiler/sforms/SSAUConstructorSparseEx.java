/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.sforms;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import java.util.Set;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchAllStatement;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SynchronizedStatement;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionEdge;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionNode;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionsGraph;
/*  24:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  25:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  26:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  27:    */ import org.jetbrains.java.decompiler.util.FastSparseSetFactory;
/*  28:    */ import org.jetbrains.java.decompiler.util.FastSparseSetFactory.FastSparseSet;
/*  29:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  30:    */ import org.jetbrains.java.decompiler.util.SFormsFastMapDirect;
/*  31:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  32:    */ 
/*  33:    */ public class SSAUConstructorSparseEx
/*  34:    */ {
/*  35: 43 */   private final HashMap<String, SFormsFastMapDirect> inVarVersions = new HashMap();
/*  36: 47 */   private final HashMap<String, SFormsFastMapDirect> outVarVersions = new HashMap();
/*  37: 51 */   private final HashMap<String, SFormsFastMapDirect> outNegVarVersions = new HashMap();
/*  38: 55 */   private final HashMap<String, SFormsFastMapDirect> extraVarVersions = new HashMap();
/*  39: 59 */   private final HashMap<VarVersionPair, HashSet<Integer>> phi = new HashMap();
/*  40: 62 */   private final HashMap<Integer, Integer> lastversion = new HashMap();
/*  41: 65 */   private final HashMap<VarVersionPair, Integer> mapVersionFirstRange = new HashMap();
/*  42: 68 */   private final HashMap<VarVersionPair, VarVersionPair> phantomppnodes = new HashMap();
/*  43: 71 */   private final HashMap<String, HashMap<VarVersionPair, VarVersionPair>> phantomexitnodes = new HashMap();
/*  44: 75 */   private final VarVersionsGraph ssuversions = new VarVersionsGraph();
/*  45: 78 */   private final HashMap<Integer, Integer> mapFieldVars = new HashMap();
/*  46: 81 */   private int fieldvarcounter = -1;
/*  47:    */   private FastSparseSetFactory<Integer> factory;
/*  48:    */   
/*  49:    */   public void splitVariables(RootStatement root, StructMethod mt)
/*  50:    */   {
/*  51: 88 */     FlattenStatementsHelper flatthelper = new FlattenStatementsHelper();
/*  52: 89 */     DirectGraph dgraph = flatthelper.buildDirectGraph(root);
/*  53:    */     
/*  54: 91 */     HashSet<Integer> setInit = new HashSet();
/*  55: 92 */     for (int i = 0; i < 64; i++) {
/*  56: 93 */       setInit.add(Integer.valueOf(i));
/*  57:    */     }
/*  58: 95 */     this.factory = new FastSparseSetFactory(setInit);
/*  59:    */     
/*  60: 97 */     this.extraVarVersions.put(dgraph.first.id, createFirstMap(mt, root));
/*  61:    */     
/*  62: 99 */     setCatchMaps(root, dgraph, flatthelper);
/*  63:    */     
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:105 */     HashSet<String> updated = new HashSet();
/*  69:    */     do
/*  70:    */     {
/*  71:108 */       ssaStatements(dgraph, updated, false);
/*  72:111 */     } while (!updated.isEmpty());
/*  73:114 */     ssaStatements(dgraph, updated, true);
/*  74:    */     
/*  75:116 */     this.ssuversions.initDominators();
/*  76:    */   }
/*  77:    */   
/*  78:    */   private void ssaStatements(DirectGraph dgraph, HashSet<String> updated, boolean calcLiveVars)
/*  79:    */   {
/*  80:121 */     for (DirectNode node : dgraph.nodes)
/*  81:    */     {
/*  82:123 */       updated.remove(node.id);
/*  83:124 */       mergeInVarMaps(node, dgraph);
/*  84:    */       
/*  85:126 */       SFormsFastMapDirect varmap = new SFormsFastMapDirect((SFormsFastMapDirect)this.inVarVersions.get(node.id));
/*  86:    */       
/*  87:128 */       SFormsFastMapDirect[] varmaparr = { varmap, null };
/*  88:130 */       if (node.exprents != null) {
/*  89:131 */         for (Exprent expr : node.exprents) {
/*  90:132 */           processExprent(expr, varmaparr, node.statement, calcLiveVars);
/*  91:    */         }
/*  92:    */       }
/*  93:136 */       if (varmaparr[1] == null) {
/*  94:137 */         varmaparr[1] = varmaparr[0];
/*  95:    */       }
/*  96:142 */       boolean allow_field_propagation = (node.succs.isEmpty()) || ((node.succs.size() == 1) && (((DirectNode)node.succs.get(0)).preds.size() == 1));
/*  97:144 */       if ((!allow_field_propagation) && (varmaparr[0] != null))
/*  98:    */       {
/*  99:145 */         varmaparr[0].removeAllFields();
/* 100:146 */         varmaparr[1].removeAllFields();
/* 101:    */       }
/* 102:149 */       boolean this_updated = (!mapsEqual(varmaparr[0], (SFormsFastMapDirect)this.outVarVersions.get(node.id))) || ((this.outNegVarVersions.containsKey(node.id)) && (!mapsEqual(varmaparr[1], (SFormsFastMapDirect)this.outNegVarVersions.get(node.id))));
/* 103:152 */       if (this_updated)
/* 104:    */       {
/* 105:154 */         this.outVarVersions.put(node.id, varmaparr[0]);
/* 106:155 */         if (dgraph.mapNegIfBranch.containsKey(node.id)) {
/* 107:156 */           this.outNegVarVersions.put(node.id, varmaparr[1]);
/* 108:    */         }
/* 109:159 */         for (DirectNode nd : node.succs) {
/* 110:160 */           updated.add(nd.id);
/* 111:    */         }
/* 112:    */       }
/* 113:    */     }
/* 114:    */   }
/* 115:    */   
/* 116:    */   private void processExprent(Exprent expr, SFormsFastMapDirect[] varmaparr, Statement stat, boolean calcLiveVars)
/* 117:    */   {
/* 118:169 */     if (expr == null) {
/* 119:170 */       return;
/* 120:    */     }
/* 121:174 */     VarExprent varassign = null;
/* 122:175 */     boolean finished = false;
/* 123:177 */     switch (expr.type)
/* 124:    */     {
/* 125:    */     case 2: 
/* 126:179 */       AssignmentExprent assexpr = (AssignmentExprent)expr;
/* 127:180 */       if (assexpr.getCondType() == -1)
/* 128:    */       {
/* 129:181 */         Exprent dest = assexpr.getLeft();
/* 130:182 */         if (dest.type == 12) {
/* 131:183 */           varassign = (VarExprent)dest;
/* 132:    */         }
/* 133:    */       }
/* 134:185 */       break;
/* 135:    */     case 6: 
/* 136:188 */       FunctionExprent func = (FunctionExprent)expr;
/* 137:189 */       switch (func.getFuncType())
/* 138:    */       {
/* 139:    */       case 36: 
/* 140:191 */         processExprent((Exprent)func.getLstOperands().get(0), varmaparr, stat, calcLiveVars);
/* 141:    */         SFormsFastMapDirect varmapFalse;
/* 142:    */         SFormsFastMapDirect varmapFalse;
/* 143:194 */         if (varmaparr[1] == null)
/* 144:    */         {
/* 145:195 */           varmapFalse = new SFormsFastMapDirect(varmaparr[0]);
/* 146:    */         }
/* 147:    */         else
/* 148:    */         {
/* 149:198 */           varmapFalse = varmaparr[1];
/* 150:199 */           varmaparr[1] = null;
/* 151:    */         }
/* 152:202 */         processExprent((Exprent)func.getLstOperands().get(1), varmaparr, stat, calcLiveVars);
/* 153:    */         
/* 154:204 */         SFormsFastMapDirect[] varmaparrNeg = { varmapFalse, null };
/* 155:205 */         processExprent((Exprent)func.getLstOperands().get(2), varmaparrNeg, stat, calcLiveVars);
/* 156:    */         
/* 157:207 */         mergeMaps(varmaparr[0], varmaparrNeg[0]);
/* 158:208 */         varmaparr[1] = null;
/* 159:    */         
/* 160:210 */         finished = true;
/* 161:211 */         break;
/* 162:    */       case 48: 
/* 163:213 */         processExprent((Exprent)func.getLstOperands().get(0), varmaparr, stat, calcLiveVars);
/* 164:    */         
/* 165:215 */         SFormsFastMapDirect[] varmaparrAnd = { new SFormsFastMapDirect(varmaparr[0]), null };
/* 166:    */         
/* 167:217 */         processExprent((Exprent)func.getLstOperands().get(1), varmaparrAnd, stat, calcLiveVars);
/* 168:    */         
/* 169:    */ 
/* 170:220 */         varmaparr[1] = mergeMaps(varmaparr[1], varmaparrAnd[1]);
/* 171:    */         
/* 172:222 */         varmaparr[0] = varmaparrAnd[0];
/* 173:    */         
/* 174:224 */         finished = true;
/* 175:225 */         break;
/* 176:    */       case 49: 
/* 177:227 */         processExprent((Exprent)func.getLstOperands().get(0), varmaparr, stat, calcLiveVars);
/* 178:    */         
/* 179:229 */         SFormsFastMapDirect[] varmaparrOr = { new SFormsFastMapDirect(varmaparr[1]), null };
/* 180:    */         
/* 181:    */ 
/* 182:232 */         processExprent((Exprent)func.getLstOperands().get(1), varmaparrOr, stat, calcLiveVars);
/* 183:    */         
/* 184:    */ 
/* 185:235 */         varmaparr[1] = varmaparrOr[1];
/* 186:    */         
/* 187:237 */         varmaparr[0] = mergeMaps(varmaparr[0], varmaparrOr[0]);
/* 188:    */         
/* 189:239 */         finished = true;
/* 190:    */       }
/* 191:    */       break;
/* 192:    */     }
/* 193:243 */     if (!finished)
/* 194:    */     {
/* 195:244 */       List<Exprent> lst = expr.getAllExprents();
/* 196:245 */       lst.remove(varassign);
/* 197:247 */       for (Exprent ex : lst) {
/* 198:248 */         processExprent(ex, varmaparr, stat, calcLiveVars);
/* 199:    */       }
/* 200:    */     }
/* 201:253 */     SFormsFastMapDirect varmap = varmaparr[0];
/* 202:256 */     if (expr.type == 5)
/* 203:    */     {
/* 204:    */       int index;
/* 205:    */       int index;
/* 206:259 */       if (this.mapFieldVars.containsKey(Integer.valueOf(expr.id)))
/* 207:    */       {
/* 208:260 */         index = ((Integer)this.mapFieldVars.get(Integer.valueOf(expr.id))).intValue();
/* 209:    */       }
/* 210:    */       else
/* 211:    */       {
/* 212:263 */         index = this.fieldvarcounter--;
/* 213:264 */         this.mapFieldVars.put(Integer.valueOf(expr.id), Integer.valueOf(index));
/* 214:    */         
/* 215:    */ 
/* 216:267 */         this.ssuversions.createNode(new VarVersionPair(index, 1));
/* 217:    */       }
/* 218:270 */       setCurrentVar(varmap, Integer.valueOf(index), Integer.valueOf(1));
/* 219:    */     }
/* 220:272 */     else if ((expr.type == 8) || ((expr.type == 2) && (((AssignmentExprent)expr).getLeft().type == 5)) || ((expr.type == 10) && (((NewExprent)expr).getNewType().type == 8)) || (expr.type == 6))
/* 221:    */     {
/* 222:277 */       boolean ismmpp = true;
/* 223:279 */       if (expr.type == 6)
/* 224:    */       {
/* 225:281 */         ismmpp = false;
/* 226:    */         
/* 227:283 */         FunctionExprent fexpr = (FunctionExprent)expr;
/* 228:284 */         if ((fexpr.getFuncType() >= 32) && (fexpr.getFuncType() <= 35) && 
/* 229:285 */           (((Exprent)fexpr.getLstOperands().get(0)).type == 5)) {
/* 230:286 */           ismmpp = true;
/* 231:    */         }
/* 232:    */       }
/* 233:291 */       if (ismmpp) {
/* 234:292 */         varmap.removeAllFields();
/* 235:    */       }
/* 236:    */     }
/* 237:297 */     if (varassign != null)
/* 238:    */     {
/* 239:299 */       Integer varindex = Integer.valueOf(varassign.getIndex());
/* 240:301 */       if (varassign.getVersion() == 0)
/* 241:    */       {
/* 242:303 */         Integer nextver = getNextFreeVersion(varindex, stat);
/* 243:    */         
/* 244:    */ 
/* 245:306 */         varassign.setVersion(nextver.intValue());
/* 246:    */         
/* 247:    */ 
/* 248:309 */         this.ssuversions.createNode(new VarVersionPair(varindex, nextver));
/* 249:    */         
/* 250:311 */         setCurrentVar(varmap, varindex, nextver);
/* 251:    */       }
/* 252:    */       else
/* 253:    */       {
/* 254:314 */         if (calcLiveVars) {
/* 255:315 */           varMapToGraph(new VarVersionPair(varindex.intValue(), varassign.getVersion()), varmap);
/* 256:    */         }
/* 257:317 */         setCurrentVar(varmap, varindex, Integer.valueOf(varassign.getVersion()));
/* 258:    */       }
/* 259:    */     }
/* 260:320 */     else if (expr.type == 6)
/* 261:    */     {
/* 262:321 */       FunctionExprent func = (FunctionExprent)expr;
/* 263:323 */       switch (func.getFuncType())
/* 264:    */       {
/* 265:    */       case 32: 
/* 266:    */       case 33: 
/* 267:    */       case 34: 
/* 268:    */       case 35: 
/* 269:329 */         if (((Exprent)func.getLstOperands().get(0)).type == 12)
/* 270:    */         {
/* 271:330 */           VarExprent var = (VarExprent)func.getLstOperands().get(0);
/* 272:331 */           Integer varindex = Integer.valueOf(var.getIndex());
/* 273:332 */           VarVersionPair varpaar = new VarVersionPair(varindex.intValue(), var.getVersion());
/* 274:    */           
/* 275:    */ 
/* 276:335 */           VarVersionPair phantomver = (VarVersionPair)this.phantomppnodes.get(varpaar);
/* 277:336 */           if (phantomver == null)
/* 278:    */           {
/* 279:338 */             Integer nextver = getNextFreeVersion(varindex, null);
/* 280:339 */             phantomver = new VarVersionPair(varindex, nextver);
/* 281:    */             
/* 282:341 */             this.ssuversions.createNode(phantomver);
/* 283:    */             
/* 284:343 */             VarVersionNode vernode = (VarVersionNode)this.ssuversions.nodes.getWithKey(varpaar);
/* 285:    */             
/* 286:345 */             FastSparseSetFactory.FastSparseSet<Integer> vers = this.factory.spawnEmptySet();
/* 287:346 */             if (vernode.preds.size() == 1) {
/* 288:347 */               vers.add(Integer.valueOf(((VarVersionEdge)vernode.preds.iterator().next()).source.version));
/* 289:    */             } else {
/* 290:350 */               for (VarVersionEdge edge : vernode.preds) {
/* 291:351 */                 vers.add(Integer.valueOf(((VarVersionEdge)edge.source.preds.iterator().next()).source.version));
/* 292:    */               }
/* 293:    */             }
/* 294:354 */             vers.add(nextver);
/* 295:355 */             createOrUpdatePhiNode(varpaar, vers, stat);
/* 296:356 */             this.phantomppnodes.put(varpaar, phantomver);
/* 297:    */           }
/* 298:358 */           if (calcLiveVars) {
/* 299:359 */             varMapToGraph(varpaar, varmap);
/* 300:    */           }
/* 301:361 */           setCurrentVar(varmap, Integer.valueOf(varindex.intValue()), Integer.valueOf(var.getVersion()));
/* 302:    */         }
/* 303:    */         break;
/* 304:    */       }
/* 305:    */     }
/* 306:365 */     else if (expr.type == 12)
/* 307:    */     {
/* 308:367 */       VarExprent vardest = (VarExprent)expr;
/* 309:    */       
/* 310:369 */       Integer varindex = Integer.valueOf(vardest.getIndex());
/* 311:370 */       Integer current_vers = Integer.valueOf(vardest.getVersion());
/* 312:    */       
/* 313:372 */       FastSparseSetFactory.FastSparseSet<Integer> vers = varmap.get(varindex.intValue());
/* 314:    */       
/* 315:374 */       int cardinality = vers.getCardinality();
/* 316:375 */       if (cardinality == 1)
/* 317:    */       {
/* 318:376 */         if (current_vers.intValue() != 0)
/* 319:    */         {
/* 320:377 */           if (calcLiveVars) {
/* 321:378 */             varMapToGraph(new VarVersionPair(varindex, current_vers), varmap);
/* 322:    */           }
/* 323:380 */           setCurrentVar(varmap, varindex, current_vers);
/* 324:    */         }
/* 325:    */         else
/* 326:    */         {
/* 327:384 */           Integer usever = getNextFreeVersion(varindex, stat);
/* 328:    */           
/* 329:    */ 
/* 330:387 */           vardest.setVersion(usever.intValue());
/* 331:388 */           setCurrentVar(varmap, varindex, usever);
/* 332:    */           
/* 333:    */ 
/* 334:391 */           Integer lastver = (Integer)vers.iterator().next();
/* 335:392 */           VarVersionNode prenode = (VarVersionNode)this.ssuversions.nodes.getWithKey(new VarVersionPair(varindex, lastver));
/* 336:393 */           VarVersionNode usenode = this.ssuversions.createNode(new VarVersionPair(varindex, usever));
/* 337:394 */           VarVersionEdge edge = new VarVersionEdge(0, prenode, usenode);
/* 338:395 */           prenode.addSuccessor(edge);
/* 339:396 */           usenode.addPredecessor(edge);
/* 340:    */         }
/* 341:    */       }
/* 342:399 */       else if (cardinality == 2)
/* 343:    */       {
/* 344:401 */         if (current_vers.intValue() != 0)
/* 345:    */         {
/* 346:402 */           if (calcLiveVars) {
/* 347:403 */             varMapToGraph(new VarVersionPair(varindex, current_vers), varmap);
/* 348:    */           }
/* 349:405 */           setCurrentVar(varmap, varindex, current_vers);
/* 350:    */         }
/* 351:    */         else
/* 352:    */         {
/* 353:409 */           Integer usever = getNextFreeVersion(varindex, stat);
/* 354:    */           
/* 355:411 */           vardest.setVersion(usever.intValue());
/* 356:    */           
/* 357:    */ 
/* 358:414 */           this.ssuversions.createNode(new VarVersionPair(varindex, usever));
/* 359:    */           
/* 360:416 */           setCurrentVar(varmap, varindex, usever);
/* 361:    */           
/* 362:418 */           current_vers = usever;
/* 363:    */         }
/* 364:421 */         createOrUpdatePhiNode(new VarVersionPair(varindex, current_vers), vers, stat);
/* 365:    */       }
/* 366:    */     }
/* 367:    */   }
/* 368:    */   
/* 369:    */   private void createOrUpdatePhiNode(VarVersionPair phivar, FastSparseSetFactory.FastSparseSet<Integer> vers, Statement stat)
/* 370:    */   {
/* 371:428 */     FastSparseSetFactory.FastSparseSet<Integer> versCopy = vers.getCopy();
/* 372:429 */     HashSet<Integer> phiVers = new HashSet();
/* 373:    */     
/* 374:    */ 
/* 375:432 */     int ppvers = this.phantomppnodes.containsKey(phivar) ? ((VarVersionPair)this.phantomppnodes.get(phivar)).version : -1;
/* 376:    */     
/* 377:    */ 
/* 378:435 */     VarVersionNode phinode = (VarVersionNode)this.ssuversions.nodes.getWithKey(phivar);
/* 379:436 */     List<VarVersionEdge> lstPreds = new ArrayList(phinode.preds);
/* 380:437 */     if (lstPreds.size() == 1)
/* 381:    */     {
/* 382:439 */       VarVersionEdge edge = (VarVersionEdge)lstPreds.get(0);
/* 383:440 */       edge.source.removeSuccessor(edge);
/* 384:441 */       phinode.removePredecessor(edge);
/* 385:    */     }
/* 386:    */     else
/* 387:    */     {
/* 388:444 */       for (VarVersionEdge edge : lstPreds)
/* 389:    */       {
/* 390:445 */         int verssrc = ((VarVersionEdge)edge.source.preds.iterator().next()).source.version;
/* 391:446 */         if ((!vers.contains(Integer.valueOf(verssrc))) && (verssrc != ppvers))
/* 392:    */         {
/* 393:447 */           edge.source.removeSuccessor(edge);
/* 394:448 */           phinode.removePredecessor(edge);
/* 395:    */         }
/* 396:    */         else
/* 397:    */         {
/* 398:451 */           versCopy.remove(Integer.valueOf(verssrc));
/* 399:452 */           phiVers.add(Integer.valueOf(verssrc));
/* 400:    */         }
/* 401:    */       }
/* 402:    */     }
/* 403:457 */     List<VarVersionNode> colnodes = new ArrayList();
/* 404:458 */     List<VarVersionPair> colpaars = new ArrayList();
/* 405:460 */     for (Integer ver : versCopy)
/* 406:    */     {
/* 407:462 */       VarVersionNode prenode = (VarVersionNode)this.ssuversions.nodes.getWithKey(new VarVersionPair(phivar.var, ver.intValue()));
/* 408:    */       
/* 409:464 */       Integer tempver = getNextFreeVersion(Integer.valueOf(phivar.var), stat);
/* 410:    */       
/* 411:466 */       VarVersionNode tempnode = new VarVersionNode(phivar.var, tempver.intValue());
/* 412:    */       
/* 413:468 */       colnodes.add(tempnode);
/* 414:469 */       colpaars.add(new VarVersionPair(phivar.var, tempver.intValue()));
/* 415:    */       
/* 416:471 */       VarVersionEdge edge = new VarVersionEdge(0, prenode, tempnode);
/* 417:    */       
/* 418:473 */       prenode.addSuccessor(edge);
/* 419:474 */       tempnode.addPredecessor(edge);
/* 420:    */       
/* 421:    */ 
/* 422:477 */       edge = new VarVersionEdge(0, tempnode, phinode);
/* 423:478 */       tempnode.addSuccessor(edge);
/* 424:479 */       phinode.addPredecessor(edge);
/* 425:    */       
/* 426:481 */       phiVers.add(tempver);
/* 427:    */     }
/* 428:484 */     this.ssuversions.addNodes(colnodes, colpaars);
/* 429:    */     
/* 430:    */ 
/* 431:487 */     this.phi.put(phivar, phiVers);
/* 432:    */   }
/* 433:    */   
/* 434:    */   private void varMapToGraph(VarVersionPair varpaar, SFormsFastMapDirect varmap)
/* 435:    */   {
/* 436:492 */     VBStyleCollection<VarVersionNode, VarVersionPair> nodes = this.ssuversions.nodes;
/* 437:    */     
/* 438:494 */     VarVersionNode node = (VarVersionNode)nodes.getWithKey(varpaar);
/* 439:    */     
/* 440:496 */     node.live = new SFormsFastMapDirect(varmap);
/* 441:    */   }
/* 442:    */   
/* 443:    */   private Integer getNextFreeVersion(Integer var, Statement stat)
/* 444:    */   {
/* 445:501 */     Integer nextver = (Integer)this.lastversion.get(var);
/* 446:503 */     if (nextver == null) {
/* 447:504 */       nextver = new Integer(1);
/* 448:    */     } else {
/* 449:507 */       nextver = new Integer(nextver.intValue() + 1);
/* 450:    */     }
/* 451:509 */     this.lastversion.put(var, nextver);
/* 452:512 */     if (stat != null)
/* 453:    */     {
/* 454:513 */       Integer firstRangeId = getFirstProtectedRange(stat);
/* 455:514 */       if (firstRangeId != null) {
/* 456:515 */         this.mapVersionFirstRange.put(new VarVersionPair(var, nextver), firstRangeId);
/* 457:    */       }
/* 458:    */     }
/* 459:519 */     return nextver;
/* 460:    */   }
/* 461:    */   
/* 462:    */   private void mergeInVarMaps(DirectNode node, DirectGraph dgraph)
/* 463:    */   {
/* 464:525 */     SFormsFastMapDirect mapNew = new SFormsFastMapDirect();
/* 465:527 */     for (DirectNode pred : node.preds)
/* 466:    */     {
/* 467:528 */       SFormsFastMapDirect mapOut = getFilteredOutMap(node.id, pred.id, dgraph, node.id);
/* 468:529 */       if (mapNew.isEmpty()) {
/* 469:530 */         mapNew = mapOut.getCopy();
/* 470:    */       } else {
/* 471:533 */         mergeMaps(mapNew, mapOut);
/* 472:    */       }
/* 473:    */     }
/* 474:537 */     if (this.extraVarVersions.containsKey(node.id))
/* 475:    */     {
/* 476:538 */       SFormsFastMapDirect mapExtra = (SFormsFastMapDirect)this.extraVarVersions.get(node.id);
/* 477:539 */       if (mapNew.isEmpty()) {
/* 478:540 */         mapNew = mapExtra.getCopy();
/* 479:    */       } else {
/* 480:543 */         mergeMaps(mapNew, mapExtra);
/* 481:    */       }
/* 482:    */     }
/* 483:547 */     this.inVarVersions.put(node.id, mapNew);
/* 484:    */   }
/* 485:    */   
/* 486:    */   private SFormsFastMapDirect getFilteredOutMap(String nodeid, String predid, DirectGraph dgraph, String destid)
/* 487:    */   {
/* 488:552 */     SFormsFastMapDirect mapNew = new SFormsFastMapDirect();
/* 489:    */     
/* 490:554 */     boolean isFinallyExit = dgraph.mapShortRangeFinallyPaths.containsKey(predid);
/* 491:556 */     if (nodeid.equals(dgraph.mapNegIfBranch.get(predid)))
/* 492:    */     {
/* 493:557 */       if (this.outNegVarVersions.containsKey(predid)) {
/* 494:558 */         mapNew = ((SFormsFastMapDirect)this.outNegVarVersions.get(predid)).getCopy();
/* 495:    */       }
/* 496:    */     }
/* 497:561 */     else if (this.outVarVersions.containsKey(predid)) {
/* 498:562 */       mapNew = ((SFormsFastMapDirect)this.outVarVersions.get(predid)).getCopy();
/* 499:    */     }
/* 500:565 */     if (isFinallyExit)
/* 501:    */     {
/* 502:567 */       SFormsFastMapDirect mapNewTemp = mapNew.getCopy();
/* 503:    */       
/* 504:569 */       SFormsFastMapDirect mapTrueSource = new SFormsFastMapDirect();
/* 505:    */       
/* 506:571 */       String exceptionDest = (String)dgraph.mapFinallyMonitorExceptionPathExits.get(predid);
/* 507:572 */       boolean isExceptionMonitorExit = (exceptionDest != null) && (!nodeid.equals(exceptionDest));
/* 508:    */       
/* 509:574 */       HashSet<String> setLongPathWrapper = new HashSet();
/* 510:575 */       for (List<FlattenStatementsHelper.FinallyPathWrapper> lstwrapper : dgraph.mapLongRangeFinallyPaths.values()) {
/* 511:576 */         for (FlattenStatementsHelper.FinallyPathWrapper finwraplong : lstwrapper) {
/* 512:577 */           setLongPathWrapper.add(finwraplong.destination + "##" + finwraplong.source);
/* 513:    */         }
/* 514:    */       }
/* 515:581 */       for (FlattenStatementsHelper.FinallyPathWrapper finwrap : (List)dgraph.mapShortRangeFinallyPaths.get(predid))
/* 516:    */       {
/* 517:584 */         boolean recFinally = dgraph.mapShortRangeFinallyPaths.containsKey(finwrap.source);
/* 518:    */         SFormsFastMapDirect map;
/* 519:    */         SFormsFastMapDirect map;
/* 520:586 */         if (recFinally)
/* 521:    */         {
/* 522:588 */           map = getFilteredOutMap(finwrap.entry, finwrap.source, dgraph, destid);
/* 523:    */         }
/* 524:    */         else
/* 525:    */         {
/* 526:    */           SFormsFastMapDirect map;
/* 527:591 */           if (finwrap.entry.equals(dgraph.mapNegIfBranch.get(finwrap.source))) {
/* 528:592 */             map = (SFormsFastMapDirect)this.outNegVarVersions.get(finwrap.source);
/* 529:    */           } else {
/* 530:595 */             map = (SFormsFastMapDirect)this.outVarVersions.get(finwrap.source);
/* 531:    */           }
/* 532:    */         }
/* 533:600 */         boolean isFalsePath = true;
/* 534:602 */         if (recFinally) {
/* 535:603 */           isFalsePath = !finwrap.destination.equals(nodeid);
/* 536:    */         } else {
/* 537:606 */           isFalsePath = !setLongPathWrapper.contains(destid + "##" + finwrap.source);
/* 538:    */         }
/* 539:609 */         if (isFalsePath) {
/* 540:610 */           mapNewTemp.complement(map);
/* 541:613 */         } else if (mapTrueSource.isEmpty())
/* 542:    */         {
/* 543:614 */           if (map != null) {
/* 544:615 */             mapTrueSource = map.getCopy();
/* 545:    */           }
/* 546:    */         }
/* 547:    */         else {
/* 548:619 */           mergeMaps(mapTrueSource, map);
/* 549:    */         }
/* 550:    */       }
/* 551:624 */       if (isExceptionMonitorExit)
/* 552:    */       {
/* 553:626 */         mapNew = mapTrueSource;
/* 554:    */       }
/* 555:    */       else
/* 556:    */       {
/* 557:630 */         mapNewTemp.union(mapTrueSource);
/* 558:631 */         mapNew.intersection(mapNewTemp);
/* 559:633 */         if ((!mapTrueSource.isEmpty()) && (!mapNew.isEmpty()))
/* 560:    */         {
/* 561:636 */           HashMap<VarVersionPair, VarVersionPair> mapPhantom = (HashMap)this.phantomexitnodes.get(predid);
/* 562:637 */           if (mapPhantom == null) {
/* 563:638 */             mapPhantom = new HashMap();
/* 564:    */           }
/* 565:641 */           SFormsFastMapDirect mapExitVar = mapNew.getCopy();
/* 566:642 */           mapExitVar.complement(mapTrueSource);
/* 567:644 */           for (Iterator i$ = mapExitVar.entryList().iterator(); i$.hasNext();)
/* 568:    */           {
/* 569:644 */             ent = (Map.Entry)i$.next();
/* 570:645 */             for (Integer version : (FastSparseSetFactory.FastSparseSet)ent.getValue())
/* 571:    */             {
/* 572:647 */               Integer varindex = (Integer)ent.getKey();
/* 573:648 */               VarVersionPair exitvar = new VarVersionPair(varindex, version);
/* 574:649 */               FastSparseSetFactory.FastSparseSet<Integer> newSet = mapNew.get(varindex.intValue());
/* 575:    */               
/* 576:    */ 
/* 577:652 */               newSet.remove(version);
/* 578:    */               
/* 579:    */ 
/* 580:655 */               VarVersionPair phantomvar = (VarVersionPair)mapPhantom.get(exitvar);
/* 581:656 */               if (phantomvar == null)
/* 582:    */               {
/* 583:657 */                 Integer newversion = getNextFreeVersion(Integer.valueOf(exitvar.var), null);
/* 584:658 */                 phantomvar = new VarVersionPair(exitvar.var, newversion.intValue());
/* 585:    */                 
/* 586:660 */                 VarVersionNode exitnode = (VarVersionNode)this.ssuversions.nodes.getWithKey(exitvar);
/* 587:661 */                 VarVersionNode phantomnode = this.ssuversions.createNode(phantomvar);
/* 588:662 */                 phantomnode.flags |= 0x2;
/* 589:    */                 
/* 590:664 */                 VarVersionEdge edge = new VarVersionEdge(1, exitnode, phantomnode);
/* 591:665 */                 exitnode.addSuccessor(edge);
/* 592:666 */                 phantomnode.addPredecessor(edge);
/* 593:    */                 
/* 594:668 */                 mapPhantom.put(exitvar, phantomvar);
/* 595:    */               }
/* 596:672 */               newSet.add(Integer.valueOf(phantomvar.version));
/* 597:    */             }
/* 598:    */           }
/* 599:    */           Map.Entry<Integer, FastSparseSetFactory.FastSparseSet<Integer>> ent;
/* 600:676 */           if (!mapPhantom.isEmpty()) {
/* 601:677 */             this.phantomexitnodes.put(predid, mapPhantom);
/* 602:    */           }
/* 603:    */         }
/* 604:    */       }
/* 605:    */     }
/* 606:683 */     return mapNew;
/* 607:    */   }
/* 608:    */   
/* 609:    */   private static SFormsFastMapDirect mergeMaps(SFormsFastMapDirect mapTo, SFormsFastMapDirect map2)
/* 610:    */   {
/* 611:688 */     if ((map2 != null) && (!map2.isEmpty())) {
/* 612:689 */       mapTo.union(map2);
/* 613:    */     }
/* 614:692 */     return mapTo;
/* 615:    */   }
/* 616:    */   
/* 617:    */   private static boolean mapsEqual(SFormsFastMapDirect map1, SFormsFastMapDirect map2)
/* 618:    */   {
/* 619:697 */     if (map1 == null) {
/* 620:698 */       return map2 == null;
/* 621:    */     }
/* 622:700 */     if (map2 == null) {
/* 623:701 */       return false;
/* 624:    */     }
/* 625:704 */     if (map1.size() != map2.size()) {
/* 626:705 */       return false;
/* 627:    */     }
/* 628:708 */     for (Map.Entry<Integer, FastSparseSetFactory.FastSparseSet<Integer>> ent2 : map2.entryList()) {
/* 629:709 */       if (!InterpreterUtil.equalObjects(map1.get(((Integer)ent2.getKey()).intValue()), ent2.getValue())) {
/* 630:710 */         return false;
/* 631:    */       }
/* 632:    */     }
/* 633:714 */     return true;
/* 634:    */   }
/* 635:    */   
/* 636:    */   private void setCurrentVar(SFormsFastMapDirect varmap, Integer var, Integer vers)
/* 637:    */   {
/* 638:719 */     FastSparseSetFactory.FastSparseSet<Integer> set = this.factory.spawnEmptySet();
/* 639:720 */     set.add(vers);
/* 640:721 */     varmap.put(var.intValue(), set);
/* 641:    */   }
/* 642:    */   
/* 643:    */   private void setCatchMaps(Statement stat, DirectGraph dgraph, FlattenStatementsHelper flatthelper)
/* 644:    */   {
/* 645:728 */     switch (stat.type)
/* 646:    */     {
/* 647:    */     case 7: 
/* 648:    */     case 12: 
/* 649:    */       List<VarExprent> lstVars;
/* 650:    */       List<VarExprent> lstVars;
/* 651:733 */       if (stat.type == 12) {
/* 652:734 */         lstVars = ((CatchAllStatement)stat).getVars();
/* 653:    */       } else {
/* 654:737 */         lstVars = ((CatchStatement)stat).getVars();
/* 655:    */       }
/* 656:740 */       for (int i = 1; i < stat.getStats().size(); i++)
/* 657:    */       {
/* 658:741 */         int varindex = ((VarExprent)lstVars.get(i - 1)).getIndex();
/* 659:742 */         int version = getNextFreeVersion(Integer.valueOf(varindex), stat).intValue();
/* 660:    */         
/* 661:744 */         SFormsFastMapDirect map = new SFormsFastMapDirect();
/* 662:745 */         setCurrentVar(map, Integer.valueOf(varindex), Integer.valueOf(version));
/* 663:    */         
/* 664:747 */         this.extraVarVersions.put(((DirectNode)dgraph.nodes.getWithKey(((String[])flatthelper.getMapDestinationNodes().get(((Statement)stat.getStats().get(i)).id))[0])).id, map);
/* 665:    */         
/* 666:749 */         this.ssuversions.createNode(new VarVersionPair(varindex, version));
/* 667:    */       }
/* 668:    */     }
/* 669:753 */     for (Statement st : stat.getStats()) {
/* 670:754 */       setCatchMaps(st, dgraph, flatthelper);
/* 671:    */     }
/* 672:    */   }
/* 673:    */   
/* 674:    */   private SFormsFastMapDirect createFirstMap(StructMethod mt, RootStatement root)
/* 675:    */   {
/* 676:759 */     boolean thisvar = !mt.hasModifier(8);
/* 677:    */     
/* 678:761 */     MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/* 679:    */     
/* 680:763 */     int paramcount = md.params.length + (thisvar ? 1 : 0);
/* 681:    */     
/* 682:765 */     int varindex = 0;
/* 683:766 */     SFormsFastMapDirect map = new SFormsFastMapDirect();
/* 684:767 */     for (int i = 0; i < paramcount; i++)
/* 685:    */     {
/* 686:768 */       int version = getNextFreeVersion(Integer.valueOf(varindex), root).intValue();
/* 687:    */       
/* 688:770 */       FastSparseSetFactory.FastSparseSet<Integer> set = this.factory.spawnEmptySet();
/* 689:771 */       set.add(Integer.valueOf(version));
/* 690:772 */       map.put(varindex, set);
/* 691:773 */       this.ssuversions.createNode(new VarVersionPair(varindex, version));
/* 692:775 */       if (thisvar)
/* 693:    */       {
/* 694:776 */         if (i == 0) {
/* 695:777 */           varindex++;
/* 696:    */         } else {
/* 697:780 */           varindex += md.params[(i - 1)].stackSize;
/* 698:    */         }
/* 699:    */       }
/* 700:    */       else {
/* 701:784 */         varindex += md.params[i].stackSize;
/* 702:    */       }
/* 703:    */     }
/* 704:788 */     return map;
/* 705:    */   }
/* 706:    */   
/* 707:    */   private static Integer getFirstProtectedRange(Statement stat)
/* 708:    */   {
/* 709:    */     for (;;)
/* 710:    */     {
/* 711:794 */       Statement parent = stat.getParent();
/* 712:796 */       if (parent == null) {
/* 713:    */         break;
/* 714:    */       }
/* 715:800 */       if ((parent.type == 12) || (parent.type == 7))
/* 716:    */       {
/* 717:802 */         if (parent.getFirst() == stat) {
/* 718:803 */           return parent.id;
/* 719:    */         }
/* 720:    */       }
/* 721:806 */       else if ((parent.type == 10) && 
/* 722:807 */         (((SynchronizedStatement)parent).getBody() == stat)) {
/* 723:808 */         return parent.id;
/* 724:    */       }
/* 725:812 */       stat = parent;
/* 726:    */     }
/* 727:815 */     return null;
/* 728:    */   }
/* 729:    */   
/* 730:    */   public HashMap<VarVersionPair, HashSet<Integer>> getPhi()
/* 731:    */   {
/* 732:819 */     return this.phi;
/* 733:    */   }
/* 734:    */   
/* 735:    */   public VarVersionsGraph getSsuversions()
/* 736:    */   {
/* 737:823 */     return this.ssuversions;
/* 738:    */   }
/* 739:    */   
/* 740:    */   public SFormsFastMapDirect getLiveVarVersionsMap(VarVersionPair varpaar)
/* 741:    */   {
/* 742:829 */     VarVersionNode node = (VarVersionNode)this.ssuversions.nodes.getWithKey(varpaar);
/* 743:830 */     if (node != null) {
/* 744:831 */       return node.live;
/* 745:    */     }
/* 746:834 */     return null;
/* 747:    */   }
/* 748:    */   
/* 749:    */   public HashMap<VarVersionPair, Integer> getMapVersionFirstRange()
/* 750:    */   {
/* 751:838 */     return this.mapVersionFirstRange;
/* 752:    */   }
/* 753:    */   
/* 754:    */   public HashMap<Integer, Integer> getMapFieldVars()
/* 755:    */   {
/* 756:842 */     return this.mapFieldVars;
/* 757:    */   }
/* 758:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAUConstructorSparseEx
 * JD-Core Version:    0.7.0.1
 */