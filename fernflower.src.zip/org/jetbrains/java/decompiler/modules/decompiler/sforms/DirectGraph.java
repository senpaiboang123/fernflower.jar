/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.sforms;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.LinkedList;
/*   6:    */ import java.util.List;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*   8:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*   9:    */ 
/*  10:    */ public class DirectGraph
/*  11:    */ {
/*  12:    */   public final VBStyleCollection<DirectNode, String> nodes;
/*  13:    */   public DirectNode first;
/*  14:    */   public final HashMap<String, List<FlattenStatementsHelper.FinallyPathWrapper>> mapShortRangeFinallyPaths;
/*  15:    */   public final HashMap<String, List<FlattenStatementsHelper.FinallyPathWrapper>> mapLongRangeFinallyPaths;
/*  16:    */   public final HashMap<String, String> mapNegIfBranch;
/*  17:    */   public final HashMap<String, String> mapFinallyMonitorExceptionPathExits;
/*  18:    */   
/*  19:    */   public DirectGraph()
/*  20:    */   {
/*  21: 30 */     this.nodes = new VBStyleCollection();
/*  22:    */     
/*  23:    */ 
/*  24:    */ 
/*  25:    */ 
/*  26: 35 */     this.mapShortRangeFinallyPaths = new HashMap();
/*  27:    */     
/*  28:    */ 
/*  29: 38 */     this.mapLongRangeFinallyPaths = new HashMap();
/*  30:    */     
/*  31:    */ 
/*  32: 41 */     this.mapNegIfBranch = new HashMap();
/*  33:    */     
/*  34:    */ 
/*  35: 44 */     this.mapFinallyMonitorExceptionPathExits = new HashMap();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void sortReversePostOrder()
/*  39:    */   {
/*  40: 47 */     LinkedList<DirectNode> res = new LinkedList();
/*  41: 48 */     addToReversePostOrderListIterative(this.first, res);
/*  42:    */     
/*  43: 50 */     this.nodes.clear();
/*  44: 51 */     for (DirectNode node : res) {
/*  45: 52 */       this.nodes.addWithKey(node, node.id);
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   private static void addToReversePostOrderListIterative(DirectNode root, List<DirectNode> lst)
/*  50:    */   {
/*  51: 58 */     LinkedList<DirectNode> stackNode = new LinkedList();
/*  52: 59 */     LinkedList<Integer> stackIndex = new LinkedList();
/*  53:    */     
/*  54: 61 */     HashSet<DirectNode> setVisited = new HashSet();
/*  55:    */     
/*  56: 63 */     stackNode.add(root);
/*  57: 64 */     stackIndex.add(Integer.valueOf(0));
/*  58: 66 */     while (!stackNode.isEmpty())
/*  59:    */     {
/*  60: 68 */       DirectNode node = (DirectNode)stackNode.getLast();
/*  61: 69 */       int index = ((Integer)stackIndex.removeLast()).intValue();
/*  62:    */       
/*  63: 71 */       setVisited.add(node);
/*  64: 73 */       for (; index < node.succs.size(); index++)
/*  65:    */       {
/*  66: 74 */         DirectNode succ = (DirectNode)node.succs.get(index);
/*  67: 76 */         if (!setVisited.contains(succ))
/*  68:    */         {
/*  69: 77 */           stackIndex.add(Integer.valueOf(index + 1));
/*  70:    */           
/*  71: 79 */           stackNode.add(succ);
/*  72: 80 */           stackIndex.add(Integer.valueOf(0));
/*  73:    */           
/*  74: 82 */           break;
/*  75:    */         }
/*  76:    */       }
/*  77: 86 */       if (index == node.succs.size())
/*  78:    */       {
/*  79: 87 */         lst.add(0, node);
/*  80:    */         
/*  81: 89 */         stackNode.removeLast();
/*  82:    */       }
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean iterateExprents(ExprentIterator iter)
/*  87:    */   {
/*  88: 97 */     LinkedList<DirectNode> stack = new LinkedList();
/*  89: 98 */     stack.add(this.first);
/*  90:    */     
/*  91:100 */     HashSet<DirectNode> setVisited = new HashSet();
/*  92:102 */     while (!stack.isEmpty())
/*  93:    */     {
/*  94:104 */       DirectNode node = (DirectNode)stack.removeFirst();
/*  95:106 */       if (!setVisited.contains(node))
/*  96:    */       {
/*  97:109 */         setVisited.add(node);
/*  98:111 */         for (int i = 0; i < node.exprents.size(); i++)
/*  99:    */         {
/* 100:112 */           int res = iter.processExprent((Exprent)node.exprents.get(i));
/* 101:114 */           if (res == 1) {
/* 102:115 */             return false;
/* 103:    */           }
/* 104:118 */           if (res == 2)
/* 105:    */           {
/* 106:119 */             node.exprents.remove(i);
/* 107:120 */             i--;
/* 108:    */           }
/* 109:    */         }
/* 110:124 */         stack.addAll(node.succs);
/* 111:    */       }
/* 112:    */     }
/* 113:127 */     return true;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static abstract interface ExprentIterator
/* 117:    */   {
/* 118:    */     public abstract int processExprent(Exprent paramExprent);
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph
 * JD-Core Version:    0.7.0.1
 */