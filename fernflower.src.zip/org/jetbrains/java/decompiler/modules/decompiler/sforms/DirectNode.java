/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler.sforms;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  6:   */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  7:   */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  8:   */ 
/*  9:   */ public class DirectNode
/* 10:   */ {
/* 11:   */   public static final int NODE_DIRECT = 1;
/* 12:   */   public static final int NODE_TAIL = 2;
/* 13:   */   public static final int NODE_INIT = 3;
/* 14:   */   public static final int NODE_CONDITION = 4;
/* 15:   */   public static final int NODE_INCREMENT = 5;
/* 16:   */   public static final int NODE_TRY = 6;
/* 17:   */   public final int type;
/* 18:   */   public final String id;
/* 19:   */   public BasicBlockStatement block;
/* 20:   */   public final Statement statement;
/* 21:43 */   public List<Exprent> exprents = new ArrayList();
/* 22:45 */   public final List<DirectNode> succs = new ArrayList();
/* 23:47 */   public final List<DirectNode> preds = new ArrayList();
/* 24:   */   
/* 25:   */   public DirectNode(int type, Statement statement, String id)
/* 26:   */   {
/* 27:50 */     this.type = type;
/* 28:51 */     this.statement = statement;
/* 29:52 */     this.id = id;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public DirectNode(int type, Statement statement, BasicBlockStatement block)
/* 33:   */   {
/* 34:56 */     this.type = type;
/* 35:57 */     this.statement = statement;
/* 36:   */     
/* 37:59 */     this.id = block.id.toString();
/* 38:60 */     this.block = block;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String toString()
/* 42:   */   {
/* 43:65 */     return this.id;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectNode
 * JD-Core Version:    0.7.0.1
 */