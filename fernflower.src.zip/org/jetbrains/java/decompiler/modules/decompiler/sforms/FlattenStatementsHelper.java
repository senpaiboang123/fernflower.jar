/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.sforms;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.LinkedList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.StatEdge;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchAllStatement;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SwitchStatement;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SynchronizedStatement;
/*  20:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  21:    */ 
/*  22:    */ public class FlattenStatementsHelper
/*  23:    */ {
/*  24:    */   private final Map<Integer, String[]> mapDestinationNodes;
/*  25:    */   private final List<Edge> listEdges;
/*  26:    */   private final Map<String, List<String[]>> mapShortRangeFinallyPathIds;
/*  27:    */   private final Map<String, List<String[]>> mapLongRangeFinallyPathIds;
/*  28:    */   private final Map<String, Integer> mapPosIfBranch;
/*  29:    */   private DirectGraph graph;
/*  30:    */   private RootStatement root;
/*  31:    */   
/*  32:    */   public FlattenStatementsHelper()
/*  33:    */   {
/*  34: 29 */     this.mapDestinationNodes = new HashMap();
/*  35:    */     
/*  36:    */ 
/*  37: 32 */     this.listEdges = new ArrayList();
/*  38:    */     
/*  39:    */ 
/*  40: 35 */     this.mapShortRangeFinallyPathIds = new HashMap();
/*  41:    */     
/*  42:    */ 
/*  43: 38 */     this.mapLongRangeFinallyPathIds = new HashMap();
/*  44:    */     
/*  45:    */ 
/*  46: 41 */     this.mapPosIfBranch = new HashMap();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public DirectGraph buildDirectGraph(RootStatement root)
/*  50:    */   {
/*  51: 49 */     this.root = root;
/*  52:    */     
/*  53: 51 */     this.graph = new DirectGraph();
/*  54:    */     
/*  55: 53 */     flattenStatement();
/*  56:    */     
/*  57:    */ 
/*  58: 56 */     Statement dummyexit = root.getDummyExit();
/*  59: 57 */     DirectNode node = new DirectNode(1, dummyexit, dummyexit.id.toString());
/*  60: 58 */     node.exprents = new ArrayList();
/*  61: 59 */     this.graph.nodes.addWithKey(node, node.id);
/*  62: 60 */     this.mapDestinationNodes.put(dummyexit.id, new String[] { node.id, null });
/*  63:    */     
/*  64: 62 */     setEdges();
/*  65:    */     
/*  66: 64 */     this.graph.first = ((DirectNode)this.graph.nodes.getWithKey(((String[])this.mapDestinationNodes.get(root.id))[0]));
/*  67: 65 */     this.graph.sortReversePostOrder();
/*  68:    */     
/*  69: 67 */     return this.graph;
/*  70:    */   }
/*  71:    */   
/*  72:    */   private void flattenStatement()
/*  73:    */   {
/*  74: 88 */     LinkedList<1StatementStackEntry> lstStackStatements = new LinkedList();
/*  75:    */     
/*  76: 90 */     lstStackStatements.add(new Object()
/*  77:    */     {
/*  78:    */       public Statement statement;
/*  79:    */       public LinkedList<FlattenStatementsHelper.StackEntry> stackFinally;
/*  80:    */       public List<Exprent> tailExprents;
/*  81:    */       public int statementIndex;
/*  82:    */       public int edgeIndex;
/*  83:    */       public List<StatEdge> succEdges;
/*  84:    */     });
/*  85:    */     label2488:
/*  86:    */     label2494:
/*  87: 93 */     while (!lstStackStatements.isEmpty())
/*  88:    */     {
/*  89: 95 */       Object statEntry = (1StatementStackEntry)lstStackStatements.removeFirst();
/*  90:    */       
/*  91: 97 */       Statement stat = statEntry.statement;
/*  92: 98 */       LinkedList<StackEntry> stackFinally = statEntry.stackFinally;
/*  93: 99 */       int statementBreakIndex = statEntry.statementIndex;
/*  94:    */       
/*  95:    */ 
/*  96:    */ 
/*  97:103 */       List<StatEdge> lstSuccEdges = new ArrayList();
/*  98:104 */       DirectNode sourcenode = null;
/*  99:106 */       if (statEntry.succEdges == null)
/* 100:    */       {
/* 101:    */         DirectNode node;
/* 102:108 */         switch (stat.type)
/* 103:    */         {
/* 104:    */         case 8: 
/* 105:110 */           node = new DirectNode(1, stat, (BasicBlockStatement)stat);
/* 106:111 */           if (stat.getExprents() != null) {
/* 107:112 */             node.exprents = stat.getExprents();
/* 108:    */           }
/* 109:114 */           this.graph.nodes.putWithKey(node, node.id);
/* 110:115 */           this.mapDestinationNodes.put(stat.id, new String[] { node.id, null });
/* 111:    */           
/* 112:117 */           lstSuccEdges.addAll(stat.getSuccessorEdges(1073741824));
/* 113:118 */           sourcenode = node;
/* 114:    */           
/* 115:120 */           List<Exprent> tailExprentList = statEntry.tailExprents;
/* 116:122 */           if (tailExprentList != null)
/* 117:    */           {
/* 118:123 */             DirectNode tail = new DirectNode(2, stat, stat.id + "_tail");
/* 119:124 */             tail.exprents = tailExprentList;
/* 120:125 */             this.graph.nodes.putWithKey(tail, tail.id);
/* 121:    */             
/* 122:127 */             this.mapDestinationNodes.put(Integer.valueOf(-stat.id.intValue()), new String[] { tail.id, null });
/* 123:128 */             this.listEdges.add(new Edge(node.id, Integer.valueOf(-stat.id.intValue()), 1));
/* 124:    */             
/* 125:130 */             sourcenode = tail;
/* 126:    */           }
/* 127:134 */           if (stat.getLastBasicType() == 0) {
/* 128:135 */             this.mapPosIfBranch.put(sourcenode.id, ((StatEdge)lstSuccEdges.get(0)).getDestination().id);
/* 129:    */           }
/* 130:    */           break;
/* 131:    */         case 7: 
/* 132:    */         case 12: 
/* 133:141 */           DirectNode firstnd = new DirectNode(6, stat, stat.id + "_try");
/* 134:    */           
/* 135:143 */           this.mapDestinationNodes.put(stat.id, new String[] { firstnd.id, null });
/* 136:144 */           this.graph.nodes.putWithKey(firstnd, firstnd.id);
/* 137:    */           
/* 138:146 */           LinkedList<1StatementStackEntry> lst = new LinkedList();
/* 139:148 */           for (Statement st : stat.getStats())
/* 140:    */           {
/* 141:149 */             this.listEdges.add(new Edge(firstnd.id, st.id, 1));
/* 142:    */             
/* 143:151 */             LinkedList<StackEntry> stack = stackFinally;
/* 144:152 */             if ((stat.type == 12) && (((CatchAllStatement)stat).isFinally()))
/* 145:    */             {
/* 146:153 */               stack = new LinkedList(stackFinally);
/* 147:155 */               if (st == stat.getFirst()) {
/* 148:156 */                 stack.add(new StackEntry((CatchAllStatement)stat, Boolean.FALSE.booleanValue()));
/* 149:    */               } else {
/* 150:159 */                 stack.add(new StackEntry((CatchAllStatement)stat, Boolean.TRUE.booleanValue(), 4, this.root.getDummyExit(), st, st, firstnd, firstnd, true));
/* 151:    */               }
/* 152:    */             }
/* 153:163 */             lst.add(new Object()
/* 154:    */             {
/* 155:    */               public Statement statement;
/* 156:    */               public LinkedList<FlattenStatementsHelper.StackEntry> stackFinally;
/* 157:    */               public List<Exprent> tailExprents;
/* 158:    */               public int statementIndex;
/* 159:    */               public int edgeIndex;
/* 160:    */               public List<StatEdge> succEdges;
/* 161:    */             });
/* 162:    */           }
/* 163:166 */           lstStackStatements.addAll(0, lst);
/* 164:167 */           break;
/* 165:    */         case 5: 
/* 166:169 */           if (statementBreakIndex == 0)
/* 167:    */           {
/* 168:170 */             statEntry.statementIndex = 1;
/* 169:171 */             lstStackStatements.addFirst(statEntry);
/* 170:172 */             lstStackStatements.addFirst(new Object()
/* 171:    */             {
/* 172:    */               public Statement statement;
/* 173:    */               public LinkedList<FlattenStatementsHelper.StackEntry> stackFinally;
/* 174:    */               public List<Exprent> tailExprents;
/* 175:    */               public int statementIndex;
/* 176:    */               public int edgeIndex;
/* 177:    */               public List<StatEdge> succEdges;
/* 178:173 */             });
/* 179:174 */             continue;
/* 180:    */           }
/* 181:177 */           DirectNode nd = (DirectNode)this.graph.nodes.getWithKey(((String[])this.mapDestinationNodes.get(stat.getFirst().id))[0]);
/* 182:    */           
/* 183:179 */           DoStatement dostat = (DoStatement)stat;
/* 184:180 */           int looptype = dostat.getLooptype();
/* 185:182 */           if (looptype == 0)
/* 186:    */           {
/* 187:183 */             this.mapDestinationNodes.put(stat.id, new String[] { nd.id, nd.id });
/* 188:    */           }
/* 189:    */           else
/* 190:    */           {
/* 191:187 */             lstSuccEdges.add(stat.getSuccessorEdges(1073741824).get(0));
/* 192:189 */             switch (looptype)
/* 193:    */             {
/* 194:    */             case 1: 
/* 195:    */             case 2: 
/* 196:192 */               node = new DirectNode(4, stat, stat.id + "_cond");
/* 197:193 */               node.exprents = dostat.getConditionExprentList();
/* 198:194 */               this.graph.nodes.putWithKey(node, node.id);
/* 199:    */               
/* 200:196 */               this.listEdges.add(new Edge(node.id, stat.getFirst().id, 1));
/* 201:198 */               if (looptype == 2)
/* 202:    */               {
/* 203:199 */                 this.mapDestinationNodes.put(stat.id, new String[] { node.id, node.id });
/* 204:    */               }
/* 205:    */               else
/* 206:    */               {
/* 207:202 */                 this.mapDestinationNodes.put(stat.id, new String[] { nd.id, node.id });
/* 208:    */                 
/* 209:204 */                 boolean found = false;
/* 210:205 */                 for (Edge edge : this.listEdges) {
/* 211:206 */                   if ((edge.statid.equals(stat.id)) && (edge.edgetype == 8))
/* 212:    */                   {
/* 213:207 */                     found = true;
/* 214:208 */                     break;
/* 215:    */                   }
/* 216:    */                 }
/* 217:211 */                 if (!found) {
/* 218:212 */                   this.listEdges.add(new Edge(nd.id, stat.id, 8));
/* 219:    */                 }
/* 220:    */               }
/* 221:215 */               sourcenode = node;
/* 222:216 */               break;
/* 223:    */             case 3: 
/* 224:218 */               DirectNode nodeinit = new DirectNode(3, stat, stat.id + "_init");
/* 225:219 */               if (dostat.getInitExprent() != null) {
/* 226:220 */                 nodeinit.exprents = dostat.getInitExprentList();
/* 227:    */               }
/* 228:222 */               this.graph.nodes.putWithKey(nodeinit, nodeinit.id);
/* 229:    */               
/* 230:224 */               DirectNode nodecond = new DirectNode(4, stat, stat.id + "_cond");
/* 231:225 */               nodecond.exprents = dostat.getConditionExprentList();
/* 232:226 */               this.graph.nodes.putWithKey(nodecond, nodecond.id);
/* 233:    */               
/* 234:228 */               DirectNode nodeinc = new DirectNode(5, stat, stat.id + "_inc");
/* 235:229 */               nodeinc.exprents = dostat.getIncExprentList();
/* 236:230 */               this.graph.nodes.putWithKey(nodeinc, nodeinc.id);
/* 237:    */               
/* 238:232 */               this.mapDestinationNodes.put(stat.id, new String[] { nodeinit.id, nodeinc.id });
/* 239:233 */               this.mapDestinationNodes.put(Integer.valueOf(-stat.id.intValue()), new String[] { nodecond.id, null });
/* 240:    */               
/* 241:235 */               this.listEdges.add(new Edge(nodecond.id, stat.getFirst().id, 1));
/* 242:236 */               this.listEdges.add(new Edge(nodeinit.id, Integer.valueOf(-stat.id.intValue()), 1));
/* 243:237 */               this.listEdges.add(new Edge(nodeinc.id, Integer.valueOf(-stat.id.intValue()), 1));
/* 244:    */               
/* 245:239 */               boolean found = false;
/* 246:240 */               for (Edge edge : this.listEdges) {
/* 247:241 */                 if ((edge.statid.equals(stat.id)) && (edge.edgetype == 8))
/* 248:    */                 {
/* 249:242 */                   found = true;
/* 250:243 */                   break;
/* 251:    */                 }
/* 252:    */               }
/* 253:246 */               if (!found) {
/* 254:247 */                 this.listEdges.add(new Edge(nd.id, stat.id, 8));
/* 255:    */               }
/* 256:250 */               sourcenode = nodecond;
/* 257:    */             }
/* 258:    */           }
/* 259:252 */           break;
/* 260:    */         case 2: 
/* 261:    */         case 6: 
/* 262:    */         case 10: 
/* 263:    */         case 13: 
/* 264:    */         case 15: 
/* 265:258 */           int statsize = stat.getStats().size();
/* 266:259 */           if (stat.type == 10) {
/* 267:260 */             statsize = 2;
/* 268:    */           }
/* 269:263 */           if (statementBreakIndex <= statsize)
/* 270:    */           {
/* 271:264 */             List<Exprent> tailexprlst = null;
/* 272:266 */             switch (stat.type)
/* 273:    */             {
/* 274:    */             case 10: 
/* 275:268 */               tailexprlst = ((SynchronizedStatement)stat).getHeadexprentList();
/* 276:269 */               break;
/* 277:    */             case 6: 
/* 278:271 */               tailexprlst = ((SwitchStatement)stat).getHeadexprentList();
/* 279:272 */               break;
/* 280:    */             case 2: 
/* 281:274 */               tailexprlst = ((IfStatement)stat).getHeadexprentList();
/* 282:    */             }
/* 283:277 */             int i = statementBreakIndex;
/* 284:277 */             if (i < statsize)
/* 285:    */             {
/* 286:278 */               statEntry.statementIndex = (i + 1);
/* 287:279 */               lstStackStatements.addFirst(statEntry);
/* 288:280 */               lstStackStatements.addFirst(new Object()
/* 289:    */               {
/* 290:    */                 public Statement statement;
/* 291:    */                 public LinkedList<FlattenStatementsHelper.StackEntry> stackFinally;
/* 292:    */                 public List<Exprent> tailExprents;
/* 293:    */                 public int statementIndex;
/* 294:    */                 public int edgeIndex;
/* 295:    */                 public List<StatEdge> succEdges;
/* 296:283 */               });
/* 297:284 */               continue;
/* 298:    */             }
/* 299:287 */             node = (DirectNode)this.graph.nodes.getWithKey(((String[])this.mapDestinationNodes.get(stat.getFirst().id))[0]);
/* 300:288 */             this.mapDestinationNodes.put(stat.id, new String[] { node.id, null });
/* 301:290 */             if ((stat.type == 2) && (((IfStatement)stat).iftype == 0))
/* 302:    */             {
/* 303:291 */               lstSuccEdges.add(stat.getSuccessorEdges(1073741824).get(0));
/* 304:292 */               sourcenode = tailexprlst.get(0) == null ? node : (DirectNode)this.graph.nodes.getWithKey(node.id + "_tail");
/* 305:    */             }
/* 306:    */           }
/* 307:    */           break;
/* 308:    */         }
/* 309:    */       }
/* 310:299 */       else if (sourcenode != null)
/* 311:    */       {
/* 312:301 */         if (statEntry.succEdges != null) {
/* 313:302 */           lstSuccEdges = statEntry.succEdges;
/* 314:    */         }
/* 315:305 */         for (int edgeindex = statEntry.edgeIndex;; edgeindex++)
/* 316:    */         {
/* 317:305 */           if (edgeindex >= lstSuccEdges.size()) {
/* 318:    */             break label2494;
/* 319:    */           }
/* 320:307 */           StatEdge edge = (StatEdge)lstSuccEdges.get(edgeindex);
/* 321:    */           
/* 322:309 */           LinkedList<StackEntry> stack = new LinkedList(stackFinally);
/* 323:    */           
/* 324:311 */           int edgetype = edge.getType();
/* 325:312 */           Statement destination = edge.getDestination();
/* 326:    */           
/* 327:314 */           DirectNode finallyShortRangeSource = sourcenode;
/* 328:315 */           DirectNode finallyLongRangeSource = sourcenode;
/* 329:316 */           Statement finallyShortRangeEntry = null;
/* 330:317 */           Statement finallyLongRangeEntry = null;
/* 331:    */           
/* 332:319 */           boolean isFinallyMonitorExceptionPath = false;
/* 333:    */           
/* 334:321 */           boolean isFinallyExit = false;
/* 335:    */           for (;;)
/* 336:    */           {
/* 337:325 */             StackEntry entry = null;
/* 338:326 */             if (!stack.isEmpty()) {
/* 339:327 */               entry = (StackEntry)stack.getLast();
/* 340:    */             }
/* 341:330 */             boolean created = true;
/* 342:332 */             if (entry == null)
/* 343:    */             {
/* 344:333 */               saveEdge(sourcenode, destination, edgetype, isFinallyExit ? finallyShortRangeSource : null, finallyLongRangeSource, finallyShortRangeEntry, finallyLongRangeEntry, isFinallyMonitorExceptionPath);
/* 345:    */             }
/* 346:    */             else
/* 347:    */             {
/* 348:338 */               CatchAllStatement catchall = entry.catchstatement;
/* 349:340 */               if (entry.state)
/* 350:    */               {
/* 351:341 */                 if (edgetype == 32)
/* 352:    */                 {
/* 353:343 */                   stack.removeLast();
/* 354:344 */                   destination = entry.destination;
/* 355:345 */                   edgetype = entry.edgetype;
/* 356:    */                   
/* 357:347 */                   finallyShortRangeSource = entry.finallyShortRangeSource;
/* 358:348 */                   finallyLongRangeSource = entry.finallyLongRangeSource;
/* 359:349 */                   finallyShortRangeEntry = entry.finallyShortRangeEntry;
/* 360:350 */                   finallyLongRangeEntry = entry.finallyLongRangeEntry;
/* 361:    */                   
/* 362:352 */                   isFinallyExit = true;
/* 363:353 */                   isFinallyMonitorExceptionPath = catchall.getMonitor() != null & entry.isFinallyExceptionPath;
/* 364:    */                   
/* 365:355 */                   created = false;
/* 366:    */                 }
/* 367:358 */                 else if (!catchall.containsStatementStrict(destination))
/* 368:    */                 {
/* 369:359 */                   stack.removeLast();
/* 370:360 */                   created = false;
/* 371:    */                 }
/* 372:    */                 else
/* 373:    */                 {
/* 374:363 */                   saveEdge(sourcenode, destination, edgetype, isFinallyExit ? finallyShortRangeSource : null, finallyLongRangeSource, finallyShortRangeEntry, finallyLongRangeEntry, isFinallyMonitorExceptionPath);
/* 375:    */                 }
/* 376:    */               }
/* 377:    */               else
/* 378:    */               {
/* 379:369 */                 if (!catchall.containsStatementStrict(destination))
/* 380:    */                 {
/* 381:370 */                   saveEdge(sourcenode, catchall.getHandler(), 1, isFinallyExit ? finallyShortRangeSource : null, finallyLongRangeSource, finallyShortRangeEntry, finallyLongRangeEntry, isFinallyMonitorExceptionPath);
/* 382:    */                   
/* 383:    */ 
/* 384:373 */                   stack.removeLast();
/* 385:374 */                   stack.add(new StackEntry(catchall, Boolean.TRUE.booleanValue(), edgetype, destination, catchall.getHandler(), finallyLongRangeEntry == null ? catchall.getHandler() : finallyLongRangeEntry, sourcenode, finallyLongRangeSource, false));
/* 386:    */                   
/* 387:    */ 
/* 388:    */ 
/* 389:378 */                   statEntry.edgeIndex = (edgeindex + 1);
/* 390:379 */                   statEntry.succEdges = lstSuccEdges;
/* 391:380 */                   lstStackStatements.addFirst(statEntry);
/* 392:381 */                   lstStackStatements.addFirst(new Object()
/* 393:    */                   {
/* 394:    */                     public Statement statement;
/* 395:    */                     public LinkedList<FlattenStatementsHelper.StackEntry> stackFinally;
/* 396:    */                     public List<Exprent> tailExprents;
/* 397:    */                     public int statementIndex;
/* 398:    */                     public int edgeIndex;
/* 399:    */                     public List<StatEdge> succEdges;
/* 400:382 */                   });
/* 401:383 */                   break;
/* 402:    */                 }
/* 403:386 */                 saveEdge(sourcenode, destination, edgetype, isFinallyExit ? finallyShortRangeSource : null, finallyLongRangeSource, finallyShortRangeEntry, finallyLongRangeEntry, isFinallyMonitorExceptionPath);
/* 404:    */               }
/* 405:    */             }
/* 406:392 */             if (created) {
/* 407:    */               break label2488;
/* 408:    */             }
/* 409:    */           }
/* 410:    */         }
/* 411:    */       }
/* 412:    */     }
/* 413:    */   }
/* 414:    */   
/* 415:    */   private void saveEdge(DirectNode sourcenode, Statement destination, int edgetype, DirectNode finallyShortRangeSource, DirectNode finallyLongRangeSource, Statement finallyShortRangeEntry, Statement finallyLongRangeEntry, boolean isFinallyMonitorExceptionPath)
/* 416:    */   {
/* 417:410 */     if (edgetype != 32) {
/* 418:411 */       this.listEdges.add(new Edge(sourcenode.id, destination.id, edgetype));
/* 419:    */     }
/* 420:414 */     if (finallyShortRangeSource != null)
/* 421:    */     {
/* 422:416 */       boolean isContinueEdge = edgetype == 8;
/* 423:    */       
/* 424:418 */       List<String[]> lst = (List)this.mapShortRangeFinallyPathIds.get(sourcenode.id);
/* 425:419 */       if (lst == null) {
/* 426:420 */         this.mapShortRangeFinallyPathIds.put(sourcenode.id, lst = new ArrayList());
/* 427:    */       }
/* 428:422 */       lst.add(new String[] { finallyShortRangeSource.id, destination.id.toString(), finallyShortRangeEntry.id.toString(), isFinallyMonitorExceptionPath ? "1" : null, isContinueEdge ? "1" : null });
/* 429:    */       
/* 430:    */ 
/* 431:425 */       lst = (List)this.mapLongRangeFinallyPathIds.get(sourcenode.id);
/* 432:426 */       if (lst == null) {
/* 433:427 */         this.mapLongRangeFinallyPathIds.put(sourcenode.id, lst = new ArrayList());
/* 434:    */       }
/* 435:429 */       lst.add(new String[] { finallyLongRangeSource.id, destination.id.toString(), finallyLongRangeEntry.id.toString(), isContinueEdge ? "1" : null });
/* 436:    */     }
/* 437:    */   }
/* 438:    */   
/* 439:    */   private void setEdges()
/* 440:    */   {
/* 441:436 */     for (Edge edge : this.listEdges)
/* 442:    */     {
/* 443:438 */       String sourceid = edge.sourceid;
/* 444:439 */       Integer statid = edge.statid;
/* 445:    */       
/* 446:441 */       DirectNode source = (DirectNode)this.graph.nodes.getWithKey(sourceid);
/* 447:    */       
/* 448:443 */       DirectNode dest = (DirectNode)this.graph.nodes.getWithKey(((String[])this.mapDestinationNodes.get(statid))[0]);
/* 449:445 */       if (!source.succs.contains(dest)) {
/* 450:446 */         source.succs.add(dest);
/* 451:    */       }
/* 452:449 */       if (!dest.preds.contains(source)) {
/* 453:450 */         dest.preds.add(source);
/* 454:    */       }
/* 455:453 */       if ((this.mapPosIfBranch.containsKey(sourceid)) && (!statid.equals(this.mapPosIfBranch.get(sourceid)))) {
/* 456:454 */         this.graph.mapNegIfBranch.put(sourceid, dest.id);
/* 457:    */       }
/* 458:    */     }
/* 459:458 */     for (int i = 0; i < 2; i++) {
/* 460:459 */       for (Map.Entry<String, List<String[]>> ent : (i == 0 ? this.mapShortRangeFinallyPathIds : this.mapLongRangeFinallyPathIds).entrySet())
/* 461:    */       {
/* 462:461 */         List<FinallyPathWrapper> newLst = new ArrayList();
/* 463:    */         
/* 464:463 */         List<String[]> lst = (List)ent.getValue();
/* 465:464 */         for (String[] arr : lst)
/* 466:    */         {
/* 467:466 */           boolean isContinueEdge = arr[3] != null;
/* 468:    */           
/* 469:468 */           DirectNode dest = (DirectNode)this.graph.nodes.getWithKey(((String[])this.mapDestinationNodes.get(Integer.valueOf(Integer.parseInt(arr[1]))))[0]);
/* 470:469 */           DirectNode enter = (DirectNode)this.graph.nodes.getWithKey(((String[])this.mapDestinationNodes.get(Integer.valueOf(Integer.parseInt(arr[2]))))[0]);
/* 471:    */           
/* 472:471 */           newLst.add(new FinallyPathWrapper(arr[0], dest.id, enter.id, null));
/* 473:473 */           if ((i == 0) && (arr[3] != null)) {
/* 474:474 */             this.graph.mapFinallyMonitorExceptionPathExits.put(ent.getKey(), dest.id);
/* 475:    */           }
/* 476:    */         }
/* 477:478 */         if (!newLst.isEmpty()) {
/* 478:479 */           (i == 0 ? this.graph.mapShortRangeFinallyPaths : this.graph.mapLongRangeFinallyPaths).put(ent.getKey(), new ArrayList(new HashSet(newLst)));
/* 479:    */         }
/* 480:    */       }
/* 481:    */     }
/* 482:    */   }
/* 483:    */   
/* 484:    */   public Map<Integer, String[]> getMapDestinationNodes()
/* 485:    */   {
/* 486:488 */     return this.mapDestinationNodes;
/* 487:    */   }
/* 488:    */   
/* 489:    */   public static class FinallyPathWrapper
/* 490:    */   {
/* 491:    */     public final String source;
/* 492:    */     public final String destination;
/* 493:    */     public final String entry;
/* 494:    */     
/* 495:    */     private FinallyPathWrapper(String source, String destination, String entry)
/* 496:    */     {
/* 497:497 */       this.source = source;
/* 498:498 */       this.destination = destination;
/* 499:499 */       this.entry = entry;
/* 500:    */     }
/* 501:    */     
/* 502:    */     public boolean equals(Object o)
/* 503:    */     {
/* 504:504 */       if (o == this) {
/* 505:504 */         return true;
/* 506:    */       }
/* 507:505 */       if ((o == null) || (!(o instanceof FinallyPathWrapper))) {
/* 508:505 */         return false;
/* 509:    */       }
/* 510:507 */       FinallyPathWrapper fpw = (FinallyPathWrapper)o;
/* 511:508 */       return (this.source + ":" + this.destination + ":" + this.entry).equals(fpw.source + ":" + fpw.destination + ":" + fpw.entry);
/* 512:    */     }
/* 513:    */     
/* 514:    */     public int hashCode()
/* 515:    */     {
/* 516:513 */       return (this.source + ":" + this.destination + ":" + this.entry).hashCode();
/* 517:    */     }
/* 518:    */     
/* 519:    */     public String toString()
/* 520:    */     {
/* 521:518 */       return this.source + "->(" + this.entry + ")->" + this.destination;
/* 522:    */     }
/* 523:    */   }
/* 524:    */   
/* 525:    */   private static class StackEntry
/* 526:    */   {
/* 527:    */     public final CatchAllStatement catchstatement;
/* 528:    */     public final boolean state;
/* 529:    */     public final int edgetype;
/* 530:    */     public final boolean isFinallyExceptionPath;
/* 531:    */     public final Statement destination;
/* 532:    */     public final Statement finallyShortRangeEntry;
/* 533:    */     public final Statement finallyLongRangeEntry;
/* 534:    */     public final DirectNode finallyShortRangeSource;
/* 535:    */     public final DirectNode finallyLongRangeSource;
/* 536:    */     
/* 537:    */     public StackEntry(CatchAllStatement catchstatement, boolean state, int edgetype, Statement destination, Statement finallyShortRangeEntry, Statement finallyLongRangeEntry, DirectNode finallyShortRangeSource, DirectNode finallyLongRangeSource, boolean isFinallyExceptionPath)
/* 538:    */     {
/* 539:546 */       this.catchstatement = catchstatement;
/* 540:547 */       this.state = state;
/* 541:548 */       this.edgetype = edgetype;
/* 542:549 */       this.isFinallyExceptionPath = isFinallyExceptionPath;
/* 543:    */       
/* 544:551 */       this.destination = destination;
/* 545:552 */       this.finallyShortRangeEntry = finallyShortRangeEntry;
/* 546:553 */       this.finallyLongRangeEntry = finallyLongRangeEntry;
/* 547:554 */       this.finallyShortRangeSource = finallyShortRangeSource;
/* 548:555 */       this.finallyLongRangeSource = finallyLongRangeSource;
/* 549:    */     }
/* 550:    */     
/* 551:    */     public StackEntry(CatchAllStatement catchstatement, boolean state)
/* 552:    */     {
/* 553:559 */       this(catchstatement, state, -1, null, null, null, null, null, false);
/* 554:    */     }
/* 555:    */   }
/* 556:    */   
/* 557:    */   private static class Edge
/* 558:    */   {
/* 559:    */     public final String sourceid;
/* 560:    */     public final Integer statid;
/* 561:    */     public final int edgetype;
/* 562:    */     
/* 563:    */     public Edge(String sourceid, Integer statid, int edgetype)
/* 564:    */     {
/* 565:569 */       this.sourceid = sourceid;
/* 566:570 */       this.statid = statid;
/* 567:571 */       this.edgetype = edgetype;
/* 568:    */     }
/* 569:    */   }
/* 570:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.sforms.FlattenStatementsHelper
 * JD-Core Version:    0.7.0.1
 */