/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler.sforms;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchAllStatement;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  18:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  19:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  20:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  21:    */ import org.jetbrains.java.decompiler.util.FastSparseSetFactory;
/*  22:    */ import org.jetbrains.java.decompiler.util.FastSparseSetFactory.FastSparseSet;
/*  23:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  24:    */ import org.jetbrains.java.decompiler.util.SFormsFastMapDirect;
/*  25:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  26:    */ 
/*  27:    */ public class SSAConstructorSparseEx
/*  28:    */ {
/*  29: 45 */   private final HashMap<String, SFormsFastMapDirect> inVarVersions = new HashMap();
/*  30: 48 */   private final HashMap<String, SFormsFastMapDirect> outVarVersions = new HashMap();
/*  31: 51 */   private final HashMap<String, SFormsFastMapDirect> outNegVarVersions = new HashMap();
/*  32: 54 */   private final HashMap<String, SFormsFastMapDirect> extraVarVersions = new HashMap();
/*  33: 57 */   private final HashMap<VarVersionPair, FastSparseSetFactory.FastSparseSet<Integer>> phi = new HashMap();
/*  34: 60 */   private final HashMap<Integer, Integer> lastversion = new HashMap();
/*  35: 62 */   private final List<VarVersionPair> startVars = new ArrayList();
/*  36:    */   private FastSparseSetFactory<Integer> factory;
/*  37:    */   
/*  38:    */   public void splitVariables(RootStatement root, StructMethod mt)
/*  39:    */   {
/*  40: 69 */     FlattenStatementsHelper flatthelper = new FlattenStatementsHelper();
/*  41: 70 */     DirectGraph dgraph = flatthelper.buildDirectGraph(root);
/*  42:    */     
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47: 76 */     HashSet<Integer> setInit = new HashSet();
/*  48: 77 */     for (int i = 0; i < 64; i++) {
/*  49: 78 */       setInit.add(Integer.valueOf(i));
/*  50:    */     }
/*  51: 80 */     this.factory = new FastSparseSetFactory(setInit);
/*  52:    */     
/*  53: 82 */     SFormsFastMapDirect firstmap = createFirstMap(mt);
/*  54: 83 */     this.extraVarVersions.put(dgraph.first.id, firstmap);
/*  55:    */     
/*  56: 85 */     setCatchMaps(root, dgraph, flatthelper);
/*  57:    */     
/*  58: 87 */     HashSet<String> updated = new HashSet();
/*  59:    */     do
/*  60:    */     {
/*  61: 90 */       ssaStatements(dgraph, updated);
/*  62: 93 */     } while (!updated.isEmpty());
/*  63:    */   }
/*  64:    */   
/*  65:    */   private void ssaStatements(DirectGraph dgraph, HashSet<String> updated)
/*  66:    */   {
/*  67:102 */     for (DirectNode node : dgraph.nodes)
/*  68:    */     {
/*  69:114 */       updated.remove(node.id);
/*  70:115 */       mergeInVarMaps(node, dgraph);
/*  71:    */       
/*  72:117 */       SFormsFastMapDirect varmap = (SFormsFastMapDirect)this.inVarVersions.get(node.id);
/*  73:118 */       varmap = new SFormsFastMapDirect(varmap);
/*  74:    */       
/*  75:120 */       SFormsFastMapDirect[] varmaparr = { varmap, null };
/*  76:122 */       if (node.exprents != null) {
/*  77:123 */         for (Exprent expr : node.exprents) {
/*  78:124 */           processExprent(expr, varmaparr);
/*  79:    */         }
/*  80:    */       }
/*  81:128 */       if (varmaparr[1] == null) {
/*  82:129 */         varmaparr[1] = varmaparr[0];
/*  83:    */       }
/*  84:132 */       boolean this_updated = (!mapsEqual(varmaparr[0], (SFormsFastMapDirect)this.outVarVersions.get(node.id))) || ((this.outNegVarVersions.containsKey(node.id)) && (!mapsEqual(varmaparr[1], (SFormsFastMapDirect)this.outNegVarVersions.get(node.id))));
/*  85:135 */       if (this_updated)
/*  86:    */       {
/*  87:136 */         this.outVarVersions.put(node.id, varmaparr[0]);
/*  88:137 */         if (dgraph.mapNegIfBranch.containsKey(node.id)) {
/*  89:138 */           this.outNegVarVersions.put(node.id, varmaparr[1]);
/*  90:    */         }
/*  91:141 */         for (DirectNode nd : node.succs) {
/*  92:142 */           updated.add(nd.id);
/*  93:    */         }
/*  94:    */       }
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   private void processExprent(Exprent expr, SFormsFastMapDirect[] varmaparr)
/*  99:    */   {
/* 100:150 */     if (expr == null) {
/* 101:151 */       return;
/* 102:    */     }
/* 103:154 */     VarExprent varassign = null;
/* 104:155 */     boolean finished = false;
/* 105:157 */     switch (expr.type)
/* 106:    */     {
/* 107:    */     case 2: 
/* 108:159 */       AssignmentExprent assexpr = (AssignmentExprent)expr;
/* 109:160 */       if (assexpr.getCondType() == -1)
/* 110:    */       {
/* 111:161 */         Exprent dest = assexpr.getLeft();
/* 112:162 */         if (dest.type == 12) {
/* 113:163 */           varassign = (VarExprent)dest;
/* 114:    */         }
/* 115:    */       }
/* 116:165 */       break;
/* 117:    */     case 6: 
/* 118:168 */       FunctionExprent func = (FunctionExprent)expr;
/* 119:169 */       switch (func.getFuncType())
/* 120:    */       {
/* 121:    */       case 36: 
/* 122:171 */         processExprent((Exprent)func.getLstOperands().get(0), varmaparr);
/* 123:    */         SFormsFastMapDirect varmapFalse;
/* 124:    */         SFormsFastMapDirect varmapFalse;
/* 125:174 */         if (varmaparr[1] == null)
/* 126:    */         {
/* 127:175 */           varmapFalse = new SFormsFastMapDirect(varmaparr[0]);
/* 128:    */         }
/* 129:    */         else
/* 130:    */         {
/* 131:178 */           varmapFalse = varmaparr[1];
/* 132:179 */           varmaparr[1] = null;
/* 133:    */         }
/* 134:182 */         processExprent((Exprent)func.getLstOperands().get(1), varmaparr);
/* 135:    */         
/* 136:184 */         SFormsFastMapDirect[] varmaparrNeg = { varmapFalse, null };
/* 137:185 */         processExprent((Exprent)func.getLstOperands().get(2), varmaparrNeg);
/* 138:    */         
/* 139:187 */         mergeMaps(varmaparr[0], varmaparrNeg[0]);
/* 140:188 */         varmaparr[1] = null;
/* 141:    */         
/* 142:190 */         finished = true;
/* 143:191 */         break;
/* 144:    */       case 48: 
/* 145:193 */         processExprent((Exprent)func.getLstOperands().get(0), varmaparr);
/* 146:    */         
/* 147:195 */         SFormsFastMapDirect[] varmaparrAnd = { new SFormsFastMapDirect(varmaparr[0]), null };
/* 148:    */         
/* 149:197 */         processExprent((Exprent)func.getLstOperands().get(1), varmaparrAnd);
/* 150:    */         
/* 151:    */ 
/* 152:200 */         varmaparr[1] = mergeMaps(varmaparr[1], varmaparrAnd[1]);
/* 153:    */         
/* 154:202 */         varmaparr[0] = varmaparrAnd[0];
/* 155:    */         
/* 156:204 */         finished = true;
/* 157:205 */         break;
/* 158:    */       case 49: 
/* 159:207 */         processExprent((Exprent)func.getLstOperands().get(0), varmaparr);
/* 160:    */         
/* 161:209 */         SFormsFastMapDirect[] varmaparrOr = { new SFormsFastMapDirect(varmaparr[1]), null };
/* 162:    */         
/* 163:    */ 
/* 164:212 */         processExprent((Exprent)func.getLstOperands().get(1), varmaparrOr);
/* 165:    */         
/* 166:    */ 
/* 167:215 */         varmaparr[1] = varmaparrOr[1];
/* 168:    */         
/* 169:217 */         varmaparr[0] = mergeMaps(varmaparr[0], varmaparrOr[0]);
/* 170:    */         
/* 171:219 */         finished = true;
/* 172:    */       }
/* 173:    */       break;
/* 174:    */     }
/* 175:223 */     if (finished) {
/* 176:224 */       return;
/* 177:    */     }
/* 178:227 */     List<Exprent> lst = expr.getAllExprents();
/* 179:228 */     lst.remove(varassign);
/* 180:230 */     for (Exprent ex : lst) {
/* 181:231 */       processExprent(ex, varmaparr);
/* 182:    */     }
/* 183:234 */     SFormsFastMapDirect varmap = varmaparr[0];
/* 184:236 */     if (varassign != null)
/* 185:    */     {
/* 186:238 */       Integer varindex = Integer.valueOf(varassign.getIndex());
/* 187:240 */       if (varassign.getVersion() == 0)
/* 188:    */       {
/* 189:242 */         Integer nextver = getNextFreeVersion(varindex);
/* 190:    */         
/* 191:    */ 
/* 192:245 */         varassign.setVersion(nextver.intValue());
/* 193:    */         
/* 194:247 */         setCurrentVar(varmap, varindex, nextver);
/* 195:    */       }
/* 196:    */       else
/* 197:    */       {
/* 198:250 */         setCurrentVar(varmap, varindex, Integer.valueOf(varassign.getVersion()));
/* 199:    */       }
/* 200:    */     }
/* 201:253 */     else if (expr.type == 12)
/* 202:    */     {
/* 203:255 */       VarExprent vardest = (VarExprent)expr;
/* 204:256 */       Integer varindex = Integer.valueOf(vardest.getIndex());
/* 205:257 */       FastSparseSetFactory.FastSparseSet<Integer> vers = varmap.get(varindex.intValue());
/* 206:    */       
/* 207:259 */       int cardinality = vers.getCardinality();
/* 208:260 */       if (cardinality == 1)
/* 209:    */       {
/* 210:262 */         Integer it = (Integer)vers.iterator().next();
/* 211:263 */         vardest.setVersion(it.intValue());
/* 212:    */       }
/* 213:265 */       else if (cardinality == 2)
/* 214:    */       {
/* 215:266 */         Integer current_vers = Integer.valueOf(vardest.getVersion());
/* 216:    */         
/* 217:268 */         VarVersionPair currpaar = new VarVersionPair(varindex, current_vers);
/* 218:269 */         if ((current_vers.intValue() != 0) && (this.phi.containsKey(currpaar)))
/* 219:    */         {
/* 220:270 */           setCurrentVar(varmap, varindex, current_vers);
/* 221:    */           
/* 222:272 */           ((FastSparseSetFactory.FastSparseSet)this.phi.get(currpaar)).union(vers);
/* 223:    */         }
/* 224:    */         else
/* 225:    */         {
/* 226:276 */           Integer nextver = getNextFreeVersion(varindex);
/* 227:    */           
/* 228:278 */           vardest.setVersion(nextver.intValue());
/* 229:    */           
/* 230:280 */           setCurrentVar(varmap, varindex, nextver);
/* 231:    */           
/* 232:282 */           this.phi.put(new VarVersionPair(varindex, nextver), vers);
/* 233:    */         }
/* 234:    */       }
/* 235:    */     }
/* 236:    */   }
/* 237:    */   
/* 238:    */   private Integer getNextFreeVersion(Integer var)
/* 239:    */   {
/* 240:289 */     Integer nextver = (Integer)this.lastversion.get(var);
/* 241:290 */     if (nextver == null) {
/* 242:291 */       nextver = new Integer(1);
/* 243:    */     } else {
/* 244:294 */       nextver = new Integer(nextver.intValue() + 1);
/* 245:    */     }
/* 246:296 */     this.lastversion.put(var, nextver);
/* 247:297 */     return nextver;
/* 248:    */   }
/* 249:    */   
/* 250:    */   private void mergeInVarMaps(DirectNode node, DirectGraph dgraph)
/* 251:    */   {
/* 252:302 */     SFormsFastMapDirect mapNew = new SFormsFastMapDirect();
/* 253:304 */     for (DirectNode pred : node.preds)
/* 254:    */     {
/* 255:305 */       SFormsFastMapDirect mapOut = getFilteredOutMap(node.id, pred.id, dgraph, node.id);
/* 256:306 */       if (mapNew.isEmpty()) {
/* 257:307 */         mapNew = mapOut.getCopy();
/* 258:    */       } else {
/* 259:310 */         mergeMaps(mapNew, mapOut);
/* 260:    */       }
/* 261:    */     }
/* 262:314 */     if (this.extraVarVersions.containsKey(node.id))
/* 263:    */     {
/* 264:315 */       SFormsFastMapDirect mapExtra = (SFormsFastMapDirect)this.extraVarVersions.get(node.id);
/* 265:316 */       if (mapNew.isEmpty()) {
/* 266:317 */         mapNew = mapExtra.getCopy();
/* 267:    */       } else {
/* 268:320 */         mergeMaps(mapNew, mapExtra);
/* 269:    */       }
/* 270:    */     }
/* 271:324 */     this.inVarVersions.put(node.id, mapNew);
/* 272:    */   }
/* 273:    */   
/* 274:    */   private SFormsFastMapDirect getFilteredOutMap(String nodeid, String predid, DirectGraph dgraph, String destid)
/* 275:    */   {
/* 276:329 */     SFormsFastMapDirect mapNew = new SFormsFastMapDirect();
/* 277:331 */     if (nodeid.equals(dgraph.mapNegIfBranch.get(predid)))
/* 278:    */     {
/* 279:332 */       if (this.outNegVarVersions.containsKey(predid)) {
/* 280:333 */         mapNew = ((SFormsFastMapDirect)this.outNegVarVersions.get(predid)).getCopy();
/* 281:    */       }
/* 282:    */     }
/* 283:336 */     else if (this.outVarVersions.containsKey(predid)) {
/* 284:337 */       mapNew = ((SFormsFastMapDirect)this.outVarVersions.get(predid)).getCopy();
/* 285:    */     }
/* 286:340 */     boolean isFinallyExit = dgraph.mapShortRangeFinallyPaths.containsKey(predid);
/* 287:342 */     if ((isFinallyExit) && (!mapNew.isEmpty()))
/* 288:    */     {
/* 289:344 */       SFormsFastMapDirect mapNewTemp = mapNew.getCopy();
/* 290:    */       
/* 291:346 */       SFormsFastMapDirect mapTrueSource = new SFormsFastMapDirect();
/* 292:    */       
/* 293:348 */       String exceptionDest = (String)dgraph.mapFinallyMonitorExceptionPathExits.get(predid);
/* 294:349 */       boolean isExceptionMonitorExit = (exceptionDest != null) && (!nodeid.equals(exceptionDest));
/* 295:    */       
/* 296:351 */       HashSet<String> setLongPathWrapper = new HashSet();
/* 297:352 */       for (FlattenStatementsHelper.FinallyPathWrapper finwraplong : (List)dgraph.mapLongRangeFinallyPaths.get(predid)) {
/* 298:353 */         setLongPathWrapper.add(finwraplong.destination + "##" + finwraplong.source);
/* 299:    */       }
/* 300:356 */       for (FlattenStatementsHelper.FinallyPathWrapper finwrap : (List)dgraph.mapShortRangeFinallyPaths.get(predid))
/* 301:    */       {
/* 302:359 */         boolean recFinally = dgraph.mapShortRangeFinallyPaths.containsKey(finwrap.source);
/* 303:    */         SFormsFastMapDirect map;
/* 304:    */         SFormsFastMapDirect map;
/* 305:361 */         if (recFinally)
/* 306:    */         {
/* 307:363 */           map = getFilteredOutMap(finwrap.entry, finwrap.source, dgraph, destid);
/* 308:    */         }
/* 309:    */         else
/* 310:    */         {
/* 311:    */           SFormsFastMapDirect map;
/* 312:366 */           if (finwrap.entry.equals(dgraph.mapNegIfBranch.get(finwrap.source))) {
/* 313:367 */             map = (SFormsFastMapDirect)this.outNegVarVersions.get(finwrap.source);
/* 314:    */           } else {
/* 315:370 */             map = (SFormsFastMapDirect)this.outVarVersions.get(finwrap.source);
/* 316:    */           }
/* 317:    */         }
/* 318:375 */         boolean isFalsePath = true;
/* 319:377 */         if (recFinally) {
/* 320:378 */           isFalsePath = !finwrap.destination.equals(nodeid);
/* 321:    */         } else {
/* 322:381 */           isFalsePath = !setLongPathWrapper.contains(destid + "##" + finwrap.source);
/* 323:    */         }
/* 324:384 */         if (isFalsePath) {
/* 325:385 */           mapNewTemp.complement(map);
/* 326:388 */         } else if (mapTrueSource.isEmpty())
/* 327:    */         {
/* 328:389 */           if (map != null) {
/* 329:390 */             mapTrueSource = map.getCopy();
/* 330:    */           }
/* 331:    */         }
/* 332:    */         else {
/* 333:394 */           mergeMaps(mapTrueSource, map);
/* 334:    */         }
/* 335:    */       }
/* 336:399 */       if (isExceptionMonitorExit)
/* 337:    */       {
/* 338:401 */         mapNew = mapTrueSource;
/* 339:    */       }
/* 340:    */       else
/* 341:    */       {
/* 342:405 */         mapNewTemp.union(mapTrueSource);
/* 343:    */         
/* 344:407 */         SFormsFastMapDirect oldInMap = (SFormsFastMapDirect)this.inVarVersions.get(nodeid);
/* 345:408 */         if (oldInMap != null) {
/* 346:409 */           mapNewTemp.union(oldInMap);
/* 347:    */         }
/* 348:412 */         mapNew.intersection(mapNewTemp);
/* 349:    */       }
/* 350:    */     }
/* 351:416 */     return mapNew;
/* 352:    */   }
/* 353:    */   
/* 354:    */   private static SFormsFastMapDirect mergeMaps(SFormsFastMapDirect mapTo, SFormsFastMapDirect map2)
/* 355:    */   {
/* 356:421 */     if ((map2 != null) && (!map2.isEmpty())) {
/* 357:422 */       mapTo.union(map2);
/* 358:    */     }
/* 359:425 */     return mapTo;
/* 360:    */   }
/* 361:    */   
/* 362:    */   private static boolean mapsEqual(SFormsFastMapDirect map1, SFormsFastMapDirect map2)
/* 363:    */   {
/* 364:430 */     if (map1 == null) {
/* 365:431 */       return map2 == null;
/* 366:    */     }
/* 367:433 */     if (map2 == null) {
/* 368:434 */       return false;
/* 369:    */     }
/* 370:437 */     if (map1.size() != map2.size()) {
/* 371:438 */       return false;
/* 372:    */     }
/* 373:441 */     for (Map.Entry<Integer, FastSparseSetFactory.FastSparseSet<Integer>> ent2 : map2.entryList()) {
/* 374:442 */       if (!InterpreterUtil.equalObjects(map1.get(((Integer)ent2.getKey()).intValue()), ent2.getValue())) {
/* 375:443 */         return false;
/* 376:    */       }
/* 377:    */     }
/* 378:447 */     return true;
/* 379:    */   }
/* 380:    */   
/* 381:    */   private void setCurrentVar(SFormsFastMapDirect varmap, Integer var, Integer vers)
/* 382:    */   {
/* 383:451 */     FastSparseSetFactory.FastSparseSet<Integer> set = this.factory.spawnEmptySet();
/* 384:452 */     set.add(vers);
/* 385:453 */     varmap.put(var.intValue(), set);
/* 386:    */   }
/* 387:    */   
/* 388:    */   private void setCatchMaps(Statement stat, DirectGraph dgraph, FlattenStatementsHelper flatthelper)
/* 389:    */   {
/* 390:460 */     switch (stat.type)
/* 391:    */     {
/* 392:    */     case 7: 
/* 393:    */     case 12: 
/* 394:    */       List<VarExprent> lstVars;
/* 395:    */       List<VarExprent> lstVars;
/* 396:465 */       if (stat.type == 12) {
/* 397:466 */         lstVars = ((CatchAllStatement)stat).getVars();
/* 398:    */       } else {
/* 399:469 */         lstVars = ((CatchStatement)stat).getVars();
/* 400:    */       }
/* 401:472 */       for (int i = 1; i < stat.getStats().size(); i++)
/* 402:    */       {
/* 403:473 */         int varindex = ((VarExprent)lstVars.get(i - 1)).getIndex();
/* 404:474 */         int version = getNextFreeVersion(Integer.valueOf(varindex)).intValue();
/* 405:    */         
/* 406:476 */         SFormsFastMapDirect map = new SFormsFastMapDirect();
/* 407:477 */         setCurrentVar(map, Integer.valueOf(varindex), Integer.valueOf(version));
/* 408:    */         
/* 409:479 */         this.extraVarVersions.put(((DirectNode)dgraph.nodes.getWithKey(((String[])flatthelper.getMapDestinationNodes().get(((Statement)stat.getStats().get(i)).id))[0])).id, map);
/* 410:480 */         this.startVars.add(new VarVersionPair(varindex, version));
/* 411:    */       }
/* 412:    */     }
/* 413:484 */     for (Statement st : stat.getStats()) {
/* 414:485 */       setCatchMaps(st, dgraph, flatthelper);
/* 415:    */     }
/* 416:    */   }
/* 417:    */   
/* 418:    */   private SFormsFastMapDirect createFirstMap(StructMethod mt)
/* 419:    */   {
/* 420:490 */     boolean thisvar = !mt.hasModifier(8);
/* 421:    */     
/* 422:492 */     MethodDescriptor md = MethodDescriptor.parseDescriptor(mt.getDescriptor());
/* 423:    */     
/* 424:494 */     int paramcount = md.params.length + (thisvar ? 1 : 0);
/* 425:    */     
/* 426:496 */     int varindex = 0;
/* 427:497 */     SFormsFastMapDirect map = new SFormsFastMapDirect();
/* 428:498 */     for (int i = 0; i < paramcount; i++)
/* 429:    */     {
/* 430:499 */       int version = getNextFreeVersion(Integer.valueOf(varindex)).intValue();
/* 431:    */       
/* 432:501 */       FastSparseSetFactory.FastSparseSet<Integer> set = this.factory.spawnEmptySet();
/* 433:502 */       set.add(Integer.valueOf(version));
/* 434:503 */       map.put(varindex, set);
/* 435:504 */       this.startVars.add(new VarVersionPair(varindex, version));
/* 436:506 */       if (thisvar)
/* 437:    */       {
/* 438:507 */         if (i == 0) {
/* 439:508 */           varindex++;
/* 440:    */         } else {
/* 441:511 */           varindex += md.params[(i - 1)].stackSize;
/* 442:    */         }
/* 443:    */       }
/* 444:    */       else {
/* 445:515 */         varindex += md.params[i].stackSize;
/* 446:    */       }
/* 447:    */     }
/* 448:519 */     return map;
/* 449:    */   }
/* 450:    */   
/* 451:    */   public HashMap<VarVersionPair, FastSparseSetFactory.FastSparseSet<Integer>> getPhi()
/* 452:    */   {
/* 453:523 */     return this.phi;
/* 454:    */   }
/* 455:    */   
/* 456:    */   public List<VarVersionPair> getStartVars()
/* 457:    */   {
/* 458:527 */     return this.startVars;
/* 459:    */   }
/* 460:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAConstructorSparseEx
 * JD-Core Version:    0.7.0.1
 */