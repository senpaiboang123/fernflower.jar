/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor;
/*  12:    */ import org.jetbrains.java.decompiler.main.ClassesProcessor.ClassNode;
/*  13:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  14:    */ import org.jetbrains.java.decompiler.main.rels.ClassWrapper;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ArrayExprent;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FieldExprent;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.IfExprent;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent;
/*  24:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.MonitorExprent;
/*  25:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*  26:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  27:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAConstructorSparseEx;
/*  28:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  29:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  30:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  31:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  32:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  33:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  34:    */ import org.jetbrains.java.decompiler.struct.match.MatchEngine;
/*  35:    */ import org.jetbrains.java.decompiler.util.FastSparseSetFactory.FastSparseSet;
/*  36:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  37:    */ 
/*  38:    */ public class SimplifyExprentsHelper
/*  39:    */ {
/*  40: 54 */   static final MatchEngine class14Builder = new MatchEngine();
/*  41:    */   private final boolean firstInvocation;
/*  42:    */   
/*  43:    */   public SimplifyExprentsHelper(boolean firstInvocation)
/*  44:    */   {
/*  45: 59 */     this.firstInvocation = firstInvocation;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public boolean simplifyStackVarsStatement(Statement stat, HashSet<Integer> setReorderedIfs, SSAConstructorSparseEx ssa, StructClass cl)
/*  49:    */   {
/*  50: 64 */     boolean res = false;
/*  51: 66 */     if (stat.getExprents() == null)
/*  52:    */     {
/*  53: 68 */       boolean processClass14 = DecompilerContext.getOption("dc4");
/*  54:    */       for (;;)
/*  55:    */       {
/*  56: 72 */         boolean changed = false;
/*  57: 74 */         for (Statement st : stat.getStats())
/*  58:    */         {
/*  59: 75 */           res |= simplifyStackVarsStatement(st, setReorderedIfs, ssa, cl);
/*  60: 78 */           if ((changed = IfHelper.mergeIfs(st, setReorderedIfs))) {
/*  61:    */             break;
/*  62:    */           }
/*  63: 83 */           if ((changed = buildIff(st, ssa))) {
/*  64:    */             break;
/*  65:    */           }
/*  66: 88 */           if ((processClass14) && ((changed = collapseInlinedClass14(st)))) {
/*  67:    */             break;
/*  68:    */           }
/*  69:    */         }
/*  70: 93 */         res |= changed;
/*  71: 95 */         if (!changed) {
/*  72:    */           break;
/*  73:    */         }
/*  74:    */       }
/*  75:    */     }
/*  76:    */     else
/*  77:    */     {
/*  78:101 */       res |= simplifyStackVarsExprents(stat.getExprents(), cl);
/*  79:    */     }
/*  80:104 */     return res;
/*  81:    */   }
/*  82:    */   
/*  83:    */   private boolean simplifyStackVarsExprents(List<Exprent> list, StructClass cl)
/*  84:    */   {
/*  85:109 */     boolean res = false;
/*  86:    */     
/*  87:111 */     int index = 0;
/*  88:113 */     while (index < list.size())
/*  89:    */     {
/*  90:115 */       Exprent current = (Exprent)list.get(index);
/*  91:    */       
/*  92:117 */       Exprent ret = isSimpleConstructorInvocation(current);
/*  93:118 */       if (ret != null)
/*  94:    */       {
/*  95:119 */         list.set(index, ret);
/*  96:120 */         res = true;
/*  97:    */       }
/*  98:    */       else
/*  99:    */       {
/* 100:126 */         ret = isLambda(current, cl);
/* 101:127 */         if (ret != null)
/* 102:    */         {
/* 103:128 */           list.set(index, ret);
/* 104:129 */           res = true;
/* 105:    */         }
/* 106:135 */         else if (isMonitorExit(current))
/* 107:    */         {
/* 108:136 */           list.remove(index);
/* 109:137 */           res = true;
/* 110:    */         }
/* 111:143 */         else if (isTrivialStackAssignment(current))
/* 112:    */         {
/* 113:144 */           list.remove(index);
/* 114:145 */           res = true;
/* 115:    */         }
/* 116:    */         else
/* 117:    */         {
/* 118:150 */           if (index == list.size() - 1) {
/* 119:    */             break;
/* 120:    */           }
/* 121:155 */           Exprent next = (Exprent)list.get(index + 1);
/* 122:159 */           if (isConstructorInvocationRemote(list, index))
/* 123:    */           {
/* 124:160 */             list.remove(index);
/* 125:161 */             res = true;
/* 126:    */           }
/* 127:167 */           else if ((DecompilerContext.getOption("rgn")) && 
/* 128:168 */             (isQualifiedNewGetClass(current, next)))
/* 129:    */           {
/* 130:169 */             list.remove(index);
/* 131:170 */             res = true;
/* 132:    */           }
/* 133:    */           else
/* 134:    */           {
/* 135:177 */             int arrcount = isArrayInitializer(list, index);
/* 136:178 */             if (arrcount > 0)
/* 137:    */             {
/* 138:179 */               for (int i = 0; i < arrcount; i++) {
/* 139:180 */                 list.remove(index + 1);
/* 140:    */               }
/* 141:182 */               res = true;
/* 142:    */             }
/* 143:188 */             else if (addArrayInitializer(current, next))
/* 144:    */             {
/* 145:189 */               list.remove(index + 1);
/* 146:190 */               res = true;
/* 147:    */             }
/* 148:    */             else
/* 149:    */             {
/* 150:196 */               Exprent func = isPPIorMMI(current);
/* 151:197 */               if (func != null)
/* 152:    */               {
/* 153:198 */                 list.set(index, func);
/* 154:199 */                 res = true;
/* 155:    */               }
/* 156:205 */               else if (isIPPorIMM(current, next))
/* 157:    */               {
/* 158:206 */                 list.remove(index + 1);
/* 159:207 */                 res = true;
/* 160:    */               }
/* 161:213 */               else if (isStackAssignement(current, next))
/* 162:    */               {
/* 163:214 */                 list.remove(index + 1);
/* 164:215 */                 res = true;
/* 165:    */               }
/* 166:220 */               else if ((!this.firstInvocation) && (isStackAssignement2(current, next)))
/* 167:    */               {
/* 168:221 */                 list.remove(index + 1);
/* 169:222 */                 res = true;
/* 170:    */               }
/* 171:    */               else
/* 172:    */               {
/* 173:227 */                 index++;
/* 174:    */               }
/* 175:    */             }
/* 176:    */           }
/* 177:    */         }
/* 178:    */       }
/* 179:    */     }
/* 180:230 */     return res;
/* 181:    */   }
/* 182:    */   
/* 183:    */   private static boolean addArrayInitializer(Exprent first, Exprent second)
/* 184:    */   {
/* 185:235 */     if (first.type == 2)
/* 186:    */     {
/* 187:236 */       AssignmentExprent as = (AssignmentExprent)first;
/* 188:238 */       if ((as.getRight().type == 10) && (as.getLeft().type == 12))
/* 189:    */       {
/* 190:239 */         NewExprent newex = (NewExprent)as.getRight();
/* 191:241 */         if (!newex.getLstArrayElements().isEmpty())
/* 192:    */         {
/* 193:243 */           VarExprent arrvar = (VarExprent)as.getLeft();
/* 194:245 */           if (second.type == 2)
/* 195:    */           {
/* 196:246 */             AssignmentExprent aas = (AssignmentExprent)second;
/* 197:247 */             if (aas.getLeft().type == 1)
/* 198:    */             {
/* 199:248 */               ArrayExprent arrex = (ArrayExprent)aas.getLeft();
/* 200:249 */               if ((arrex.getArray().type == 12) && (arrvar.equals(arrex.getArray())) && (arrex.getIndex().type == 3))
/* 201:    */               {
/* 202:252 */                 int constvalue = ((ConstExprent)arrex.getIndex()).getIntValue();
/* 203:254 */                 if (constvalue < newex.getLstArrayElements().size())
/* 204:    */                 {
/* 205:255 */                   Exprent init = (Exprent)newex.getLstArrayElements().get(constvalue);
/* 206:256 */                   if (init.type == 3)
/* 207:    */                   {
/* 208:257 */                     ConstExprent cinit = (ConstExprent)init;
/* 209:    */                     
/* 210:259 */                     VarType arrtype = newex.getNewType().decreaseArrayDim();
/* 211:    */                     
/* 212:261 */                     ConstExprent defaultval = ExprProcessor.getDefaultArrayValue(arrtype);
/* 213:263 */                     if (cinit.equals(defaultval))
/* 214:    */                     {
/* 215:265 */                       Exprent tempexpr = aas.getRight();
/* 216:267 */                       if (!tempexpr.containsExprent(arrvar))
/* 217:    */                       {
/* 218:268 */                         newex.getLstArrayElements().set(constvalue, tempexpr);
/* 219:270 */                         if (tempexpr.type == 10)
/* 220:    */                         {
/* 221:271 */                           NewExprent tempnewex = (NewExprent)tempexpr;
/* 222:272 */                           int dims = newex.getNewType().arrayDim;
/* 223:273 */                           if ((dims > 1) && (!tempnewex.getLstArrayElements().isEmpty())) {
/* 224:274 */                             tempnewex.setDirectArrayInit(true);
/* 225:    */                           }
/* 226:    */                         }
/* 227:278 */                         return true;
/* 228:    */                       }
/* 229:    */                     }
/* 230:    */                   }
/* 231:    */                 }
/* 232:    */               }
/* 233:    */             }
/* 234:    */           }
/* 235:    */         }
/* 236:    */       }
/* 237:    */     }
/* 238:290 */     return false;
/* 239:    */   }
/* 240:    */   
/* 241:    */   private static int isArrayInitializer(List<Exprent> list, int index)
/* 242:    */   {
/* 243:296 */     Exprent current = (Exprent)list.get(index);
/* 244:297 */     if (current.type == 2)
/* 245:    */     {
/* 246:298 */       AssignmentExprent as = (AssignmentExprent)current;
/* 247:300 */       if ((as.getRight().type == 10) && (as.getLeft().type == 12))
/* 248:    */       {
/* 249:301 */         NewExprent newex = (NewExprent)as.getRight();
/* 250:303 */         if ((newex.getExprType().arrayDim > 0) && (newex.getLstDims().size() == 1) && (newex.getLstArrayElements().isEmpty()) && (((Exprent)newex.getLstDims().get(0)).type == 3))
/* 251:    */         {
/* 252:306 */           int size = ((Integer)((ConstExprent)newex.getLstDims().get(0)).getValue()).intValue();
/* 253:307 */           if (size == 0) {
/* 254:308 */             return 0;
/* 255:    */           }
/* 256:311 */           VarExprent arrvar = (VarExprent)as.getLeft();
/* 257:    */           
/* 258:313 */           HashMap<Integer, Exprent> mapInit = new HashMap();
/* 259:    */           
/* 260:315 */           int i = 1;
/* 261:316 */           while ((index + i < list.size()) && (i <= size))
/* 262:    */           {
/* 263:317 */             boolean found = false;
/* 264:    */             
/* 265:319 */             Exprent expr = (Exprent)list.get(index + i);
/* 266:320 */             if (expr.type == 2)
/* 267:    */             {
/* 268:321 */               AssignmentExprent aas = (AssignmentExprent)expr;
/* 269:322 */               if (aas.getLeft().type == 1)
/* 270:    */               {
/* 271:323 */                 ArrayExprent arrex = (ArrayExprent)aas.getLeft();
/* 272:324 */                 if ((arrex.getArray().type == 12) && (arrvar.equals(arrex.getArray())) && (arrex.getIndex().type == 3))
/* 273:    */                 {
/* 274:327 */                   int constvalue = ((ConstExprent)arrex.getIndex()).getIntValue();
/* 275:330 */                   if ((constvalue < size) && (!mapInit.containsKey(Integer.valueOf(constvalue)))) {
/* 276:332 */                     if (!aas.getRight().containsExprent(arrvar))
/* 277:    */                     {
/* 278:333 */                       mapInit.put(Integer.valueOf(constvalue), aas.getRight());
/* 279:334 */                       found = true;
/* 280:    */                     }
/* 281:    */                   }
/* 282:    */                 }
/* 283:    */               }
/* 284:    */             }
/* 285:341 */             if (!found) {
/* 286:    */               break;
/* 287:    */             }
/* 288:345 */             i++;
/* 289:    */           }
/* 290:348 */           double fraction = mapInit.size() / size;
/* 291:350 */           if (((arrvar.isStack()) && (fraction > 0.0D)) || ((size <= 7) && (fraction >= 0.3D)) || ((size > 7) && (fraction >= 0.7D)))
/* 292:    */           {
/* 293:353 */             List<Exprent> lstRet = new ArrayList();
/* 294:    */             
/* 295:355 */             VarType arrtype = newex.getNewType().decreaseArrayDim();
/* 296:    */             
/* 297:357 */             ConstExprent defaultval = ExprProcessor.getDefaultArrayValue(arrtype);
/* 298:359 */             for (int j = 0; j < size; j++) {
/* 299:360 */               lstRet.add(defaultval.copy());
/* 300:    */             }
/* 301:363 */             int dims = newex.getNewType().arrayDim;
/* 302:364 */             for (Map.Entry<Integer, Exprent> ent : mapInit.entrySet())
/* 303:    */             {
/* 304:365 */               Exprent tempexpr = (Exprent)ent.getValue();
/* 305:366 */               lstRet.set(((Integer)ent.getKey()).intValue(), tempexpr);
/* 306:368 */               if (tempexpr.type == 10)
/* 307:    */               {
/* 308:369 */                 NewExprent tempnewex = (NewExprent)tempexpr;
/* 309:370 */                 if ((dims > 1) && (!tempnewex.getLstArrayElements().isEmpty())) {
/* 310:371 */                   tempnewex.setDirectArrayInit(true);
/* 311:    */                 }
/* 312:    */               }
/* 313:    */             }
/* 314:376 */             newex.setLstArrayElements(lstRet);
/* 315:    */             
/* 316:378 */             return mapInit.size();
/* 317:    */           }
/* 318:    */         }
/* 319:    */       }
/* 320:    */     }
/* 321:384 */     return 0;
/* 322:    */   }
/* 323:    */   
/* 324:    */   private static boolean isTrivialStackAssignment(Exprent first)
/* 325:    */   {
/* 326:389 */     if (first.type == 2)
/* 327:    */     {
/* 328:390 */       AssignmentExprent asf = (AssignmentExprent)first;
/* 329:392 */       if ((asf.getLeft().type == 12) && (asf.getRight().type == 12))
/* 330:    */       {
/* 331:393 */         VarExprent varleft = (VarExprent)asf.getLeft();
/* 332:394 */         VarExprent varright = (VarExprent)asf.getRight();
/* 333:396 */         if ((varleft.getIndex() == varright.getIndex()) && (varleft.isStack()) && (varright.isStack())) {
/* 334:398 */           return true;
/* 335:    */         }
/* 336:    */       }
/* 337:    */     }
/* 338:403 */     return false;
/* 339:    */   }
/* 340:    */   
/* 341:    */   private static boolean isStackAssignement2(Exprent first, Exprent second)
/* 342:    */   {
/* 343:408 */     if ((first.type == 2) && (second.type == 2))
/* 344:    */     {
/* 345:409 */       AssignmentExprent asf = (AssignmentExprent)first;
/* 346:410 */       AssignmentExprent ass = (AssignmentExprent)second;
/* 347:412 */       if ((asf.getLeft().type == 12) && (ass.getRight().type == 12) && (asf.getLeft().equals(ass.getRight())) && (((VarExprent)asf.getLeft()).isStack())) {
/* 348:414 */         if ((ass.getLeft().type != 12) || (!((VarExprent)ass.getLeft()).isStack()))
/* 349:    */         {
/* 350:415 */           asf.setRight(new AssignmentExprent(ass.getLeft(), asf.getRight(), ass.bytecode));
/* 351:416 */           return true;
/* 352:    */         }
/* 353:    */       }
/* 354:    */     }
/* 355:421 */     return false;
/* 356:    */   }
/* 357:    */   
/* 358:    */   private static boolean isStackAssignement(Exprent first, Exprent second)
/* 359:    */   {
/* 360:426 */     if ((first.type == 2) && (second.type == 2))
/* 361:    */     {
/* 362:427 */       AssignmentExprent asf = (AssignmentExprent)first;
/* 363:428 */       AssignmentExprent ass = (AssignmentExprent)second;
/* 364:    */       for (;;)
/* 365:    */       {
/* 366:431 */         if ((asf.getRight().equals(ass.getRight())) && 
/* 367:432 */           (asf.getLeft().type == 12) && (((VarExprent)asf.getLeft()).isStack()) && ((ass.getLeft().type != 12) || (!((VarExprent)ass.getLeft()).isStack()))) {
/* 368:435 */           if (!ass.getLeft().containsExprent(asf.getLeft()))
/* 369:    */           {
/* 370:436 */             asf.setRight(ass);
/* 371:437 */             return true;
/* 372:    */           }
/* 373:    */         }
/* 374:441 */         if (asf.getRight().type != 2) {
/* 375:    */           break;
/* 376:    */         }
/* 377:442 */         asf = (AssignmentExprent)asf.getRight();
/* 378:    */       }
/* 379:    */     }
/* 380:450 */     return false;
/* 381:    */   }
/* 382:    */   
/* 383:    */   private static Exprent isPPIorMMI(Exprent first)
/* 384:    */   {
/* 385:455 */     if (first.type == 2)
/* 386:    */     {
/* 387:456 */       AssignmentExprent as = (AssignmentExprent)first;
/* 388:458 */       if (as.getRight().type == 6)
/* 389:    */       {
/* 390:459 */         FunctionExprent func = (FunctionExprent)as.getRight();
/* 391:461 */         if ((func.getFuncType() == 0) || (func.getFuncType() == 1))
/* 392:    */         {
/* 393:463 */           Exprent econd = (Exprent)func.getLstOperands().get(0);
/* 394:464 */           Exprent econst = (Exprent)func.getLstOperands().get(1);
/* 395:466 */           if ((econst.type != 3) && (econd.type == 3) && (func.getFuncType() == 0))
/* 396:    */           {
/* 397:468 */             econd = econst;
/* 398:469 */             econst = (Exprent)func.getLstOperands().get(0);
/* 399:    */           }
/* 400:472 */           if ((econst.type == 3) && (((ConstExprent)econst).hasValueOne()))
/* 401:    */           {
/* 402:473 */             Exprent left = as.getLeft();
/* 403:475 */             if ((left.type != 12) && (left.equals(econd)))
/* 404:    */             {
/* 405:476 */               FunctionExprent ret = new FunctionExprent(func.getFuncType() == 0 ? 35 : 33, econd, func.bytecode);
/* 406:    */               
/* 407:    */ 
/* 408:479 */               ret.setImplicitType(VarType.VARTYPE_INT);
/* 409:480 */               return ret;
/* 410:    */             }
/* 411:    */           }
/* 412:    */         }
/* 413:    */       }
/* 414:    */     }
/* 415:487 */     return null;
/* 416:    */   }
/* 417:    */   
/* 418:    */   private static boolean isIPPorIMM(Exprent first, Exprent second)
/* 419:    */   {
/* 420:492 */     if ((first.type == 2) && (second.type == 6))
/* 421:    */     {
/* 422:493 */       AssignmentExprent as = (AssignmentExprent)first;
/* 423:494 */       FunctionExprent in = (FunctionExprent)second;
/* 424:496 */       if (((in.getFuncType() == 33) || (in.getFuncType() == 35)) && (((Exprent)in.getLstOperands().get(0)).equals(as.getRight())))
/* 425:    */       {
/* 426:499 */         if (in.getFuncType() == 33) {
/* 427:500 */           in.setFuncType(32);
/* 428:    */         } else {
/* 429:503 */           in.setFuncType(34);
/* 430:    */         }
/* 431:505 */         as.setRight(in);
/* 432:    */         
/* 433:507 */         return true;
/* 434:    */       }
/* 435:    */     }
/* 436:511 */     return false;
/* 437:    */   }
/* 438:    */   
/* 439:    */   private static boolean isMonitorExit(Exprent first)
/* 440:    */   {
/* 441:515 */     if (first.type == 9)
/* 442:    */     {
/* 443:516 */       MonitorExprent monexpr = (MonitorExprent)first;
/* 444:517 */       if ((monexpr.getMonType() == 1) && (monexpr.getValue().type == 12) && (!((VarExprent)monexpr.getValue()).isStack())) {
/* 445:519 */         return true;
/* 446:    */       }
/* 447:    */     }
/* 448:523 */     return false;
/* 449:    */   }
/* 450:    */   
/* 451:    */   private static boolean isQualifiedNewGetClass(Exprent first, Exprent second)
/* 452:    */   {
/* 453:    */     InvocationExprent invexpr;
/* 454:528 */     if (first.type == 8)
/* 455:    */     {
/* 456:529 */       invexpr = (InvocationExprent)first;
/* 457:531 */       if ((!invexpr.isStatic()) && (invexpr.getInstance().type == 12) && (invexpr.getName().equals("getClass")) && (invexpr.getStringDescriptor().equals("()Ljava/lang/Class;")))
/* 458:    */       {
/* 459:534 */         List<Exprent> lstExprents = second.getAllExprents();
/* 460:535 */         lstExprents.add(second);
/* 461:537 */         for (Exprent expr : lstExprents) {
/* 462:538 */           if (expr.type == 10)
/* 463:    */           {
/* 464:539 */             NewExprent nexpr = (NewExprent)expr;
/* 465:540 */             if ((nexpr.getConstructor() != null) && (!nexpr.getConstructor().getLstParameters().isEmpty()) && (((Exprent)nexpr.getConstructor().getLstParameters().get(0)).equals(invexpr.getInstance())))
/* 466:    */             {
/* 467:543 */               String classname = nexpr.getNewType().value;
/* 468:544 */               ClassesProcessor.ClassNode node = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(classname);
/* 469:545 */               if ((node != null) && (node.type != 0)) {
/* 470:546 */                 return true;
/* 471:    */               }
/* 472:    */             }
/* 473:    */           }
/* 474:    */         }
/* 475:    */       }
/* 476:    */     }
/* 477:554 */     return false;
/* 478:    */   }
/* 479:    */   
/* 480:    */   private static boolean isConstructorInvocationRemote(List<Exprent> list, int index)
/* 481:    */   {
/* 482:669 */     Exprent current = (Exprent)list.get(index);
/* 483:671 */     if (current.type == 2)
/* 484:    */     {
/* 485:672 */       AssignmentExprent as = (AssignmentExprent)current;
/* 486:674 */       if ((as.getLeft().type == 12) && (as.getRight().type == 10))
/* 487:    */       {
/* 488:676 */         NewExprent newexpr = (NewExprent)as.getRight();
/* 489:677 */         VarType newtype = newexpr.getNewType();
/* 490:678 */         VarVersionPair leftPaar = new VarVersionPair((VarExprent)as.getLeft());
/* 491:680 */         if ((newtype.type == 8) && (newtype.arrayDim == 0) && (newexpr.getConstructor() == null)) {
/* 492:682 */           for (int i = index + 1; i < list.size(); i++)
/* 493:    */           {
/* 494:683 */             Exprent remote = (Exprent)list.get(i);
/* 495:686 */             if (remote.type == 8)
/* 496:    */             {
/* 497:687 */               InvocationExprent in = (InvocationExprent)remote;
/* 498:689 */               if ((in.getFunctype() == 2) && (in.getInstance().type == 12) && (as.getLeft().equals(in.getInstance())))
/* 499:    */               {
/* 500:693 */                 newexpr.setConstructor(in);
/* 501:694 */                 in.setInstance(null);
/* 502:    */                 
/* 503:696 */                 list.set(i, as.copy());
/* 504:    */                 
/* 505:698 */                 return true;
/* 506:    */               }
/* 507:    */             }
/* 508:703 */             Set<VarVersionPair> setVars = remote.getAllVariables();
/* 509:704 */             if (setVars.contains(leftPaar)) {
/* 510:705 */               return false;
/* 511:    */             }
/* 512:    */           }
/* 513:    */         }
/* 514:    */       }
/* 515:    */     }
/* 516:712 */     return false;
/* 517:    */   }
/* 518:    */   
/* 519:    */   private static Exprent isLambda(Exprent exprent, StructClass cl)
/* 520:    */   {
/* 521:717 */     List<Exprent> lst = exprent.getAllExprents();
/* 522:718 */     for (Exprent expr : lst)
/* 523:    */     {
/* 524:719 */       Exprent ret = isLambda(expr, cl);
/* 525:720 */       if (ret != null) {
/* 526:721 */         exprent.replaceExprent(expr, ret);
/* 527:    */       }
/* 528:    */     }
/* 529:725 */     if (exprent.type == 8)
/* 530:    */     {
/* 531:726 */       InvocationExprent in = (InvocationExprent)exprent;
/* 532:728 */       if (in.getInvocationTyp() == 5)
/* 533:    */       {
/* 534:730 */         String lambda_class_name = cl.qualifiedName + in.getInvokeDynamicClassSuffix();
/* 535:731 */         ClassesProcessor.ClassNode lambda_class = (ClassesProcessor.ClassNode)DecompilerContext.getClassProcessor().getMapRootClasses().get(lambda_class_name);
/* 536:733 */         if (lambda_class != null)
/* 537:    */         {
/* 538:735 */           NewExprent newexp = new NewExprent(new VarType(lambda_class_name, true), null, 0, in.bytecode);
/* 539:736 */           newexp.setConstructor(in);
/* 540:    */           
/* 541:    */ 
/* 542:    */ 
/* 543:    */ 
/* 544:741 */           return newexp;
/* 545:    */         }
/* 546:    */       }
/* 547:    */     }
/* 548:746 */     return null;
/* 549:    */   }
/* 550:    */   
/* 551:    */   private static Exprent isSimpleConstructorInvocation(Exprent exprent)
/* 552:    */   {
/* 553:752 */     List<Exprent> lst = exprent.getAllExprents();
/* 554:753 */     for (Exprent expr : lst)
/* 555:    */     {
/* 556:754 */       Exprent ret = isSimpleConstructorInvocation(expr);
/* 557:755 */       if (ret != null) {
/* 558:756 */         exprent.replaceExprent(expr, ret);
/* 559:    */       }
/* 560:    */     }
/* 561:760 */     if (exprent.type == 8)
/* 562:    */     {
/* 563:761 */       InvocationExprent in = (InvocationExprent)exprent;
/* 564:762 */       if ((in.getFunctype() == 2) && (in.getInstance().type == 10))
/* 565:    */       {
/* 566:763 */         NewExprent newexp = (NewExprent)in.getInstance();
/* 567:764 */         newexp.setConstructor(in);
/* 568:765 */         in.setInstance(null);
/* 569:766 */         return newexp;
/* 570:    */       }
/* 571:    */     }
/* 572:770 */     return null;
/* 573:    */   }
/* 574:    */   
/* 575:    */   private static boolean buildIff(Statement stat, SSAConstructorSparseEx ssa)
/* 576:    */   {
/* 577:776 */     if ((stat.type == 2) && (stat.getExprents() == null))
/* 578:    */     {
/* 579:777 */       IfStatement stif = (IfStatement)stat;
/* 580:    */       
/* 581:779 */       Exprent ifheadexpr = stif.getHeadexprent();
/* 582:780 */       Set<Integer> ifheadexpr_bytecode = ifheadexpr == null ? null : ifheadexpr.bytecode;
/* 583:782 */       if (stif.iftype == 1)
/* 584:    */       {
/* 585:783 */         Statement ifstat = stif.getIfstat();
/* 586:784 */         Statement elsestat = stif.getElsestat();
/* 587:786 */         if ((ifstat.getExprents() != null) && (ifstat.getExprents().size() == 1) && (elsestat.getExprents() != null) && (elsestat.getExprents().size() == 1) && (ifstat.getAllSuccessorEdges().size() == 1) && (elsestat.getAllSuccessorEdges().size() == 1) && (((StatEdge)ifstat.getAllSuccessorEdges().get(0)).getDestination() == ((StatEdge)elsestat.getAllSuccessorEdges().get(0)).getDestination()))
/* 588:    */         {
/* 589:791 */           Exprent ifexpr = (Exprent)ifstat.getExprents().get(0);
/* 590:792 */           Exprent elseexpr = (Exprent)elsestat.getExprents().get(0);
/* 591:794 */           if ((ifexpr.type == 2) && (elseexpr.type == 2))
/* 592:    */           {
/* 593:795 */             AssignmentExprent ifas = (AssignmentExprent)ifexpr;
/* 594:796 */             AssignmentExprent elseas = (AssignmentExprent)elseexpr;
/* 595:798 */             if ((ifas.getLeft().type == 12) && (elseas.getLeft().type == 12))
/* 596:    */             {
/* 597:799 */               VarExprent ifvar = (VarExprent)ifas.getLeft();
/* 598:800 */               VarExprent elsevar = (VarExprent)elseas.getLeft();
/* 599:802 */               if ((ifvar.getIndex() == elsevar.getIndex()) && (ifvar.isStack()))
/* 600:    */               {
/* 601:804 */                 boolean found = false;
/* 602:806 */                 for (Map.Entry<VarVersionPair, FastSparseSetFactory.FastSparseSet<Integer>> ent : ssa.getPhi().entrySet()) {
/* 603:807 */                   if ((((VarVersionPair)ent.getKey()).var == ifvar.getIndex()) && 
/* 604:808 */                     (((FastSparseSetFactory.FastSparseSet)ent.getValue()).contains(Integer.valueOf(ifvar.getVersion()))) && (((FastSparseSetFactory.FastSparseSet)ent.getValue()).contains(Integer.valueOf(elsevar.getVersion()))))
/* 605:    */                   {
/* 606:809 */                     found = true;
/* 607:810 */                     break;
/* 608:    */                   }
/* 609:    */                 }
/* 610:815 */                 if (found)
/* 611:    */                 {
/* 612:816 */                   List<Exprent> data = new ArrayList();
/* 613:817 */                   data.addAll(stif.getFirst().getExprents());
/* 614:    */                   
/* 615:819 */                   data.add(new AssignmentExprent(ifvar, new FunctionExprent(36, Arrays.asList(new Exprent[] { stif.getHeadexprent().getCondition(), ifas.getRight(), elseas.getRight() }), ifheadexpr_bytecode), ifheadexpr_bytecode));
/* 616:    */                   
/* 617:    */ 
/* 618:    */ 
/* 619:    */ 
/* 620:824 */                   stif.setExprents(data);
/* 621:826 */                   if (stif.getAllSuccessorEdges().isEmpty())
/* 622:    */                   {
/* 623:827 */                     StatEdge ifedge = (StatEdge)ifstat.getAllSuccessorEdges().get(0);
/* 624:828 */                     StatEdge edge = new StatEdge(ifedge.getType(), stif, ifedge.getDestination());
/* 625:    */                     
/* 626:830 */                     stif.addSuccessor(edge);
/* 627:831 */                     if (ifedge.closure != null) {
/* 628:832 */                       ifedge.closure.addLabeledEdge(edge);
/* 629:    */                     }
/* 630:    */                   }
/* 631:836 */                   SequenceHelper.destroyAndFlattenStatement(stif);
/* 632:    */                   
/* 633:838 */                   return true;
/* 634:    */                 }
/* 635:    */               }
/* 636:    */             }
/* 637:    */           }
/* 638:843 */           else if ((ifexpr.type == 4) && (elseexpr.type == 4))
/* 639:    */           {
/* 640:844 */             ExitExprent ifex = (ExitExprent)ifexpr;
/* 641:845 */             ExitExprent elseex = (ExitExprent)elseexpr;
/* 642:847 */             if ((ifex.getExitType() == elseex.getExitType()) && (ifex.getValue() != null) && (elseex.getValue() != null) && (ifex.getExitType() == 0))
/* 643:    */             {
/* 644:852 */               if ((ifex.getExitType() == 1) && (!ifex.getValue().getExprType().equals(elseex.getValue().getExprType()))) {
/* 645:854 */                 return false;
/* 646:    */               }
/* 647:857 */               List<Exprent> data = new ArrayList();
/* 648:858 */               data.addAll(stif.getFirst().getExprents());
/* 649:    */               
/* 650:860 */               data.add(new ExitExprent(ifex.getExitType(), new FunctionExprent(36, Arrays.asList(new Exprent[] { stif.getHeadexprent().getCondition(), ifex.getValue(), elseex.getValue() }), ifheadexpr_bytecode), ifex.getRetType(), ifheadexpr_bytecode));
/* 651:    */               
/* 652:    */ 
/* 653:    */ 
/* 654:    */ 
/* 655:865 */               stif.setExprents(data);
/* 656:    */               
/* 657:867 */               StatEdge retedge = (StatEdge)ifstat.getAllSuccessorEdges().get(0);
/* 658:868 */               stif.addSuccessor(new StatEdge(4, stif, retedge.getDestination(), retedge.closure == stif ? stif.getParent() : retedge.closure));
/* 659:    */               
/* 660:    */ 
/* 661:871 */               SequenceHelper.destroyAndFlattenStatement(stif);
/* 662:    */               
/* 663:873 */               return true;
/* 664:    */             }
/* 665:    */           }
/* 666:    */         }
/* 667:    */       }
/* 668:    */     }
/* 669:880 */     return false;
/* 670:    */   }
/* 671:    */   
/* 672:    */   static
/* 673:    */   {
/* 674:884 */     class14Builder.parse("statement type:if iftype:if exprsize:-1\n exprent position:head type:if\n  exprent type:function functype:eq\n   exprent type:field name:$fieldname$\n   exprent type:constant consttype:null\n statement type:basicblock\n  exprent position:-1 type:assignment ret:$assignfield$\n   exprent type:var index:$var$\n   exprent type:field name:$fieldname$\n statement type:sequence statsize:2\n  statement type:trycatch\n   statement type:basicblock exprsize:1\n    exprent type:assignment\n     exprent type:var index:$var$\n     exprent type:invocation invclass:java/lang/Class signature:forName(Ljava/lang/String;)Ljava/lang/Class;\n      exprent position:0 type:constant consttype:string constvalue:$classname$\n   statement type:basicblock exprsize:1\n    exprent type:exit exittype:throw\n  statement type:basicblock exprsize:1\n   exprent type:assignment\n    exprent type:field name:$fieldname$ ret:$field$\n    exprent type:var index:$var$");
/* 675:    */   }
/* 676:    */   
/* 677:    */   private static boolean collapseInlinedClass14(Statement stat)
/* 678:    */   {
/* 679:912 */     boolean ret = class14Builder.match(stat);
/* 680:913 */     if (ret)
/* 681:    */     {
/* 682:915 */       String class_name = (String)class14Builder.getVariableValue("$classname$");
/* 683:916 */       AssignmentExprent assfirst = (AssignmentExprent)class14Builder.getVariableValue("$assignfield$");
/* 684:917 */       FieldExprent fieldexpr = (FieldExprent)class14Builder.getVariableValue("$field$");
/* 685:    */       
/* 686:919 */       assfirst.replaceExprent(assfirst.getRight(), new ConstExprent(VarType.VARTYPE_CLASS, class_name, null));
/* 687:    */       
/* 688:921 */       List<Exprent> data = new ArrayList();
/* 689:922 */       data.addAll(stat.getFirst().getExprents());
/* 690:    */       
/* 691:924 */       stat.setExprents(data);
/* 692:    */       
/* 693:926 */       SequenceHelper.destroyAndFlattenStatement(stat);
/* 694:    */       
/* 695:928 */       ClassWrapper wrapper = (ClassWrapper)DecompilerContext.getProperty("CURRENT_CLASS_WRAPPER");
/* 696:929 */       if (wrapper != null) {
/* 697:930 */         wrapper.getHiddenMembers().add(InterpreterUtil.makeUniqueKey(fieldexpr.getName(), fieldexpr.getDescriptor().descriptorString));
/* 698:    */       }
/* 699:    */     }
/* 700:935 */     return ret;
/* 701:    */   }
/* 702:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.SimplifyExprentsHelper
 * JD-Core Version:    0.7.0.1
 */