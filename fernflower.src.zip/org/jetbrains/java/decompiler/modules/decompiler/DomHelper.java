/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.LinkedList;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.Set;
/*  12:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*  13:    */ import org.jetbrains.java.decompiler.code.cfg.ControlFlowGraph;
/*  14:    */ import org.jetbrains.java.decompiler.code.cfg.ExceptionRangeCFG;
/*  15:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  16:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
/*  17:    */ import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger.Severity;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.decompose.FastExtendedPostdominanceHelper;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.deobfuscator.IrreducibleCFGDeobfuscator;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchAllStatement;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.CatchStatement;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*  24:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DummyExitStatement;
/*  25:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.GeneralStatement;
/*  26:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  27:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  28:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement;
/*  29:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  30:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SwitchStatement;
/*  31:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SynchronizedStatement;
/*  32:    */ import org.jetbrains.java.decompiler.util.FastFixedSetFactory;
/*  33:    */ import org.jetbrains.java.decompiler.util.FastFixedSetFactory.FastFixedSet;
/*  34:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  35:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  36:    */ 
/*  37:    */ public class DomHelper
/*  38:    */ {
/*  39:    */   private static RootStatement graphToStatement(ControlFlowGraph graph)
/*  40:    */   {
/*  41: 38 */     VBStyleCollection<Statement, Integer> stats = new VBStyleCollection();
/*  42: 39 */     VBStyleCollection<BasicBlock, Integer> blocks = graph.getBlocks();
/*  43: 41 */     for (BasicBlock block : blocks) {
/*  44: 42 */       stats.addWithKey(new BasicBlockStatement(block), Integer.valueOf(block.id));
/*  45:    */     }
/*  46: 45 */     BasicBlock firstblock = graph.getFirst();
/*  47:    */     
/*  48: 47 */     Statement firstst = (Statement)stats.getWithKey(Integer.valueOf(firstblock.id));
/*  49:    */     
/*  50: 49 */     DummyExitStatement dummyexit = new DummyExitStatement();
/*  51:    */     Statement general;
/*  52: 52 */     if ((stats.size() > 1) || (firstblock.isSuccessor(firstblock)))
/*  53:    */     {
/*  54: 53 */       general = new GeneralStatement(firstst, stats, null);
/*  55:    */     }
/*  56:    */     else
/*  57:    */     {
/*  58: 56 */       RootStatement root = new RootStatement(firstst, dummyexit);
/*  59: 57 */       firstst.addSuccessor(new StatEdge(4, firstst, dummyexit, root));
/*  60:    */       
/*  61: 59 */       return root;
/*  62:    */     }
/*  63:    */     Statement general;
/*  64: 62 */     for (Iterator i$ = blocks.iterator(); i$.hasNext();)
/*  65:    */     {
/*  66: 62 */       block = (BasicBlock)i$.next();
/*  67: 63 */       stat = (Statement)stats.getWithKey(Integer.valueOf(block.id));
/*  68: 65 */       for (BasicBlock succ : block.getSuccs())
/*  69:    */       {
/*  70: 66 */         Statement stsucc = (Statement)stats.getWithKey(Integer.valueOf(succ.id));
/*  71:    */         int type;
/*  72:    */         int type;
/*  73: 69 */         if (stsucc == firstst)
/*  74:    */         {
/*  75: 70 */           type = 8;
/*  76:    */         }
/*  77: 72 */         else if (graph.getFinallyExits().contains(block))
/*  78:    */         {
/*  79: 73 */           int type = 32;
/*  80: 74 */           stsucc = dummyexit;
/*  81:    */         }
/*  82: 76 */         else if (succ.id == graph.getLast().id)
/*  83:    */         {
/*  84: 77 */           int type = 4;
/*  85: 78 */           stsucc = dummyexit;
/*  86:    */         }
/*  87:    */         else
/*  88:    */         {
/*  89: 81 */           type = 1;
/*  90:    */         }
/*  91: 84 */         stat.addSuccessor(new StatEdge(type, stat, type == 8 ? general : stsucc, type == 1 ? null : general));
/*  92:    */       }
/*  93: 89 */       for (BasicBlock succex : block.getSuccExceptions())
/*  94:    */       {
/*  95: 90 */         Statement stsuccex = (Statement)stats.getWithKey(Integer.valueOf(succex.id));
/*  96:    */         
/*  97: 92 */         ExceptionRangeCFG range = graph.getExceptionRange(succex, block);
/*  98: 93 */         if (!range.isCircular()) {
/*  99: 94 */           stat.addSuccessor(new StatEdge(stat, stsuccex, range.getExceptionTypes()));
/* 100:    */         }
/* 101:    */       }
/* 102:    */     }
/* 103:    */     BasicBlock block;
/* 104:    */     Statement stat;
/* 105: 99 */     general.buildContinueSet();
/* 106:100 */     general.buildMonitorFlags();
/* 107:101 */     return new RootStatement(general, dummyexit);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static VBStyleCollection<List<Integer>, Integer> calcPostDominators(Statement container)
/* 111:    */   {
/* 112:106 */     HashMap<Statement, FastFixedSetFactory.FastFixedSet<Statement>> lists = new HashMap();
/* 113:    */     
/* 114:108 */     StrongConnectivityHelper schelper = new StrongConnectivityHelper(container);
/* 115:109 */     List<List<Statement>> components = schelper.getComponents();
/* 116:    */     
/* 117:111 */     List<Statement> lstStats = container.getPostReversePostOrderList(StrongConnectivityHelper.getExitReps(components));
/* 118:    */     
/* 119:113 */     FastFixedSetFactory<Statement> factory = new FastFixedSetFactory(lstStats);
/* 120:    */     
/* 121:115 */     FastFixedSetFactory.FastFixedSet<Statement> setFlagNodes = factory.spawnEmptySet();
/* 122:116 */     setFlagNodes.setAllElements();
/* 123:    */     
/* 124:118 */     FastFixedSetFactory.FastFixedSet<Statement> initSet = factory.spawnEmptySet();
/* 125:119 */     initSet.setAllElements();
/* 126:121 */     for (List<Statement> lst : components)
/* 127:    */     {
/* 128:124 */       if (StrongConnectivityHelper.isExitComponent(lst))
/* 129:    */       {
/* 130:125 */         FastFixedSetFactory.FastFixedSet<Statement> tmpSet = factory.spawnEmptySet();
/* 131:126 */         tmpSet.addAll(lst);
/* 132:    */       }
/* 133:    */       else
/* 134:    */       {
/* 135:129 */         tmpSet = initSet.getCopy();
/* 136:    */       }
/* 137:132 */       for (Statement stat : lst) {
/* 138:133 */         lists.put(stat, tmpSet);
/* 139:    */       }
/* 140:    */     }
/* 141:    */     FastFixedSetFactory.FastFixedSet<Statement> tmpSet;
/* 142:    */     do
/* 143:    */     {
/* 144:139 */       for (Statement stat : lstStats) {
/* 145:141 */         if (setFlagNodes.contains(stat))
/* 146:    */         {
/* 147:144 */           setFlagNodes.remove(stat);
/* 148:    */           
/* 149:146 */           FastFixedSetFactory.FastFixedSet<Statement> doms = (FastFixedSetFactory.FastFixedSet)lists.get(stat);
/* 150:147 */           FastFixedSetFactory.FastFixedSet<Statement> domsSuccs = factory.spawnEmptySet();
/* 151:    */           
/* 152:149 */           List<Statement> lstSuccs = stat.getNeighbours(1, 1);
/* 153:150 */           for (int j = 0; j < lstSuccs.size(); j++)
/* 154:    */           {
/* 155:151 */             Statement succ = (Statement)lstSuccs.get(j);
/* 156:152 */             FastFixedSetFactory.FastFixedSet<Statement> succlst = (FastFixedSetFactory.FastFixedSet)lists.get(succ);
/* 157:154 */             if (j == 0) {
/* 158:155 */               domsSuccs.union(succlst);
/* 159:    */             } else {
/* 160:158 */               domsSuccs.intersection(succlst);
/* 161:    */             }
/* 162:    */           }
/* 163:162 */           if (!domsSuccs.contains(stat)) {
/* 164:163 */             domsSuccs.add(stat);
/* 165:    */           }
/* 166:166 */           if (!InterpreterUtil.equalObjects(domsSuccs, doms))
/* 167:    */           {
/* 168:168 */             lists.put(stat, domsSuccs);
/* 169:    */             
/* 170:170 */             List<Statement> lstPreds = stat.getNeighbours(1, 0);
/* 171:171 */             for (Statement pred : lstPreds) {
/* 172:172 */               setFlagNodes.add(pred);
/* 173:    */             }
/* 174:    */           }
/* 175:    */         }
/* 176:    */       }
/* 177:177 */     } while (!setFlagNodes.isEmpty());
/* 178:179 */     VBStyleCollection<List<Integer>, Integer> ret = new VBStyleCollection();
/* 179:180 */     List<Statement> lstRevPost = container.getReversePostOrderList();
/* 180:    */     
/* 181:182 */     HashMap<Integer, Integer> mapSortOrder = new HashMap();
/* 182:183 */     for (int i = 0; i < lstRevPost.size(); i++) {
/* 183:184 */       mapSortOrder.put(((Statement)lstRevPost.get(i)).id, Integer.valueOf(i));
/* 184:    */     }
/* 185:187 */     for (Statement st : lstStats)
/* 186:    */     {
/* 187:189 */       List<Integer> lstPosts = new ArrayList();
/* 188:190 */       for (Statement stt : (FastFixedSetFactory.FastFixedSet)lists.get(st)) {
/* 189:191 */         lstPosts.add(stt.id);
/* 190:    */       }
/* 191:194 */       Collections.sort(lstPosts, new Comparator()
/* 192:    */       {
/* 193:    */         public int compare(Integer o1, Integer o2)
/* 194:    */         {
/* 195:196 */           return ((Integer)this.val$mapSortOrder.get(o1)).compareTo((Integer)this.val$mapSortOrder.get(o2));
/* 196:    */         }
/* 197:    */       });
/* 198:200 */       if ((lstPosts.size() > 1) && (((Integer)lstPosts.get(0)).intValue() == st.id.intValue())) {
/* 199:201 */         lstPosts.add(lstPosts.remove(0));
/* 200:    */       }
/* 201:204 */       ret.addWithKey(lstPosts, st.id);
/* 202:    */     }
/* 203:207 */     return ret;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static RootStatement parseGraph(ControlFlowGraph graph)
/* 207:    */   {
/* 208:212 */     RootStatement root = graphToStatement(graph);
/* 209:214 */     if (!processStatement(root, new HashMap())) {
/* 210:221 */       throw new RuntimeException("parsing failure!");
/* 211:    */     }
/* 212:224 */     LabelHelper.lowContinueLabels(root, new HashSet());
/* 213:    */     
/* 214:226 */     SequenceHelper.condenseSequences(root);
/* 215:227 */     root.buildMonitorFlags();
/* 216:    */     
/* 217:    */ 
/* 218:230 */     buildSynchronized(root);
/* 219:    */     
/* 220:232 */     return root;
/* 221:    */   }
/* 222:    */   
/* 223:    */   public static void removeSynchronizedHandler(Statement stat)
/* 224:    */   {
/* 225:237 */     for (Statement st : stat.getStats()) {
/* 226:238 */       removeSynchronizedHandler(st);
/* 227:    */     }
/* 228:241 */     if (stat.type == 10) {
/* 229:242 */       ((SynchronizedStatement)stat).removeExc();
/* 230:    */     }
/* 231:    */   }
/* 232:    */   
/* 233:    */   private static void buildSynchronized(Statement stat)
/* 234:    */   {
/* 235:249 */     for (Statement st : stat.getStats()) {
/* 236:250 */       buildSynchronized(st);
/* 237:    */     }
/* 238:253 */     if (stat.type == 15) {
/* 239:    */       for (;;)
/* 240:    */       {
/* 241:257 */         boolean found = false;
/* 242:    */         
/* 243:259 */         List<Statement> lst = stat.getStats();
/* 244:260 */         for (int i = 0; i < lst.size() - 1; i++)
/* 245:    */         {
/* 246:261 */           Statement current = (Statement)lst.get(i);
/* 247:263 */           if (current.isMonitorEnter())
/* 248:    */           {
/* 249:265 */             Statement next = (Statement)lst.get(i + 1);
/* 250:266 */             Statement nextDirect = next;
/* 251:268 */             while (next.type == 15) {
/* 252:269 */               next = next.getFirst();
/* 253:    */             }
/* 254:272 */             if (next.type == 12)
/* 255:    */             {
/* 256:274 */               CatchAllStatement ca = (CatchAllStatement)next;
/* 257:276 */               if ((ca.getFirst().isContainsMonitorExit()) && (ca.getHandler().isContainsMonitorExit()))
/* 258:    */               {
/* 259:279 */                 current.removeSuccessor((StatEdge)current.getSuccessorEdges(1073741824).get(0));
/* 260:281 */                 for (StatEdge edge : current.getPredecessorEdges(1073741824))
/* 261:    */                 {
/* 262:282 */                   current.removePredecessor(edge);
/* 263:283 */                   edge.getSource().changeEdgeNode(1, edge, nextDirect);
/* 264:284 */                   nextDirect.addPredecessor(edge);
/* 265:    */                 }
/* 266:287 */                 stat.getStats().removeWithKey(current.id);
/* 267:288 */                 stat.setFirst((Statement)stat.getStats().get(0));
/* 268:    */                 
/* 269:    */ 
/* 270:291 */                 SynchronizedStatement sync = new SynchronizedStatement(current, ca.getFirst(), ca.getHandler());
/* 271:292 */                 sync.setAllParent();
/* 272:294 */                 for (StatEdge edge : new HashSet(ca.getLabelEdges())) {
/* 273:295 */                   sync.addLabeledEdge(edge);
/* 274:    */                 }
/* 275:298 */                 current.addSuccessor(new StatEdge(1, current, ca.getFirst()));
/* 276:    */                 
/* 277:300 */                 ca.getParent().replaceStatement(ca, sync);
/* 278:301 */                 found = true;
/* 279:302 */                 break;
/* 280:    */               }
/* 281:    */             }
/* 282:    */           }
/* 283:    */         }
/* 284:308 */         if (!found) {
/* 285:    */           break;
/* 286:    */         }
/* 287:    */       }
/* 288:    */     }
/* 289:    */   }
/* 290:    */   
/* 291:    */   private static boolean processStatement(Statement general, HashMap<Integer, Set<Integer>> mapExtPost)
/* 292:    */   {
/* 293:317 */     if (general.type == 13)
/* 294:    */     {
/* 295:318 */       Statement stat = general.getFirst();
/* 296:319 */       if (stat.type != 0) {
/* 297:320 */         return true;
/* 298:    */       }
/* 299:323 */       boolean complete = processStatement(stat, mapExtPost);
/* 300:324 */       if (complete) {
/* 301:326 */         general.replaceStatement(stat, stat.getFirst());
/* 302:    */       }
/* 303:328 */       return complete;
/* 304:    */     }
/* 305:332 */     boolean mapRefreshed = mapExtPost.isEmpty();
/* 306:334 */     for (int mapstage = 0; mapstage < 2; mapstage++)
/* 307:    */     {
/* 308:336 */       for (int reducibility = 0; reducibility < 5; reducibility++)
/* 309:    */       {
/* 310:340 */         if (reducibility > 0)
/* 311:    */         {
/* 312:347 */           if (IrreducibleCFGDeobfuscator.isStatementIrreducible(general))
/* 313:    */           {
/* 314:348 */             if (!IrreducibleCFGDeobfuscator.splitIrreducibleNode(general))
/* 315:    */             {
/* 316:349 */               DecompilerContext.getLogger().writeMessage("Irreducible statement cannot be decomposed!", IFernflowerLogger.Severity.ERROR);
/* 317:350 */               break;
/* 318:    */             }
/* 319:    */           }
/* 320:    */           else
/* 321:    */           {
/* 322:354 */             if ((mapstage != 2) && (!mapRefreshed)) {
/* 323:    */               break;
/* 324:    */             }
/* 325:355 */             DecompilerContext.getLogger().writeMessage("Statement cannot be decomposed although reducible!", IFernflowerLogger.Severity.ERROR); break;
/* 326:    */           }
/* 327:364 */           mapExtPost = new HashMap();
/* 328:365 */           mapRefreshed = true;
/* 329:    */         }
/* 330:368 */         for (int i = 0; i < 2; i++)
/* 331:    */         {
/* 332:370 */           boolean forceall = i != 0;
/* 333:    */           for (;;)
/* 334:    */           {
/* 335:374 */             if (findSimpleStatements(general, mapExtPost)) {
/* 336:375 */               reducibility = 0;
/* 337:    */             }
/* 338:378 */             if (general.type == 11) {
/* 339:379 */               return true;
/* 340:    */             }
/* 341:382 */             Statement stat = findGeneralStatement(general, forceall, mapExtPost);
/* 342:384 */             if (stat == null) {
/* 343:    */               break;
/* 344:    */             }
/* 345:385 */             boolean complete = processStatement(stat, general.getFirst() == stat ? mapExtPost : new HashMap());
/* 346:387 */             if (complete) {
/* 347:389 */               general.replaceStatement(stat, stat.getFirst());
/* 348:    */             } else {
/* 349:392 */               return false;
/* 350:    */             }
/* 351:395 */             mapExtPost = new HashMap();
/* 352:396 */             mapRefreshed = true;
/* 353:397 */             reducibility = 0;
/* 354:    */           }
/* 355:    */         }
/* 356:    */       }
/* 357:412 */       if (mapRefreshed) {
/* 358:    */         break;
/* 359:    */       }
/* 360:416 */       mapExtPost = new HashMap();
/* 361:    */     }
/* 362:420 */     return false;
/* 363:    */   }
/* 364:    */   
/* 365:    */   private static Statement findGeneralStatement(Statement stat, boolean forceall, HashMap<Integer, Set<Integer>> mapExtPost)
/* 366:    */   {
/* 367:425 */     VBStyleCollection<Statement, Integer> stats = stat.getStats();
/* 368:428 */     if (mapExtPost.isEmpty())
/* 369:    */     {
/* 370:429 */       FastExtendedPostdominanceHelper extpost = new FastExtendedPostdominanceHelper();
/* 371:430 */       mapExtPost.putAll(extpost.getExtendedPostdominators(stat));
/* 372:    */     }
/* 373:    */     VBStyleCollection<List<Integer>, Integer> vbPost;
/* 374:    */     VBStyleCollection<List<Integer>, Integer> vbPost;
/* 375:433 */     if (forceall)
/* 376:    */     {
/* 377:434 */       vbPost = new VBStyleCollection();
/* 378:435 */       List<Statement> lstAll = stat.getPostReversePostOrderList();
/* 379:437 */       for (Statement st : lstAll)
/* 380:    */       {
/* 381:438 */         Set<Integer> set = (Set)mapExtPost.get(st.id);
/* 382:439 */         if (set != null) {
/* 383:440 */           vbPost.addWithKey(new ArrayList(set), st.id);
/* 384:    */         }
/* 385:    */       }
/* 386:445 */       Set<Integer> setFirst = (Set)mapExtPost.get(stat.getFirst().id);
/* 387:446 */       if (setFirst != null) {
/* 388:447 */         for (Integer id : setFirst)
/* 389:    */         {
/* 390:448 */           List<Integer> lst = (List)vbPost.getWithKey(id);
/* 391:449 */           if (lst == null) {
/* 392:450 */             vbPost.addWithKey(lst = new ArrayList(), id);
/* 393:    */           }
/* 394:452 */           lst.add(id);
/* 395:    */         }
/* 396:    */       }
/* 397:    */     }
/* 398:    */     else
/* 399:    */     {
/* 400:457 */       vbPost = calcPostDominators(stat);
/* 401:    */     }
/* 402:460 */     for (int k = 0; k < vbPost.size(); k++)
/* 403:    */     {
/* 404:462 */       Integer headid = (Integer)vbPost.getKey(k);
/* 405:463 */       List<Integer> posts = (List)vbPost.get(k);
/* 406:465 */       if ((mapExtPost.containsKey(headid)) || ((posts.size() == 1) && (((Integer)posts.get(0)).equals(headid))))
/* 407:    */       {
/* 408:470 */         Statement head = (Statement)stats.getWithKey(headid);
/* 409:    */         
/* 410:472 */         Set<Integer> setExtPosts = (Set)mapExtPost.get(headid);
/* 411:474 */         for (int i = 0; i < posts.size(); i++)
/* 412:    */         {
/* 413:476 */           Integer postid = (Integer)posts.get(i);
/* 414:477 */           if ((postid.equals(headid)) || (setExtPosts.contains(postid)))
/* 415:    */           {
/* 416:481 */             Statement post = (Statement)stats.getWithKey(postid);
/* 417:483 */             if (post != null)
/* 418:    */             {
/* 419:487 */               boolean same = post == head;
/* 420:    */               
/* 421:489 */               HashSet<Statement> setNodes = new HashSet();
/* 422:490 */               HashSet<Statement> setPreds = new HashSet();
/* 423:    */               
/* 424:    */ 
/* 425:493 */               HashSet<Statement> setHandlers = new HashSet();
/* 426:494 */               setHandlers.add(head);
/* 427:    */               for (;;)
/* 428:    */               {
/* 429:497 */                 boolean hdfound = false;
/* 430:498 */                 for (Statement handler : setHandlers) {
/* 431:499 */                   if (!setNodes.contains(handler))
/* 432:    */                   {
/* 433:503 */                     boolean addhd = setNodes.size() == 0;
/* 434:504 */                     if (!addhd)
/* 435:    */                     {
/* 436:505 */                       List<Statement> hdsupp = handler.getNeighbours(2, 0);
/* 437:506 */                       addhd = (setNodes.containsAll(hdsupp)) && ((setNodes.size() > hdsupp.size()) || (setNodes.size() == 1));
/* 438:    */                     }
/* 439:510 */                     if (addhd)
/* 440:    */                     {
/* 441:511 */                       LinkedList<Statement> lstStack = new LinkedList();
/* 442:512 */                       lstStack.add(handler);
/* 443:514 */                       while (!lstStack.isEmpty())
/* 444:    */                       {
/* 445:515 */                         Statement st = (Statement)lstStack.remove(0);
/* 446:517 */                         if ((!setNodes.contains(st)) && ((same) || (st != post)))
/* 447:    */                         {
/* 448:518 */                           setNodes.add(st);
/* 449:519 */                           if (st != head) {
/* 450:521 */                             setPreds.addAll(st.getNeighbours(1, 0));
/* 451:    */                           }
/* 452:525 */                           lstStack.addAll(st.getNeighbours(1, 1));
/* 453:    */                           
/* 454:    */ 
/* 455:528 */                           setHandlers.addAll(st.getNeighbours(2, 1));
/* 456:    */                         }
/* 457:    */                       }
/* 458:532 */                       hdfound = true;
/* 459:533 */                       setHandlers.remove(handler);
/* 460:534 */                       break;
/* 461:    */                     }
/* 462:    */                   }
/* 463:    */                 }
/* 464:538 */                 if (!hdfound) {
/* 465:    */                   break;
/* 466:    */                 }
/* 467:    */               }
/* 468:544 */               setHandlers.clear();
/* 469:545 */               for (Statement st : setNodes) {
/* 470:546 */                 setHandlers.addAll(st.getNeighbours(2, 1));
/* 471:    */               }
/* 472:548 */               setHandlers.removeAll(setNodes);
/* 473:    */               
/* 474:550 */               boolean excok = true;
/* 475:551 */               for (Statement handler : setHandlers) {
/* 476:552 */                 if (!handler.getNeighbours(2, 0).containsAll(setNodes))
/* 477:    */                 {
/* 478:553 */                   excok = false;
/* 479:554 */                   break;
/* 480:    */                 }
/* 481:    */               }
/* 482:559 */               if (excok)
/* 483:    */               {
/* 484:560 */                 Statement res = null;
/* 485:    */                 
/* 486:562 */                 setPreds.removeAll(setNodes);
/* 487:563 */                 if ((setPreds.size() == 0) && 
/* 488:564 */                   ((setNodes.size() > 1) || (head.getNeighbours(1, 0).contains(head))) && (setNodes.size() < stats.size())) {
/* 489:567 */                   if (checkSynchronizedCompleteness(head, setNodes))
/* 490:    */                   {
/* 491:568 */                     res = new GeneralStatement(head, setNodes, same ? null : post);
/* 492:569 */                     stat.collapseNodesToStatement(res);
/* 493:    */                     
/* 494:571 */                     return res;
/* 495:    */                   }
/* 496:    */                 }
/* 497:    */               }
/* 498:    */             }
/* 499:    */           }
/* 500:    */         }
/* 501:    */       }
/* 502:    */     }
/* 503:579 */     return null;
/* 504:    */   }
/* 505:    */   
/* 506:    */   private static boolean checkSynchronizedCompleteness(Statement head, HashSet<Statement> setNodes)
/* 507:    */   {
/* 508:585 */     for (Statement stat : setNodes) {
/* 509:586 */       if (stat.isMonitorEnter())
/* 510:    */       {
/* 511:587 */         List<StatEdge> lstSuccs = stat.getSuccessorEdges(1073741824);
/* 512:588 */         if ((lstSuccs.size() != 1) || (((StatEdge)lstSuccs.get(0)).getType() != 1)) {
/* 513:589 */           return false;
/* 514:    */         }
/* 515:592 */         if (!setNodes.contains(((StatEdge)lstSuccs.get(0)).getDestination())) {
/* 516:593 */           return false;
/* 517:    */         }
/* 518:    */       }
/* 519:    */     }
/* 520:598 */     return true;
/* 521:    */   }
/* 522:    */   
/* 523:    */   private static boolean findSimpleStatements(Statement stat, HashMap<Integer, Set<Integer>> mapExtPost)
/* 524:    */   {
/* 525:603 */     boolean success = false;
/* 526:    */     boolean found;
/* 527:    */     do
/* 528:    */     {
/* 529:606 */       found = false;
/* 530:    */       
/* 531:608 */       List<Statement> lstStats = stat.getPostReversePostOrderList();
/* 532:609 */       for (Statement st : lstStats)
/* 533:    */       {
/* 534:611 */         Statement result = detectStatement(st);
/* 535:613 */         if (result != null)
/* 536:    */         {
/* 537:615 */           if ((stat.type == 0) && (result.getFirst() == stat.getFirst()) && (stat.getStats().size() == result.getStats().size())) {
/* 538:618 */             stat.type = 11;
/* 539:    */           }
/* 540:621 */           stat.collapseNodesToStatement(result);
/* 541:    */           HashSet<Integer> setOldNodes;
/* 542:    */           Integer newid;
/* 543:624 */           if (!mapExtPost.isEmpty())
/* 544:    */           {
/* 545:625 */             setOldNodes = new HashSet();
/* 546:626 */             for (Statement old : result.getStats()) {
/* 547:627 */               setOldNodes.add(old.id);
/* 548:    */             }
/* 549:630 */             newid = result.id;
/* 550:632 */             for (Integer key : new ArrayList(mapExtPost.keySet()))
/* 551:    */             {
/* 552:633 */               Set<Integer> set = (Set)mapExtPost.get(key);
/* 553:    */               
/* 554:635 */               int oldsize = set.size();
/* 555:636 */               set.removeAll(setOldNodes);
/* 556:638 */               if (setOldNodes.contains(key))
/* 557:    */               {
/* 558:639 */                 Set<Integer> setNew = (Set)mapExtPost.get(newid);
/* 559:640 */                 if (setNew == null) {
/* 560:641 */                   mapExtPost.put(newid, setNew = new HashSet());
/* 561:    */                 }
/* 562:643 */                 setNew.addAll(set);
/* 563:    */                 
/* 564:645 */                 mapExtPost.remove(key);
/* 565:    */               }
/* 566:648 */               else if (set.size() < oldsize)
/* 567:    */               {
/* 568:649 */                 set.add(newid);
/* 569:    */               }
/* 570:    */             }
/* 571:    */           }
/* 572:656 */           found = true;
/* 573:657 */           break;
/* 574:    */         }
/* 575:    */       }
/* 576:661 */       if (found) {
/* 577:662 */         success = true;
/* 578:    */       }
/* 579:665 */     } while (found);
/* 580:667 */     return success;
/* 581:    */   }
/* 582:    */   
/* 583:    */   private static Statement detectStatement(Statement head)
/* 584:    */   {
/* 585:    */     Statement res;
/* 586:675 */     if ((res = DoStatement.isHead(head)) != null) {
/* 587:676 */       return res;
/* 588:    */     }
/* 589:679 */     if ((res = SwitchStatement.isHead(head)) != null) {
/* 590:680 */       return res;
/* 591:    */     }
/* 592:683 */     if ((res = IfStatement.isHead(head)) != null) {
/* 593:684 */       return res;
/* 594:    */     }
/* 595:690 */     if ((res = SequenceStatement.isHead2Block(head)) != null) {
/* 596:691 */       return res;
/* 597:    */     }
/* 598:694 */     if ((res = CatchStatement.isHead(head)) != null) {
/* 599:695 */       return res;
/* 600:    */     }
/* 601:698 */     if ((res = CatchAllStatement.isHead(head)) != null) {
/* 602:699 */       return res;
/* 603:    */     }
/* 604:702 */     return null;
/* 605:    */   }
/* 606:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.DomHelper
 * JD-Core Version:    0.7.0.1
 */