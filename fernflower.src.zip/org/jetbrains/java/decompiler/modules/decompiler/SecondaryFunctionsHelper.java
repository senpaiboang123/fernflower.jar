/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.List;
/*   7:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*   8:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.IfExprent;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  19:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  20:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  21:    */ 
/*  22:    */ public class SecondaryFunctionsHelper
/*  23:    */ {
/*  24: 35 */   private static final int[] funcsnot = { 43, 42, 45, 44, 47, 46, 49, 48 };
/*  25: 46 */   private static final HashMap<Integer, Integer[]> mapNumComparisons = new HashMap();
/*  26:    */   
/*  27:    */   static
/*  28:    */   {
/*  29: 49 */     mapNumComparisons.put(Integer.valueOf(42), new Integer[] { Integer.valueOf(44), Integer.valueOf(42), Integer.valueOf(46) });
/*  30:    */     
/*  31: 51 */     mapNumComparisons.put(Integer.valueOf(43), new Integer[] { Integer.valueOf(45), Integer.valueOf(43), Integer.valueOf(47) });
/*  32:    */     
/*  33: 53 */     mapNumComparisons.put(Integer.valueOf(46), new Integer[] { Integer.valueOf(45), Integer.valueOf(46), null });
/*  34: 54 */     mapNumComparisons.put(Integer.valueOf(45), new Integer[] { null, Integer.valueOf(45), Integer.valueOf(46) });
/*  35: 55 */     mapNumComparisons.put(Integer.valueOf(44), new Integer[] { null, Integer.valueOf(44), Integer.valueOf(47) });
/*  36: 56 */     mapNumComparisons.put(Integer.valueOf(47), new Integer[] { Integer.valueOf(44), Integer.valueOf(47), null });
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static boolean identifySecondaryFunctions(Statement stat)
/*  40:    */   {
/*  41: 62 */     if (stat.getExprents() == null) {
/*  42: 64 */       if (stat.type == 2)
/*  43:    */       {
/*  44: 65 */         IfStatement ifelsestat = (IfStatement)stat;
/*  45: 66 */         Statement ifstat = ifelsestat.getIfstat();
/*  46: 68 */         if ((ifelsestat.iftype == 1) && (ifstat.getExprents() != null) && (ifstat.getExprents().isEmpty()) && ((ifstat.getAllSuccessorEdges().isEmpty()) || (!((StatEdge)ifstat.getAllSuccessorEdges().get(0)).explicit)))
/*  47:    */         {
/*  48: 72 */           ifelsestat.getStats().removeWithKey(ifstat.id);
/*  49:    */           
/*  50: 74 */           ifelsestat.iftype = 0;
/*  51: 75 */           ifelsestat.setIfstat(ifelsestat.getElsestat());
/*  52: 76 */           ifelsestat.setElsestat(null);
/*  53: 78 */           if ((ifelsestat.getAllSuccessorEdges().isEmpty()) && (!ifstat.getAllSuccessorEdges().isEmpty()))
/*  54:    */           {
/*  55: 79 */             StatEdge endedge = (StatEdge)ifstat.getAllSuccessorEdges().get(0);
/*  56:    */             
/*  57: 81 */             ifstat.removeSuccessor(endedge);
/*  58: 82 */             endedge.setSource(ifelsestat);
/*  59: 83 */             if (endedge.closure != null) {
/*  60: 84 */               ifelsestat.getParent().addLabeledEdge(endedge);
/*  61:    */             }
/*  62: 86 */             ifelsestat.addSuccessor(endedge);
/*  63:    */           }
/*  64: 89 */           ifelsestat.getFirst().removeSuccessor(ifelsestat.getIfEdge());
/*  65:    */           
/*  66: 91 */           ifelsestat.setIfEdge(ifelsestat.getElseEdge());
/*  67: 92 */           ifelsestat.setElseEdge(null);
/*  68:    */           
/*  69:    */ 
/*  70: 95 */           ifelsestat.setNegated(!ifelsestat.isNegated());
/*  71: 96 */           ifelsestat.getHeadexprentList().set(0, ((IfExprent)ifelsestat.getHeadexprent().copy()).negateIf());
/*  72:    */           
/*  73: 98 */           return true;
/*  74:    */         }
/*  75:    */       }
/*  76:    */     }
/*  77:104 */     boolean replaced = true;
/*  78:105 */     while (replaced)
/*  79:    */     {
/*  80:106 */       replaced = false;
/*  81:    */       
/*  82:108 */       List<Object> lstObjects = new ArrayList(stat.getExprents() == null ? stat.getSequentialObjects() : stat.getExprents());
/*  83:110 */       for (int i = 0; i < lstObjects.size(); i++)
/*  84:    */       {
/*  85:111 */         Object obj = lstObjects.get(i);
/*  86:113 */         if ((obj instanceof Statement))
/*  87:    */         {
/*  88:114 */           if (identifySecondaryFunctions((Statement)obj))
/*  89:    */           {
/*  90:115 */             replaced = true;
/*  91:116 */             break;
/*  92:    */           }
/*  93:    */         }
/*  94:119 */         else if ((obj instanceof Exprent))
/*  95:    */         {
/*  96:120 */           Exprent retexpr = identifySecondaryFunctions((Exprent)obj, true);
/*  97:121 */           if (retexpr != null)
/*  98:    */           {
/*  99:122 */             if (stat.getExprents() == null) {
/* 100:124 */               stat.replaceExprent((Exprent)obj, retexpr);
/* 101:    */             } else {
/* 102:127 */               stat.getExprents().set(i, retexpr);
/* 103:    */             }
/* 104:129 */             replaced = true;
/* 105:130 */             break;
/* 106:    */           }
/* 107:    */         }
/* 108:    */       }
/* 109:    */     }
/* 110:136 */     return false;
/* 111:    */   }
/* 112:    */   
/* 113:    */   private static Exprent identifySecondaryFunctions(Exprent exprent, boolean statement_level)
/* 114:    */   {
/* 115:142 */     if (exprent.type == 6)
/* 116:    */     {
/* 117:143 */       FunctionExprent fexpr = (FunctionExprent)exprent;
/* 118:145 */       switch (fexpr.getFuncType())
/* 119:    */       {
/* 120:    */       case 12: 
/* 121:148 */         Exprent retparam = propagateBoolNot(fexpr);
/* 122:150 */         if (retparam != null) {
/* 123:151 */           return retparam;
/* 124:    */         }
/* 125:    */         break;
/* 126:    */       case 42: 
/* 127:    */       case 43: 
/* 128:    */       case 44: 
/* 129:    */       case 45: 
/* 130:    */       case 46: 
/* 131:    */       case 47: 
/* 132:161 */         Exprent expr1 = (Exprent)fexpr.getLstOperands().get(0);
/* 133:162 */         Exprent expr2 = (Exprent)fexpr.getLstOperands().get(1);
/* 134:164 */         if (expr1.type == 3)
/* 135:    */         {
/* 136:165 */           expr2 = expr1;
/* 137:166 */           expr1 = (Exprent)fexpr.getLstOperands().get(1);
/* 138:    */         }
/* 139:169 */         if ((expr1.type == 6) && (expr2.type == 3))
/* 140:    */         {
/* 141:170 */           FunctionExprent funcexpr = (FunctionExprent)expr1;
/* 142:171 */           ConstExprent cexpr = (ConstExprent)expr2;
/* 143:    */           
/* 144:173 */           int functype = funcexpr.getFuncType();
/* 145:174 */           if ((functype == 37) || (functype == 39) || (functype == 38) || (functype == 41) || (functype == 40))
/* 146:    */           {
/* 147:178 */             int desttype = -1;
/* 148:    */             
/* 149:180 */             Integer[] destcons = (Integer[])mapNumComparisons.get(Integer.valueOf(fexpr.getFuncType()));
/* 150:181 */             if (destcons != null)
/* 151:    */             {
/* 152:182 */               int index = cexpr.getIntValue() + 1;
/* 153:183 */               if ((index >= 0) && (index <= 2))
/* 154:    */               {
/* 155:184 */                 Integer destcon = destcons[index];
/* 156:185 */                 if (destcon != null) {
/* 157:186 */                   desttype = destcon.intValue();
/* 158:    */                 }
/* 159:    */               }
/* 160:    */             }
/* 161:191 */             if (desttype >= 0) {
/* 162:192 */               return new FunctionExprent(desttype, funcexpr.getLstOperands(), funcexpr.bytecode);
/* 163:    */             }
/* 164:    */           }
/* 165:    */         }
/* 166:    */         break;
/* 167:    */       }
/* 168:    */     }
/* 169:200 */     boolean replaced = true;
/* 170:201 */     while (replaced)
/* 171:    */     {
/* 172:202 */       replaced = false;
/* 173:204 */       for (Exprent expr : exprent.getAllExprents())
/* 174:    */       {
/* 175:205 */         Exprent retexpr = identifySecondaryFunctions(expr, false);
/* 176:206 */         if (retexpr != null)
/* 177:    */         {
/* 178:207 */           exprent.replaceExprent(expr, retexpr);
/* 179:208 */           replaced = true;
/* 180:209 */           break;
/* 181:    */         }
/* 182:    */       }
/* 183:    */     }
/* 184:214 */     switch (exprent.type)
/* 185:    */     {
/* 186:    */     case 6: 
/* 187:216 */       FunctionExprent fexpr = (FunctionExprent)exprent;
/* 188:217 */       List<Exprent> lstOperands = fexpr.getLstOperands();
/* 189:219 */       switch (fexpr.getFuncType())
/* 190:    */       {
/* 191:    */       case 6: 
/* 192:221 */         for (int i = 0; i < 2; i++)
/* 193:    */         {
/* 194:222 */           Exprent operand = (Exprent)lstOperands.get(i);
/* 195:223 */           VarType operandtype = operand.getExprType();
/* 196:225 */           if ((operand.type == 3) && (operandtype.type != 7))
/* 197:    */           {
/* 198:227 */             ConstExprent cexpr = (ConstExprent)operand;
/* 199:    */             long val;
/* 200:    */             long val;
/* 201:229 */             if (operandtype.type == 5) {
/* 202:230 */               val = ((Long)cexpr.getValue()).longValue();
/* 203:    */             } else {
/* 204:233 */               val = ((Integer)cexpr.getValue()).intValue();
/* 205:    */             }
/* 206:236 */             if (val == -1L)
/* 207:    */             {
/* 208:237 */               List<Exprent> lstBitNotOperand = new ArrayList();
/* 209:238 */               lstBitNotOperand.add(lstOperands.get(1 - i));
/* 210:239 */               return new FunctionExprent(11, lstBitNotOperand, fexpr.bytecode);
/* 211:    */             }
/* 212:    */           }
/* 213:    */         }
/* 214:243 */         break;
/* 215:    */       case 42: 
/* 216:    */       case 43: 
/* 217:246 */         if ((((Exprent)lstOperands.get(0)).getExprType().type == 7) && (((Exprent)lstOperands.get(1)).getExprType().type == 7)) {
/* 218:248 */           for (int i = 0; i < 2; i++) {
/* 219:249 */             if (((Exprent)lstOperands.get(i)).type == 3)
/* 220:    */             {
/* 221:250 */               ConstExprent cexpr = (ConstExprent)lstOperands.get(i);
/* 222:251 */               int val = ((Integer)cexpr.getValue()).intValue();
/* 223:253 */               if (((fexpr.getFuncType() == 42) && (val == 1)) || ((fexpr.getFuncType() == 43) && (val == 0))) {
/* 224:255 */                 return (Exprent)lstOperands.get(1 - i);
/* 225:    */               }
/* 226:258 */               List<Exprent> lstNotOperand = new ArrayList();
/* 227:259 */               lstNotOperand.add(lstOperands.get(1 - i));
/* 228:260 */               return new FunctionExprent(12, lstNotOperand, fexpr.bytecode);
/* 229:    */             }
/* 230:    */           }
/* 231:    */         }
/* 232:    */         break;
/* 233:    */       case 12: 
/* 234:267 */         if (((Exprent)lstOperands.get(0)).type == 3)
/* 235:    */         {
/* 236:268 */           int val = ((ConstExprent)lstOperands.get(0)).getIntValue();
/* 237:269 */           if (val == 0) {
/* 238:270 */             return new ConstExprent(VarType.VARTYPE_BOOLEAN, new Integer(1), fexpr.bytecode);
/* 239:    */           }
/* 240:273 */           return new ConstExprent(VarType.VARTYPE_BOOLEAN, new Integer(0), fexpr.bytecode);
/* 241:    */         }
/* 242:    */         break;
/* 243:    */       case 36: 
/* 244:278 */         Exprent expr1 = (Exprent)lstOperands.get(1);
/* 245:279 */         Exprent expr2 = (Exprent)lstOperands.get(2);
/* 246:281 */         if ((expr1.type == 3) && (expr2.type == 3))
/* 247:    */         {
/* 248:282 */           ConstExprent cexpr1 = (ConstExprent)expr1;
/* 249:283 */           ConstExprent cexpr2 = (ConstExprent)expr2;
/* 250:285 */           if ((cexpr1.getExprType().type == 7) && (cexpr2.getExprType().type == 7))
/* 251:    */           {
/* 252:288 */             if ((cexpr1.getIntValue() == 0) && (cexpr2.getIntValue() != 0)) {
/* 253:289 */               return new FunctionExprent(12, (Exprent)lstOperands.get(0), fexpr.bytecode);
/* 254:    */             }
/* 255:291 */             if ((cexpr1.getIntValue() != 0) && (cexpr2.getIntValue() == 0)) {
/* 256:292 */               return (Exprent)lstOperands.get(0);
/* 257:    */             }
/* 258:    */           }
/* 259:    */         }
/* 260:295 */         break;
/* 261:    */       case 37: 
/* 262:    */       case 38: 
/* 263:    */       case 39: 
/* 264:    */       case 40: 
/* 265:    */       case 41: 
/* 266:302 */         int var = DecompilerContext.getCounterContainer().getCounterAndIncrement(2);
/* 267:303 */         VarType type = ((Exprent)lstOperands.get(0)).getExprType();
/* 268:304 */         VarProcessor processor = (VarProcessor)DecompilerContext.getProperty("CURRENT_VAR_PROCESSOR");
/* 269:    */         
/* 270:306 */         FunctionExprent iff = new FunctionExprent(36, Arrays.asList(new Exprent[] { new FunctionExprent(44, Arrays.asList(new Exprent[] { new VarExprent(var, type, processor), ConstExprent.getZeroConstant(type.type) }), null), new ConstExprent(VarType.VARTYPE_INT, new Integer(-1), null), new ConstExprent(VarType.VARTYPE_INT, new Integer(1), null) }), null);
/* 271:    */         
/* 272:    */ 
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:312 */         FunctionExprent head = new FunctionExprent(42, Arrays.asList(new Exprent[] { new AssignmentExprent(new VarExprent(var, type, processor), new FunctionExprent(1, Arrays.asList(new Exprent[] { (Exprent)lstOperands.get(0), (Exprent)lstOperands.get(1) }), null), null), ConstExprent.getZeroConstant(type.type) }), null);
/* 277:    */         
/* 278:    */ 
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:318 */         processor.setVarType(new VarVersionPair(var, 0), type);
/* 283:    */         
/* 284:320 */         return new FunctionExprent(36, Arrays.asList(new Exprent[] { head, new ConstExprent(VarType.VARTYPE_INT, new Integer(0), null), iff }), fexpr.bytecode);
/* 285:    */       }
/* 286:323 */       break;
/* 287:    */     case 2: 
/* 288:325 */       AssignmentExprent asexpr = (AssignmentExprent)exprent;
/* 289:326 */       Exprent right = asexpr.getRight();
/* 290:327 */       Exprent left = asexpr.getLeft();
/* 291:329 */       if (right.type == 6)
/* 292:    */       {
/* 293:330 */         FunctionExprent func = (FunctionExprent)right;
/* 294:    */         
/* 295:332 */         VarType midlayer = null;
/* 296:333 */         if ((func.getFuncType() >= 14) && (func.getFuncType() <= 28))
/* 297:    */         {
/* 298:335 */           right = (Exprent)func.getLstOperands().get(0);
/* 299:336 */           midlayer = func.getSimpleCastType();
/* 300:337 */           if (right.type == 6) {
/* 301:338 */             func = (FunctionExprent)right;
/* 302:    */           } else {
/* 303:341 */             return null;
/* 304:    */           }
/* 305:    */         }
/* 306:345 */         List<Exprent> lstFuncOperands = func.getLstOperands();
/* 307:    */         
/* 308:347 */         Exprent cond = null;
/* 309:349 */         switch (func.getFuncType())
/* 310:    */         {
/* 311:    */         case 0: 
/* 312:    */         case 4: 
/* 313:    */         case 5: 
/* 314:    */         case 6: 
/* 315:354 */           if (left.equals(lstFuncOperands.get(1))) {
/* 316:355 */             cond = (Exprent)lstFuncOperands.get(0);
/* 317:    */           }
/* 318:356 */           break;
/* 319:    */         case 1: 
/* 320:    */         case 2: 
/* 321:    */         case 3: 
/* 322:    */         case 7: 
/* 323:    */         case 8: 
/* 324:    */         case 9: 
/* 325:    */         case 10: 
/* 326:365 */           if (left.equals(lstFuncOperands.get(0))) {
/* 327:366 */             cond = (Exprent)lstFuncOperands.get(1);
/* 328:    */           }
/* 329:    */           break;
/* 330:    */         }
/* 331:370 */         if ((cond != null) && ((midlayer == null) || (midlayer.equals(cond.getExprType()))))
/* 332:    */         {
/* 333:371 */           asexpr.setRight(cond);
/* 334:372 */           asexpr.setCondType(func.getFuncType());
/* 335:    */         }
/* 336:    */       }
/* 337:374 */       break;
/* 338:    */     case 8: 
/* 339:377 */       if (!statement_level)
/* 340:    */       {
/* 341:378 */         Exprent retexpr = ConcatenationHelper.contractStringConcat(exprent);
/* 342:379 */         if (!exprent.equals(retexpr)) {
/* 343:380 */           return retexpr;
/* 344:    */         }
/* 345:    */       }
/* 346:    */       break;
/* 347:    */     }
/* 348:385 */     return null;
/* 349:    */   }
/* 350:    */   
/* 351:    */   public static Exprent propagateBoolNot(Exprent exprent)
/* 352:    */   {
/* 353:390 */     if (exprent.type == 6)
/* 354:    */     {
/* 355:391 */       FunctionExprent fexpr = (FunctionExprent)exprent;
/* 356:393 */       if (fexpr.getFuncType() == 12)
/* 357:    */       {
/* 358:395 */         Exprent param = (Exprent)fexpr.getLstOperands().get(0);
/* 359:397 */         if (param.type == 6)
/* 360:    */         {
/* 361:398 */           FunctionExprent fparam = (FunctionExprent)param;
/* 362:    */           
/* 363:400 */           int ftype = fparam.getFuncType();
/* 364:401 */           switch (ftype)
/* 365:    */           {
/* 366:    */           case 12: 
/* 367:403 */             Exprent newexpr = (Exprent)fparam.getLstOperands().get(0);
/* 368:404 */             Exprent retexpr = propagateBoolNot(newexpr);
/* 369:405 */             return retexpr == null ? newexpr : retexpr;
/* 370:    */           case 48: 
/* 371:    */           case 49: 
/* 372:408 */             List<Exprent> operands = fparam.getLstOperands();
/* 373:409 */             for (int i = 0; i < operands.size(); i++)
/* 374:    */             {
/* 375:410 */               Exprent newparam = new FunctionExprent(12, (Exprent)operands.get(i), ((Exprent)operands.get(i)).bytecode);
/* 376:    */               
/* 377:412 */               Exprent retparam = propagateBoolNot(newparam);
/* 378:413 */               operands.set(i, retparam == null ? newparam : retparam);
/* 379:    */             }
/* 380:    */           case 42: 
/* 381:    */           case 43: 
/* 382:    */           case 44: 
/* 383:    */           case 45: 
/* 384:    */           case 46: 
/* 385:    */           case 47: 
/* 386:421 */             fparam.setFuncType(funcsnot[(ftype - 42)]);
/* 387:422 */             return fparam;
/* 388:    */           }
/* 389:    */         }
/* 390:    */       }
/* 391:    */     }
/* 392:428 */     return null;
/* 393:    */   }
/* 394:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.SecondaryFunctionsHelper
 * JD-Core Version:    0.7.0.1
 */