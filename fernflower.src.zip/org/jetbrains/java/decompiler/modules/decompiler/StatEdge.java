/*  1:   */ package org.jetbrains.java.decompiler.modules.decompiler;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  6:   */ 
/*  7:   */ public class StatEdge
/*  8:   */ {
/*  9:   */   public static final int TYPE_ALL = 255;
/* 10:   */   public static final int TYPE_REGULAR = 1;
/* 11:   */   public static final int TYPE_EXCEPTION = 2;
/* 12:   */   public static final int TYPE_BREAK = 4;
/* 13:   */   public static final int TYPE_CONTINUE = 8;
/* 14:   */   public static final int TYPE_FINALLYEXIT = 32;
/* 15:33 */   public static final int[] TYPES = { 1, 2, 4, 8, 32 };
/* 16:   */   private int type;
/* 17:   */   private Statement source;
/* 18:   */   private Statement destination;
/* 19:   */   private List<String> exceptions;
/* 20:   */   public Statement closure;
/* 21:51 */   public boolean labeled = true;
/* 22:53 */   public boolean explicit = true;
/* 23:   */   
/* 24:   */   public StatEdge(int type, Statement source, Statement destination, Statement closure)
/* 25:   */   {
/* 26:56 */     this(type, source, destination);
/* 27:57 */     this.closure = closure;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public StatEdge(int type, Statement source, Statement destination)
/* 31:   */   {
/* 32:61 */     this.type = type;
/* 33:62 */     this.source = source;
/* 34:63 */     this.destination = destination;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public StatEdge(Statement source, Statement destination, List<String> exceptions)
/* 38:   */   {
/* 39:67 */     this(2, source, destination);
/* 40:68 */     if (exceptions != null) {
/* 41:69 */       this.exceptions = new ArrayList(exceptions);
/* 42:   */     }
/* 43:   */   }
/* 44:   */   
/* 45:   */   public int getType()
/* 46:   */   {
/* 47:74 */     return this.type;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void setType(int type)
/* 51:   */   {
/* 52:78 */     this.type = type;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public Statement getSource()
/* 56:   */   {
/* 57:82 */     return this.source;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void setSource(Statement source)
/* 61:   */   {
/* 62:86 */     this.source = source;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public Statement getDestination()
/* 66:   */   {
/* 67:90 */     return this.destination;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public void setDestination(Statement destination)
/* 71:   */   {
/* 72:94 */     this.destination = destination;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public List<String> getExceptions()
/* 76:   */   {
/* 77:98 */     return this.exceptions;
/* 78:   */   }
/* 79:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.StatEdge
 * JD-Core Version:    0.7.0.1
 */