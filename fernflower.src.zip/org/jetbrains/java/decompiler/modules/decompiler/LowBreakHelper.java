/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*   5:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*   6:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SynchronizedStatement;
/*   7:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*   8:    */ 
/*   9:    */ public class LowBreakHelper
/*  10:    */ {
/*  11:    */   public static void lowBreakLabels(Statement root)
/*  12:    */   {
/*  13: 28 */     lowBreakLabelsRec(root);
/*  14:    */     
/*  15: 30 */     liftBreakLabels(root);
/*  16:    */   }
/*  17:    */   
/*  18:    */   private static void lowBreakLabelsRec(Statement stat)
/*  19:    */   {
/*  20:    */     for (;;)
/*  21:    */     {
/*  22: 37 */       boolean found = false;
/*  23: 39 */       for (StatEdge edge : stat.getLabelEdges()) {
/*  24: 40 */         if (edge.getType() == 4)
/*  25:    */         {
/*  26: 41 */           Statement minclosure = getMinClosure(stat, edge.getSource());
/*  27: 42 */           if (minclosure != stat)
/*  28:    */           {
/*  29: 43 */             minclosure.addLabeledEdge(edge);
/*  30: 44 */             edge.labeled = isBreakEdgeLabeled(edge.getSource(), minclosure);
/*  31: 45 */             found = true;
/*  32: 46 */             break;
/*  33:    */           }
/*  34:    */         }
/*  35:    */       }
/*  36: 51 */       if (!found) {
/*  37:    */         break;
/*  38:    */       }
/*  39:    */     }
/*  40: 56 */     for (Statement st : stat.getStats()) {
/*  41: 57 */       lowBreakLabelsRec(st);
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static boolean isBreakEdgeLabeled(Statement source, Statement closure)
/*  46:    */   {
/*  47: 63 */     if ((closure.type == 5) || (closure.type == 6))
/*  48:    */     {
/*  49: 65 */       Statement parent = source.getParent();
/*  50: 67 */       if (parent == closure) {
/*  51: 68 */         return false;
/*  52:    */       }
/*  53: 71 */       return (isBreakEdgeLabeled(parent, closure)) || (parent.type == 5) || (parent.type == 6);
/*  54:    */     }
/*  55: 76 */     return true;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static Statement getMinClosure(Statement closure, Statement source)
/*  59:    */   {
/*  60:    */     for (;;)
/*  61:    */     {
/*  62: 84 */       Statement newclosure = null;
/*  63: 86 */       switch (closure.type)
/*  64:    */       {
/*  65:    */       case 15: 
/*  66: 88 */         Statement last = (Statement)closure.getStats().getLast();
/*  67: 90 */         if (isOkClosure(closure, source, last)) {
/*  68: 91 */           newclosure = last;
/*  69:    */         }
/*  70:    */         break;
/*  71:    */       case 2: 
/*  72: 95 */         IfStatement ifclosure = (IfStatement)closure;
/*  73: 96 */         if (isOkClosure(closure, source, ifclosure.getIfstat())) {
/*  74: 97 */           newclosure = ifclosure.getIfstat();
/*  75: 99 */         } else if (isOkClosure(closure, source, ifclosure.getElsestat())) {
/*  76:100 */           newclosure = ifclosure.getElsestat();
/*  77:    */         }
/*  78:    */         break;
/*  79:    */       case 7: 
/*  80:104 */         for (Statement st : closure.getStats()) {
/*  81:105 */           if (isOkClosure(closure, source, st))
/*  82:    */           {
/*  83:106 */             newclosure = st;
/*  84:107 */             break;
/*  85:    */           }
/*  86:    */         }
/*  87:110 */         break;
/*  88:    */       case 10: 
/*  89:112 */         Statement body = ((SynchronizedStatement)closure).getBody();
/*  90:114 */         if (isOkClosure(closure, source, body)) {
/*  91:115 */           newclosure = body;
/*  92:    */         }
/*  93:    */         break;
/*  94:    */       }
/*  95:119 */       if (newclosure == null) {
/*  96:    */         break;
/*  97:    */       }
/*  98:123 */       closure = newclosure;
/*  99:    */     }
/* 100:126 */     return closure;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private static boolean isOkClosure(Statement closure, Statement source, Statement stat)
/* 104:    */   {
/* 105:131 */     boolean ok = false;
/* 106:133 */     if ((stat != null) && (stat.containsStatementStrict(source)))
/* 107:    */     {
/* 108:135 */       List<StatEdge> lst = stat.getAllSuccessorEdges();
/* 109:    */       
/* 110:137 */       ok = lst.isEmpty();
/* 111:138 */       if (!ok)
/* 112:    */       {
/* 113:139 */         StatEdge edge = (StatEdge)lst.get(0);
/* 114:140 */         ok = (edge.closure == closure) && (edge.getType() == 4);
/* 115:    */       }
/* 116:    */     }
/* 117:144 */     return ok;
/* 118:    */   }
/* 119:    */   
/* 120:    */   private static void liftBreakLabels(Statement stat)
/* 121:    */   {
/* 122:150 */     for (Statement st : stat.getStats()) {
/* 123:151 */       liftBreakLabels(st);
/* 124:    */     }
/* 125:    */     for (;;)
/* 126:    */     {
/* 127:157 */       boolean found = false;
/* 128:159 */       for (StatEdge edge : stat.getLabelEdges()) {
/* 129:160 */         if ((edge.explicit) && (edge.labeled) && (edge.getType() == 4))
/* 130:    */         {
/* 131:162 */           Statement newclosure = getMaxBreakLift(stat, edge);
/* 132:164 */           if (newclosure != null)
/* 133:    */           {
/* 134:165 */             newclosure.addLabeledEdge(edge);
/* 135:166 */             edge.labeled = isBreakEdgeLabeled(edge.getSource(), newclosure);
/* 136:    */             
/* 137:168 */             found = true;
/* 138:169 */             break;
/* 139:    */           }
/* 140:    */         }
/* 141:    */       }
/* 142:174 */       if (!found) {
/* 143:    */         break;
/* 144:    */       }
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   private static Statement getMaxBreakLift(Statement stat, StatEdge edge)
/* 149:    */   {
/* 150:182 */     Statement closure = null;
/* 151:183 */     Statement newclosure = stat;
/* 152:185 */     while ((newclosure = getNextBreakLift(newclosure, edge)) != null) {
/* 153:186 */       closure = newclosure;
/* 154:    */     }
/* 155:189 */     return closure;
/* 156:    */   }
/* 157:    */   
/* 158:    */   private static Statement getNextBreakLift(Statement stat, StatEdge edge)
/* 159:    */   {
/* 160:194 */     Statement closure = stat.getParent();
/* 161:196 */     while ((closure != null) && (!closure.containsStatementStrict(edge.getDestination())))
/* 162:    */     {
/* 163:198 */       boolean labeled = isBreakEdgeLabeled(edge.getSource(), closure);
/* 164:199 */       if ((closure.isLabeled()) || (!labeled)) {
/* 165:200 */         return closure;
/* 166:    */       }
/* 167:203 */       closure = closure.getParent();
/* 168:    */     }
/* 169:206 */     return null;
/* 170:    */   }
/* 171:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.LowBreakHelper
 * JD-Core Version:    0.7.0.1
 */