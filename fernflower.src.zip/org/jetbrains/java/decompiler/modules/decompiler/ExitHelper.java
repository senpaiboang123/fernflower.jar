/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.jetbrains.java.decompiler.code.cfg.BasicBlock;
/*   9:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  10:    */ import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DummyExitStatement;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  20:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  21:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  22:    */ 
/*  23:    */ public class ExitHelper
/*  24:    */ {
/*  25:    */   public static boolean condenseExits(RootStatement root)
/*  26:    */   {
/*  27: 36 */     int changed = integrateExits(root);
/*  28: 38 */     if (changed > 0)
/*  29:    */     {
/*  30: 40 */       cleanUpUnreachableBlocks(root);
/*  31:    */       
/*  32: 42 */       SequenceHelper.condenseSequences(root);
/*  33:    */     }
/*  34: 45 */     return changed > 0;
/*  35:    */   }
/*  36:    */   
/*  37:    */   private static void cleanUpUnreachableBlocks(Statement stat)
/*  38:    */   {
/*  39:    */     boolean found;
/*  40:    */     do
/*  41:    */     {
/*  42: 54 */       found = false;
/*  43: 56 */       for (int i = 0; i < stat.getStats().size(); i++)
/*  44:    */       {
/*  45: 58 */         Statement st = (Statement)stat.getStats().get(i);
/*  46:    */         
/*  47: 60 */         cleanUpUnreachableBlocks(st);
/*  48: 62 */         if ((st.type == 15) && (st.getStats().size() > 1))
/*  49:    */         {
/*  50: 64 */           Statement last = (Statement)st.getStats().getLast();
/*  51: 65 */           Statement secondlast = (Statement)st.getStats().get(st.getStats().size() - 2);
/*  52: 67 */           if (((last.getExprents() == null) || (!last.getExprents().isEmpty())) && 
/*  53: 68 */             (!secondlast.hasBasicSuccEdge()))
/*  54:    */           {
/*  55: 70 */             Set<Statement> set = last.getNeighboursSet(1073741824, 0);
/*  56: 71 */             set.remove(secondlast);
/*  57: 73 */             if (set.isEmpty())
/*  58:    */             {
/*  59: 74 */               last.setExprents(new ArrayList());
/*  60: 75 */               found = true;
/*  61: 76 */               break;
/*  62:    */             }
/*  63:    */           }
/*  64:    */         }
/*  65:    */       }
/*  66: 83 */     } while (found);
/*  67:    */   }
/*  68:    */   
/*  69:    */   private static int integrateExits(Statement stat)
/*  70:    */   {
/*  71: 89 */     int ret = 0;
/*  72: 90 */     Statement dest = null;
/*  73: 92 */     if (stat.getExprents() == null)
/*  74:    */     {
/*  75:    */       for (;;)
/*  76:    */       {
/*  77: 96 */         int changed = 0;
/*  78: 98 */         for (Statement st : stat.getStats())
/*  79:    */         {
/*  80: 99 */           changed = integrateExits(st);
/*  81:100 */           if (changed > 0)
/*  82:    */           {
/*  83:101 */             ret = 1;
/*  84:102 */             break;
/*  85:    */           }
/*  86:    */         }
/*  87:106 */         if (changed == 0) {
/*  88:    */           break;
/*  89:    */         }
/*  90:    */       }
/*  91:112 */       switch (stat.type)
/*  92:    */       {
/*  93:    */       case 2: 
/*  94:114 */         IfStatement ifst = (IfStatement)stat;
/*  95:115 */         if (ifst.getIfstat() == null)
/*  96:    */         {
/*  97:116 */           StatEdge ifedge = ifst.getIfEdge();
/*  98:117 */           dest = isExitEdge(ifedge);
/*  99:118 */           if (dest != null)
/* 100:    */           {
/* 101:119 */             BasicBlockStatement bstat = new BasicBlockStatement(new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0)));
/* 102:    */             
/* 103:121 */             bstat.setExprents(DecHelper.copyExprentList(dest.getExprents()));
/* 104:    */             
/* 105:123 */             ifst.getFirst().removeSuccessor(ifedge);
/* 106:124 */             StatEdge newedge = new StatEdge(1, ifst.getFirst(), bstat);
/* 107:125 */             ifst.getFirst().addSuccessor(newedge);
/* 108:126 */             ifst.setIfEdge(newedge);
/* 109:127 */             ifst.setIfstat(bstat);
/* 110:128 */             ifst.getStats().addWithKey(bstat, bstat.id);
/* 111:129 */             bstat.setParent(ifst);
/* 112:    */             
/* 113:131 */             StatEdge oldexitedge = (StatEdge)dest.getAllSuccessorEdges().get(0);
/* 114:132 */             StatEdge newexitedge = new StatEdge(4, bstat, oldexitedge.getDestination());
/* 115:133 */             bstat.addSuccessor(newexitedge);
/* 116:134 */             oldexitedge.closure.addLabeledEdge(newexitedge);
/* 117:135 */             ret = 1;
/* 118:    */           }
/* 119:    */         }
/* 120:    */         break;
/* 121:    */       }
/* 122:    */     }
/* 123:142 */     if ((stat.getAllSuccessorEdges().size() == 1) && (((StatEdge)stat.getAllSuccessorEdges().get(0)).getType() == 4) && (stat.getLabelEdges().isEmpty()))
/* 124:    */     {
/* 125:145 */       Statement parent = stat.getParent();
/* 126:146 */       if ((stat != parent.getFirst()) || ((parent.type != 2) && (parent.type != 6)))
/* 127:    */       {
/* 128:149 */         StatEdge destedge = (StatEdge)stat.getAllSuccessorEdges().get(0);
/* 129:150 */         dest = isExitEdge(destedge);
/* 130:151 */         if (dest != null)
/* 131:    */         {
/* 132:152 */           stat.removeSuccessor(destedge);
/* 133:    */           
/* 134:154 */           BasicBlockStatement bstat = new BasicBlockStatement(new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0)));
/* 135:    */           
/* 136:156 */           bstat.setExprents(DecHelper.copyExprentList(dest.getExprents()));
/* 137:    */           
/* 138:158 */           StatEdge oldexitedge = (StatEdge)dest.getAllSuccessorEdges().get(0);
/* 139:159 */           StatEdge newexitedge = new StatEdge(4, bstat, oldexitedge.getDestination());
/* 140:160 */           bstat.addSuccessor(newexitedge);
/* 141:161 */           oldexitedge.closure.addLabeledEdge(newexitedge);
/* 142:    */           
/* 143:163 */           SequenceStatement block = new SequenceStatement(Arrays.asList(new Statement[] { stat, bstat }));
/* 144:164 */           block.setAllParent();
/* 145:    */           
/* 146:166 */           parent.replaceStatement(stat, block);
/* 147:170 */           for (StatEdge prededge : block.getPredecessorEdges(8))
/* 148:    */           {
/* 149:172 */             block.removePredecessor(prededge);
/* 150:173 */             prededge.getSource().changeEdgeNode(1, prededge, stat);
/* 151:174 */             stat.addPredecessor(prededge);
/* 152:    */             
/* 153:176 */             stat.addLabeledEdge(prededge);
/* 154:    */           }
/* 155:180 */           stat.addSuccessor(new StatEdge(1, stat, bstat));
/* 156:182 */           for (StatEdge edge : dest.getAllPredecessorEdges()) {
/* 157:183 */             if ((!edge.explicit) && (stat.containsStatementStrict(edge.getSource())) && (MergeHelper.isDirectPath(edge.getSource().getParent(), bstat)))
/* 158:    */             {
/* 159:186 */               dest.removePredecessor(edge);
/* 160:187 */               edge.getSource().changeEdgeNode(1, edge, bstat);
/* 161:188 */               bstat.addPredecessor(edge);
/* 162:190 */               if (!stat.containsStatementStrict(edge.closure)) {
/* 163:191 */                 stat.addLabeledEdge(edge);
/* 164:    */               }
/* 165:    */             }
/* 166:    */           }
/* 167:196 */           ret = 2;
/* 168:    */         }
/* 169:    */       }
/* 170:    */     }
/* 171:201 */     return ret;
/* 172:    */   }
/* 173:    */   
/* 174:    */   private static Statement isExitEdge(StatEdge edge)
/* 175:    */   {
/* 176:206 */     Statement dest = edge.getDestination();
/* 177:208 */     if ((edge.getType() == 4) && (dest.type == 8) && (edge.explicit) && ((edge.labeled) || (isOnlyEdge(edge))))
/* 178:    */     {
/* 179:210 */       List<Exprent> data = dest.getExprents();
/* 180:212 */       if ((data != null) && (data.size() == 1) && 
/* 181:213 */         (((Exprent)data.get(0)).type == 4)) {
/* 182:214 */         return dest;
/* 183:    */       }
/* 184:    */     }
/* 185:219 */     return null;
/* 186:    */   }
/* 187:    */   
/* 188:    */   private static boolean isOnlyEdge(StatEdge edge)
/* 189:    */   {
/* 190:224 */     Statement stat = edge.getDestination();
/* 191:226 */     for (StatEdge ed : stat.getAllPredecessorEdges()) {
/* 192:227 */       if (ed != edge) {
/* 193:228 */         if (ed.getType() == 1)
/* 194:    */         {
/* 195:229 */           Statement source = ed.getSource();
/* 196:231 */           if ((source.type == 8) || ((source.type == 2) && (((IfStatement)source).iftype == 0)) || ((source.type == 5) && (((DoStatement)source).getLooptype() != 0))) {
/* 197:234 */             return false;
/* 198:    */           }
/* 199:    */         }
/* 200:    */         else
/* 201:    */         {
/* 202:238 */           return false;
/* 203:    */         }
/* 204:    */       }
/* 205:    */     }
/* 206:243 */     return true;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public static boolean removeRedundantReturns(RootStatement root)
/* 210:    */   {
/* 211:248 */     boolean res = false;
/* 212:    */     
/* 213:250 */     DummyExitStatement dummyExit = root.getDummyExit();
/* 214:252 */     for (StatEdge edge : dummyExit.getAllPredecessorEdges()) {
/* 215:253 */       if (!edge.explicit)
/* 216:    */       {
/* 217:254 */         Statement source = edge.getSource();
/* 218:255 */         List<Exprent> lstExpr = source.getExprents();
/* 219:256 */         if ((lstExpr != null) && (!lstExpr.isEmpty()))
/* 220:    */         {
/* 221:257 */           Exprent expr = (Exprent)lstExpr.get(lstExpr.size() - 1);
/* 222:258 */           if (expr.type == 4)
/* 223:    */           {
/* 224:259 */             ExitExprent ex = (ExitExprent)expr;
/* 225:260 */             if ((ex.getExitType() == 0) && (ex.getValue() == null))
/* 226:    */             {
/* 227:262 */               dummyExit.addBytecodeOffsets(ex.bytecode);
/* 228:263 */               lstExpr.remove(lstExpr.size() - 1);
/* 229:264 */               res = true;
/* 230:    */             }
/* 231:    */           }
/* 232:    */         }
/* 233:    */       }
/* 234:    */     }
/* 235:271 */     return res;
/* 236:    */   }
/* 237:    */   
/* 238:    */   public static boolean handleReturnFromInitializer(RootStatement root)
/* 239:    */   {
/* 240:276 */     boolean res = false;
/* 241:    */     
/* 242:278 */     Statement exit = root.getDummyExit();
/* 243:279 */     Statement top = root.getFirst();
/* 244:280 */     Statement newret = null;
/* 245:    */     
/* 246:282 */     boolean sharedcreated = false;
/* 247:284 */     for (StatEdge edge : exit.getAllPredecessorEdges()) {
/* 248:285 */       if (edge.explicit)
/* 249:    */       {
/* 250:287 */         if (!sharedcreated)
/* 251:    */         {
/* 252:288 */           newret = addSharedInitializerReturn(root);
/* 253:289 */           sharedcreated = true;
/* 254:    */         }
/* 255:292 */         Statement source = edge.getSource();
/* 256:293 */         List<Exprent> lstExpr = source.getExprents();
/* 257:294 */         if ((lstExpr != null) && (!lstExpr.isEmpty()))
/* 258:    */         {
/* 259:295 */           Exprent expr = (Exprent)lstExpr.get(lstExpr.size() - 1);
/* 260:296 */           if (expr.type == 4)
/* 261:    */           {
/* 262:297 */             ExitExprent ex = (ExitExprent)expr;
/* 263:298 */             if ((ex.getExitType() == 0) && (ex.getValue() == null))
/* 264:    */             {
/* 265:299 */               lstExpr.remove(lstExpr.size() - 1);
/* 266:    */               
/* 267:301 */               source.removeSuccessor(edge);
/* 268:302 */               source.addSuccessor(new StatEdge(4, source, newret, top));
/* 269:    */               
/* 270:304 */               res = true;
/* 271:    */             }
/* 272:    */           }
/* 273:    */         }
/* 274:    */       }
/* 275:    */     }
/* 276:311 */     return res;
/* 277:    */   }
/* 278:    */   
/* 279:    */   private static Statement addSharedInitializerReturn(RootStatement root)
/* 280:    */   {
/* 281:316 */     Statement exit = root.getDummyExit();
/* 282:317 */     Statement top = root.getFirst();
/* 283:    */     
/* 284:    */ 
/* 285:320 */     BasicBlockStatement bstat = new BasicBlockStatement(new BasicBlock(DecompilerContext.getCounterContainer().getCounterAndIncrement(0)));
/* 286:    */     
/* 287:    */ 
/* 288:323 */     ExitExprent retexpr = new ExitExprent(0, null, ((MethodDescriptor)DecompilerContext.getProperty("CURRENT_METHOD_DESCRIPTOR")).ret, null);
/* 289:    */     
/* 290:    */ 
/* 291:    */ 
/* 292:327 */     bstat.setExprents(new ArrayList(Arrays.asList(new Exprent[] { retexpr })));
/* 293:    */     
/* 294:    */ 
/* 295:330 */     SequenceStatement seq = new SequenceStatement(Arrays.asList(new Statement[] { top, bstat }));
/* 296:331 */     top.setParent(seq);
/* 297:332 */     bstat.setParent(seq);
/* 298:333 */     seq.setParent(root);
/* 299:    */     
/* 300:335 */     root.getStats().removeWithKey(top.id);
/* 301:336 */     root.getStats().addWithKeyAndIndex(0, seq, seq.id);
/* 302:337 */     root.setFirst(seq);
/* 303:339 */     for (StatEdge succedge : top.getAllSuccessorEdges()) {
/* 304:340 */       top.removeSuccessor(succedge);
/* 305:    */     }
/* 306:343 */     top.addSuccessor(new StatEdge(1, top, bstat));
/* 307:344 */     bstat.addSuccessor(new StatEdge(4, bstat, exit, seq));
/* 308:    */     
/* 309:346 */     return bstat;
/* 310:    */   }
/* 311:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.ExitHelper
 * JD-Core Version:    0.7.0.1
 */