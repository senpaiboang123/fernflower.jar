/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*   6:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SwitchStatement;
/*  10:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  11:    */ 
/*  12:    */ public class InlineSingleBlockHelper
/*  13:    */ {
/*  14:    */   public static boolean inlineSingleBlocks(RootStatement root)
/*  15:    */   {
/*  16: 29 */     boolean res = inlineSingleBlocksRec(root);
/*  17: 31 */     if (res) {
/*  18: 32 */       SequenceHelper.condenseSequences(root);
/*  19:    */     }
/*  20: 35 */     return res;
/*  21:    */   }
/*  22:    */   
/*  23:    */   private static boolean inlineSingleBlocksRec(Statement stat)
/*  24:    */   {
/*  25: 40 */     boolean res = false;
/*  26: 42 */     for (Statement st : stat.getStats()) {
/*  27: 43 */       res |= inlineSingleBlocksRec(st);
/*  28:    */     }
/*  29: 46 */     if (stat.type == 15)
/*  30:    */     {
/*  31: 48 */       SequenceStatement seq = (SequenceStatement)stat;
/*  32: 49 */       for (int i = 1; i < seq.getStats().size(); i++) {
/*  33: 50 */         if (isInlineable(seq, i))
/*  34:    */         {
/*  35: 51 */           inlineBlock(seq, i);
/*  36: 52 */           return true;
/*  37:    */         }
/*  38:    */       }
/*  39:    */     }
/*  40: 57 */     return res;
/*  41:    */   }
/*  42:    */   
/*  43:    */   private static void inlineBlock(SequenceStatement seq, int index)
/*  44:    */   {
/*  45: 62 */     Statement first = (Statement)seq.getStats().get(index);
/*  46: 63 */     Statement pre = (Statement)seq.getStats().get(index - 1);
/*  47: 64 */     pre.removeSuccessor((StatEdge)pre.getAllSuccessorEdges().get(0));
/*  48:    */     
/*  49: 66 */     StatEdge edge = (StatEdge)first.getPredecessorEdges(4).get(0);
/*  50: 67 */     Statement source = edge.getSource();
/*  51: 68 */     Statement parent = source.getParent();
/*  52: 69 */     source.removeSuccessor(edge);
/*  53:    */     
/*  54: 71 */     List<Statement> lst = new ArrayList();
/*  55: 72 */     for (int i = seq.getStats().size() - 1; i >= index; i--) {
/*  56: 73 */       lst.add(0, seq.getStats().remove(i));
/*  57:    */     }
/*  58: 76 */     if ((parent.type == 2) && (((IfStatement)parent).iftype == 0) && (source == parent.getFirst()))
/*  59:    */     {
/*  60: 78 */       IfStatement ifparent = (IfStatement)parent;
/*  61: 79 */       SequenceStatement block = new SequenceStatement(lst);
/*  62: 80 */       block.setAllParent();
/*  63:    */       
/*  64: 82 */       StatEdge newedge = new StatEdge(1, source, block);
/*  65: 83 */       source.addSuccessor(newedge);
/*  66: 84 */       ifparent.setIfEdge(newedge);
/*  67: 85 */       ifparent.setIfstat(block);
/*  68:    */       
/*  69: 87 */       ifparent.getStats().addWithKey(block, block.id);
/*  70: 88 */       block.setParent(ifparent);
/*  71:    */     }
/*  72:    */     else
/*  73:    */     {
/*  74: 91 */       lst.add(0, source);
/*  75:    */       
/*  76: 93 */       SequenceStatement block = new SequenceStatement(lst);
/*  77: 94 */       block.setAllParent();
/*  78:    */       
/*  79: 96 */       parent.replaceStatement(source, block);
/*  80:101 */       for (StatEdge prededge : block.getPredecessorEdges(8))
/*  81:    */       {
/*  82:103 */         block.removePredecessor(prededge);
/*  83:104 */         prededge.getSource().changeEdgeNode(1, prededge, source);
/*  84:105 */         source.addPredecessor(prededge);
/*  85:    */         
/*  86:107 */         source.addLabeledEdge(prededge);
/*  87:    */       }
/*  88:111 */       if (parent.type == 6) {
/*  89:112 */         ((SwitchStatement)parent).sortEdgesAndNodes();
/*  90:    */       }
/*  91:115 */       source.addSuccessor(new StatEdge(1, source, first));
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   private static boolean isInlineable(SequenceStatement seq, int index)
/*  96:    */   {
/*  97:121 */     Statement first = (Statement)seq.getStats().get(index);
/*  98:122 */     Statement pre = (Statement)seq.getStats().get(index - 1);
/*  99:124 */     if (pre.hasBasicSuccEdge()) {
/* 100:125 */       return false;
/* 101:    */     }
/* 102:129 */     List<StatEdge> lst = first.getPredecessorEdges(4);
/* 103:131 */     if (lst.size() == 1)
/* 104:    */     {
/* 105:132 */       StatEdge edge = (StatEdge)lst.get(0);
/* 106:134 */       if (sameCatchRanges(edge))
/* 107:    */       {
/* 108:135 */         if (edge.explicit) {
/* 109:136 */           return true;
/* 110:    */         }
/* 111:139 */         for (int i = index; i < seq.getStats().size(); i++) {
/* 112:140 */           if (!noExitLabels((Statement)seq.getStats().get(i), seq)) {
/* 113:141 */             return false;
/* 114:    */           }
/* 115:    */         }
/* 116:144 */         return true;
/* 117:    */       }
/* 118:    */     }
/* 119:150 */     return false;
/* 120:    */   }
/* 121:    */   
/* 122:    */   private static boolean sameCatchRanges(StatEdge edge)
/* 123:    */   {
/* 124:155 */     Statement from = edge.getSource();
/* 125:156 */     Statement to = edge.getDestination();
/* 126:    */     for (;;)
/* 127:    */     {
/* 128:160 */       Statement parent = from.getParent();
/* 129:161 */       if (parent.containsStatementStrict(to)) {
/* 130:    */         break;
/* 131:    */       }
/* 132:165 */       if ((parent.type == 7) || (parent.type == 12))
/* 133:    */       {
/* 134:167 */         if (parent.getFirst() == from) {
/* 135:168 */           return false;
/* 136:    */         }
/* 137:    */       }
/* 138:171 */       else if ((parent.type == 10) && 
/* 139:172 */         (parent.getStats().get(1) == from)) {
/* 140:173 */         return false;
/* 141:    */       }
/* 142:177 */       from = parent;
/* 143:    */     }
/* 144:180 */     return true;
/* 145:    */   }
/* 146:    */   
/* 147:    */   private static boolean noExitLabels(Statement block, Statement sequence)
/* 148:    */   {
/* 149:185 */     for (StatEdge edge : block.getAllSuccessorEdges()) {
/* 150:186 */       if ((edge.getType() != 1) && (edge.getDestination().type != 14) && 
/* 151:187 */         (!sequence.containsStatementStrict(edge.getDestination()))) {
/* 152:188 */         return false;
/* 153:    */       }
/* 154:    */     }
/* 155:193 */     for (Statement st : block.getStats()) {
/* 156:194 */       if (!noExitLabels(st, sequence)) {
/* 157:195 */         return false;
/* 158:    */       }
/* 159:    */     }
/* 160:199 */     return true;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public static boolean isBreakEdgeLabeled(Statement source, Statement closure)
/* 164:    */   {
/* 165:204 */     if ((closure.type == 5) || (closure.type == 6))
/* 166:    */     {
/* 167:206 */       Statement parent = source.getParent();
/* 168:208 */       if (parent == closure) {
/* 169:209 */         return false;
/* 170:    */       }
/* 171:212 */       return (parent.type == 5) || (parent.type == 6) || (isBreakEdgeLabeled(parent, closure));
/* 172:    */     }
/* 173:217 */     return true;
/* 174:    */   }
/* 175:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.InlineSingleBlockHelper
 * JD-Core Version:    0.7.0.1
 */