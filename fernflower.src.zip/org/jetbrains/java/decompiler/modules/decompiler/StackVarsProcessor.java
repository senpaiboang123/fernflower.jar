/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.LinkedList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent;
/*  11:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.Exprent;
/*  12:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.MonitorExprent;
/*  13:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.NewExprent;
/*  14:    */ import org.jetbrains.java.decompiler.modules.decompiler.exps.VarExprent;
/*  15:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectGraph;
/*  16:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.DirectNode;
/*  17:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.FlattenStatementsHelper;
/*  18:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAConstructorSparseEx;
/*  19:    */ import org.jetbrains.java.decompiler.modules.decompiler.sforms.SSAUConstructorSparseEx;
/*  20:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*  21:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement;
/*  22:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  23:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionEdge;
/*  24:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionNode;
/*  25:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
/*  26:    */ import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionsGraph;
/*  27:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  28:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  29:    */ import org.jetbrains.java.decompiler.struct.gen.VarType;
/*  30:    */ import org.jetbrains.java.decompiler.util.FastSparseSetFactory.FastSparseSet;
/*  31:    */ import org.jetbrains.java.decompiler.util.InterpreterUtil;
/*  32:    */ import org.jetbrains.java.decompiler.util.SFormsFastMapDirect;
/*  33:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  34:    */ 
/*  35:    */ public class StackVarsProcessor
/*  36:    */ {
/*  37:    */   public void simplifyStackVars(RootStatement root, StructMethod mt, StructClass cl)
/*  38:    */   {
/*  39: 42 */     HashSet<Integer> setReorderedIfs = new HashSet();
/*  40:    */     
/*  41: 44 */     SSAUConstructorSparseEx ssau = null;
/*  42:    */     for (;;)
/*  43:    */     {
/*  44: 48 */       boolean found = false;
/*  45:    */       
/*  46:    */ 
/*  47:    */ 
/*  48: 52 */       SSAConstructorSparseEx ssa = new SSAConstructorSparseEx();
/*  49: 53 */       ssa.splitVariables(root, mt);
/*  50:    */       
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54: 58 */       SimplifyExprentsHelper sehelper = new SimplifyExprentsHelper(ssau == null);
/*  55: 59 */       while (sehelper.simplifyStackVarsStatement(root, setReorderedIfs, ssa, cl)) {
/*  56: 61 */         found = true;
/*  57:    */       }
/*  58: 67 */       setVersionsToNull(root);
/*  59:    */       
/*  60: 69 */       SequenceHelper.condenseSequences(root);
/*  61:    */       
/*  62: 71 */       ssau = new SSAUConstructorSparseEx();
/*  63: 72 */       ssau.splitVariables(root, mt);
/*  64: 83 */       if (iterateStatements(root, ssau)) {
/*  65: 84 */         found = true;
/*  66:    */       }
/*  67: 89 */       setVersionsToNull(root);
/*  68: 91 */       if (!found) {
/*  69:    */         break;
/*  70:    */       }
/*  71:    */     }
/*  72: 97 */     ssau = new SSAUConstructorSparseEx();
/*  73: 98 */     ssau.splitVariables(root, mt);
/*  74:    */     
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:106 */     iterateStatements(root, ssau);
/*  82:    */     
/*  83:    */ 
/*  84:    */ 
/*  85:110 */     setVersionsToNull(root);
/*  86:    */   }
/*  87:    */   
/*  88:    */   private static void setVersionsToNull(Statement stat)
/*  89:    */   {
/*  90:115 */     if (stat.getExprents() == null) {
/*  91:116 */       for (Object obj : stat.getSequentialObjects()) {
/*  92:117 */         if ((obj instanceof Statement)) {
/*  93:118 */           setVersionsToNull((Statement)obj);
/*  94:120 */         } else if ((obj instanceof Exprent)) {
/*  95:121 */           setExprentVersionsToNull((Exprent)obj);
/*  96:    */         }
/*  97:    */       }
/*  98:    */     } else {
/*  99:126 */       for (Exprent exprent : stat.getExprents()) {
/* 100:127 */         setExprentVersionsToNull(exprent);
/* 101:    */       }
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   private static void setExprentVersionsToNull(Exprent exprent)
/* 106:    */   {
/* 107:134 */     List<Exprent> lst = exprent.getAllExprents(true);
/* 108:135 */     lst.add(exprent);
/* 109:137 */     for (Exprent expr : lst) {
/* 110:138 */       if (expr.type == 12) {
/* 111:139 */         ((VarExprent)expr).setVersion(0);
/* 112:    */       }
/* 113:    */     }
/* 114:    */   }
/* 115:    */   
/* 116:    */   private boolean iterateStatements(RootStatement root, SSAUConstructorSparseEx ssa)
/* 117:    */   {
/* 118:147 */     FlattenStatementsHelper flatthelper = new FlattenStatementsHelper();
/* 119:148 */     DirectGraph dgraph = flatthelper.buildDirectGraph(root);
/* 120:    */     
/* 121:150 */     boolean res = false;
/* 122:    */     
/* 123:152 */     HashSet<DirectNode> setVisited = new HashSet();
/* 124:153 */     LinkedList<DirectNode> stack = new LinkedList();
/* 125:154 */     LinkedList<HashMap<VarVersionPair, Exprent>> stackMaps = new LinkedList();
/* 126:    */     
/* 127:156 */     stack.add(dgraph.first);
/* 128:157 */     stackMaps.add(new HashMap());
/* 129:159 */     while (!stack.isEmpty())
/* 130:    */     {
/* 131:161 */       DirectNode nd = (DirectNode)stack.removeFirst();
/* 132:162 */       HashMap<VarVersionPair, Exprent> mapVarValues = (HashMap)stackMaps.removeFirst();
/* 133:164 */       if (!setVisited.contains(nd))
/* 134:    */       {
/* 135:167 */         setVisited.add(nd);
/* 136:    */         
/* 137:169 */         List<List<Exprent>> lstLists = new ArrayList();
/* 138:171 */         if (!nd.exprents.isEmpty()) {
/* 139:172 */           lstLists.add(nd.exprents);
/* 140:    */         }
/* 141:175 */         if (nd.succs.size() == 1)
/* 142:    */         {
/* 143:176 */           DirectNode ndsucc = (DirectNode)nd.succs.get(0);
/* 144:177 */           if ((ndsucc.type == 2) && (!ndsucc.exprents.isEmpty()))
/* 145:    */           {
/* 146:178 */             lstLists.add(((DirectNode)nd.succs.get(0)).exprents);
/* 147:179 */             nd = ndsucc;
/* 148:    */           }
/* 149:    */         }
/* 150:183 */         for (int i = 0; i < lstLists.size(); i++)
/* 151:    */         {
/* 152:184 */           List<Exprent> lst = (List)lstLists.get(i);
/* 153:    */           
/* 154:186 */           int index = 0;
/* 155:187 */           while (index < lst.size())
/* 156:    */           {
/* 157:188 */             Exprent next = null;
/* 158:189 */             if (index == lst.size() - 1)
/* 159:    */             {
/* 160:190 */               if (i < lstLists.size() - 1) {
/* 161:191 */                 next = (Exprent)((List)lstLists.get(i + 1)).get(0);
/* 162:    */               }
/* 163:    */             }
/* 164:    */             else {
/* 165:195 */               next = (Exprent)lst.get(index + 1);
/* 166:    */             }
/* 167:198 */             int[] ret = iterateExprent(lst, index, next, mapVarValues, ssa);
/* 168:202 */             if (ret[0] >= 0) {
/* 169:203 */               index = ret[0];
/* 170:    */             } else {
/* 171:206 */               index++;
/* 172:    */             }
/* 173:208 */             res |= ret[1] == 1;
/* 174:    */           }
/* 175:    */         }
/* 176:212 */         for (DirectNode ndx : nd.succs)
/* 177:    */         {
/* 178:213 */           stack.add(ndx);
/* 179:214 */           stackMaps.add(new HashMap(mapVarValues));
/* 180:    */         }
/* 181:219 */         if ((nd.exprents.isEmpty()) && ((nd.type == 3) || (nd.type == 4) || (nd.type == 5)))
/* 182:    */         {
/* 183:221 */           nd.exprents.add(null);
/* 184:223 */           if (nd.statement.type == 5)
/* 185:    */           {
/* 186:224 */             DoStatement loop = (DoStatement)nd.statement;
/* 187:226 */             if ((loop.getLooptype() == 3) && (loop.getInitExprent() == null) && (loop.getIncExprent() == null)) {
/* 188:229 */               loop.setLooptype(2);
/* 189:    */             }
/* 190:    */           }
/* 191:    */         }
/* 192:    */       }
/* 193:    */     }
/* 194:235 */     return res;
/* 195:    */   }
/* 196:    */   
/* 197:    */   private static Exprent isReplaceableVar(Exprent exprent, HashMap<VarVersionPair, Exprent> mapVarValues, SSAUConstructorSparseEx ssau)
/* 198:    */   {
/* 199:241 */     Exprent dest = null;
/* 200:243 */     if (exprent.type == 12)
/* 201:    */     {
/* 202:244 */       VarExprent var = (VarExprent)exprent;
/* 203:245 */       dest = (Exprent)mapVarValues.get(new VarVersionPair(var));
/* 204:    */     }
/* 205:248 */     return dest;
/* 206:    */   }
/* 207:    */   
/* 208:    */   private static void replaceSingleVar(Exprent parent, VarExprent var, Exprent dest, SSAUConstructorSparseEx ssau)
/* 209:    */   {
/* 210:253 */     parent.replaceExprent(var, dest);
/* 211:    */     
/* 212:    */ 
/* 213:256 */     SFormsFastMapDirect livemap = ssau.getLiveVarVersionsMap(new VarVersionPair(var));
/* 214:257 */     HashSet<VarVersionPair> setVars = getAllVersions(dest);
/* 215:259 */     for (VarVersionPair varpaar : setVars)
/* 216:    */     {
/* 217:260 */       VarVersionNode node = (VarVersionNode)ssau.getSsuversions().nodes.getWithKey(varpaar);
/* 218:262 */       for (itent = node.live.entryList().iterator(); itent.hasNext();)
/* 219:    */       {
/* 220:263 */         Map.Entry<Integer, FastSparseSetFactory.FastSparseSet<Integer>> ent = (Map.Entry)itent.next();
/* 221:    */         
/* 222:265 */         Integer key = (Integer)ent.getKey();
/* 223:267 */         if (!livemap.containsKey(key.intValue()))
/* 224:    */         {
/* 225:268 */           itent.remove();
/* 226:    */         }
/* 227:    */         else
/* 228:    */         {
/* 229:271 */           FastSparseSetFactory.FastSparseSet<Integer> set = (FastSparseSetFactory.FastSparseSet)ent.getValue();
/* 230:    */           
/* 231:273 */           set.complement(livemap.get(key.intValue()));
/* 232:274 */           if (set.isEmpty()) {
/* 233:275 */             itent.remove();
/* 234:    */           }
/* 235:    */         }
/* 236:    */       }
/* 237:    */     }
/* 238:    */     Iterator<Map.Entry<Integer, FastSparseSetFactory.FastSparseSet<Integer>>> itent;
/* 239:    */   }
/* 240:    */   
/* 241:    */   private int[] iterateExprent(List<Exprent> lstExprents, int index, Exprent next, HashMap<VarVersionPair, Exprent> mapVarValues, SSAUConstructorSparseEx ssau)
/* 242:    */   {
/* 243:285 */     Exprent exprent = (Exprent)lstExprents.get(index);
/* 244:    */     
/* 245:287 */     int changed = 0;
/* 246:289 */     for (Exprent expr : exprent.getAllExprents()) {
/* 247:    */       for (;;)
/* 248:    */       {
/* 249:291 */         Object[] arr = iterateChildExprent(expr, exprent, next, mapVarValues, ssau);
/* 250:292 */         Exprent retexpr = (Exprent)arr[0];
/* 251:293 */         changed |= (((Boolean)arr[1]).booleanValue() ? 1 : 0);
/* 252:    */         
/* 253:295 */         boolean isReplaceable = ((Boolean)arr[2]).booleanValue();
/* 254:296 */         if (retexpr != null)
/* 255:    */         {
/* 256:297 */           if (isReplaceable)
/* 257:    */           {
/* 258:298 */             replaceSingleVar(exprent, (VarExprent)expr, retexpr, ssau);
/* 259:299 */             expr = retexpr;
/* 260:    */           }
/* 261:    */           else
/* 262:    */           {
/* 263:302 */             exprent.replaceExprent(expr, retexpr);
/* 264:    */           }
/* 265:304 */           changed = 1;
/* 266:    */         }
/* 267:307 */         if (!isReplaceable) {
/* 268:    */           break;
/* 269:    */         }
/* 270:    */       }
/* 271:    */     }
/* 272:315 */     VarExprent left = null;
/* 273:316 */     Exprent right = null;
/* 274:318 */     if (exprent.type == 2)
/* 275:    */     {
/* 276:319 */       AssignmentExprent as = (AssignmentExprent)exprent;
/* 277:320 */       if (as.getLeft().type == 12)
/* 278:    */       {
/* 279:321 */         left = (VarExprent)as.getLeft();
/* 280:322 */         right = as.getRight();
/* 281:    */       }
/* 282:    */     }
/* 283:326 */     if (left == null) {
/* 284:327 */       return new int[] { -1, changed };
/* 285:    */     }
/* 286:330 */     VarVersionPair leftpaar = new VarVersionPair(left);
/* 287:    */     
/* 288:332 */     List<VarVersionNode> usedVers = new ArrayList();
/* 289:333 */     boolean notdom = getUsedVersions(ssau, leftpaar, usedVers);
/* 290:335 */     if ((!notdom) && (usedVers.isEmpty()))
/* 291:    */     {
/* 292:336 */       if ((left.isStack()) && ((right.type == 8) || (right.type == 2) || (right.type == 10)))
/* 293:    */       {
/* 294:338 */         if (right.type == 10)
/* 295:    */         {
/* 296:340 */           NewExprent nexpr = (NewExprent)right;
/* 297:341 */           if ((nexpr.isAnonymous()) || (nexpr.getNewType().arrayDim > 0) || (nexpr.getNewType().type != 8)) {
/* 298:343 */             return new int[] { -1, changed };
/* 299:    */           }
/* 300:    */         }
/* 301:347 */         lstExprents.set(index, right);
/* 302:348 */         return new int[] { index + 1, 1 };
/* 303:    */       }
/* 304:350 */       if (right.type == 12)
/* 305:    */       {
/* 306:351 */         lstExprents.remove(index);
/* 307:352 */         return new int[] { index, 1 };
/* 308:    */       }
/* 309:355 */       return new int[] { -1, changed };
/* 310:    */     }
/* 311:359 */     int useflags = right.getExprentUse();
/* 312:362 */     if ((!left.isStack()) && ((right.type != 12) || (((VarExprent)right).isStack()))) {
/* 313:364 */       return new int[] { -1, changed };
/* 314:    */     }
/* 315:367 */     if (((useflags & 0x1) == 0) && ((notdom) || (usedVers.size() > 1))) {
/* 316:368 */       return new int[] { -1, changed };
/* 317:    */     }
/* 318:371 */     HashMap<Integer, HashSet<VarVersionPair>> mapVars = getAllVarVersions(leftpaar, right, ssau);
/* 319:    */     
/* 320:373 */     boolean isSelfReference = mapVars.containsKey(Integer.valueOf(leftpaar.var));
/* 321:374 */     if ((isSelfReference) && (notdom)) {
/* 322:375 */       return new int[] { -1, changed };
/* 323:    */     }
/* 324:378 */     HashSet<VarVersionPair> setNextVars = next == null ? null : getAllVersions(next);
/* 325:381 */     if ((right.type != 3) && (right.type != 12) && (setNextVars != null) && (mapVars.containsKey(Integer.valueOf(leftpaar.var)))) {
/* 326:385 */       for (VarVersionNode usedvar : usedVers) {
/* 327:386 */         if (!setNextVars.contains(new VarVersionPair(usedvar.var, usedvar.version))) {
/* 328:387 */           return new int[] { -1, changed };
/* 329:    */         }
/* 330:    */       }
/* 331:    */     }
/* 332:392 */     mapVars.remove(Integer.valueOf(leftpaar.var));
/* 333:    */     
/* 334:394 */     boolean vernotreplaced = false;
/* 335:395 */     boolean verreplaced = false;
/* 336:    */     
/* 337:    */ 
/* 338:398 */     HashSet<VarVersionPair> setTempUsedVers = new HashSet();
/* 339:400 */     for (VarVersionNode usedvar : usedVers)
/* 340:    */     {
/* 341:401 */       VarVersionPair usedver = new VarVersionPair(usedvar.var, usedvar.version);
/* 342:402 */       if ((isVersionToBeReplaced(usedver, mapVars, ssau, leftpaar)) && ((right.type == 3) || (right.type == 12) || (right.type == 5) || (setNextVars == null) || (setNextVars.contains(usedver))))
/* 343:    */       {
/* 344:406 */         setTempUsedVers.add(usedver);
/* 345:407 */         verreplaced = true;
/* 346:    */       }
/* 347:    */       else
/* 348:    */       {
/* 349:410 */         vernotreplaced = true;
/* 350:    */       }
/* 351:    */     }
/* 352:414 */     if ((isSelfReference) && (vernotreplaced)) {
/* 353:415 */       return new int[] { -1, changed };
/* 354:    */     }
/* 355:418 */     for (VarVersionPair usedver : setTempUsedVers)
/* 356:    */     {
/* 357:419 */       Exprent copy = right.copy();
/* 358:420 */       if ((right.type == 5) && (ssau.getMapFieldVars().containsKey(Integer.valueOf(right.id)))) {
/* 359:421 */         ssau.getMapFieldVars().put(Integer.valueOf(copy.id), ssau.getMapFieldVars().get(Integer.valueOf(right.id)));
/* 360:    */       }
/* 361:424 */       mapVarValues.put(usedver, copy);
/* 362:    */     }
/* 363:428 */     if ((!notdom) && (!vernotreplaced))
/* 364:    */     {
/* 365:430 */       lstExprents.remove(index);
/* 366:431 */       return new int[] { index, 1 };
/* 367:    */     }
/* 368:433 */     if (verreplaced) {
/* 369:434 */       return new int[] { index + 1, changed };
/* 370:    */     }
/* 371:437 */     return new int[] { -1, changed };
/* 372:    */   }
/* 373:    */   
/* 374:    */   private static HashSet<VarVersionPair> getAllVersions(Exprent exprent)
/* 375:    */   {
/* 376:443 */     HashSet<VarVersionPair> res = new HashSet();
/* 377:    */     
/* 378:445 */     List<Exprent> listTemp = new ArrayList(exprent.getAllExprents(true));
/* 379:446 */     listTemp.add(exprent);
/* 380:448 */     for (Exprent expr : listTemp) {
/* 381:449 */       if (expr.type == 12)
/* 382:    */       {
/* 383:450 */         VarExprent var = (VarExprent)expr;
/* 384:451 */         res.add(new VarVersionPair(var));
/* 385:    */       }
/* 386:    */     }
/* 387:455 */     return res;
/* 388:    */   }
/* 389:    */   
/* 390:    */   private static Object[] iterateChildExprent(Exprent exprent, Exprent parent, Exprent next, HashMap<VarVersionPair, Exprent> mapVarValues, SSAUConstructorSparseEx ssau)
/* 391:    */   {
/* 392:464 */     boolean changed = false;
/* 393:466 */     for (Exprent expr : exprent.getAllExprents()) {
/* 394:    */       for (;;)
/* 395:    */       {
/* 396:468 */         Object[] arr = iterateChildExprent(expr, parent, next, mapVarValues, ssau);
/* 397:469 */         Exprent retexpr = (Exprent)arr[0];
/* 398:470 */         changed |= ((Boolean)arr[1]).booleanValue();
/* 399:    */         
/* 400:472 */         boolean isReplaceable = ((Boolean)arr[2]).booleanValue();
/* 401:473 */         if (retexpr != null)
/* 402:    */         {
/* 403:474 */           if (isReplaceable)
/* 404:    */           {
/* 405:475 */             replaceSingleVar(exprent, (VarExprent)expr, retexpr, ssau);
/* 406:476 */             expr = retexpr;
/* 407:    */           }
/* 408:    */           else
/* 409:    */           {
/* 410:479 */             exprent.replaceExprent(expr, retexpr);
/* 411:    */           }
/* 412:481 */           changed = true;
/* 413:    */         }
/* 414:484 */         if (!isReplaceable) {
/* 415:    */           break;
/* 416:    */         }
/* 417:    */       }
/* 418:    */     }
/* 419:490 */     Exprent dest = isReplaceableVar(exprent, mapVarValues, ssau);
/* 420:491 */     if (dest != null) {
/* 421:492 */       return new Object[] { dest, Boolean.valueOf(true), Boolean.valueOf(true) };
/* 422:    */     }
/* 423:496 */     VarExprent left = null;
/* 424:497 */     Exprent right = null;
/* 425:499 */     if (exprent.type == 2)
/* 426:    */     {
/* 427:500 */       AssignmentExprent as = (AssignmentExprent)exprent;
/* 428:501 */       if (as.getLeft().type == 12)
/* 429:    */       {
/* 430:502 */         left = (VarExprent)as.getLeft();
/* 431:503 */         right = as.getRight();
/* 432:    */       }
/* 433:    */     }
/* 434:507 */     if (left == null) {
/* 435:508 */       return new Object[] { null, Boolean.valueOf(changed), Boolean.valueOf(false) };
/* 436:    */     }
/* 437:511 */     boolean isHeadSynchronized = false;
/* 438:512 */     if ((next == null) && (parent.type == 9))
/* 439:    */     {
/* 440:513 */       MonitorExprent monexpr = (MonitorExprent)parent;
/* 441:514 */       if ((monexpr.getMonType() == 0) && (exprent.equals(monexpr.getValue()))) {
/* 442:515 */         isHeadSynchronized = true;
/* 443:    */       }
/* 444:    */     }
/* 445:520 */     if ((!left.isStack()) && (!isHeadSynchronized)) {
/* 446:521 */       return new Object[] { null, Boolean.valueOf(changed), Boolean.valueOf(false) };
/* 447:    */     }
/* 448:524 */     VarVersionPair leftpaar = new VarVersionPair(left);
/* 449:    */     
/* 450:526 */     List<VarVersionNode> usedVers = new ArrayList();
/* 451:527 */     boolean notdom = getUsedVersions(ssau, leftpaar, usedVers);
/* 452:529 */     if ((!notdom) && (usedVers.isEmpty())) {
/* 453:530 */       return new Object[] { right, Boolean.valueOf(changed), Boolean.valueOf(false) };
/* 454:    */     }
/* 455:534 */     if (!left.isStack()) {
/* 456:535 */       return new Object[] { null, Boolean.valueOf(changed), Boolean.valueOf(false) };
/* 457:    */     }
/* 458:538 */     int useflags = right.getExprentUse();
/* 459:540 */     if ((useflags & 0x3) != 3) {
/* 460:541 */       return new Object[] { null, Boolean.valueOf(changed), Boolean.valueOf(false) };
/* 461:    */     }
/* 462:544 */     HashMap<Integer, HashSet<VarVersionPair>> mapVars = getAllVarVersions(leftpaar, right, ssau);
/* 463:546 */     if ((mapVars.containsKey(Integer.valueOf(leftpaar.var))) && (notdom)) {
/* 464:547 */       return new Object[] { null, Boolean.valueOf(changed), Boolean.valueOf(false) };
/* 465:    */     }
/* 466:551 */     mapVars.remove(Integer.valueOf(leftpaar.var));
/* 467:    */     
/* 468:553 */     HashSet<VarVersionPair> setAllowedVars = getAllVersions(parent);
/* 469:554 */     if (next != null) {
/* 470:555 */       setAllowedVars.addAll(getAllVersions(next));
/* 471:    */     }
/* 472:558 */     boolean vernotreplaced = false;
/* 473:    */     
/* 474:560 */     HashSet<VarVersionPair> setTempUsedVers = new HashSet();
/* 475:562 */     for (VarVersionNode usedvar : usedVers)
/* 476:    */     {
/* 477:563 */       VarVersionPair usedver = new VarVersionPair(usedvar.var, usedvar.version);
/* 478:564 */       if ((isVersionToBeReplaced(usedver, mapVars, ssau, leftpaar)) && ((right.type == 12) || (setAllowedVars.contains(usedver)))) {
/* 479:567 */         setTempUsedVers.add(usedver);
/* 480:    */       } else {
/* 481:570 */         vernotreplaced = true;
/* 482:    */       }
/* 483:    */     }
/* 484:574 */     if ((!notdom) && (!vernotreplaced))
/* 485:    */     {
/* 486:576 */       for (VarVersionPair usedver : setTempUsedVers)
/* 487:    */       {
/* 488:577 */         Exprent copy = right.copy();
/* 489:578 */         if ((right.type == 5) && (ssau.getMapFieldVars().containsKey(Integer.valueOf(right.id)))) {
/* 490:579 */           ssau.getMapFieldVars().put(Integer.valueOf(copy.id), ssau.getMapFieldVars().get(Integer.valueOf(right.id)));
/* 491:    */         }
/* 492:582 */         mapVarValues.put(usedver, copy);
/* 493:    */       }
/* 494:586 */       return new Object[] { right, Boolean.valueOf(changed), Boolean.valueOf(false) };
/* 495:    */     }
/* 496:589 */     return new Object[] { null, Boolean.valueOf(changed), Boolean.valueOf(false) };
/* 497:    */   }
/* 498:    */   
/* 499:    */   private static boolean getUsedVersions(SSAUConstructorSparseEx ssa, VarVersionPair var, List<VarVersionNode> res)
/* 500:    */   {
/* 501:594 */     VarVersionsGraph ssuversions = ssa.getSsuversions();
/* 502:595 */     VarVersionNode varnode = (VarVersionNode)ssuversions.nodes.getWithKey(var);
/* 503:    */     
/* 504:597 */     HashSet<VarVersionNode> setVisited = new HashSet();
/* 505:    */     
/* 506:599 */     HashSet<VarVersionNode> setNotDoms = new HashSet();
/* 507:    */     
/* 508:601 */     LinkedList<VarVersionNode> stack = new LinkedList();
/* 509:602 */     stack.add(varnode);
/* 510:604 */     while (!stack.isEmpty())
/* 511:    */     {
/* 512:606 */       VarVersionNode nd = (VarVersionNode)stack.remove(0);
/* 513:607 */       setVisited.add(nd);
/* 514:609 */       if ((nd != varnode) && ((nd.flags & 0x2) == 0)) {
/* 515:610 */         res.add(nd);
/* 516:    */       }
/* 517:613 */       for (VarVersionEdge edge : nd.succs)
/* 518:    */       {
/* 519:614 */         VarVersionNode succ = edge.dest;
/* 520:616 */         if (!setVisited.contains(edge.dest))
/* 521:    */         {
/* 522:618 */           boolean isDominated = true;
/* 523:619 */           for (VarVersionEdge prededge : succ.preds) {
/* 524:620 */             if (!setVisited.contains(prededge.source))
/* 525:    */             {
/* 526:621 */               isDominated = false;
/* 527:622 */               break;
/* 528:    */             }
/* 529:    */           }
/* 530:626 */           if (isDominated) {
/* 531:627 */             stack.add(succ);
/* 532:    */           } else {
/* 533:630 */             setNotDoms.add(succ);
/* 534:    */           }
/* 535:    */         }
/* 536:    */       }
/* 537:    */     }
/* 538:636 */     setNotDoms.removeAll(setVisited);
/* 539:    */     
/* 540:638 */     return !setNotDoms.isEmpty();
/* 541:    */   }
/* 542:    */   
/* 543:    */   private static boolean isVersionToBeReplaced(VarVersionPair usedvar, HashMap<Integer, HashSet<VarVersionPair>> mapVars, SSAUConstructorSparseEx ssau, VarVersionPair leftpaar)
/* 544:    */   {
/* 545:646 */     VarVersionsGraph ssuversions = ssau.getSsuversions();
/* 546:    */     
/* 547:648 */     SFormsFastMapDirect mapLiveVars = ssau.getLiveVarVersionsMap(usedvar);
/* 548:649 */     if (mapLiveVars == null) {
/* 549:651 */       return false;
/* 550:    */     }
/* 551:655 */     if (!InterpreterUtil.equalObjects(ssau.getMapVersionFirstRange().get(leftpaar), ssau.getMapVersionFirstRange().get(usedvar))) {
/* 552:657 */       return false;
/* 553:    */     }
/* 554:660 */     for (Map.Entry<Integer, HashSet<VarVersionPair>> ent : mapVars.entrySet())
/* 555:    */     {
/* 556:661 */       FastSparseSetFactory.FastSparseSet<Integer> liveverset = mapLiveVars.get(((Integer)ent.getKey()).intValue());
/* 557:662 */       if (liveverset == null) {
/* 558:663 */         return false;
/* 559:    */       }
/* 560:666 */       HashSet<VarVersionNode> domset = new HashSet();
/* 561:667 */       for (VarVersionPair verpaar : (HashSet)ent.getValue()) {
/* 562:668 */         domset.add(ssuversions.nodes.getWithKey(verpaar));
/* 563:    */       }
/* 564:671 */       boolean isdom = false;
/* 565:673 */       for (Integer livever : liveverset)
/* 566:    */       {
/* 567:674 */         VarVersionNode node = (VarVersionNode)ssuversions.nodes.getWithKey(new VarVersionPair(((Integer)ent.getKey()).intValue(), livever.intValue()));
/* 568:676 */         if (ssuversions.isDominatorSet(node, domset))
/* 569:    */         {
/* 570:677 */           isdom = true;
/* 571:678 */           break;
/* 572:    */         }
/* 573:    */       }
/* 574:682 */       if (!isdom) {
/* 575:683 */         return false;
/* 576:    */       }
/* 577:    */     }
/* 578:687 */     return true;
/* 579:    */   }
/* 580:    */   
/* 581:    */   private static HashMap<Integer, HashSet<VarVersionPair>> getAllVarVersions(VarVersionPair leftvar, Exprent exprent, SSAUConstructorSparseEx ssau)
/* 582:    */   {
/* 583:694 */     HashMap<Integer, HashSet<VarVersionPair>> map = new HashMap();
/* 584:695 */     SFormsFastMapDirect mapLiveVars = ssau.getLiveVarVersionsMap(leftvar);
/* 585:    */     
/* 586:697 */     List<Exprent> lst = exprent.getAllExprents(true);
/* 587:698 */     lst.add(exprent);
/* 588:700 */     for (Exprent expr : lst) {
/* 589:701 */       if (expr.type == 12)
/* 590:    */       {
/* 591:702 */         int varindex = ((VarExprent)expr).getIndex();
/* 592:703 */         if (leftvar.var != varindex)
/* 593:    */         {
/* 594:704 */           if (mapLiveVars.containsKey(varindex))
/* 595:    */           {
/* 596:705 */             HashSet<VarVersionPair> verset = new HashSet();
/* 597:706 */             for (Integer vers : mapLiveVars.get(varindex)) {
/* 598:707 */               verset.add(new VarVersionPair(varindex, vers.intValue()));
/* 599:    */             }
/* 600:709 */             map.put(Integer.valueOf(varindex), verset);
/* 601:    */           }
/* 602:    */           else
/* 603:    */           {
/* 604:712 */             throw new RuntimeException("inkonsistent live map!");
/* 605:    */           }
/* 606:    */         }
/* 607:    */         else {
/* 608:716 */           map.put(Integer.valueOf(varindex), null);
/* 609:    */         }
/* 610:    */       }
/* 611:719 */       else if ((expr.type == 5) && 
/* 612:720 */         (ssau.getMapFieldVars().containsKey(Integer.valueOf(expr.id))))
/* 613:    */       {
/* 614:721 */         int varindex = ((Integer)ssau.getMapFieldVars().get(Integer.valueOf(expr.id))).intValue();
/* 615:722 */         if (mapLiveVars.containsKey(varindex))
/* 616:    */         {
/* 617:723 */           HashSet<VarVersionPair> verset = new HashSet();
/* 618:724 */           for (Integer vers : mapLiveVars.get(varindex)) {
/* 619:725 */             verset.add(new VarVersionPair(varindex, vers.intValue()));
/* 620:    */           }
/* 621:727 */           map.put(Integer.valueOf(varindex), verset);
/* 622:    */         }
/* 623:    */       }
/* 624:    */     }
/* 625:733 */     return map;
/* 626:    */   }
/* 627:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.StackVarsProcessor
 * JD-Core Version:    0.7.0.1
 */