/*   1:    */ package org.jetbrains.java.decompiler.modules.decompiler;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Set;
/*   7:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.DoStatement;
/*   8:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
/*   9:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement;
/*  10:    */ import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
/*  11:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  12:    */ 
/*  13:    */ public class LoopExtractHelper
/*  14:    */ {
/*  15:    */   public static boolean extractLoops(Statement root)
/*  16:    */   {
/*  17: 33 */     boolean res = extractLoopsRec(root) != 0;
/*  18: 35 */     if (res) {
/*  19: 36 */       SequenceHelper.condenseSequences(root);
/*  20:    */     }
/*  21: 39 */     return res;
/*  22:    */   }
/*  23:    */   
/*  24:    */   private static int extractLoopsRec(Statement stat)
/*  25:    */   {
/*  26: 45 */     boolean res = false;
/*  27:    */     for (;;)
/*  28:    */     {
/*  29: 49 */       boolean updated = false;
/*  30: 51 */       for (Statement st : stat.getStats())
/*  31:    */       {
/*  32: 52 */         int extr = extractLoopsRec(st);
/*  33: 53 */         res |= extr != 0;
/*  34: 55 */         if (extr == 2)
/*  35:    */         {
/*  36: 56 */           updated = true;
/*  37: 57 */           break;
/*  38:    */         }
/*  39:    */       }
/*  40: 61 */       if (!updated) {
/*  41:    */         break;
/*  42:    */       }
/*  43:    */     }
/*  44: 66 */     if ((stat.type == 5) && 
/*  45: 67 */       (extractLoop((DoStatement)stat))) {
/*  46: 68 */       return 2;
/*  47:    */     }
/*  48: 72 */     return res ? 1 : 0;
/*  49:    */   }
/*  50:    */   
/*  51:    */   private static boolean extractLoop(DoStatement stat)
/*  52:    */   {
/*  53: 78 */     if (stat.getLooptype() != 0) {
/*  54: 79 */       return false;
/*  55:    */     }
/*  56: 82 */     for (StatEdge edge : stat.getLabelEdges()) {
/*  57: 83 */       if ((edge.getType() != 8) && (edge.getDestination().type != 14)) {
/*  58: 84 */         return false;
/*  59:    */       }
/*  60:    */     }
/*  61: 88 */     if (!extractLastIf(stat)) {
/*  62: 89 */       return extractFirstIf(stat);
/*  63:    */     }
/*  64: 92 */     return true;
/*  65:    */   }
/*  66:    */   
/*  67:    */   private static boolean extractLastIf(DoStatement stat)
/*  68:    */   {
/*  69: 99 */     Statement last = stat.getFirst();
/*  70:100 */     while (last.type == 15) {
/*  71:101 */       last = (Statement)last.getStats().getLast();
/*  72:    */     }
/*  73:104 */     if (last.type == 2)
/*  74:    */     {
/*  75:105 */       IfStatement lastif = (IfStatement)last;
/*  76:106 */       if ((lastif.iftype == 0) && (lastif.getIfstat() != null))
/*  77:    */       {
/*  78:107 */         Statement ifstat = lastif.getIfstat();
/*  79:108 */         StatEdge elseedge = (StatEdge)lastif.getAllSuccessorEdges().get(0);
/*  80:110 */         if ((elseedge.getType() == 8) && (elseedge.closure == stat))
/*  81:    */         {
/*  82:112 */           Set<Statement> set = stat.getNeighboursSet(8, 0);
/*  83:113 */           set.remove(last);
/*  84:115 */           if ((set.isEmpty()) && 
/*  85:116 */             (isExternStatement(stat, ifstat, ifstat)))
/*  86:    */           {
/*  87:117 */             extractIfBlock(stat, lastif);
/*  88:118 */             return true;
/*  89:    */           }
/*  90:    */         }
/*  91:    */       }
/*  92:    */     }
/*  93:124 */     return false;
/*  94:    */   }
/*  95:    */   
/*  96:    */   private static boolean extractFirstIf(DoStatement stat)
/*  97:    */   {
/*  98:130 */     Statement first = stat.getFirst();
/*  99:131 */     while (first.type == 15) {
/* 100:132 */       first = first.getFirst();
/* 101:    */     }
/* 102:136 */     if (first.type == 2)
/* 103:    */     {
/* 104:137 */       IfStatement firstif = (IfStatement)first;
/* 105:139 */       if (firstif.getFirst().getExprents().isEmpty()) {
/* 106:141 */         if ((firstif.iftype == 0) && (firstif.getIfstat() != null))
/* 107:    */         {
/* 108:142 */           Statement ifstat = firstif.getIfstat();
/* 109:144 */           if (isExternStatement(stat, ifstat, ifstat))
/* 110:    */           {
/* 111:145 */             extractIfBlock(stat, firstif);
/* 112:146 */             return true;
/* 113:    */           }
/* 114:    */         }
/* 115:    */       }
/* 116:    */     }
/* 117:151 */     return false;
/* 118:    */   }
/* 119:    */   
/* 120:    */   private static boolean isExternStatement(DoStatement loop, Statement block, Statement stat)
/* 121:    */   {
/* 122:157 */     for (StatEdge edge : stat.getAllSuccessorEdges()) {
/* 123:158 */       if ((loop.containsStatement(edge.getDestination())) && (!block.containsStatement(edge.getDestination()))) {
/* 124:160 */         return false;
/* 125:    */       }
/* 126:    */     }
/* 127:164 */     for (Statement st : stat.getStats()) {
/* 128:165 */       if (!isExternStatement(loop, block, st)) {
/* 129:166 */         return false;
/* 130:    */       }
/* 131:    */     }
/* 132:170 */     return true;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static void extractIfBlock(DoStatement loop, IfStatement ifstat)
/* 136:    */   {
/* 137:176 */     Statement target = ifstat.getIfstat();
/* 138:177 */     StatEdge ifedge = ifstat.getIfEdge();
/* 139:    */     
/* 140:179 */     ifstat.setIfstat(null);
/* 141:180 */     ifedge.getSource().changeEdgeType(1, ifedge, 4);
/* 142:181 */     ifedge.closure = loop;
/* 143:182 */     ifstat.getStats().removeWithKey(target.id);
/* 144:    */     
/* 145:184 */     loop.addLabeledEdge(ifedge);
/* 146:    */     
/* 147:186 */     SequenceStatement block = new SequenceStatement(Arrays.asList(new Statement[] { loop, target }));
/* 148:187 */     loop.getParent().replaceStatement(loop, block);
/* 149:188 */     block.setAllParent();
/* 150:    */     
/* 151:190 */     loop.addSuccessor(new StatEdge(1, loop, target));
/* 152:192 */     for (StatEdge edge : new ArrayList(block.getLabelEdges())) {
/* 153:193 */       if ((edge.getType() == 8) || (edge == ifedge)) {
/* 154:194 */         loop.addLabeledEdge(edge);
/* 155:    */       }
/* 156:    */     }
/* 157:198 */     for (StatEdge edge : block.getPredecessorEdges(8)) {
/* 158:199 */       if (loop.containsStatementStrict(edge.getSource()))
/* 159:    */       {
/* 160:200 */         block.removePredecessor(edge);
/* 161:201 */         edge.getSource().changeEdgeNode(1, edge, loop);
/* 162:202 */         loop.addPredecessor(edge);
/* 163:    */       }
/* 164:    */     }
/* 165:    */   }
/* 166:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.decompiler.LoopExtractHelper
 * JD-Core Version:    0.7.0.1
 */