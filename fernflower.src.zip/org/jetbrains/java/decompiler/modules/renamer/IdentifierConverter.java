/*   1:    */ package org.jetbrains.java.decompiler.modules.renamer;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.LinkedList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.jetbrains.java.decompiler.main.DecompilerContext;
/*  12:    */ import org.jetbrains.java.decompiler.main.extern.IIdentifierRenamer;
/*  13:    */ import org.jetbrains.java.decompiler.main.extern.IIdentifierRenamer.Type;
/*  14:    */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  15:    */ import org.jetbrains.java.decompiler.struct.StructContext;
/*  16:    */ import org.jetbrains.java.decompiler.struct.StructField;
/*  17:    */ import org.jetbrains.java.decompiler.struct.StructMethod;
/*  18:    */ import org.jetbrains.java.decompiler.struct.consts.PrimitiveConstant;
/*  19:    */ import org.jetbrains.java.decompiler.struct.gen.FieldDescriptor;
/*  20:    */ import org.jetbrains.java.decompiler.struct.gen.MethodDescriptor;
/*  21:    */ import org.jetbrains.java.decompiler.struct.gen.NewClassNameBuilder;
/*  22:    */ import org.jetbrains.java.decompiler.util.VBStyleCollection;
/*  23:    */ 
/*  24:    */ public class IdentifierConverter
/*  25:    */   implements NewClassNameBuilder
/*  26:    */ {
/*  27:    */   private StructContext context;
/*  28:    */   private IIdentifierRenamer helper;
/*  29:    */   private PoolInterceptor interceptor;
/*  30: 39 */   private List<ClassWrapperNode> rootClasses = new ArrayList();
/*  31: 40 */   private List<ClassWrapperNode> rootInterfaces = new ArrayList();
/*  32: 41 */   private Map<String, Map<String, String>> interfaceNameMaps = new HashMap();
/*  33:    */   
/*  34:    */   public void rename(StructContext context)
/*  35:    */   {
/*  36:    */     try
/*  37:    */     {
/*  38: 45 */       this.context = context;
/*  39:    */       
/*  40: 47 */       String user_class = (String)DecompilerContext.getProperty("urc");
/*  41: 48 */       if (user_class != null) {
/*  42:    */         try
/*  43:    */         {
/*  44: 50 */           this.helper = ((IIdentifierRenamer)IdentifierConverter.class.getClassLoader().loadClass(user_class).newInstance());
/*  45:    */         }
/*  46:    */         catch (Exception ignored) {}
/*  47:    */       }
/*  48: 55 */       if (this.helper == null) {
/*  49: 56 */         this.helper = new ConverterHelper();
/*  50:    */       }
/*  51: 59 */       this.interceptor = new PoolInterceptor(this.helper);
/*  52:    */       
/*  53: 61 */       buildInheritanceTree();
/*  54:    */       
/*  55: 63 */       renameAllClasses();
/*  56:    */       
/*  57: 65 */       renameInterfaces();
/*  58:    */       
/*  59: 67 */       renameClasses();
/*  60:    */       
/*  61: 69 */       DecompilerContext.setPoolInterceptor(this.interceptor);
/*  62: 70 */       context.reloadContext();
/*  63:    */     }
/*  64:    */     catch (IOException ex)
/*  65:    */     {
/*  66: 73 */       throw new RuntimeException("Renaming failed!");
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   private void renameClasses()
/*  71:    */   {
/*  72: 78 */     List<ClassWrapperNode> lstClasses = getReversePostOrderListIterative(this.rootClasses);
/*  73: 79 */     Map<String, Map<String, String>> classNameMaps = new HashMap();
/*  74: 81 */     for (ClassWrapperNode node : lstClasses)
/*  75:    */     {
/*  76: 82 */       StructClass cl = node.getClassStruct();
/*  77: 83 */       Map<String, String> names = new HashMap();
/*  78: 86 */       if (cl.superClass != null)
/*  79:    */       {
/*  80: 87 */         Map<String, String> mapClass = (Map)classNameMaps.get(cl.superClass.getString());
/*  81: 88 */         if (mapClass != null) {
/*  82: 89 */           names.putAll(mapClass);
/*  83:    */         }
/*  84:    */       }
/*  85: 94 */       for (String ifName : cl.getInterfaceNames())
/*  86:    */       {
/*  87: 95 */         Map<String, String> mapInt = (Map)this.interfaceNameMaps.get(ifName);
/*  88: 96 */         if (mapInt != null)
/*  89:    */         {
/*  90: 97 */           names.putAll(mapInt);
/*  91:    */         }
/*  92:    */         else
/*  93:    */         {
/*  94:100 */           StructClass clintr = this.context.getClass(ifName);
/*  95:101 */           if (clintr != null) {
/*  96:102 */             names.putAll(processExternalInterface(clintr));
/*  97:    */           }
/*  98:    */         }
/*  99:    */       }
/* 100:107 */       renameClassIdentifiers(cl, names);
/* 101:109 */       if (!node.getSubclasses().isEmpty()) {
/* 102:110 */         classNameMaps.put(cl.qualifiedName, names);
/* 103:    */       }
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   private Map<String, String> processExternalInterface(StructClass cl)
/* 108:    */   {
/* 109:116 */     Map<String, String> names = new HashMap();
/* 110:118 */     for (String ifName : cl.getInterfaceNames())
/* 111:    */     {
/* 112:119 */       Map<String, String> mapInt = (Map)this.interfaceNameMaps.get(ifName);
/* 113:120 */       if (mapInt != null)
/* 114:    */       {
/* 115:121 */         names.putAll(mapInt);
/* 116:    */       }
/* 117:    */       else
/* 118:    */       {
/* 119:124 */         StructClass clintr = this.context.getClass(ifName);
/* 120:125 */         if (clintr != null) {
/* 121:126 */           names.putAll(processExternalInterface(clintr));
/* 122:    */         }
/* 123:    */       }
/* 124:    */     }
/* 125:131 */     renameClassIdentifiers(cl, names);
/* 126:    */     
/* 127:133 */     return names;
/* 128:    */   }
/* 129:    */   
/* 130:    */   private void renameInterfaces()
/* 131:    */   {
/* 132:137 */     List<ClassWrapperNode> lstInterfaces = getReversePostOrderListIterative(this.rootInterfaces);
/* 133:138 */     Map<String, Map<String, String>> interfaceNameMaps = new HashMap();
/* 134:141 */     for (ClassWrapperNode node : lstInterfaces)
/* 135:    */     {
/* 136:143 */       StructClass cl = node.getClassStruct();
/* 137:144 */       Map<String, String> names = new HashMap();
/* 138:147 */       for (String ifName : cl.getInterfaceNames())
/* 139:    */       {
/* 140:148 */         Map<String, String> mapInt = (Map)interfaceNameMaps.get(ifName);
/* 141:149 */         if (mapInt != null) {
/* 142:150 */           names.putAll(mapInt);
/* 143:    */         }
/* 144:    */       }
/* 145:154 */       renameClassIdentifiers(cl, names);
/* 146:    */       
/* 147:156 */       interfaceNameMaps.put(cl.qualifiedName, names);
/* 148:    */     }
/* 149:159 */     this.interfaceNameMaps = interfaceNameMaps;
/* 150:    */   }
/* 151:    */   
/* 152:    */   private void renameAllClasses()
/* 153:    */   {
/* 154:164 */     List<ClassWrapperNode> lstAllClasses = new ArrayList(getReversePostOrderListIterative(this.rootInterfaces));
/* 155:165 */     lstAllClasses.addAll(getReversePostOrderListIterative(this.rootClasses));
/* 156:168 */     for (ClassWrapperNode node : lstAllClasses) {
/* 157:169 */       renameClass(node.getClassStruct());
/* 158:    */     }
/* 159:    */   }
/* 160:    */   
/* 161:    */   private void renameClass(StructClass cl)
/* 162:    */   {
/* 163:175 */     if (!cl.isOwn()) {
/* 164:176 */       return;
/* 165:    */     }
/* 166:179 */     String classOldFullName = cl.qualifiedName;
/* 167:    */     
/* 168:    */ 
/* 169:182 */     String clSimpleName = ConverterHelper.getSimpleClassName(classOldFullName);
/* 170:183 */     if (this.helper.toBeRenamed(IIdentifierRenamer.Type.ELEMENT_CLASS, clSimpleName, null, null))
/* 171:    */     {
/* 172:    */       String classNewFullName;
/* 173:    */       do
/* 174:    */       {
/* 175:187 */         String classname = this.helper.getNextClassName(classOldFullName, ConverterHelper.getSimpleClassName(classOldFullName));
/* 176:188 */         classNewFullName = ConverterHelper.replaceSimpleClassName(classOldFullName, classname);
/* 177:190 */       } while (this.context.getClasses().containsKey(classNewFullName));
/* 178:192 */       this.interceptor.addName(classOldFullName, classNewFullName);
/* 179:    */     }
/* 180:    */   }
/* 181:    */   
/* 182:    */   private void renameClassIdentifiers(StructClass cl, Map<String, String> names)
/* 183:    */   {
/* 184:198 */     String classOldFullName = cl.qualifiedName;
/* 185:199 */     String classNewFullName = this.interceptor.getName(classOldFullName);
/* 186:201 */     if (classNewFullName == null) {
/* 187:202 */       classNewFullName = classOldFullName;
/* 188:    */     }
/* 189:206 */     HashSet<String> setMethodNames = new HashSet();
/* 190:207 */     for (StructMethod md : cl.getMethods()) {
/* 191:208 */       setMethodNames.add(md.getName());
/* 192:    */     }
/* 193:211 */     VBStyleCollection<StructMethod, String> methods = cl.getMethods();
/* 194:212 */     for (int i = 0; i < methods.size(); i++)
/* 195:    */     {
/* 196:214 */       StructMethod mt = (StructMethod)methods.get(i);
/* 197:215 */       String key = (String)methods.getKey(i);
/* 198:    */       
/* 199:217 */       boolean isPrivate = mt.hasModifier(2);
/* 200:    */       
/* 201:219 */       String name = mt.getName();
/* 202:220 */       if ((!cl.isOwn()) || (mt.hasModifier(256)))
/* 203:    */       {
/* 204:222 */         if (!isPrivate) {
/* 205:223 */           names.put(key, name);
/* 206:    */         }
/* 207:    */       }
/* 208:226 */       else if (this.helper.toBeRenamed(IIdentifierRenamer.Type.ELEMENT_METHOD, classOldFullName, name, mt.getDescriptor()))
/* 209:    */       {
/* 210:227 */         if ((isPrivate) || (!names.containsKey(key)))
/* 211:    */         {
/* 212:    */           do
/* 213:    */           {
/* 214:229 */             name = this.helper.getNextMethodName(classOldFullName, name, mt.getDescriptor());
/* 215:231 */           } while (setMethodNames.contains(name));
/* 216:233 */           if (!isPrivate) {
/* 217:234 */             names.put(key, name);
/* 218:    */           }
/* 219:    */         }
/* 220:    */         else
/* 221:    */         {
/* 222:238 */           name = (String)names.get(key);
/* 223:    */         }
/* 224:241 */         this.interceptor.addName(classOldFullName + " " + mt.getName() + " " + mt.getDescriptor(), classNewFullName + " " + name + " " + buildNewDescriptor(false, mt.getDescriptor()));
/* 225:    */       }
/* 226:    */     }
/* 227:247 */     if (!cl.isOwn()) {
/* 228:248 */       return;
/* 229:    */     }
/* 230:253 */     HashSet<String> setFieldNames = new HashSet();
/* 231:254 */     for (StructField fd : cl.getFields()) {
/* 232:255 */       setFieldNames.add(fd.getName());
/* 233:    */     }
/* 234:258 */     for (StructField fd : cl.getFields()) {
/* 235:259 */       if (this.helper.toBeRenamed(IIdentifierRenamer.Type.ELEMENT_FIELD, classOldFullName, fd.getName(), fd.getDescriptor()))
/* 236:    */       {
/* 237:    */         String newName;
/* 238:    */         do
/* 239:    */         {
/* 240:262 */           newName = this.helper.getNextFieldName(classOldFullName, fd.getName(), fd.getDescriptor());
/* 241:264 */         } while (setFieldNames.contains(newName));
/* 242:266 */         this.interceptor.addName(classOldFullName + " " + fd.getName() + " " + fd.getDescriptor(), classNewFullName + " " + newName + " " + buildNewDescriptor(true, fd.getDescriptor()));
/* 243:    */       }
/* 244:    */     }
/* 245:    */   }
/* 246:    */   
/* 247:    */   public String buildNewClassname(String className)
/* 248:    */   {
/* 249:274 */     return this.interceptor.getName(className);
/* 250:    */   }
/* 251:    */   
/* 252:    */   private String buildNewDescriptor(boolean isField, String descriptor)
/* 253:    */   {
/* 254:    */     String newDescriptor;
/* 255:    */     String newDescriptor;
/* 256:279 */     if (isField) {
/* 257:280 */       newDescriptor = FieldDescriptor.parseDescriptor(descriptor).buildNewDescriptor(this);
/* 258:    */     } else {
/* 259:283 */       newDescriptor = MethodDescriptor.parseDescriptor(descriptor).buildNewDescriptor(this);
/* 260:    */     }
/* 261:285 */     return newDescriptor != null ? newDescriptor : descriptor;
/* 262:    */   }
/* 263:    */   
/* 264:    */   private static List<ClassWrapperNode> getReversePostOrderListIterative(List<ClassWrapperNode> roots)
/* 265:    */   {
/* 266:289 */     List<ClassWrapperNode> res = new ArrayList();
/* 267:    */     
/* 268:291 */     LinkedList<ClassWrapperNode> stackNode = new LinkedList();
/* 269:292 */     LinkedList<Integer> stackIndex = new LinkedList();
/* 270:    */     
/* 271:294 */     Set<ClassWrapperNode> setVisited = new HashSet();
/* 272:296 */     for (ClassWrapperNode root : roots)
/* 273:    */     {
/* 274:297 */       stackNode.add(root);
/* 275:298 */       stackIndex.add(Integer.valueOf(0));
/* 276:    */     }
/* 277:301 */     while (!stackNode.isEmpty())
/* 278:    */     {
/* 279:302 */       ClassWrapperNode node = (ClassWrapperNode)stackNode.getLast();
/* 280:303 */       int index = ((Integer)stackIndex.removeLast()).intValue();
/* 281:    */       
/* 282:305 */       setVisited.add(node);
/* 283:    */       
/* 284:307 */       List<ClassWrapperNode> lstSubs = node.getSubclasses();
/* 285:309 */       for (; index < lstSubs.size(); index++)
/* 286:    */       {
/* 287:310 */         ClassWrapperNode sub = (ClassWrapperNode)lstSubs.get(index);
/* 288:311 */         if (!setVisited.contains(sub))
/* 289:    */         {
/* 290:312 */           stackIndex.add(Integer.valueOf(index + 1));
/* 291:313 */           stackNode.add(sub);
/* 292:314 */           stackIndex.add(Integer.valueOf(0));
/* 293:315 */           break;
/* 294:    */         }
/* 295:    */       }
/* 296:319 */       if (index == lstSubs.size())
/* 297:    */       {
/* 298:320 */         res.add(0, node);
/* 299:321 */         stackNode.removeLast();
/* 300:    */       }
/* 301:    */     }
/* 302:325 */     return res;
/* 303:    */   }
/* 304:    */   
/* 305:    */   private void buildInheritanceTree()
/* 306:    */   {
/* 307:329 */     Map<String, ClassWrapperNode> nodes = new HashMap();
/* 308:330 */     Map<String, StructClass> classes = this.context.getClasses();
/* 309:    */     
/* 310:332 */     List<ClassWrapperNode> rootClasses = new ArrayList();
/* 311:333 */     List<ClassWrapperNode> rootInterfaces = new ArrayList();
/* 312:335 */     for (StructClass cl : classes.values()) {
/* 313:336 */       if (cl.isOwn())
/* 314:    */       {
/* 315:340 */         LinkedList<StructClass> stack = new LinkedList();
/* 316:341 */         LinkedList<ClassWrapperNode> stackSubNodes = new LinkedList();
/* 317:    */         
/* 318:343 */         stack.add(cl);
/* 319:344 */         stackSubNodes.add(null);
/* 320:346 */         while (!stack.isEmpty())
/* 321:    */         {
/* 322:347 */           StructClass clStr = (StructClass)stack.removeFirst();
/* 323:348 */           ClassWrapperNode child = (ClassWrapperNode)stackSubNodes.removeFirst();
/* 324:    */           
/* 325:350 */           ClassWrapperNode node = (ClassWrapperNode)nodes.get(clStr.qualifiedName);
/* 326:351 */           boolean isNewNode = node == null;
/* 327:353 */           if (isNewNode) {
/* 328:354 */             nodes.put(clStr.qualifiedName, node = new ClassWrapperNode(clStr));
/* 329:    */           }
/* 330:358 */           if (child != null) {
/* 331:359 */             node.addSubclass(child);
/* 332:    */           }
/* 333:362 */           if (!isNewNode) {
/* 334:    */             break;
/* 335:    */           }
/* 336:366 */           boolean isInterface = clStr.hasModifier(512);
/* 337:367 */           boolean found_parent = false;
/* 338:369 */           if (isInterface)
/* 339:    */           {
/* 340:370 */             for (String ifName : clStr.getInterfaceNames())
/* 341:    */             {
/* 342:371 */               StructClass clParent = (StructClass)classes.get(ifName);
/* 343:372 */               if (clParent != null)
/* 344:    */               {
/* 345:373 */                 stack.add(clParent);
/* 346:374 */                 stackSubNodes.add(node);
/* 347:375 */                 found_parent = true;
/* 348:    */               }
/* 349:    */             }
/* 350:    */           }
/* 351:379 */           else if (clStr.superClass != null)
/* 352:    */           {
/* 353:380 */             StructClass clParent = (StructClass)classes.get(clStr.superClass.getString());
/* 354:381 */             if (clParent != null)
/* 355:    */             {
/* 356:382 */               stack.add(clParent);
/* 357:383 */               stackSubNodes.add(node);
/* 358:384 */               found_parent = true;
/* 359:    */             }
/* 360:    */           }
/* 361:388 */           if (!found_parent) {
/* 362:389 */             (isInterface ? rootInterfaces : rootClasses).add(node);
/* 363:    */           }
/* 364:    */         }
/* 365:    */       }
/* 366:    */     }
/* 367:395 */     this.rootClasses = rootClasses;
/* 368:396 */     this.rootInterfaces = rootInterfaces;
/* 369:    */   }
/* 370:    */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.renamer.IdentifierConverter
 * JD-Core Version:    0.7.0.1
 */