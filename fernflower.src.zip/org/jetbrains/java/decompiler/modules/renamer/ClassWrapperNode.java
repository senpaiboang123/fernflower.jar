/*  1:   */ package org.jetbrains.java.decompiler.modules.renamer;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ import org.jetbrains.java.decompiler.struct.StructClass;
/*  6:   */ 
/*  7:   */ public class ClassWrapperNode
/*  8:   */ {
/*  9:   */   private final StructClass classStruct;
/* 10:   */   private ClassWrapperNode superclass;
/* 11:29 */   private final List<ClassWrapperNode> subclasses = new ArrayList();
/* 12:   */   
/* 13:   */   public ClassWrapperNode(StructClass cl)
/* 14:   */   {
/* 15:32 */     this.classStruct = cl;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void addSubclass(ClassWrapperNode node)
/* 19:   */   {
/* 20:36 */     node.setSuperclass(this);
/* 21:37 */     this.subclasses.add(node);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public StructClass getClassStruct()
/* 25:   */   {
/* 26:41 */     return this.classStruct;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public List<ClassWrapperNode> getSubclasses()
/* 30:   */   {
/* 31:45 */     return this.subclasses;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public ClassWrapperNode getSuperclass()
/* 35:   */   {
/* 36:49 */     return this.superclass;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setSuperclass(ClassWrapperNode superclass)
/* 40:   */   {
/* 41:53 */     this.superclass = superclass;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.renamer.ClassWrapperNode
 * JD-Core Version:    0.7.0.1
 */