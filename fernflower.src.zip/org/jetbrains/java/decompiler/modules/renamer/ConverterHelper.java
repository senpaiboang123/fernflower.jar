/*  1:   */ package org.jetbrains.java.decompiler.modules.renamer;
/*  2:   */ 
/*  3:   */ import java.util.Arrays;
/*  4:   */ import java.util.HashSet;
/*  5:   */ import java.util.Set;
/*  6:   */ import org.jetbrains.java.decompiler.main.extern.IIdentifierRenamer;
/*  7:   */ import org.jetbrains.java.decompiler.main.extern.IIdentifierRenamer.Type;
/*  8:   */ 
/*  9:   */ public class ConverterHelper
/* 10:   */   implements IIdentifierRenamer
/* 11:   */ {
/* 12:26 */   private static final Set<String> KEYWORDS = new HashSet(Arrays.asList(new String[] { "abstract", "do", "if", "package", "synchronized", "boolean", "double", "implements", "private", "this", "break", "else", "import", "protected", "throw", "byte", "extends", "instanceof", "public", "throws", "case", "false", "int", "return", "transient", "catch", "final", "interface", "short", "true", "char", "finally", "long", "static", "try", "class", "float", "native", "strictfp", "void", "const", "for", "new", "super", "volatile", "continue", "goto", "null", "switch", "while", "default", "assert", "enum" }));
/* 13:32 */   private int classCounter = 0;
/* 14:33 */   private int fieldCounter = 0;
/* 15:34 */   private int methodCounter = 0;
/* 16:35 */   private final Set<String> setNonStandardClassNames = new HashSet();
/* 17:   */   
/* 18:   */   public boolean toBeRenamed(IIdentifierRenamer.Type elementType, String className, String element, String descriptor)
/* 19:   */   {
/* 20:39 */     String value = elementType == IIdentifierRenamer.Type.ELEMENT_CLASS ? className : element;
/* 21:40 */     return (value == null) || (value.length() == 0) || (value.length() <= 2) || (KEYWORDS.contains(value)) || (Character.isDigit(value.charAt(0)));
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getNextClassName(String fullName, String shortName)
/* 25:   */   {
/* 26:48 */     if (shortName == null) {
/* 27:49 */       return "class_" + this.classCounter++;
/* 28:   */     }
/* 29:52 */     int index = 0;
/* 30:53 */     while (Character.isDigit(shortName.charAt(index))) {
/* 31:54 */       index++;
/* 32:   */     }
/* 33:57 */     if ((index == 0) || (index == shortName.length())) {
/* 34:58 */       return "class_" + this.classCounter++;
/* 35:   */     }
/* 36:61 */     String name = shortName.substring(index);
/* 37:63 */     if (this.setNonStandardClassNames.contains(name)) {
/* 38:64 */       return "Inner" + name + "_" + this.classCounter++;
/* 39:   */     }
/* 40:67 */     this.setNonStandardClassNames.add(name);
/* 41:68 */     return "Inner" + name;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getNextFieldName(String className, String field, String descriptor)
/* 45:   */   {
/* 46:75 */     return "field_" + this.fieldCounter++;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public String getNextMethodName(String className, String method, String descriptor)
/* 50:   */   {
/* 51:80 */     return "method_" + this.methodCounter++;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public static String getSimpleClassName(String fullName)
/* 55:   */   {
/* 56:88 */     return fullName.substring(fullName.lastIndexOf('/') + 1);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public static String replaceSimpleClassName(String fullName, String newName)
/* 60:   */   {
/* 61:92 */     return fullName.substring(0, fullName.lastIndexOf('/') + 1) + newName;
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.renamer.ConverterHelper
 * JD-Core Version:    0.7.0.1
 */