/*  1:   */ package org.jetbrains.java.decompiler.modules.renamer;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import org.jetbrains.java.decompiler.main.extern.IIdentifierRenamer;
/*  5:   */ 
/*  6:   */ public class PoolInterceptor
/*  7:   */ {
/*  8:   */   private final IIdentifierRenamer helper;
/*  9:26 */   private final HashMap<String, String> mapOldToNewNames = new HashMap();
/* 10:28 */   private final HashMap<String, String> mapNewToOldNames = new HashMap();
/* 11:   */   
/* 12:   */   public PoolInterceptor(IIdentifierRenamer helper)
/* 13:   */   {
/* 14:31 */     this.helper = helper;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void addName(String oldName, String newName)
/* 18:   */   {
/* 19:35 */     this.mapOldToNewNames.put(oldName, newName);
/* 20:36 */     this.mapNewToOldNames.put(newName, oldName);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getName(String oldName)
/* 24:   */   {
/* 25:40 */     return (String)this.mapOldToNewNames.get(oldName);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getOldName(String newName)
/* 29:   */   {
/* 30:44 */     return (String)this.mapNewToOldNames.get(newName);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public IIdentifierRenamer getHelper()
/* 34:   */   {
/* 35:48 */     return this.helper;
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\PC\Downloads\fernflower.jar
 * Qualified Name:     org.jetbrains.java.decompiler.modules.renamer.PoolInterceptor
 * JD-Core Version:    0.7.0.1
 */